/* O que mudou em cada versão, em poucas palavras: aparece no sino por 10 dias depois
   que a atualização entra, para o Odilon saber que ela chegou e o que mudou. */

export const NOVIDADES = {
  '0.6.5': [
    'O tempo de cada serviço não marca mais o horário como ocupado: o aviso aparece só quando outro pet está marcado para chegar no mesmo horário, e nunca impede de agendar.',
    'Dá para tirar um serviço que o pet não vai fazer no meio do atendimento (botão "Não fez").',
    'Horário da loja: seg a sex 8h às 18h com almoço 12h às 14h, sábado 8h às 12h30. Confira em Perfil → Editar dados da loja.',
  ],
};

export const DIAS_NO_SINO = 10;
