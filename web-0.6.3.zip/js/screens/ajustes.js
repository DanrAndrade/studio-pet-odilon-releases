import { html, icon, fmtHora, mesmoDia, fmtData } from '../core/dom.js';
import { linhaToggle, secao } from '../core/ui.js';
import { servicos, lixeira } from '../data/repo.js';
import * as config from '../data/config.js';
import { gerarBackup, restaurarBackup, escolherArquivoBackup, fmtTamanho } from '../data/backup.js';
import { VERSAO } from '../versao.js';
import { verificarAtualizacao } from '../data/atualizacao.js';
import { instalarAtualizacao } from '../core/nativo.js';

/* AJUSTES — funcionamento, backup, catálogos e lixeira. */

const LISTAS = [
  { nome: 'Lista de raças', unidade: ['raça', 'raças'], icone: 'paw-print' },
  { nome: 'Alertas de saúde', unidade: ['alerta', 'alertas'], icone: 'heart-pulse' },
  { nome: 'Temperamentos', unidade: ['opção', 'opções'], icone: 'smile' },
  { nome: 'Formas de pagamento', unidade: ['forma', 'formas'], icone: 'credit-card' },
  { nome: 'Tipos de ocorrência', unidade: ['tipo', 'tipos'], icone: 'clipboard-list' },
];

const plural = (n, [um, varios]) => `${n} ${n === 1 ? um : varios}`;

// atualizacao: undefined = ainda não verificou · null = verificando · false = sem rede · {versao,url} = nova · {atual:true}
const ui = { atualizacao: undefined, progresso: '' };

function textoAtualizacao() {
  if (ui.progresso) return ui.progresso;
  if (ui.atualizacao === null) return 'Verificando…';
  if (ui.atualizacao === false) return 'Não foi possível verificar · o tablet está sem internet?';
  if (ui.atualizacao?.versao) return `Nova versão ${ui.atualizacao.versao} disponível`;
  if (ui.atualizacao?.atual) return 'Você já está na versão mais nova';
  return 'Precisa de internet só na hora de verificar';
}

export default {
  titulo: 'Ajustes',
  menu: 'ajustes',

  async carregar() {
    const listas = {};
    for (const l of LISTAS) listas[l.nome] = (await config.lista(l.nome)).length;
    return {
      chaves: await config.obter('chaves'),
      loja: await config.lojaComHorario(),
      backup: await config.obter('ultimoBackup'),
      totalServicos: (await servicos.listar()).length,
      listas,
      naLixeira: (await lixeira.listar()).length,
    };
  },

  render(vm) {
    const b = vm.backup;
    const ultimo = b ? `${mesmoDia(b.em, Date.now()) ? 'Hoje' : fmtData(b.em)}, ${fmtHora(b.em)} · ${fmtTamanho(b.bytes)}` : 'Nunca feito';
    const toggles = [
      { chave: 'conflito', rotulo: 'Avisar conflito de horário', dica: 'Apenas aviso, nunca bloqueia' },
      { chave: 'foraExpediente', rotulo: 'Permitir agendar fora do expediente', dica: vm.loja.expediente },
      { chave: 'whats', rotulo: 'Lembretes por WhatsApp', dica: '1 dia antes do atendimento' },
    ];

    return html`<div class="card r22 ajustes-card">
      <div class="ajustes-grade">
        <div>
          <div style="margin-bottom:6px">${secao('settings-2', 'Funcionamento')}</div>
          ${toggles.map((t) => linhaToggle({ rotulo: t.rotulo, dica: t.dica, ligado: !!vm.chaves[t.chave], acao: 'chave', attrs: { chave: t.chave } }))}

          <div style="margin:22px 0 6px">${secao('hard-drive-download', 'Backup e restauração')}</div>
          <div class="linha"><span class="l-rotulo">Último backup</span><span class="l-valor">${ultimo}</span></div>
          <div class="linha"><span class="l-rotulo">Destino</span><span class="l-valor">Drive, WhatsApp ou e-mail</span></div>
          ${!b || Date.now() - b.em > 7 * 24 * 3600 * 1000
            ? html`<div class="aviso-ambar r16" style="margin-top:10px;padding:11px 13px"><div class="aviso-texto" style="margin:0">Os dados ficam só neste aparelho. Faça backup toda semana para não perder nada se o tablet quebrar.</div></div>`
            : ''}
          <div class="botoes-linha" style="margin-top:14px">
            <button class="btn btn-roxo" style="flex:1;padding:12px" data-acao="backup">Fazer backup agora</button>
            <button class="btn btn-branco" style="flex:1;padding:12px;font-weight:600" data-acao="restaurar">Restaurar</button>
          </div>
        </div>

        <div>
          <div style="margin-bottom:6px">${secao('list', 'Cadastros e catálogos')}</div>
          <button class="linha-nav" data-acao="ir" data-rota="servicos">
            <span class="ln-esq">${icon('scissors', 16)}<span>Catálogo de serviços</span></span>
            <span class="ln-dir">${plural(vm.totalServicos, ['serviço', 'serviços'])}<span style="color:var(--texto-5);display:flex">${icon('chevron-right', 15)}</span></span>
          </button>
          ${LISTAS.map(
            (l) => html`<button class="linha-nav" data-acao="lista" data-nome="${l.nome}">
              <span class="ln-esq">${icon(l.icone, 16)}<span>${l.nome}</span></span>
              <span class="ln-dir">${plural(vm.listas[l.nome], l.unidade)}<span style="color:var(--texto-5);display:flex">${icon('chevron-right', 15)}</span></span>
            </button>`
          )}

          <div class="ajustes-lixeira">
            <div>
              <div class="titulo-card">Lixeira</div>
              <div class="mutado" style="font-size:12.5px;margin-top:3px">${plural(vm.naLixeira, ['registro', 'registros'])} · excluídos há até 30 dias</div>
            </div>
            <button class="btn btn-branco" style="font-weight:600;padding:10px 14px" data-acao="ir" data-rota="lixeira">${icon('trash-2', 14)}<span>Abrir</span></button>
          </div>

          <div class="ajustes-lixeira" style="margin-top:12px">
            <div>
              <div class="titulo-card">Versão do app · ${VERSAO}</div>
              <div class="mutado" style="font-size:12.5px;margin-top:3px">${textoAtualizacao()}</div>
            </div>
            ${ui.atualizacao?.versao
              ? html`<button class="btn btn-roxo" style="padding:10px 14px" data-acao="instalar" ${ui.progresso ? 'disabled' : ''}>${icon('download', 14)}<span>Baixar e instalar</span></button>`
              : html`<button class="btn btn-branco" style="font-weight:600;padding:10px 14px" data-acao="verificar" ${ui.atualizacao === null ? 'disabled' : ''}>${icon('rotate-ccw', 14)}<span>Verificar</span></button>`}
          </div>
        </div>
      </div>
    </div>`;
  },

  acoes: {
    chave: async ({ chave }, ctx) => {
      const ligar = !ctx.vm.chaves[chave];
      await config.atualizar('chaves', { [chave]: ligar });
      if (chave === 'whats') ctx.atualizarAvisos();
      ctx.recarregar();
    },
    lista: ({ nome }, ctx) => ctx.navegar('lista', { nome }),
    verificar: async (_, ctx) => {
      ui.atualizacao = null;
      ctx.redesenhar();
      const nova = await verificarAtualizacao();
      ui.atualizacao = nova === undefined ? false : nova || { atual: true };
      ctx.redesenhar();
    },
    instalar: (_, ctx) => {
      ui.progresso = 'Baixando…';
      ctx.redesenhar();
      instalarAtualizacao(ui.atualizacao.url, (estado, detalhe) => {
        if (estado === 'baixando') ui.progresso = `Baixando… ${detalhe}%`;
        else if (estado === 'permissao') {
          ui.progresso = '';
          ctx.toast('Permita "instalar apps desconhecidos" para o Studio Pet e toque de novo em Baixar e instalar', { erro: true });
        } else if (estado === 'erro') {
          ui.progresso = '';
          ctx.toast('Não deu para baixar: ' + detalhe, { erro: true });
        } else ui.progresso = 'Abrindo o instalador…';
        ctx.redesenhar();
      });
    },
    backup: async (_, ctx) => {
      const { bytes } = await gerarBackup();
      ctx.toast(`Backup gerado (${fmtTamanho(bytes)}) · escolha onde guardar`);
      ctx.recarregar();
    },
    restaurar: async (_, ctx) => {
      const texto = await escolherArquivoBackup();
      if (!texto) return;
      const ok = await ctx.confirmar({
        titulo: 'Restaurar este backup?',
        texto: 'Todos os dados atuais do app serão substituídos pelos do arquivo. Faça um backup antes se não tiver certeza.',
        botao: 'Substituir dados',
      });
      if (!ok) return;
      try {
        await restaurarBackup(texto);
      } catch (erro) {
        return ctx.toast(erro.message, { erro: true });
      }
      ctx.toast('Backup restaurado · reabrindo o app');
      setTimeout(() => window.location.replace(window.location.pathname), 900);
    },
  },
};
