/* Versão do app. O Gradle lê este arquivo (versionName) e a checagem de
   atualização compara com a versão publicada. Mude só aqui. */
export const VERSAO = '0.6.3';
