import { STORES, obter as obterRegistro, put } from './db.js';
import { ordemAlfabetica } from '../core/busca.js';
import { lerHorarios, montarExpediente, normalizar, textoDoExpediente } from '../logic/expediente.js';

/* Preferências e dados da loja, guardados como pares chave/valor. */

export const LISTAS_PADRAO = {
  'Tipos de ocorrência': ['Comportamento', 'Machucado / pele', 'Atraso do tutor', 'Equipamento', 'Outro'],
  'Categorias de serviço': ['Banho', 'Tosa', 'Estética', 'Adicional', 'Saúde'],
  'Lista de raças': ['SRD', 'Golden Retriever', 'Labrador', 'Poodle', 'Shih Tzu', 'Yorkshire', 'Lhasa Apso', 'Spitz Alemão', 'Persa', 'Siamês'],
  'Alertas de saúde': ['Pele sensível', 'Alergia a shampoo comum', 'Cardíaco', 'Idoso', 'Epilepsia', 'Pós-cirúrgico'],
  Temperamentos: ['Calmo', 'Agitado', 'Morde', 'Arranha', 'Estressa no secador', 'Medroso', 'Dócil', 'Territorial', 'Brincalhão'],
  'Formas de pagamento': ['Dinheiro', 'PIX', 'Débito', 'Crédito', 'Boleto', 'Fiado', 'Incluso no plano'],
};

const PADROES = {
  loja: {
    nome: 'Studio Pet Odilon Groomer',
    endereco: '',
    expediente: 'Seg a sáb · 08:00 às 18:00',
    cnpj: '',
    telefone: '',
    pix: '',
  },
  perfil: {
    nome: 'Odilon',
    funcao: 'Groomer responsável',
    email: '',
    telefone: '',
    foto: null,
    desde: null,
  },
  chaves: {
    conflito: true,
    foraExpediente: true,
    whats: true,
  },
  listas: LISTAS_PADRAO,
  ultimoBackup: null,
  // correções de dados que rodam uma única vez
  migracoes: {},
};

const cache = new Map();

// JSON em vez de structuredClone: roda também em WebViews antigos de tablet.
const clonar = (v) => (v === undefined || v === null ? null : JSON.parse(JSON.stringify(v)));

export async function obter(chave) {
  if (cache.has(chave)) return cache.get(chave);
  const registro = await obterRegistro(STORES.config, chave);
  const padrao = PADROES[chave];
  let valor = registro ? registro.valor : clonar(padrao);
  // novos campos adicionados em versões futuras entram com o valor padrão
  if (valor && padrao && typeof padrao === 'object' && !Array.isArray(padrao) && chave !== 'listas') {
    valor = { ...clonar(padrao), ...valor };
  }
  cache.set(chave, valor);
  return valor;
}

export async function salvar(chave, valor) {
  cache.set(chave, valor);
  await put(STORES.config, { chave, valor });
  return valor;
}

export async function atualizar(chave, parcial) {
  const atual = await obter(chave);
  return salvar(chave, { ...atual, ...parcial });
}

export const limparCache = () => cache.clear();

// listas que ficam na ordem em que foram cadastradas (as outras saem em ordem alfabética)
const ORDEM_DE_CADASTRO = new Set(['Formas de pagamento']);

export async function lista(nome) {
  const listas = await obter('listas');
  const itens = [...(listas[nome] || LISTAS_PADRAO[nome] || [])];
  return ORDEM_DE_CADASTRO.has(nome) ? itens : itens.sort(ordemAlfabetica);
}

export async function salvarLista(nome, itens) {
  const listas = await obter('listas');
  return salvar('listas', { ...listas, [nome]: itens });
}

/** Lê "Seg a sáb · 08:00 às 18:00" → { abre, fecha, dias } em minutos do dia. */
/** Expediente a partir do texto escrito à mão (lojas que ainda não usam o quadro de horários). */
export function lerExpediente(texto) {
  return montarExpediente(lerHorarios(texto));
}

/** Horário de cada dia: o quadro de Dados da loja; sem ele, o texto do expediente. */
export async function horariosDaLoja() {
  const loja = await obter('loja');
  return normalizar(loja.horarios) || lerHorarios(loja.expediente);
}

/** Dados da loja com o texto do expediente montado do horário de cada dia. */
export async function lojaComHorario() {
  return { ...(await obter('loja')), expediente: textoDoExpediente(await horariosDaLoja()) };
}

export async function expediente() {
  return montarExpediente(await horariosDaLoja());
}
