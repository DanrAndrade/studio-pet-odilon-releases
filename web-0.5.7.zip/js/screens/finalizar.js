import { html, icon, fmtBRL, fmtDur, fmtHora, fmtDataCurta, paraCentavos, centavosParaCampo, comHora, addDias, valorData, deCampos, mesmoDia, MESES, $ } from '../core/dom.js';
import { chip, linhaToggle, vazio, voltar } from '../core/ui.js';
import { agendamentos, pets, tutores, servicos, tempos, montarItens, planos, mensalidadesDoPlano } from '../data/repo.js';
import { situacaoPagamento } from '../logic/pagamento.js';
import * as config from '../data/config.js';
import { estatisticasPet, sugestaoRetorno } from '../logic/metricas.js';
import { cronSessao, cronSoma, segundosItem } from './_cronometro.js';

/* FINALIZAR ATENDIMENTO — congela os tempos, cobra e (opcional) agenda o retorno. */

const ui = {};

// formas que contam como "já recebi" (fiado e incluso no plano não são pagamento recebido)
const SEM_RECEBIMENTO = ['Fiado', 'Incluso no plano', 'A definir'];

/*
 * Por padrão o atendimento fecha SEM pagamento (muitos clientes deixam o pet e
 * pagam depois): ele entra em "A receber" e é marcado como pago no Faturamento
 * ou no Histórico, com a forma e a data do pagamento. Se o cliente já pagou,
 * liga "Já recebi o pagamento" e escolhe a forma. Reaberto: volta como estava.
 */
function reiniciar(ag, itens) {
  const anterior = ag.pagamentoAnterior;
  const prevista = ag.formaPagamento && !SEM_RECEBIMENTO.includes(ag.formaPagamento) ? ag.formaPagamento : null;
  Object.assign(ui, {
    id: ag.id,
    desconto: centavosParaCampo(ag.descontoCentavos),
    recebido: !!anterior,
    forma: anterior?.formaPagamento && !SEM_RECEBIMENTO.includes(anterior.formaPagamento) ? anterior.formaPagamento : prevista,
    // dia do pagamento (reaberto: o de antes); hoje por padrão
    dataPagamento: valorData(anterior?.pagoEm || Date.now()),
    // mensalidade do plano cobrada neste banho (1º banho do mês)
    recebeuMensalidade: false,
    formaMensalidade: null,
    // reaberto: o "não usar na média" marcado antes continua marcado
    semMedia: itens.some((i) => i.usarNaMedia === false),
    retorno: false,
    recomendacao: ag.recomendacao || '',
    // preço final de cada serviço digitado na hora de cobrar ({ itemId: texto do campo })
    precos: {},
  });
}

/** Preço final do serviço: o digitado agora ou o que veio do agendamento. */
const precoDe = (item) => (ui.precos[item.id] !== undefined ? paraCentavos(ui.precos[item.id]) : item.precoCentavos || 0);
const subtotalDe = (vm) => vm.itens.reduce((s, i) => s + precoDe(i), 0);
const totalCom = (vm) => Math.max(0, subtotalDe(vm) - paraCentavos(ui.desconto) + (vm.ag.acrescimoCentavos || 0));
const formasPara = (vm) => vm.todasFormas.filter((f) => !SEM_RECEBIMENTO.includes(f));

export default {
  titulo: 'Finalizar atendimento',
  menu: 'atendimento-dia',

  async carregar({ id }) {
    const ag = await agendamentos.obter(id);
    if (!ag) return { ag: null };

    const pet = await pets.obter(ag.petId);
    const tutor = pet?.tutorId ? await tutores.obter(pet.tutorId) : null;
    const itens = await agendamentos.itens(id);

    const historico = await agendamentos.doPet(ag.petId);
    const stats = estatisticasPet(historico, await agendamentos.itensDe(historico));

    const medias = new Map();
    for (const item of itens) {
      const servico = item.servicoId ? await servicos.obter(item.servicoId) : null;
      medias.set(item.id, servico && pet ? (await tempos.estimar(pet, servico)).minutos : Math.round((item.mediaSeg || 0) / 60));
    }

    if (ui.id !== id) reiniciar(ag, itens);
    const todasFormas = await config.lista('Formas de pagamento');
    // este é o banho que cobra a mensalidade do mês e ela ainda não foi paga?
    let mensalidade = null;
    if (ag.planoId) {
      const plano = await planos.obter(ag.planoId);
      if (plano) mensalidade = (await mensalidadesDoPlano(plano)).find((m) => m.ts === ag.inicio && !m.pagamento) || null;
    }
    return { ag, pet, tutor, itens, stats, medias, todasFormas, mensalidade };
  },

  render(vm) {
    if (!vm.ag || !vm.pet) return html`${voltar('Voltar')}<div class="card pad-18">${vazio({ icone: 'search', titulo: 'Atendimento não encontrado' })}</div>`;
    if (vm.ag.status === 'concluido') {
      return html`${voltar('Voltar')}<div class="card pad-18">${vazio({
        icone: 'circle-check-big',
        titulo: 'Este atendimento já foi concluído',
        texto: `Valor: ${fmtBRL(vm.ag.valorCentavos)} · ${situacaoPagamento(vm.ag).texto}. Para mudar o pagamento, use o Histórico.`,
        acao: html`<button class="btn btn-branco" data-acao="ficha">Ver ficha do pet</button>`,
      })}</div>`;
    }

    const { ag, pet, itens, medias, stats } = vm;
    const subtotal = subtotalDe(vm);
    const formas = formasPara(vm);
    const sug = sugestaoRetorno(stats, ag.inicio);
    const total = totalCom(vm);
    const incluso = !total && ag.origem === 'plano';
    const desconto = paraCentavos(ui.desconto);

    return html`
      ${voltar('Voltar ao atendimento', 'voltar-atendimento')}
      <div class="titulo-pagina">Finalizar atendimento · ${pet.nome}</div>
      <div class="sub-pagina">Tempo de atendimento: ${cronSessao(ag)} · em serviço ${cronSoma(itens)}</div>

      <div class="at-grade">
        <div class="at-col">
          <div class="card fin-tabela">
            <div class="cab-tabela fin-colunas"><div>Serviço realizado</div><div>Duração real</div><div>Média anterior</div><div style="text-align:right">Preço final</div></div>
            ${itens.map((item) => {
              const realMin = Math.round(segundosItem(item) / 60);
              const mediaMin = medias.get(item.id) || 0;
              const delta = mediaMin ? realMin - mediaMin : 0;
              const cor = delta > 0 ? 'var(--rosa)' : delta < 0 ? 'var(--verde-escuro)' : 'var(--texto-2)';
              return html`<div class="linha-tabela fin-colunas">
                <div class="fin-nome"><span class="fin-check">${icon('check', 12)}</span><span>${item.nome}</span></div>
                <div class="fin-real" style="color:${cor}">${fmtDur(realMin)} ${delta ? html`<small>(${delta > 0 ? '+' : ''}${delta}min)</small>` : ''}</div>
                <div class="mutado">${mediaMin ? fmtDur(mediaMin) : '—'}</div>
                <div class="fin-preco">
                  <input class="campo-inline" data-campo="preco-${item.id}" value="${centavosParaCampo(precoDe(item))}" placeholder="R$ 0" inputmode="decimal" data-formato="moeda" aria-label="Preço final de ${item.nome}">
                  ${precoDe(item) !== (item.precoTabelaCentavos ?? item.precoCentavos ?? 0)
                    ? html`<small>tabela ${fmtBRL(item.precoTabelaCentavos ?? item.precoCentavos ?? 0)}</small>`
                    : ''}
                </div>
              </div>`;
            })}
          </div>

          <div class="card pad-18">
            <div class="titulo-card" style="margin-bottom:10px">Observações e recomendação</div>
            <div style="display:flex;flex-direction:column;gap:8px">
              ${(ag.observacoes || []).length
                ? ag.observacoes.map((o) => html`<div class="obs-item">${o}</div>`)
                : html`<div class="obs-item">Sem observações registradas neste atendimento.</div>`}
            </div>
            <textarea class="caixa-texto" style="margin-top:10px" data-campo="recomendacao" rows="2" placeholder="Recomendação para a próxima visita…">${ui.recomendacao}</textarea>
          </div>
        </div>

        <div class="at-col">
          <div class="card pad-18">
            <div class="titulo-card" style="margin-bottom:10px">Pagamento</div>
            <div class="linha"><span class="l-rotulo">Subtotal</span><span class="l-valor" id="fin-subtotal" style="color:var(--texto-2)">${fmtBRL(subtotal)}</span></div>
            <div class="mutado" style="font-size:11.5px;margin:-2px 0 4px">Toque no preço de um serviço para mudar só neste atendimento.</div>
            <div class="linha">
              <span class="l-rotulo">Desconto</span>
              <input class="campo-inline" data-campo="desconto" value="${ui.desconto}" placeholder="—" inputmode="decimal" data-formato="moeda" style="color:${desconto ? 'var(--rosa)' : 'var(--texto-3)'}">
            </div>
            ${ag.acrescimoCentavos ? html`<div class="linha"><span class="l-rotulo">Acréscimo</span><span class="l-valor" style="color:var(--texto-2)">+ ${fmtBRL(ag.acrescimoCentavos)}</span></div>` : ''}
            <div class="linha"><span class="l-rotulo">Total</span><span class="l-valor" id="fin-total" style="font-weight:700">${fmtBRL(total)}</span></div>
            ${incluso
              ? html`<div class="mutado" style="font-size:12.5px;margin-top:10px">Banho incluso no plano: nada a cobrar pelo banho.</div>`
              : !total
                ? html`<div class="mutado" style="font-size:12.5px;margin-top:10px">Sem cobrança: nada a pagar neste atendimento.</div>`
                : html`<div style="margin-top:6px">${linhaToggle({ rotulo: 'Já recebi o pagamento', dica: ui.recebido ? 'Escolha como e em que dia foi pago' : 'Desligado: fica como não pago (em "A receber" no Faturamento) até você marcar que pagou', ligado: ui.recebido, acao: 'sw', attrs: { chave: 'recebido' }, compacta: true })}</div>
                  ${ui.recebido
                    ? html`<div class="chips" style="margin-top:8px">${formas.map((f) => chip(f, ui.forma === f, 'forma', { forma: f }, { suave: true, cls: 'mini' }))}</div>
                      <div class="linha" style="margin-top:6px"><span class="l-rotulo">Dia do pagamento</span><input class="campo-data" type="date" data-campo="dataPagamento" value="${ui.dataPagamento}" max="${valorData(Date.now())}"></div>`
                    : ''}`}
          </div>
          ${vm.mensalidade
            ? html`<div class="card pad-18">
                <div class="titulo-card" style="margin-bottom:4px">Mensalidade do plano</div>
                <div class="mutado" style="font-size:12.5px;margin-bottom:6px">Este é o 1º banho de ${MESES[new Date(vm.mensalidade.ts).getMonth()]}: a mensalidade ${vm.mensalidade.k}/${vm.mensalidade.total} de ${fmtBRL(vm.mensalidade.valorCentavos)} é cobrada hoje e ainda não foi paga.</div>
                ${linhaToggle({ rotulo: 'Já recebi a mensalidade', dica: ui.recebeuMensalidade ? 'Escolha como foi paga' : 'Desligado: continua em aberto no Faturamento', ligado: ui.recebeuMensalidade, acao: 'sw', attrs: { chave: 'recebeuMensalidade' }, compacta: true })}
                ${ui.recebeuMensalidade ? html`<div class="chips" style="margin-top:8px">${formas.map((f) => chip(f, ui.formaMensalidade === f, 'forma-mensalidade', { forma: f }, { suave: true, cls: 'mini' }))}</div>` : ''}
              </div>`
            : ''}

          <div class="card pad-18" style="padding-top:7px">
            ${linhaToggle({ rotulo: 'Não usar este tempo na média', dica: 'Quando algo fora do normal atrasou o serviço', ligado: ui.semMedia, acao: 'sw', attrs: { chave: 'semMedia' }, compacta: true })}
            ${linhaToggle({ rotulo: 'Já agendar retorno', dica: `Sugestão: ${sug.dias} dias · ${fmtDataCurta(sug.ts)}`, ligado: ui.retorno, acao: 'sw', attrs: { chave: 'retorno' }, compacta: true })}
          </div>

          <div class="botoes">
            <button class="btn btn-roxo bloco" data-acao="concluir">Concluir atendimento</button>
            <button class="btn btn-branco bloco" data-acao="concluir-retorno">Concluir e agendar retorno</button>
          </div>
        </div>
      </div>`;
  },

  aoDigitar(campo, valor, ctx, el) {
    if (campo.startsWith('preco-')) {
      ui.precos[campo.slice(6)] = valor;
      const sub = $('#fin-subtotal');
      if (sub) sub.textContent = fmtBRL(subtotalDe(ctx.vm));
      const total = $('#fin-total');
      if (total) total.textContent = fmtBRL(totalCom(ctx.vm));
      return;
    }
    ui[campo] = valor;
    if (campo === 'desconto') {
      const total = $('#fin-total');
      if (total) total.textContent = fmtBRL(totalCom(ctx.vm));
      el.style.color = paraCentavos(valor) ? 'var(--rosa)' : 'var(--texto-3)';
    }
  },

  // ao sair do campo de preço: banho do plano com preço passa a pedir pagamento (e vice-versa)
  aoAlterar(campo, _, ctx) {
    if (!campo.startsWith('preco-')) return;
    ctx.redesenhar();
  },

  acoes: {
    forma: ({ forma }, ctx) => {
      ui.forma = ui.forma === forma ? null : forma;
      ctx.redesenhar();
    },
    'forma-mensalidade': ({ forma }, ctx) => {
      ui.formaMensalidade = ui.formaMensalidade === forma ? null : forma;
      ctx.redesenhar();
    },
    sw: ({ chave }, ctx) => {
      ui[chave] = !ui[chave];
      ctx.redesenhar();
    },
    'voltar-atendimento': (_, ctx) => ctx.navegar('atendimento', { id: ctx.vm.ag.id }, { substituir: true }),
    ficha: (_, ctx) => ctx.navegar('ficha-pet', { id: ctx.vm.pet.id }),
    concluir: (_, ctx) => concluir(ctx, false),
    'concluir-retorno': (_, ctx) => concluir(ctx, true),
  },
};

async function concluir(ctx, abrirRetorno) {
  const { ag, pet, itens, stats } = ctx.vm;
  const total = totalCom(ctx.vm);
  const recebido = total > 0 && ui.recebido;
  if (recebido && (!ui.forma || SEM_RECEBIMENTO.includes(ui.forma))) {
    return ctx.toast('Escolha como foi pago ou desligue "Já recebi o pagamento"', { erro: true });
  }
  if (ctx.vm.mensalidade && ui.recebeuMensalidade && !ui.formaMensalidade) {
    return ctx.toast('Escolha como a mensalidade foi paga ou desligue "Já recebi a mensalidade"', { erro: true });
  }
  // dia do pagamento: hoje = agora; reaberto no mesmo dia de antes = mantém; outro dia = meio-dia
  const agoraTs = Date.now();
  const diaEscolhido = deCampos(ui.dataPagamento, '12:00');
  const anterior = ag.pagamentoAnterior?.pagoEm;
  let pagoEm = diaEscolhido;
  if (!diaEscolhido) pagoEm = agoraTs;
  else if (anterior && mesmoDia(anterior, diaEscolhido)) pagoEm = anterior;
  else if (mesmoDia(diaEscolhido, agoraTs) || diaEscolhido > agoraTs) pagoEm = agoraTs;
  await agendamentos.finalizar(ag.id, {
    descontoCentavos: paraCentavos(ui.desconto),
    formaPagamento: recebido ? ui.forma : !total && ag.origem === 'plano' ? 'Incluso no plano' : null,
    pagamentoPendente: total > 0 && !recebido,
    pagoEm: recebido ? pagoEm : null,
    usarNaMedia: !ui.semMedia,
    recomendacao: ui.recomendacao.trim(),
    // só os preços que ele mexeu; os outros ficam como vieram do agendamento
    precos: Object.fromEntries(itens.filter((i) => ui.precos[i.id] !== undefined).map((i) => [i.id, precoDe(i)])),
  });
  if (ctx.vm.mensalidade && ui.recebeuMensalidade) {
    await planos.registrarPagamento(ag.planoId, ctx.vm.mensalidade.mes, ui.formaMensalidade, agoraTs);
  }
  ui.id = null;

  const sug = sugestaoRetorno(stats, ag.inicio);
  const exp = await config.expediente();
  let inicioRetorno = comHora(sug.ts, fmtHora(ag.inicio));
  // o retorno cai num dia em que a loja abre
  for (let i = 0; i < 7 && !exp.dias.includes(new Date(inicioRetorno).getDay()); i++) inicioRetorno = addDias(inicioRetorno, 1);
  const idsServicos = itens.map((i) => i.servicoId).filter(Boolean);

  if (abrirRetorno) {
    ctx.toast('Atendimento concluído');
    return ctx.navegar('novo-agendamento', { petId: pet.id, inicio: inicioRetorno, servicos: idsServicos.join(',') }, { substituir: true });
  }

  if (ui.retorno) {
    const lista = (await Promise.all(idsServicos.map((id) => servicos.obter(id)))).filter((s) => s && !s.excluidoEm);
    const retorno = await agendamentos.gravarComItens(
      { petId: pet.id, tutorId: pet.tutorId, inicio: inicioRetorno, status: 'agendado', origem: 'avulso' },
      await montarItens(pet, lista)
    );
    // guardado no atendimento: se ele for reaberto ou desfeito, o retorno sai junto
    const finalizado = await agendamentos.obter(ag.id);
    await agendamentos.salvar({ ...finalizado, retornoId: retorno.id });
    ctx.toast(`Atendimento concluído · retorno em ${fmtDataCurta(inicioRetorno)} às ${fmtHora(inicioRetorno)}`);
  } else {
    ctx.toast('Atendimento concluído');
  }

  const aindaNaLoja = await agendamentos.emAtendimento();
  ctx.navegar(aindaNaLoja.length ? 'atendimento-dia' : 'agenda', {}, { substituir: true });
}
