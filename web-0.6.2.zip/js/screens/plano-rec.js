import {
  html, icon, fmtDur, fmtData, fmtDataCurta, fmtBRL, MESES, paraCentavos, paraMinutos, centavosParaCampo, digitos,
  valorData, deCampos, normalizarHora, inicioDoDia, DIAS_CURTOS,
} from '../core/dom.js';
import { chip, campo, voltar, selo, avPet, STATUS } from '../core/ui.js';
import { pets, tutores, planos, servicos, tempos, agendamentos, mensalidadesDoPlano } from '../data/repo.js';
import { escolherFormaRecebimento, descreverRecebimento } from '../modais/recebimento.js';
import { escolher } from '../core/modais.js';
import * as config from '../data/config.js';
import { conflitos, foraDoExpediente } from '../logic/agenda.js';
import {
  TIPOS, VIGENCIAS, EDITAVEIS, montarBanhos, chaveBanho, rotuloBanho, limitarMeses, tipoDoPlano,
  banhosPorMes, addMeses, descricaoVigencia, horaDe,
} from '../logic/planos.js';

/* PLANO (PACOTE) — a folha do contrato: Mês 1..N, com o 1º, 2º, 3º e 4º banho
   (mensal) ou o 1º e 2º banho (quinzenal). A primeira data preenche as outras;
   cada banho pode ter a data e a hora trocadas à mão. Salvar põe tudo na agenda. */

const ui = { chave: null, f: null, edicoes: new Map() };

function formDe(plano, petId) {
  const tipo = plano ? tipoDoPlano(plano) : 'Mensal';
  return {
    nome: plano?.nome || '',
    valor: centavosParaCampo(plano?.valorCentavos),
    petId: plano?.petId || petId || null,
    servicos: [...(plano?.servicos || [])],
    tipo,
    meses: String(plano?.meses || 6),
    hora: plano?.hora || '10:00',
    duracao: plano?.duracaoMin ? fmtDur(plano.duracaoMin) : '',
    inicio: valorData(plano?.inicio || Date.now()),
  };
}

/** Configuração da folha a partir do formulário. */
function cfgDoForm(f) {
  return {
    tipo: f.tipo,
    meses: limitarMeses(f.meses),
    // intervalo fixo pelo tipo: mensal a cada 7 dias, quinzenal a cada 14 (mesmo dia da semana)
    intervalo: TIPOS[f.tipo].intervalo,
    hora: normalizarHora(f.hora) || '10:00',
    inicio: deCampos(f.inicio, '00:00') || inicioDoDia(Date.now()),
  };
}

/** Plano no formato do domínio (sem id). */
function planoDoForm(f, pet) {
  const cfg = cfgDoForm(f);
  return {
    nome: f.nome.trim(),
    tutorId: pet?.tutorId || null,
    petId: f.petId,
    servicos: f.servicos,
    tipo: cfg.tipo,
    banhosPorMes: TIPOS[cfg.tipo].banhosPorMes,
    intervalo: cfg.intervalo,
    meses: cfg.meses,
    hora: cfg.hora,
    inicio: cfg.inicio,
    duracaoMin: paraMinutos(f.duracao),
    valorCentavos: paraCentavos(f.valor),
    // a vigência fica gravada: é ela que conta as mensalidades
    fim: addMeses(cfg.inicio, cfg.meses),
  };
}

/**
 * Banhos já na agenda, por "mês-banho". Visitas antigas sem numeração são
 * numeradas pela ordem. Uma data diferente da que o padrão daria (trocada
 * aqui ou remarcada na agenda) conta como trocada à mão e é preservada.
 */
function banhosSalvos(plano, visitas) {
  const fixas = new Map();
  if (!plano) return fixas;
  const porMes = banhosPorMes(plano);
  visitas.forEach((ag, i) => {
    const mes = ag.planoMes || Math.floor(i / porMes) + 1;
    const banho = ag.planoBanho || (i % porMes) + 1;
    fixas.set(chaveBanho(mes, banho), {
      agId: ag.id,
      status: ag.status,
      ts: ag.inicio,
      travado: !EDITAVEIS.includes(ag.status),
      ancora: !!ag.planoAncora,
    });
  });
  // compara com o padrão do plano como estava salvo para achar as datas trocadas
  const original = {
    tipo: tipoDoPlano(plano),
    meses: plano.meses || 6,
    intervalo: plano.intervalo,
    hora: plano.hora,
    inicio: plano.inicio,
  };
  const soAncoras = new Map([...fixas].map(([k, v]) => [k, { ...v, manual: false }]));
  for (const l of montarBanhos(original, soAncoras)) {
    const v = fixas.get(l.chave);
    if (v && !v.travado) v.manual = v.ts !== l.padrao;
  }
  return fixas;
}

/**
 * Planos da versão anterior (Semanal, Quinzenal de 14 dias, mensais) não têm
 * a folha: o 1º banho é a primeira visita e o intervalo é o que eles usavam.
 */
function comoPacote(plano, visitas) {
  if (plano.banhosPorMes || !visitas.length) return plano;
  return {
    ...plano,
    tipo: tipoDoPlano(plano),
    inicio: inicioDoDia(visitas[0].inicio),
    intervalo: plano.tipo === 'Semanal' ? 7 : plano.tipo === 'Quinzenal' ? 14 : 30,
  };
}

function folha(vm) {
  const fixas = new Map(vm.salvos);
  for (const [k, e] of ui.edicoes) fixas.set(k, { ...(fixas.get(k) || {}), ...e });
  return montarBanhos(cfgDoForm(ui.f), fixas);
}

/** Aviso de uma linha: conflito, loja fechada ou data passada. */
function avisoDaLinha(l, vm, duracao) {
  if (l.travado) return null;
  if (!l.agId && l.ts < inicioDoDia(Date.now())) return { tom: 'neutro', texto: 'Data passada: não entra na agenda' };
  if (!vm.exp.dias.includes(new Date(l.ts).getDay())) return { tom: 'ambar', texto: 'A loja não abre neste dia' };
  const choque = conflitos(l.ts, duracao, vm.outros, l.agId);
  if (choque.length) {
    const outro = choque[0];
    return { tom: 'ambar', texto: `Horário ocupado: ${vm.nomesPets.get(outro.petId) || 'outro pet'} às ${horaDe(outro.inicio)}` };
  }
  if (foraDoExpediente(l.ts, duracao, vm.exp)) return { tom: 'ambar', texto: 'Fora do horário da loja' };
  return null;
}

const ROTULO_TRAVADO = { concluido: 'Realizado', em_atendimento: 'Em atendimento', cancelado: 'Cancelado', nao_compareceu: 'Faltou' };

export default {
  titulo: (vm) => (vm?.plano ? 'Editar plano' : 'Novo plano'),
  menu: 'planos',

  async carregar({ id, petId }) {
    const salvo = id ? await planos.obter(id) : null;
    const visitas = salvo ? await agendamentos.doPlano(salvo.id) : [];
    const plano = salvo ? comoPacote(salvo, visitas) : null;
    const chave = `${id || ''}|${petId || ''}`;
    if (ui.chave !== chave) {
      ui.chave = chave;
      ui.f = formDe(plano, petId);
      ui.edicoes = new Map();
    }
    const nomesTutores = new Map((await tutores.listar()).map((t) => [t.id, t.nome]));
    const todosPets = await pets.listar();
    const listaPets = todosPets.map((p) => ({ pet: p, tutor: nomesTutores.get(p.tutorId) || '' }));
    const catalogo = (await servicos.listar()).filter((s) => s.ativo !== false || ui.f.servicos.includes(s.id));
    // agenda dos outros pets no período do plano, para avisar de horário ocupado
    const de = inicioDoDia(Math.min(deCampos(ui.f.inicio, '00:00') || Date.now(), Date.now()));
    const outros = (await agendamentos.porPeriodo(de, addMeses(de, limitarMeses(ui.f.meses) + 2))).filter((a) => !plano || a.planoId !== plano.id);
    return {
      plano,
      encerrado: !!plano?.encerradoEm,
      listaPets,
      catalogo,
      salvos: banhosSalvos(plano, visitas),
      mensalidades: salvo ? await mensalidadesDoPlano(salvo) : [],
      outros,
      exp: await config.expediente(),
      nomesPets: new Map(todosPets.map((p) => [p.id, p.nome])),
    };
  },

  render(vm) {
    const f = ui.f;
    const escolhido = vm.listaPets.find((l) => l.pet.id === f.petId);
    const dados = planoDoForm(f, escolhido?.pet);
    // plano encerrado mostra só os banhos que chegaram a existir
    const linhas = vm.encerrado ? folha(vm).filter((l) => l.agId) : folha(vm);
    const duracao = dados.duracaoMin || 60;
    const avisos = linhas.filter((l) => avisoDaLinha(l, vm, duracao)?.tom === 'ambar').length;
    const meses = [];
    for (const l of linhas) {
      if (!meses.length || meses[meses.length - 1][0].mes !== l.mes) meses.push([]);
      meses[meses.length - 1].push(l);
    }
    // banho que cobra a mensalidade de cada mês (com o valor que está no formulário)
    const cobrancas = cobrancasDaFolha(linhas, { ...(vm.plano || {}), valorCentavos: dados.valorCentavos }, limitarMeses(f.meses));

    return html`
      ${voltar('Voltar para planos', 'cancelar')}
      <div class="editar-topo">
        <button class="btn btn-branco" style="font-size:13.5px;padding:11px 18px" data-acao="cancelar">Cancelar</button>
        ${vm.encerrado
          ? ''
          : html`<button class="btn btn-roxo" style="font-size:13.5px;padding:11px 20px" data-acao="salvar">${icon('calendar-check', 15)}<span>${vm.plano ? 'Salvar plano' : 'Criar plano e agendar banhos'}</span></button>`}
      </div>

      ${vm.encerrado
        ? html`<div class="aviso-lavanda" style="margin-bottom:14px"><div class="aviso-titulo">${icon('info', 15)}<span>Plano encerrado em ${fmtData(vm.plano.encerradoEm)}</span></div><div class="aviso-texto">As mensalidades pararam nessa data e os banhos que faltavam saíram da agenda. Para voltar a atender com plano, crie um novo.</div></div>`
        : ''}

      <div class="grade-2 pac-config">
        <div class="card r22 pad-18">
          <div class="titulo-card g" style="margin-bottom:14px">Pacote</div>
          <div class="rotulo-campo" style="margin-bottom:7px">Tipo de plano</div>
          <div class="pac-tipos">
            ${Object.entries(TIPOS).map(
              ([tipo, t]) => html`<button class="pac-tipo${f.tipo === tipo ? ' on' : ''}" data-acao="tipo" data-tipo="${tipo}">
                <span class="pac-tipo-nome">${tipo}</span><span class="pac-tipo-sub">${t.descricao}</span>
              </button>`
            )}
          </div>
          <div class="rotulo-campo" style="margin:14px 0 7px">Duração do contrato</div>
          <div class="chips">
            ${VIGENCIAS.map((m) => chip(m === 1 ? '1 mês' : `${m} meses`, Number(f.meses) === m, 'meses', { meses: m }, { cls: 'rec-semana' }))}
          </div>
          <div class="mt-16">
            ${campo({ rotulo: 'Valor por mês', nome: 'valor', valor: f.valor, placeholder: 'R$ 320', formato: 'moeda' })}
            <div class="mutado" style="font-size:12.5px;margin-top:-4px">A mensalidade é cobrada no 1º banho de cada mês.</div>
          </div>
          ${campo({ rotulo: 'Nome do plano (opcional)', nome: 'nome', valor: f.nome, placeholder: `Ex.: ${f.tipo} · ${escolhido?.pet.nome || 'Thor'}` })}
        </div>

        <div class="card r22 pad-18">
          <div class="titulo-card g" style="margin-bottom:14px">Pet e banhos</div>
          <div class="pac-pet-fixo">
            ${escolhido ? avPet(escolhido.pet, 34, { borda: 0, sombra: false }) : icon('paw-print', 15)}
            <span style="flex:1;min-width:0"><strong>${escolhido?.pet.nome || 'Nenhum pet escolhido'}</strong>${escolhido?.tutor ? ' · ' + escolhido.tutor : ''}</span>
            ${vm.plano ? '' : html`<button class="link-acao" data-acao="trocar-pet">${escolhido ? 'Trocar' : 'Escolher pet'}</button>`}
          </div>
          <div class="rotulo-campo" style="margin:14px 0 7px">Serviços de cada banho</div>
          <div class="chips">${vm.catalogo.map((s) => chip(s.nome, f.servicos.includes(s.id), 'servico', { id: s.id }))}</div>
          <div class="grade-2 mt-16 pac-datas">
            <div><div class="rotulo-campo">Data do 1º banho</div><input class="campo-data" type="date" data-campo="inicio" value="${f.inicio}"></div>
            <div><div class="rotulo-campo">Horário</div><input class="campo-data" type="time" data-campo="hora" value="${f.hora}" step="300"></div>
            ${campo({ rotulo: 'Duração de cada banho', nome: 'duracao', valor: f.duracao, placeholder: 'pelo histórico', formato: 'duracao' })}
          </div>
          <div class="mutado" style="font-size:12px;margin-top:10px">O app preenche um banho a cada ${TIPOS[f.tipo].intervalo} dias a partir do 1º. Para um banho em outro dia, troque a data dele na folha abaixo.</div>
        </div>
      </div>

      <div class="pac-cab-folha">
        <div>
          <div class="titulo-card g">Banhos do pacote</div>
          <div class="mutado" style="font-size:12.5px;margin-top:2px">Toque na data ou na hora de um banho para trocar. Depois escolha se muda só ele ou se os seguintes andam junto.</div>
        </div>
        <div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap">
          ${avisos ? selo(`${avisos} ${avisos === 1 ? 'aviso' : 'avisos'}`, 'ambar') : ''}
          ${vm.encerrado ? '' : html`<button class="btn btn-branco" style="padding:9px 14px;font-size:13px" data-acao="refazer-datas">${icon('rotate-ccw', 14)}<span>Refazer as datas a partir do 1º banho</span></button>`}
        </div>
      </div>

      <div class="pac-meses-grade">
        ${meses.map(
          (doMes) => html`<div class="card r22 pac-mes">
            <div class="pac-mes-cab">
              <span>Mês ${doMes[0].mes}</span>
              <span class="mutado">${fmtDataCurta(doMes[0].ts)} a ${fmtDataCurta(doMes[doMes.length - 1].ts)}</span>
            </div>
            ${doMes.map((l) => linhaBanho(l, avisoDaLinha(l, vm, duracao), vm.encerrado, cobrancas.get(l.chave)))}
          </div>`
        )}
      </div>

      ${vm.plano && vm.mensalidades.length
        ? html`<div class="card r22 pad-18" style="margin-top:14px">
            <div class="titulo-card g" style="margin-bottom:4px">Mensalidades</div>
            <div class="mutado" style="font-size:12.5px;margin-bottom:6px">Cobradas no 1º banho do plano em cada mês do calendário. Se o cliente pagar meses adiantados, toque em "Receber adiantado" em cada um: o valor entra no faturamento no dia do pagamento.</div>
            ${vm.mensalidades.map(
              (m) => html`<div class="linha">
                <span class="l-rotulo">${MESES[new Date(m.ts).getMonth()].replace(/^./, (c) => c.toUpperCase())} · ${fmtBRL(m.valorCentavos)} · banho de ${fmtDataCurta(m.ts)}</span>
                <span style="display:flex;align-items:center;gap:8px">
                  ${m.pagamento
                    ? html`${selo(`Paga${m.pagamento.formaPagamento ? ' · ' + m.pagamento.formaPagamento : ''}`, 'verde')}<button class="link-acao" data-acao="mens-desfazer" data-mes="${m.mes}">Marcar não paga</button>`
                    : html`${selo(m.ts <= Date.now() ? 'Em aberto' : 'A cobrar', m.ts <= Date.now() ? 'rosa' : 'neutro')}<button class="link-acao" data-acao="mens-receber" data-mes="${m.mes}">${m.ts > Date.now() + 7 * 864e5 ? 'Receber adiantado' : 'Receber'}</button>`}
                </span>
              </div>`
            )}
          </div>`
        : ''}

      ${vm.plano
        ? html`<div class="pac-rodape">
            ${vm.encerrado ? '' : html`<button class="btn btn-branco" data-acao="encerrar">${icon('circle-stop', 15)}<span>Encerrar plano</span></button>`}
            <button class="btn btn-rosa-contorno" data-acao="excluir">${icon('trash-2', 15)}<span>Excluir plano</span></button>
          </div>`
        : ''}`;
  },

  aoDigitar(nome, valor, ctx) {
    if (!(nome in ui.f)) return;
    ui.f[nome] = valor;
  },

  // seletores nativos de data e hora disparam "change"
  async aoAlterar(nome, valor, ctx) {
    const m = /^(data|hora)-(\d+-\d+)$/.exec(nome);
    if (m) {
      const [, campoNome, chave] = m;
      const atual = folha(ctx.vm).find((l) => l.chave === chave);
      // data apagada ou inválida: o campo volta a mostrar a data que vale
      const desfazer = () => {
        const el = document.querySelector(`#tela [data-campo="${nome}"]`);
        if (el && atual) el.value = campoNome === 'data' ? valorData(atual.ts) : horaDe(atual.ts);
        return ctx.redesenhar();
      };
      if (!atual || !valor) return desfazer();
      const ts = campoNome === 'data' ? deCampos(valor, horaDe(atual.ts)) : deCampos(valorData(atual.ts), normalizarHora(valor) || horaDe(atual.ts));
      if (!ts) return desfazer();
      if (ts === atual.ts) return ctx.redesenhar();
      // há banhos depois deste que ainda podem mudar? pergunta se andam junto
      const linhas = folha(ctx.vm);
      const seguintes = linhas.filter((l) => l.indice > atual.indice && !l.travado);
      let resposta = 'so';
      if (seguintes.length) {
        const dias = Math.round((inicioDoDia(ts) - inicioDoDia(atual.ts)) / 864e5);
        resposta = await escolher({
          titulo: campoNome === 'data' ? 'Mudar só este banho?' : 'Mudar o horário só deste banho?',
          texto: campoNome === 'data'
            ? `Este banho passa para ${fmtDataCurta(ts)}. Os ${seguintes.length} banhos seguintes do plano (de todos os meses) podem ficar como estão ou andar junto, mantendo o intervalo.`
            : `Este banho passa para ${horaDe(ts)}. Os ${seguintes.length} banhos seguintes do plano podem ficar no horário de antes ou passar para ${horaDe(ts)} também.`,
          opcoes: [
            { valor: 'so', rotulo: 'Só este banho', sub: 'Os outros banhos continuam como estão' },
            {
              valor: 'seguintes',
              rotulo: 'Este e os seguintes',
              sub: campoNome === 'data'
                ? `Os próximos ${seguintes.length} banhos contam a partir deste (${dias > 0 ? `${dias} ${dias === 1 ? 'dia' : 'dias'} para frente` : `${-dias} ${dias === -1 ? 'dia' : 'dias'} para trás`})`
                : `Os próximos ${seguintes.length} banhos passam para ${horaDe(ts)}`,
            },
          ],
        });
        if (!resposta) return desfazer();
      }
      if (resposta === 'seguintes') {
        seguirDaqui(linhas, atual, ts);
      } else {
        // só este: se os seguintes contavam a partir dele, passam a contar do próximo (ficam onde estão)
        if (atual.ancora) {
          const proximo = linhas.find((l) => l.indice > atual.indice && !l.travado);
          if (proximo) ui.edicoes.set(proximo.chave, { ...(ui.edicoes.get(proximo.chave) || {}), ts: proximo.ts, ancora: true, manual: true });
        }
        ui.edicoes.set(chave, { ...(ui.edicoes.get(chave) || {}), ts, manual: true, ancora: false });
      }
      return ctx.redesenhar();
    }
    if (!(nome in ui.f)) return;
    ui.f[nome] = valor;
    // início e meses mudam o período: busca de novo a agenda para checar horários ocupados
    if (nome === 'inicio' || nome === 'meses') ctx.recarregar();
    else ctx.redesenhar();
  },

  acoes: {
    'trocar-pet': (_, ctx) => {
      ui.chave = null;
      ctx.navegar('plano-pet', {}, { substituir: true });
    },
    servico: ({ id }, ctx) => {
      const lista = ui.f.servicos;
      ui.f.servicos = lista.includes(id) ? lista.filter((x) => x !== id) : [...lista, id];
      ctx.redesenhar();
    },
    tipo: ({ tipo }, ctx) => {
      if (ui.f.tipo === tipo) return;
      ui.f.tipo = tipo;
      // a folha muda de formato: datas trocadas à mão voltam ao padrão (as que já aconteceram ficam)
      ui.edicoes = new Map();
      for (const [chave, v] of ctx.vm.salvos) if (!v.travado) ui.edicoes.set(chave, { manual: false, ancora: false, ts: undefined });
      ctx.redesenhar();
    },
    meses: ({ meses }, ctx) => {
      ui.f.meses = String(meses);
      ctx.recarregar();
    },
    'mens-receber': async ({ mes }, ctx) => {
      const m = ctx.vm.mensalidades.find((x) => x.mes === mes);
      const nomeMes = MESES[new Date(m.ts).getMonth()];
      const r = await escolherFormaRecebimento(ctx, { titulo: m.ts > Date.now() + 7 * 864e5 ? `Receber a mensalidade de ${nomeMes} adiantada` : `Receber a mensalidade de ${nomeMes}`, valorCentavos: m.valorCentavos, detalhe: ctx.vm.plano.nome });
      if (!r) return;
      await planos.registrarPagamento(ctx.vm.plano.id, mes, r.forma, r.quando, r.partes);
      ctx.toast(`Mensalidade marcada como paga · ${descreverRecebimento(r)}`);
      ctx.recarregar();
    },
    'mens-desfazer': async ({ mes }, ctx) => {
      const ok = await ctx.confirmar({ titulo: 'Marcar a mensalidade como não paga?', texto: 'Ela volta a ficar em aberto e sai do faturamento até ser marcada como paga de novo.', botao: 'Marcar como não paga', perigo: false, icone: 'wallet' });
      if (!ok) return;
      await planos.desfazerPagamento(ctx.vm.plano.id, mes);
      ctx.toast('Mensalidade marcada como não paga');
      ctx.recarregar();
    },
    // todas as datas (menos as que já aconteceram) voltam ao ritmo do plano, a partir do 1º banho
    'refazer-datas': async (_, ctx) => {
      const ok = await ctx.confirmar({
        titulo: 'Refazer as datas a partir do 1º banho?',
        texto: `Todos os banhos que ainda não aconteceram voltam ao ritmo do plano: a cada ${TIPOS[ui.f.tipo].intervalo} dias, sempre no mesmo dia da semana e no horário do plano, contando da data do 1º banho. As datas trocadas à mão são desfeitas. Nada é salvo até você tocar em "Salvar plano".`,
        botao: 'Refazer as datas',
        perigo: false,
        icone: 'rotate-ccw',
      });
      if (!ok) return;
      for (const l of folha(ctx.vm)) if (!l.travado) ui.edicoes.set(l.chave, { manual: false, ancora: false, ts: undefined });
      ctx.redesenhar();
      ctx.toast('Datas refeitas a partir do 1º banho · confira e toque em Salvar plano');
    },
    // banho trocado volta para a data do padrão
    padrao: ({ chave }, ctx) => {
      ui.edicoes.set(chave, { manual: false, ancora: false, ts: undefined });
      ctx.redesenhar();
    },
    // os banhos seguintes passam a contar a partir deste
    seguir: ({ chave }, ctx) => {
      const linhas = folha(ctx.vm);
      const atual = linhas.find((l) => l.chave === chave);
      seguirDaqui(linhas, atual, atual.ts);
      ctx.redesenhar();
      ctx.toast('Os banhos seguintes andaram junto com este');
    },
    // volta a mudar só este banho: os seguintes voltam às datas de antes
    'so-este': ({ chave }, ctx) => {
      const atual = folha(ctx.vm).find((l) => l.chave === chave);
      ui.edicoes.set(chave, { ...(ui.edicoes.get(chave) || {}), ts: atual.ts, ancora: false, manual: true });
      ctx.redesenhar();
      ctx.toast('Só este banho mudou; os seguintes voltaram às datas de antes');
    },
    cancelar: (_, ctx) => {
      ui.chave = null;
      ctx.navegar('planos', {}, { substituir: true });
    },
    salvar: async (_, ctx) => {
      const f = ui.f;
      const escolhido = ctx.vm.listaPets.find((l) => l.pet.id === f.petId);
      if (!escolhido) return ctx.toast('Escolha o pet do plano', { erro: true });
      if (!f.servicos.length) return ctx.toast('Escolha ao menos um serviço de cada banho', { erro: true });
      if (!normalizarHora(f.hora)) return ctx.toast('Informe o horário dos banhos', { erro: true });
      if (!deCampos(f.inicio, '00:00')) return ctx.toast('Informe a data do 1º banho', { erro: true });

      const dados = { ...(ctx.vm.plano || {}), ...planoDoForm(f, escolhido.pet) };
      // plano novo começa ativo; um plano existente mantém como estava (pausado continua pausado)
      if (!ctx.vm.plano) dados.ativo = true;
      // nome automático acompanha o tipo; nome escrito pelo Odilon fica como está
      if (!dados.nome || /^(Mensal|Quinzenal) · /.test(dados.nome)) dados.nome = `${f.tipo} · ${escolhido.pet.nome}`;
      if (!dados.duracaoMin) {
        let total = 0;
        for (const s of ctx.vm.catalogo.filter((x) => f.servicos.includes(x.id))) total += (await tempos.estimar(escolhido.pet, s)).minutos;
        dados.duracaoMin = total || 60;
      }
      const linhas = folha(ctx.vm);
      // o plano vale até o último banho (se um banho foi para depois do fim do contrato)
      const ultimo = Math.max(...linhas.map((l) => l.ts));
      if (Number.isFinite(ultimo) && ultimo >= dados.fim) dados.fim = inicioDoDia(ultimo) + 864e5;
      const { criados, removidos } = await planos.salvarPacote(dados, linhas);
      ui.chave = null;
      const partes = [ctx.vm.plano ? 'Plano salvo' : 'Plano criado'];
      if (criados) partes.push(`${criados} ${criados === 1 ? 'banho agendado' : 'banhos agendados'}`);
      if (removidos) partes.push(`${removidos} ${removidos === 1 ? 'banho removido' : 'banhos removidos'} da agenda`);
      ctx.toast(partes.join(' · '));
      ctx.navegar('planos', {}, { substituir: true });
    },
    encerrar: async (_, ctx) => {
      const plano = ctx.vm.plano;
      const ok = await ctx.confirmar({
        titulo: `Encerrar “${plano.nome}”?`,
        texto: 'Use quando o cliente desiste antes do fim do contrato. As mensalidades param hoje e os banhos que ainda não aconteceram saem da agenda. O que já foi feito e pago continua no histórico e no faturamento.',
        botao: 'Encerrar plano',
        icone: 'circle-stop',
      });
      if (!ok) return;
      const removidos = await planos.encerrar(plano.id);
      ui.chave = null;
      ctx.toast(`Plano encerrado${removidos ? ` · ${removidos} ${removidos === 1 ? 'banho saiu' : 'banhos saíram'} da agenda` : ''}`);
      ctx.navegar('planos', {}, { substituir: true });
    },
    excluir: async (_, ctx) => {
      const plano = ctx.vm.plano;
      const ok = await ctx.confirmar({
        titulo: `Excluir “${plano.nome}”?`,
        texto: 'Use para um plano criado por engano. O plano e os banhos que ainda não aconteceram vão para a lixeira por 30 dias. Se o cliente desistiu, prefira "Encerrar plano".',
        botao: 'Mover para lixeira',
      });
      if (!ok) return;
      await planos.excluir(plano.id);
      ui.chave = null;
      ctx.toast('Plano movido para a lixeira');
      ctx.navegar('planos', {}, { substituir: true });
    },
  },
};

/** Marca do banho que cobra a mensalidade do mês. */
const marcaCobranca = (c) =>
  c ? html`<span class="pac-cobra ${c.pago ? 'paga' : ''}">${icon('circle-dollar-sign', 12)}cobra a mensalidade de ${c.mesNome}${c.pago ? ' · paga' : ''}</span>` : '';

function linhaBanho(l, aviso, somenteLeitura, cobranca) {
  const dia = DIAS_CURTOS[new Date(l.ts).getDay()];
  if (l.travado || somenteLeitura) {
    const st = ROTULO_TRAVADO[l.status] || (STATUS[l.status]?.rotulo ?? 'Agendado');
    return html`<div class="pac-banho travado">
      <span class="pac-num">${rotuloBanho(l.banho)}</span>
      <span class="pac-data-fixa">${dia}, ${fmtDataCurta(l.ts)} · ${horaDe(l.ts)}</span>
      <span class="pac-st ${l.status === 'concluido' ? 'verde' : ''}">${st}</span>
      ${marcaCobranca(cobranca)}
    </div>`;
  }
  return html`<div class="pac-banho${l.manual ? ' trocado' : ''}">
    <span class="pac-num">${rotuloBanho(l.banho)}</span>
    <span class="pac-dia">${dia}</span>
    <input class="campo-data pac-in-data" type="date" data-campo="data-${l.chave}" value="${valorData(l.ts)}" aria-label="Data do ${rotuloBanho(l.banho)}">
    <input class="campo-data pac-in-hora" type="time" data-campo="hora-${l.chave}" value="${horaDe(l.ts)}" step="300" aria-label="Hora do ${rotuloBanho(l.banho)}">
    ${l.manual || l.ancora
      ? html`<span class="pac-trocado">
          ${l.ancora
            ? html`<span class="pac-tag">os seguintes andaram junto</span><button class="link-acao" data-acao="so-este" data-chave="${l.chave}">Mudar só este</button>`
            : html`<span class="pac-tag">só este mudou</span><button class="link-acao" data-acao="seguir" data-chave="${l.chave}">Mudar os seguintes também</button>`}
          <button class="link-acao" data-acao="padrao" data-chave="${l.chave}">Voltar ao padrão</button>
        </span>`
      : ''}
    ${marcaCobranca(cobranca)}
    ${aviso ? html`<span class="pac-aviso ${aviso.tom}">${icon(aviso.tom === 'neutro' ? 'info' : 'triangle-alert', 12)}${aviso.texto}</span>` : ''}
  </div>`;
}

/**
 * Banho que cobra a mensalidade em cada mês do calendário, pelas datas da folha
 * como estão na tela (acompanha as trocas antes de salvar). Mesma regra do app:
 * o 1º banho do mês (cancelado/faltou passa para o seguinte), no máximo N meses.
 */
function cobrancasDaFolha(linhas, plano, meses) {
  const saida = new Map();
  if (!plano?.valorCentavos) return saida;
  const porMes = new Map();
  for (const l of [...linhas].sort((a, b) => a.ts - b.ts)) {
    const d = new Date(l.ts);
    const mes = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
    const veio = !['cancelado', 'nao_compareceu'].includes(l.status);
    const atual = porMes.get(mes);
    if (!atual || (!atual.veio && veio)) porMes.set(mes, { l, veio });
  }
  // como o app cobra: no máximo uma por mês de contrato, contando as já pagas
  const pagos = new Set(Object.keys(plano.pagamentos || {}).filter((m) => plano.pagamentos[m]));
  let livres = Math.max(0, meses - pagos.size);
  [...porMes.entries()].sort(([a], [b]) => (a < b ? -1 : 1)).forEach(([mes, { l }]) => {
    if (!pagos.has(mes)) {
      if (livres <= 0) return;
      livres--;
    }
    saida.set(l.chave, { mes, mesNome: MESES[new Date(l.ts).getMonth()], pago: pagos.has(mes) });
  });
  return saida;
}

/**
 * "Este e os seguintes" (o mesmo da Agenda): o banho vira o ponto de onde os
 * seguintes contam. TODOS os banhos depois dele (de todos os meses, inclusive os
 * que tinham data própria) passam para o ritmo do plano a partir dele: 7 ou 14
 * dias, sempre no mesmo dia da semana e na hora dele. Os anteriores e os que já
 * aconteceram não mudam.
 */
function seguirDaqui(linhas, atual, ts) {
  ui.edicoes.set(atual.chave, { ...(ui.edicoes.get(atual.chave) || {}), ts, ancora: true, manual: true });
  for (const l of linhas) {
    if (l.indice > atual.indice && !l.travado) ui.edicoes.set(l.chave, { manual: false, ancora: false, ts: undefined });
  }
}
