import {
  html, icon, fmtBRL, fmtHora, fmtDataCurta, mesmoDia, addDias, digitos, DIAS_LONGOS,
  inicioDoDia, fimDoDia, inicioDaSemana, inicioDoMes, fimDoMes,
} from '../core/dom.js';
import { avPet, vazio, chip } from '../core/ui.js';
import { agendamentos, pets, tutores, planos, dataDoAtendimento, nomesParaRelatorio, mensalidadesDoPlano } from '../data/repo.js';
import { situacaoPagamento, ehBanhoDePlano } from '../logic/pagamento.js';
import { combina } from '../core/busca.js';
import { escolherFormaRecebimento, descreverRecebimento } from '../modais/recebimento.js';
import { nomesParaBusca, telefonesDoTutor } from '../logic/contatos.js';

/* HISTÓRICO — todos os atendimentos finalizados, do mais recente para o mais
   antigo. Daqui dá para reabrir (voltar ao atendimento para corrigir) ou
   desfazer (voltar a ser só um agendamento) um atendimento finalizado por engano. */

const PERIODOS = ['Hoje', 'Semana', 'Este mês', 'Mês passado', 'Tudo'];
const FILTROS = ['Todos', 'Pagos', 'Não pagos', 'Plano'];
const POR_PAGINA = 60;
const ui = { periodo: 'Semana', filtro: 'Todos', busca: '', limite: POR_PAGINA };

/**
 * Filtros em que a linha aparece. Mensalidade recebida: Pagos e Plano. Banho do plano:
 * Plano (e Não pagos se a mensalidade cobrada nele está em aberto, ou o extra não foi pago).
 */
function situacao(l) {
  if (l.mensalidade) return ['Pagos', 'Plano'];
  const s = [];
  const chave = situacaoPagamento(l.ag).chave;
  if (chave === 'pago') s.push('Pagos');
  if (chave === 'naoPago') s.push('Não pagos');
  if (ehBanhoDePlano(l.ag)) s.push('Plano');
  if (l.cobranca && !l.cobranca.pagamento && !s.includes('Não pagos')) s.push('Não pagos');
  return s;
}
const temCobranca = (ag) => (ag.valorCentavos || 0) > 0;

function intervalo(periodo, agora = Date.now()) {
  switch (periodo) {
    case 'Hoje':
      return { de: inicioDoDia(agora), ate: fimDoDia(agora) };
    case 'Semana':
      return { de: inicioDaSemana(agora), ate: fimDoDia(agora) };
    case 'Este mês':
      return { de: inicioDoMes(agora), ate: fimDoDia(agora) };
    case 'Mês passado': {
      const d = new Date(agora);
      const ref = new Date(d.getFullYear(), d.getMonth() - 1, 15).getTime();
      return { de: inicioDoMes(ref), ate: fimDoMes(ref) };
    }
    default:
      return { de: 0, ate: Infinity };
  }
}

function rotuloDia(ts) {
  const agora = Date.now();
  if (mesmoDia(ts, agora)) return 'Hoje';
  if (mesmoDia(ts, addDias(agora, -1))) return 'Ontem';
  return `${DIAS_LONGOS[new Date(ts).getDay()]}, ${fmtDataCurta(ts)}${new Date(ts).getFullYear() !== new Date(agora).getFullYear() ? '/' + new Date(ts).getFullYear() : ''}`;
}

const pagamento = situacaoPagamento;

export default {
  titulo: 'Histórico',
  menu: 'historico',

  async carregar() {
    const mapaPets = new Map((await pets.listar()).map((p) => [p.id, p]));
    const mapaTutores = new Map((await tutores.listar()).map((t) => [t.id, t]));
    // nomes também de pets e tutores excluídos: o histórico não perde quem foi
    const nomes = await nomesParaRelatorio();
    const { de, ate } = intervalo(ui.periodo);
    const lista = (await agendamentos.concluidos())
      // mesmo critério do faturamento: o dia em que o pet foi atendido
      .map((ag) => ({ ag, quando: dataDoAtendimento(ag) }))
      .filter((x) => x.quando >= de && x.quando <= ate)
      .sort((a, b) => b.quando - a.quando);
    const itensPorAg = await agendamentos.itensDe(lista.map((x) => x.ag));
    // mensalidades: cada banho de cobrança mostra se a mensalidade foi paga, e a mensalidade
    // recebida aparece também no dia em que foi paga
    const cobrancaPorVisita = new Map();
    const mensalidadesPagas = [];
    const planoPorId = new Map();
    for (const plano of await planos.todos()) {
      planoPorId.set(plano.id, plano);
      // mesma regra do Faturamento: só cobra plano valendo, com valor, até o encerramento
      const mens = await mensalidadesDoPlano(plano);
      const visitas = await agendamentos.doPlano(plano.id);
      for (const m of mens) {
        const visita = visitas.find((v) => v.inicio === m.ts);
        if (visita) cobrancaPorVisita.set(visita.id, m);
        if (m.pagamento?.pagoEm >= de && m.pagamento.pagoEm <= ate) mensalidadesPagas.push(m);
      }
    }
    const linhas = [];
    for (const { ag, quando } of lista) {
      const pet = mapaPets.get(ag.petId) || (nomes.pets.get(ag.petId) ? { id: null, nome: nomes.pets.get(ag.petId) } : null);
      const tutorId = ag.tutorId || pet?.tutorId;
      const tutor = mapaTutores.get(tutorId) || (nomes.tutores.get(tutorId) ? { nome: nomes.tutores.get(tutorId) } : null);
      linhas.push({
        ag,
        quando,
        pet,
        tutor,
        servicos: (itensPorAg.get(ag.id) || []).map((i) => i.nome).join(' + '),
        cobranca: cobrancaPorVisita.get(ag.id) || null,
        plano: ag.planoId ? planoPorId.get(ag.planoId) || null : null,
        textos: [pet?.nome, ...nomesParaBusca(tutor)],
        telefones: telefonesDoTutor(tutor),
      });
    }
    for (const m of mensalidadesPagas) {
      const pet = mapaPets.get(m.plano.petId) || (nomes.pets.get(m.plano.petId) ? { id: null, nome: nomes.pets.get(m.plano.petId) } : null);
      const tutor = mapaTutores.get(m.plano.tutorId) || (nomes.tutores.get(m.plano.tutorId) ? { nome: nomes.tutores.get(m.plano.tutorId) } : null);
      linhas.push({ mensalidade: m, quando: m.pagamento.pagoEm, pet, tutor, servicos: '', textos: [pet?.nome, m.plano.nome, ...nomesParaBusca(tutor)], telefones: telefonesDoTutor(tutor) });
    }
    linhas.sort((a, b) => b.quando - a.quando);
    return { linhas };
  },

  render(vm) {
    const termo = ui.busca.trim();
    const filtradas = vm.linhas.filter((l) => (ui.filtro === 'Todos' || situacao(l).includes(ui.filtro)) && combina(termo, [...l.textos, l.servicos], l.telefones));
    const visiveis = filtradas.slice(0, ui.limite);
    const atendimentos = filtradas.filter((l) => l.ag);
    const total = atendimentos.reduce((s, l) => s + (l.ag.valorCentavos || 0), 0);
    const mensalidades = filtradas.filter((l) => l.mensalidade);
    const totalMensalidades = mensalidades.reduce((s, l) => s + l.mensalidade.valorCentavos, 0);

    // agrupa por dia de finalização
    const grupos = [];
    for (const l of visiveis) {
      const chave = inicioDoDia(l.quando);
      if (!grupos.length || grupos[grupos.length - 1].chave !== chave) grupos.push({ chave, linhas: [] });
      grupos[grupos.length - 1].linhas.push(l);
    }

    return html`
      <div class="hist-topo">
        <div class="segmento">${PERIODOS.map((p) => html`<button class="${ui.periodo === p ? 'on' : ''}" data-acao="periodo" data-periodo="${p}">${p}</button>`)}</div>
        <div class="busca branca">
          ${icon('search', 16)}
          <input data-campo="busca" value="${ui.busca}" placeholder="Buscar por pet, tutor ou telefone…">
          ${ui.busca ? html`<button data-acao="limpar" style="display:flex;color:var(--texto-3)" aria-label="Limpar">${icon('x', 15)}</button>` : ''}
        </div>
      </div>

      <div class="chips" style="margin:-4px 0 12px;gap:8px">${FILTROS.map((f) => chip(f, ui.filtro === f, 'filtro', { filtro: f }, { suave: true }))}</div>

      <div class="hist-resumo-linha">
        <span><strong>${atendimentos.length}</strong> ${atendimentos.length === 1 ? 'atendimento finalizado' : 'atendimentos finalizados'}</span>
        <span>Total cobrado <strong>${fmtBRL(total)}</strong>${totalMensalidades ? html` · mensalidades recebidas <strong>${fmtBRL(totalMensalidades)}</strong>` : ''}</span>
      </div>

      ${!filtradas.length
        ? html`<div class="card pad-18">${vazio({
            icone: 'history',
            titulo: termo || ui.filtro !== 'Todos' ? 'Nenhum atendimento encontrado' : 'Nenhum atendimento finalizado neste período',
            texto: termo || ui.filtro !== 'Todos' ? 'Tente outro filtro, nome ou período.' : 'Os atendimentos aparecem aqui assim que são finalizados.',
          })}</div>`
        : html`${grupos.map(
            (g) => html`<div class="card r22 hist-grupo">
              <div class="hist-dia">${rotuloDia(g.chave)}<span>${(() => { const n = g.linhas.filter((l) => l.ag).length; return `${n} ${n === 1 ? 'atendimento' : 'atendimentos'}`; })()}</span></div>
              ${g.linhas.map((l) => (l.mensalidade ? linhaMensalidade(l) : linha(l)))}
            </div>`
          )}
          ${filtradas.length > visiveis.length
            ? html`<button class="btn btn-branco bloco" data-acao="mais">Mostrar mais (${filtradas.length - visiveis.length} restantes)</button>`
            : ''}`}`;
  },

  aoDigitar(campo, valor, ctx) {
    if (campo !== 'busca') return;
    ui.busca = valor;
    ui.limite = POR_PAGINA;
    ctx.redesenhar();
  },

  acoes: {
    periodo: ({ periodo }, ctx) => {
      ui.periodo = periodo;
      ui.limite = POR_PAGINA;
      ctx.recarregar();
    },
    limpar: (_, ctx) => {
      ui.busca = '';
      ctx.redesenhar();
    },
    filtro: ({ filtro }, ctx) => {
      ui.filtro = filtro;
      ui.limite = POR_PAGINA;
      ctx.redesenhar();
    },
    // mensalidade do plano: receber / desfazer daqui também
    'pagar-mensalidade': async ({ plano, mes }, ctx) => {
      const p = (await planos.todos()).find((x) => x.id === plano);
      if (!p) return;
      const r = await escolherFormaRecebimento(ctx, { valorCentavos: p.valorCentavos, detalhe: `${p.nome} · mensalidade` });
      if (!r) return;
      await planos.registrarPagamento(plano, mes, r.forma, r.quando, r.partes);
      ctx.toast(`Mensalidade recebida · ${descreverRecebimento(r)}`);
      ctx.recarregar();
    },
    'mensalidade-nao-paga': async ({ plano, mes }, ctx) => {
      const ok = await ctx.confirmar({
        titulo: 'Marcar a mensalidade como não paga?',
        texto: 'Ela volta a ficar como não paga (em "A receber" no Faturamento) e sai do faturamento até ser marcada como paga de novo.',
        botao: 'Marcar como não paga',
        perigo: false,
        icone: 'wallet',
      });
      if (!ok) return;
      await planos.desfazerPagamento(plano, mes);
      ctx.toast('Mensalidade marcada como não paga');
      ctx.recarregar();
    },
    // pago / não pago direto daqui, sem reabrir o atendimento
    pagar: async ({ id }, ctx) => {
      const l = ctx.vm.linhas.find((x) => x.ag?.id === id);
      const r = await escolherFormaRecebimento(ctx, { valorCentavos: l.ag.valorCentavos, detalhe: l.pet?.nome || '' });
      if (!r) return;
      await agendamentos.registrarRecebimento(id, r.forma, r.quando, r.partes);
      ctx.toast(`Marcado como pago · ${descreverRecebimento(r)}`);
      ctx.recarregar();
    },
    'nao-pago': async ({ id }, ctx) => {
      const l = ctx.vm.linhas.find((x) => x.ag?.id === id);
      const ok = await ctx.confirmar({
        titulo: `Marcar como não pago?`,
        texto: `${l.pet?.nome || 'O atendimento'} · ${fmtBRL(l.ag.valorCentavos)} volta a ficar como não pago (em "A receber" no Faturamento) e sai do faturamento até ser marcado como pago de novo.`,
        botao: 'Marcar como não pago',
        perigo: false,
        icone: 'wallet',
      });
      if (!ok) return;
      await agendamentos.marcarNaoPago(id);
      ctx.toast('Marcado como não pago');
      ctx.recarregar();
    },
    mais: (_, ctx) => {
      ui.limite += POR_PAGINA;
      ctx.redesenhar();
    },
    ficha: ({ id }, ctx) => id && ctx.navegar('ficha-pet', { id }),
    reabrir: async ({ id }, ctx) => {
      const l = ctx.vm.linhas.find((x) => x.ag?.id === id);
      const nome = l.pet?.nome || 'o pet';
      const ok = await ctx.confirmar({
        titulo: `Reabrir o atendimento de ${nome}?`,
        texto: `O atendimento volta para o Atendimento do dia com os tempos já registrados e o relógio parado (não conta o tempo desde que foi finalizado). Você corrige o que precisar e finaliza de novo. Para só trocar pago/não pago, não precisa reabrir: use o botão ao lado.${l.ag.retornoId ? ' O retorno marcado na finalização é desmarcado.' : ''}`,
        botao: 'Reabrir',
        perigo: false,
        icone: 'rotate-ccw',
      });
      if (!ok) return;
      const r = await agendamentos.reabrir(id);
      if (!r) return ctx.toast('Este atendimento já não está finalizado', { erro: true });
      ctx.toast(`Atendimento de ${nome} reaberto${r.retornoRemovido ? ' · retorno desmarcado' : ''}`);
      ctx.navegar('atendimento', { id });
    },
    desfazer: async ({ id }, ctx) => {
      const l = ctx.vm.linhas.find((x) => x.ag?.id === id);
      const nome = l.pet?.nome || 'o pet';
      const ok = await ctx.confirmar({
        titulo: `Desfazer o atendimento de ${nome}?`,
        texto: `Volta a ser só um agendamento em ${fmtDataCurta(l.ag.inicio)} às ${fmtHora(l.ag.inicio)}, como se ${nome} não tivesse vindo. Os tempos cronometrados e o pagamento são apagados, e o valor sai do faturamento.${l.ag.retornoId ? ' O retorno marcado na finalização também é desmarcado.' : ''}`,
        botao: 'Desfazer atendimento',
        icone: 'undo-2',
      });
      if (!ok) return;
      const r = await agendamentos.desfazer(id);
      if (!r) return ctx.toast('Este atendimento já não está finalizado', { erro: true });
      ctx.toast(`Atendimento desfeito · ${nome} voltou para a agenda${r.retornoRemovido ? ' · retorno desmarcado' : ''}`);
      ctx.recarregar();
    },
  },
};

function linha(l) {
  const { ag, pet, tutor } = l;
  const pg = pagamento(ag);
  const { servicos } = l;
  return html`<div class="hist-item">
    <button class="hist-item-info" data-acao="ficha" data-id="${pet?.id || ''}">
      <span class="hist-hora">${fmtHora(l.quando)}</span>
      ${pet?.id ? avPet(pet, 40, { borda: 0, sombra: false }) : html`<span style="width:40px"></span>`}
      <span class="hist-nomes">
        <span class="hist-pet truncar">${pet?.nome || 'Pet excluído'}</span>
        <span class="hist-tutor truncar">${tutor?.nome || 'Sem tutor'}${servicos ? ' · ' + servicos : ''}</span>
      </span>
      <span class="hist-valor">
        ${valorDaLinha(l)}
        ${ag.planoId && ag.valorCentavos ? html`<span class="hist-pg lavanda">Plano · extra cobrado</span>` : ''}
        <span class="hist-pg ${pg.cls}">${pg.texto}</span>
        ${l.cobranca ? html`<span class="hist-pg ${l.cobranca.pagamento ? 'verde' : 'ambar'}">Mensalidade ${l.cobranca.k}/${l.cobranca.total} · ${valorMensalidade(l.cobranca)} · ${l.cobranca.pagamento ? `paga${l.cobranca.pagamento.formaPagamento ? ' · ' + l.cobranca.pagamento.formaPagamento : ''}` : 'não paga'}</span>` : ''}
      </span>
    </button>
    <div class="hist-acoes">
      ${temCobranca(ag)
        ? ag.pagamentoPendente
          ? html`<button class="btn btn-roxo hist-btn" data-acao="pagar" data-id="${ag.id}">${icon('circle-dollar-sign', 14)}<span>Marcar pago</span></button>`
          : html`<button class="btn btn-branco hist-btn discreto" data-acao="nao-pago" data-id="${ag.id}">${icon('undo-2', 14)}<span>Marcar não pago</span></button>`
        : ''}
      ${l.cobranca && !l.cobranca.pagamento && !l.cobranca.plano.excluidoEm
        ? html`<button class="btn btn-roxo hist-btn" data-acao="pagar-mensalidade" data-plano="${l.cobranca.plano.id}" data-mes="${l.cobranca.mes}">${icon('circle-dollar-sign', 14)}<span>Receber mensalidade</span></button>`
        : ''}
      <button class="btn btn-lavanda hist-btn" data-acao="reabrir" data-id="${ag.id}">${icon('rotate-ccw', 14)}<span>Reabrir</span></button>
      <button class="btn btn-branco hist-btn desfazer" data-acao="desfazer" data-id="${ag.id}">${icon('undo-2', 14)}<span>Desfazer</span></button>
    </div>
  </div>`;
}

/** Mensalidade de plano recebida: aparece no dia em que foi paga. */
function linhaMensalidade(l) {
  const { mensalidade: m, pet, tutor } = l;
  return html`<div class="hist-item">
    <button class="hist-item-info" data-acao="ficha" data-id="${pet?.id || ''}">
      <span class="hist-hora">${fmtHora(l.quando)}</span>
      ${pet?.id ? avPet(pet, 40, { borda: 0, sombra: false }) : html`<span style="width:40px"></span>`}
      <span class="hist-nomes">
        <span class="hist-pet truncar">${pet?.nome || 'Pet excluído'} · mensalidade${m.k ? ` ${m.k}/${m.total}` : ''}</span>
        <span class="hist-tutor truncar">${tutor?.nome || 'Sem tutor'} · ${m.plano.nome}</span>
      </span>
      <span class="hist-valor">
        <span>${fmtBRL(m.pagamento.valorCentavos ?? m.plano.valorCentavos ?? 0)}</span>
        <span class="hist-pg verde">Mensalidade paga${m.pagamento.formaPagamento ? ' · ' + m.pagamento.formaPagamento : ''}</span>
      </span>
    </button>
    <div class="hist-acoes">
      <button class="btn btn-branco hist-btn discreto" data-acao="mensalidade-nao-paga" data-plano="${m.plano.id}" data-mes="${m.mes}">${icon('undo-2', 14)}<span>Marcar não paga</span></button>
    </div>
  </div>`;
}

const valorMensalidade = (c) => fmtBRL(c.valorCentavos ?? c.plano.valorCentavos ?? 0);

/**
 * Valor mostrado na linha: o cobrado no atendimento; num banho do plano sem extra,
 * o valor do plano por mês (o banho está incluso nele).
 */
function valorDaLinha(l) {
  const { ag } = l;
  if (ag.planoId && !ag.valorCentavos) {
    return l.plano?.valorCentavos
      ? html`<span>${fmtBRL(l.plano.valorCentavos)}<small class="hist-mes">/mês</small></span>`
      : html`<span class="mutado">Incluso</span>`;
  }
  return html`<span>${fmtBRL(ag.valorCentavos || 0)}</span>`;
}
