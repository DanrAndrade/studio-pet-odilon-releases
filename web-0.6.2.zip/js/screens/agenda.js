import {
  html, icon, fmtBRL, fmtBRLCurto, fmtDur, fmtHora, fmtDataExtenso, inicioDoDia, fimDoDia,
  inicioDaSemana, inicioDoMes, fimDoMes, addDias, mesmoDia, DIAS_CURTOS, MESES, MESES_CURTOS,
} from '../core/dom.js';
import { avPet, tagsPet, STATUS, CORES_TRACO, patinhasHero, selo, vazio } from '../core/ui.js';
import { agendamentos, pets, tutores, planos, mensalidadesDoPlano } from '../data/repo.js';
import { ehBanhoDePlano, situacaoPagamento } from '../logic/pagamento.js';
import * as config from '../data/config.js';
import { horariosLivres } from '../logic/agenda.js';
import { escolherFormaRecebimento, descreverRecebimento } from '../modais/recebimento.js';

const ui = { ref: Date.now(), visao: 'Dia', pagina: 0, livres: false };

const ehCelular = () => window.matchMedia('(max-width: 760px)').matches;
const ATIVOS = (ag) => ag.status !== 'cancelado' && ag.status !== 'nao_compareceu';
const AGUARDANDO = ['agendado', 'confirmado', 'rascunho_plano'];

function periodo() {
  if (ui.visao === 'Semana') {
    const de = inicioDaSemana(ui.ref);
    return [de, addDias(de, 7) - 1];
  }
  if (ui.visao === 'Mês') return [inicioDoMes(ui.ref), fimDoMes(ui.ref)];
  return [inicioDoDia(ui.ref), fimDoDia(ui.ref)];
}

function rotuloPeriodo() {
  const d = new Date(ui.ref);
  if (ui.visao === 'Semana') {
    const a = new Date(inicioDaSemana(ui.ref));
    const b = new Date(addDias(a.getTime(), 5));
    return `${a.getDate()} – ${b.getDate()} de ${MESES_CURTOS[b.getMonth()]}`;
  }
  if (ui.visao === 'Mês') {
    const mes = MESES[d.getMonth()];
    return `${mes.charAt(0).toUpperCase()}${mes.slice(1)} ${d.getFullYear()}`;
  }
  return fmtDataExtenso(ui.ref);
}

function acaoDa(ag, itens) {
  switch (ag.status) {
    case 'em_atendimento':
      return itens.length && itens.every((i) => i.done)
        ? { rotulo: 'Finalizar e cobrar', estilo: 'cheio', acao: 'finalizar' }
        : { rotulo: 'Em atendimento', estilo: 'lavanda', acao: 'abrir-atendimento' };
    case 'concluido':
      return ag.pagamentoPendente
        ? { rotulo: 'Marcar pago', estilo: '', acao: 'receber' }
        : { rotulo: 'Ver ficha', estilo: 'neutro', acao: 'ver-ficha' };
    case 'rascunho_plano':
      return { rotulo: 'Confirmar', estilo: '', acao: 'confirmar' };
    case 'cancelado':
    case 'nao_compareceu':
      return { rotulo: 'Reagendar', estilo: 'neutro', acao: 'editar' };
    default:
      return { rotulo: 'Registrar chegada', estilo: '', acao: 'chegada' };
  }
}

/* =============================== Linhas ============================== */

function linhaAgendamento({ ag, pet, tutor, itens, cobranca }) {
  const st = STATUS[ag.status] || STATUS.agendado;
  const alerta = tagsPet(pet)[0];
  const acao = acaoDa(ag, itens);
  const valor = ehBanhoDePlano(ag) && !ag.valorCentavos ? 'Plano' : fmtBRL(ag.valorCentavos);
  const servicosTxt = (itens.map((i) => i.nome).join(' + ') || 'Sem serviço') + (ag.planoMes ? ` · Plano: mês ${ag.planoMes}, ${ag.planoBanho}º banho` : '');

  return html`<div class="ag-linha" data-acao="abrir" data-id="${ag.id}">
    <div class="ag-linha-miolo">
      <div class="ag-hora">${fmtHora(ag.inicio)}</div>
      <div class="ag-divisor"></div>
      ${avPet(pet, 48)}
      <div class="ag-info">
        <div class="ag-nome">
          <span class="ag-pet">${pet.nome}</span>
          <span class="ag-tutor">${tutor?.nome || 'Sem tutor'}</span>
          ${alerta ? html`<span class="ag-alerta ${alerta.tom === 'ambar' ? 'ambar' : ''}">${icon('triangle-alert', 11)}${alerta.label}</span>` : ''}
        </div>
        <div class="ag-servicos">${icon('scissors', 12)}<span class="truncar">${servicosTxt} · ~${fmtDur(ag.duracaoPrevistaMin)}</span></div>
        ${cobranca
          ? html`<div class="ag-cobra ${cobranca.pagamento ? 'paga' : ''}">${icon('circle-dollar-sign', 12)}<span>${cobranca.pagamento ? `Mensalidade ${fmtBRL(cobranca.valorCentavos)} paga` : `Cobrar mensalidade ${fmtBRL(cobranca.valorCentavos)} neste banho`}</span></div>`
          : ''}
      </div>
      <div class="ag-direita">
        <div class="ag-valor">${valor}</div>
        ${ag.status === 'concluido' && ag.valorCentavos ? selo(situacaoPagamento(ag).texto, situacaoPagamento(ag).cls === 'verde' ? 'verde' : 'ambar', 'p') : selo(ag.pausadoEm && ag.status === 'em_atendimento' ? 'Pausado' : st.rotulo, st.tom, 'p')}
      </div>
      <div class="ag-acao"><button class="${acao.estilo}" data-acao="${acao.acao}" data-id="${ag.id}">${acao.rotulo}</button></div>
    </div>
  </div>`;
}

function linhaLivre(janela) {
  return html`<div class="ag-livre" data-acao="encaixar" data-inicio="${janela.inicio}">
    <div class="ag-linha-miolo">
      <div class="ag-hora">${fmtHora(janela.inicio)}</div>
      <div class="ag-divisor"></div>
      <div class="ag-livre-circulo">${icon('plus', 18)}</div>
      <div class="ag-info">
        <div class="ag-livre-titulo">Horário disponível</div>
        <div class="ag-livre-sub">${fmtHora(janela.inicio)} às ${fmtHora(janela.fim)} · ${janela.minutos}min livres — toque para encaixar um pet</div>
      </div>
      <div class="ag-acao"><span>Agendar aqui</span></div>
    </div>
  </div>`;
}

/* =============================== Visões ============================== */

function visaoDia(vm) {
  let itens = vm.linhas.map((l) => ({ ts: l.ag.inicio, l }));
  if (ui.livres) {
    const livres = horariosLivres(vm.de, vm.linhas.map((l) => l.ag), { ...vm.exp, minimo: 30 });
    itens = [...itens, ...livres.map((j) => ({ ts: j.inicio, j }))].sort((a, b) => a.ts - b.ts);
  }

  const aguardando = vm.linhas.filter((l) => AGUARDANDO.includes(l.ag.status)).length;
  const cabecalho = html`<div class="fila-cab">
    <span class="fila-titulo">Fila do dia</span>
    <div class="fila-dir">
      <span class="fila-contagem">${aguardando} aguardando</span>
      <button class="btn-livres${ui.livres ? ' on' : ''}" data-acao="livres" title="Exibir horários disponíveis para atendimento">
        ${icon('clock', 14)}<span>Horários disponíveis</span><div class="mini-trilho"></div>
      </button>
    </div>
  </div>`;

  if (!itens.length) {
    return html`${cabecalho}${vazio({
      icone: 'calendar-days',
      titulo: 'Nenhum atendimento neste dia',
      texto: 'Use “Horários disponíveis” para ver as janelas livres do expediente.',
      acao: html`<button class="btn btn-roxo" style="margin-top:6px" data-acao="novo-no-dia">${icon('plus', 15)}<span>Novo agendamento</span></button>`,
    })}`;
  }

  const porPagina = ehCelular() ? itens.length : ui.livres ? 6 : 4;
  const paginas = Math.max(1, Math.ceil(itens.length / porPagina));
  ui.pagina = Math.min(ui.pagina, paginas - 1);
  const ini = ui.pagina * porPagina;
  const visiveis = itens.slice(ini, ini + porPagina);

  return html`${cabecalho}
    <div>${visiveis.map((it) => (it.l ? linhaAgendamento(it.l) : linhaLivre(it.j)))}</div>
    ${paginas > 1
      ? html`<div class="fila-rodape">
          <span class="fila-faixa">${ini + 1}–${Math.min(ini + porPagina, itens.length)} de ${itens.length} ${ui.livres ? 'horários' : 'pets'}</span>
          <div class="fila-pag">
            <div class="fila-pontos">${Array.from({ length: paginas }, (_, i) => html`<button class="fila-ponto${i === ui.pagina ? ' on' : ''}" data-acao="pagina" data-pagina="${i}" aria-label="Página ${i + 1}"></button>`)}</div>
            <button class="fila-seta" data-acao="pagina" data-pagina="${ui.pagina - 1}" ${ui.pagina === 0 ? 'disabled' : ''}>${icon('chevron-left', 15)}</button>
            <button class="fila-seta" data-acao="pagina" data-pagina="${ui.pagina + 1}" ${ui.pagina >= paginas - 1 ? 'disabled' : ''}>${icon('chevron-right', 15)}</button>
          </div>
        </div>`
      : ''}`;
}

function visaoSemana(vm) {
  const inicio = inicioDaSemana(ui.ref);
  const temDomingo = vm.linhas.some((l) => new Date(l.ag.inicio).getDay() === 0);
  const dias = Array.from({ length: temDomingo ? 7 : 6 }, (_, i) => addDias(inicio, i));
  const hoje = Date.now();

  return html`<div class="semana">
    <div class="semana-grade" style="--colunas:${dias.length}">
      ${dias.map((dia) => {
        const doDia = vm.linhas.filter((l) => mesmoDia(l.ag.inicio, dia));
        const ehHoje = mesmoDia(dia, hoje);
        const pets = doDia.filter((l) => ATIVOS(l.ag)).length;
        return html`<div class="semana-col">
          <button class="semana-cab" data-acao="ver-dia" data-dia="${dia}">
            <div class="semana-dia">${DIAS_CURTOS[new Date(dia).getDay()]}</div>
            <div class="semana-num${ehHoje ? ' hoje' : ''}">${new Date(dia).getDate()}</div>
          </button>
          <div class="semana-itens">
            ${doDia.map(
              (l, i) => html`<button class="semana-item${ehHoje ? ' hoje' : ''}" style="border-left-color:${CORES_TRACO[i % 5]}" data-acao="abrir" data-id="${l.ag.id}">
                <div class="semana-item-hora">${fmtHora(l.ag.inicio)}</div>
                <div class="semana-item-pet">${l.pet.nome}</div>
                <div class="semana-item-serv">${l.itens.map((x) => x.nome).join(' + ') || '—'}</div>
              </button>`
            )}
          </div>
          <div class="semana-total">${pets} ${pets === 1 ? 'pet' : 'pets'}</div>
        </div>`;
      })}
    </div>
  </div>`;
}

function visaoMes(vm) {
  const primeiro = new Date(inicioDoMes(ui.ref));
  const mes = primeiro.getMonth();
  const inicioGrade = addDias(primeiro.getTime(), -primeiro.getDay());
  const ultimo = new Date(fimDoMes(ui.ref));
  const celulas = Math.ceil((primeiro.getDay() + ultimo.getDate()) / 7) * 7;
  const hoje = Date.now();

  return html`<div class="mes">
    <div class="mes-semana">${DIAS_CURTOS.map((d) => html`<div>${d}</div>`)}</div>
    <div class="mes-grade">
      ${Array.from({ length: celulas }, (_, i) => {
        const dia = addDias(inicioGrade, i);
        const d = new Date(dia);
        const noMes = d.getMonth() === mes;
        const doDia = noMes ? vm.linhas.filter((l) => mesmoDia(l.ag.inicio, dia) && ATIVOS(l.ag)) : [];
        const valor = doDia.reduce((s, l) => s + (l.ag.valorCentavos || 0), 0);
        const traco = doDia.length ? CORES_TRACO[d.getDate() % 5] : 'transparent';
        const cls = ['mes-dia', noMes ? '' : 'fora', mesmoDia(dia, hoje) ? 'hoje' : ''].join(' ');
        return html`<button class="${cls}" style="border-top-color:${traco}" data-acao="ver-dia" data-dia="${dia}">
          <div class="mes-num">${d.getDate()}</div>
          ${doDia.length ? html`<div class="mes-qtd">${doDia.length} ${doDia.length === 1 ? 'pet' : 'pets'}</div>` : ''}
          ${valor ? html`<div class="mes-valor">${fmtBRLCurto(valor)}</div>` : ''}
        </button>`;
      })}
    </div>
  </div>`;
}

function resumo(vm) {
  const ativos = vm.linhas.filter((l) => ATIVOS(l.ag));
  const concluidos = ativos.filter((l) => l.ag.status === 'concluido');
  const somar = (xs) => xs.reduce((s, l) => s + (l.ag.valorCentavos || 0), 0);
  const rotuloPets = ui.visao === 'Semana' ? 'Pets na semana' : ui.visao === 'Mês' ? 'Pets no mês' : mesmoDia(ui.ref, Date.now()) ? 'Pets hoje' : 'Pets no dia';

  const itens = [
    { rotulo: rotuloPets, valor: String(ativos.length), cor: 'var(--tinta-2)' },
    { rotulo: 'Concluídos', valor: String(concluidos.length), cor: 'var(--verde-escuro)' },
    { rotulo: 'Previsto', valor: fmtBRLCurto(somar(ativos)), cor: 'var(--tinta-2)' },
    // atendido = valor dos concluídos, pagos ou não (o que foi pago está no Faturamento)
    { rotulo: 'Atendido', valor: fmtBRLCurto(somar(concluidos)), cor: 'var(--roxo-escuro)' },
  ];
  return html`<div class="ag-resumo"><div class="ag-resumo-grade">
    ${itens.map(
      (r) => html`<div class="ag-resumo-item">
        <div class="ag-resumo-rotulo">${r.rotulo}</div>
        <div class="ag-resumo-valor" style="color:${r.cor}">${r.valor}</div>
      </div>`
    )}
  </div></div>`;
}

/* ================================ Tela =============================== */

export default {
  titulo: 'Agenda',
  menu: 'agenda',
  fab: true,

  async carregar() {
    const [de, ate] = periodo();
    const lista = await agendamentos.porPeriodo(de, ate);
    const mapaPets = new Map((await pets.listar()).map((p) => [p.id, p]));
    const mapaTutores = new Map((await tutores.listar()).map((t) => [t.id, t]));
    const itens = await agendamentos.itensDe(lista);
    // banhos de plano que cobram a mensalidade do mês (mesma regra do Faturamento)
    const cobrancas = new Map();
    const idsPlanos = new Set(lista.map((a) => a.planoId).filter(Boolean));
    for (const id of idsPlanos) {
      const plano = await planos.obter(id);
      if (!plano) continue;
      for (const m of await mensalidadesDoPlano(plano, de, ate)) {
        const visita = lista.find((a) => a.planoId === id && a.inicio === m.ts);
        if (visita) cobrancas.set(visita.id, m);
      }
    }
    const linhas = lista
      .map((ag) => {
        const pet = mapaPets.get(ag.petId);
        return pet ? { ag, pet, tutor: mapaTutores.get(pet.tutorId), itens: itens.get(ag.id) || [], cobranca: cobrancas.get(ag.id) || null } : null;
      })
      .filter(Boolean);
    return { de, ate, linhas, exp: await config.expediente() };
  },

  render(vm) {
    const corpo = ui.visao === 'Semana' ? visaoSemana(vm) : ui.visao === 'Mês' ? visaoMes(vm) : visaoDia(vm);
    return html`<div class="card r24 cortar">
      <div class="hero ag-hero">
        ${patinhasHero('agenda')}
        <div class="hero-conteudo ag-topo">
          <span class="ag-topo-titulo">Resumo do dia</span>
          <div class="nav-periodo">
            <button class="seta" data-acao="anterior" aria-label="Anterior">${icon('chevron-left', 15)}</button>
            <button class="nav-periodo-rotulo" data-acao="hoje" title="Voltar para hoje">${rotuloPeriodo()}</button>
            <button class="seta" data-acao="proximo" aria-label="Próximo">${icon('chevron-right', 15)}</button>
          </div>
          <div class="segmento">
            ${['Dia', 'Semana', 'Mês'].map((v) => html`<button class="${ui.visao === v ? 'on' : ''}" data-acao="visao" data-visao="${v}">${v}</button>`)}
          </div>
          <button class="btn-novo-hero" data-acao="novo-no-dia">${icon('plus', 15)}<span>Novo agendamento</span></button>
        </div>
      </div>
      ${resumo(vm)}
      <div class="ag-corpo">${corpo}</div>
    </div>`;
  },

  acoes: {
    anterior: (_, ctx) => mover(-1, ctx),
    proximo: (_, ctx) => mover(1, ctx),
    hoje: (_, ctx) => {
      ui.ref = Date.now();
      ui.pagina = 0;
      ctx.recarregar();
    },
    visao: ({ visao }, ctx) => {
      ui.visao = visao;
      ui.pagina = 0;
      ctx.recarregar();
    },
    'ver-dia': ({ dia }, ctx) => {
      ui.ref = Number(dia);
      ui.visao = 'Dia';
      ui.pagina = 0;
      ctx.recarregar();
    },
    livres: (_, ctx) => {
      ui.livres = !ui.livres;
      ui.pagina = 0;
      ctx.redesenhar();
    },
    pagina: ({ pagina }, ctx) => {
      ui.pagina = Math.max(0, Number(pagina));
      ctx.redesenhar();
    },
    'novo-no-dia': (_, ctx) => {
      const inicio = mesmoDia(ui.ref, Date.now()) ? null : new Date(inicioDoDia(ui.ref)).setHours(9, 0, 0, 0);
      ctx.navegar('novo-agendamento', { inicio });
    },
    encaixar: ({ inicio }, ctx) => ctx.navegar('novo-agendamento', { inicio }),

    abrir: async ({ id }, ctx) => {
      const ag = await agendamentos.obter(id);
      if (!ag) return;
      if (ag.status === 'em_atendimento') return ctx.navegar('atendimento', { id });
      if (ag.status === 'concluido') return ctx.navegar('ficha-pet', { id: ag.petId });
      ctx.navegar('novo-agendamento', { id });
    },
    editar: ({ id }, ctx) => ctx.navegar('novo-agendamento', { id }),
    'abrir-atendimento': ({ id }, ctx) => ctx.navegar('atendimento', { id }),
    finalizar: ({ id }, ctx) => ctx.navegar('finalizar', { id }),
    'ver-ficha': async ({ id }, ctx) => {
      const ag = await agendamentos.obter(id);
      if (ag) ctx.navegar('ficha-pet', { id: ag.petId });
    },
    chegada: async ({ id }, ctx) => {
      await agendamentos.registrarChegada(id);
      ctx.navegar('atendimento', { id });
    },
    confirmar: async ({ id }, ctx) => {
      await agendamentos.mudarStatus(id, 'confirmado');
      ctx.toast('Agendamento confirmado');
      ctx.recarregar();
    },
    receber: async ({ id }, ctx) => {
      const ag = await agendamentos.obter(id);
      if (!ag) return;
      const linha = ctx.vm.linhas.find((l) => l.ag.id === id);
      const r = await escolherFormaRecebimento(ctx, { titulo: 'Marcar como pago', valorCentavos: ag.valorCentavos, detalhe: linha?.pet?.nome || '' });
      if (!r) return;
      await agendamentos.registrarRecebimento(id, r.forma, r.quando, r.partes);
      ctx.toast(`Marcado como pago · ${descreverRecebimento(r)}`);
      ctx.recarregar();
    },
  },
};

function mover(direcao, ctx) {
  if (ui.visao === 'Semana') ui.ref = addDias(ui.ref, 7 * direcao);
  else if (ui.visao === 'Mês') {
    const d = new Date(ui.ref);
    ui.ref = new Date(d.getFullYear(), d.getMonth() + direcao, 1).getTime();
  } else ui.ref = addDias(ui.ref, direcao);
  ui.pagina = 0;
  ctx.recarregar();
}
