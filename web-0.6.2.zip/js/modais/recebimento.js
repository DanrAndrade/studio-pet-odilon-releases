import { html, icon, fmtBRL, valorData, deCampos, mesmoDia, paraCentavos, $ } from '../core/dom.js';
import { partesValidas, nomeDasPartes } from '../logic/pagamento.js';
import { chip } from '../core/ui.js';
import * as config from '../data/config.js';

/* Registrar um recebimento: pergunta a forma realmente usada e o dia em que foi
   pago (padrão: hoje). O faturamento do mês conta pela data do pagamento, então
   um pagamento marcado depois pode ser lançado no dia certo. */

const FORMAS_RESERVA = ['Dinheiro', 'PIX', 'Débito', 'Crédito', 'Boleto'];

/* Pago em mais de uma forma: um campo de valor por forma; precisa somar o total. */
const partesDe = (e) => e.formas.map((forma, i) => ({ forma, valorCentavos: paraCentavos(e['p-' + i] || '') })).filter((p) => p.valorCentavos > 0);
const somaDe = (e) => partesDe(e).reduce((s, p) => s + p.valorCentavos, 0);
const textoSoma = (e) => {
  const falta = e.valorCentavos - somaDe(e);
  if (!falta) return partesDe(e).length >= 2 ? 'Fechou o valor certinho' : 'Preencha pelo menos duas formas';
  return falta > 0 ? `Falta ${fmtBRL(falta)}` : `Passou ${fmtBRL(-falta)} do valor`;
};
const podeRegistrar = (e) => (e.dividir ? !!partesValidas(partesDe(e), e.valorCentavos) : !!e.forma);

const modal = {
  render: (e) => html`<div class="modal-fundo">
    <div class="modal m-430">
      <div class="modal-cab">
        <div>
          <div class="modal-titulo m">${e.titulo}</div>
          <div class="modal-sub">${e.sub}</div>
        </div>
        <button class="modal-fechar" data-acao="fechar-modal" aria-label="Fechar">${icon('x', 16)}</button>
      </div>
      <div>
        <div class="rotulo-campo" style="margin-bottom:8px">Como foi pago?</div>
        ${e.dividir
          ? html`<div class="partes-pagamento">
              ${e.formas.map((f, i) => html`<label class="parte-linha"><span>${f}</span><input class="entrada" data-campo="p-${i}" value="${e['p-' + i] || ''}" placeholder="R$ 0" inputmode="decimal" data-formato="moeda" aria-label="Valor pago em ${f}"></label>`)}
              <div class="parte-soma" id="parte-soma">${textoSoma(e)}</div>
            </div>`
          : html`<div class="chips">${e.formas.map((f) => chip(f, e.forma === f, 'forma', { forma: f }, { suave: true, cls: 'forte' }))}</div>`}
        ${e.podeDividir
          ? html`<button class="link-acao" style="margin-top:10px" data-acao="dividir">${e.dividir ? 'Pagou numa forma só' : 'Pagou com mais de uma forma (ex.: parte no PIX, parte em dinheiro)'}</button>`
          : ''}
        <div class="rotulo-campo" style="margin:14px 0 7px">Dia do pagamento</div>
        <input class="entrada campo-data" type="date" data-campo="data" value="${e.data}" max="${e.hoje}">
      </div>
      <div class="modal-rodape" style="margin-top:6px">
        <button class="btn btn-branco" data-acao="fechar-modal">Cancelar</button>
        <button class="btn btn-roxo" data-acao="ok" ${podeRegistrar(e) ? '' : 'disabled'}>Registrar recebimento</button>
      </div>
    </div>
  </div>`,

  // digitando os valores: atualiza só a soma e o botão (o campo não perde o foco)
  aoDigitar(campo, _, { estado }) {
    if (!campo.startsWith('p-')) return;
    const soma = $('#parte-soma');
    if (soma) soma.textContent = textoSoma(estado);
    const ok = $('#camada-modal [data-acao="ok"]');
    if (ok) ok.disabled = !podeRegistrar(estado);
  },

  acoes: {
    forma: ({ forma }, { atualizar }) => atualizar({ forma }),
    dividir: (_, { estado, atualizar }) => atualizar({ dividir: !estado.dividir }),
    ok: (_, { estado, fechar }) => {
      if (!podeRegistrar(estado)) return;
      const partes = estado.dividir ? partesValidas(partesDe(estado), estado.valorCentavos) : null;
      // hoje: a hora de agora; outro dia: meio-dia (só o dia importa para o relatório)
      const agora = Date.now();
      const dia = deCampos(estado.data, '12:00');
      const quando = !dia || mesmoDia(dia, agora) || dia > agora ? agora : dia;
      fechar(partes ? { forma: nomeDasPartes(partes), partes, quando } : { forma: estado.forma, partes: null, quando });
    },
  },
};

/**
 * Abre o modal e devolve { forma, partes, quando } (ou null se cancelar).
 * partes: [{ forma, valorCentavos }] quando foi pago em mais de uma forma; senão null.
 * podeDividir: false quando o mesmo pagamento cobre várias coisas de uma vez.
 */
export async function escolherFormaRecebimento(ctx, { titulo = 'Registrar recebimento', valorCentavos = 0, detalhe = '', podeDividir = true } = {}) {
  const configuradas = (await config.lista('Formas de pagamento')).filter((f) => f !== 'Incluso no plano' && f !== 'Fiado');
  const hoje = valorData(Date.now());
  return ctx.abrirModal(modal, {
    titulo,
    sub: [fmtBRL(valorCentavos), detalhe].filter(Boolean).join(' · '),
    formas: configuradas.length ? configuradas : FORMAS_RESERVA,
    forma: null,
    valorCentavos,
    podeDividir: podeDividir && valorCentavos > 0,
    dividir: false,
    data: hoje,
    hoje,
  });
}

/** Texto curto do recebimento para o aviso: "PIX" ou "PIX · pago em 12/10". */
export const descreverRecebimento = (r) => (mesmoDia(r.quando, Date.now()) ? r.forma : `${r.forma} · pago em ${new Date(r.quando).toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit' })}`);
