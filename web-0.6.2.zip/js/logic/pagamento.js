/* Situação de pagamento de um atendimento — o mesmo texto em todas as telas
   (Histórico, fichas do tutor e do pet, atendimento concluído). */

/** Banho que faz parte de um plano (pelo plano ou marcado como incluso). */
export const ehBanhoDePlano = (ag) => !!(ag?.planoId || ag?.origem === 'plano');

/**
 * @returns {{ chave: 'plano'|'semCobranca'|'naoPago'|'pago', texto: string, cls: string }}
 *   cls é o tom do selo: lavanda (plano/sem cobrança), ambar (não pago), verde (pago)
 */
export function situacaoPagamento(ag) {
  const valor = ag?.valorCentavos || 0;
  if (!valor && ehBanhoDePlano(ag)) return { chave: 'plano', texto: 'Incluso no plano', cls: 'lavanda' };
  if (!valor) return { chave: 'semCobranca', texto: 'Sem cobrança', cls: 'lavanda' };
  if (ag.pagamentoPendente) return { chave: 'naoPago', texto: 'Não pago', cls: 'ambar' };
  return { chave: 'pago', texto: `Pago${ag.formaPagamento ? ' · ' + ag.formaPagamento : ''}`, cls: 'verde' };
}

/**
 * Pagamento dividido em mais de uma forma (ex.: parte no PIX, parte em dinheiro):
 * [{ forma, valorCentavos }]. Só vale se tiver 2 partes ou mais e somar o valor total;
 * senão devolve null (pagamento numa forma só).
 */
export function partesValidas(partes, totalCentavos) {
  const lista = (partes || []).filter((p) => p && p.forma && p.valorCentavos > 0);
  if (lista.length < 2) return null;
  return lista.reduce((s, p) => s + p.valorCentavos, 0) === totalCentavos ? lista.map((p) => ({ forma: p.forma, valorCentavos: p.valorCentavos })) : null;
}

/** "PIX + Dinheiro" (o nome da forma que fica gravado e aparece nos selos). */
export const nomeDasPartes = (partes) => partes.map((p) => p.forma).join(' + ');

/** Quanto entrou em cada forma: [{ forma, valorCentavos }] (uma linha se não foi dividido). */
export const valoresPorForma = (forma, valorCentavos, partes) => (partes?.length ? partes : [{ forma: forma || 'Não informado', valorCentavos }]);

/** Atendimento com valor e já pago (é o que conta como "pago" nos totais). */
export const foiPago = (ag) => (ag?.valorCentavos || 0) > 0 && !ag.pagamentoPendente;
