/* O que mudou em cada versão, em poucas palavras: aparece no sino por 10 dias depois
   que a atualização entra, para o Odilon saber que ela chegou e o que mudou. */

export const NOVIDADES = {
  '0.7.1': [
    'O tempo agora é um só por atendimento: conta da chegada do pet até finalizar, sem as pausas. Os outros serviços (hidratação, corte de unha, tosa...) entram só com o valor.',
    'Serviços marcados como "Etapa comum do banho" (em Serviços) já vêm marcados no agendamento novo.',
    'Ao finalizar um banho de plano, a mensalidade recebida fica no dia do pagamento escolhido.',
    'Pets do mesmo tutor marcados juntos ficam cada um com o seu tempo estimado.',
  ],
  '0.6.6': [
    'No Histórico, cada atendimento mostra as duas datas: o dia em que foi atendido e o dia em que foi pago.',
    'Na ficha do pet, as últimas visitas mostram se foi pago e quando.',
  ],
  '0.6.5': [
    'O tempo de cada serviço não marca mais o horário como ocupado: o aviso aparece só quando outro pet está marcado para chegar no mesmo horário, e nunca impede de agendar.',
    'Dá para tirar um serviço que o pet não vai fazer no meio do atendimento (botão "Não fez").',
    'Horário da loja: seg a sex 8h às 18h com almoço 12h às 14h, sábado 8h às 12h30. Confira em Perfil → Editar dados da loja.',
  ],
};

export const DIAS_NO_SINO = 10;
