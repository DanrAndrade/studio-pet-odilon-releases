import {
  html, icon, fmtBRL, fmtDur, fmtHora, fmtDataCurta, digitos, paraCentavos, centavosParaCampo,
  valorData, valorHora, deCampos, addDias, inicioDoDia, fimDoDia, DIAS_CURTOS, DIAS_LONGOS, $,
} from '../core/dom.js';
import { avPet, tagsPet, chip, linhaToggle, patinhasHero, selo, vazio } from '../core/ui.js';
import { agendamentos, pets, tutores, servicos, planos, tempos, precoParaPorte, servicosInclusosNoPlano } from '../data/repo.js';
import * as config from '../data/config.js';
import { conflitos, foraDoExpediente } from '../logic/agenda.js';
import { servicoAvulso } from '../modais/servico-avulso.js';
import { planoVigente } from '../logic/planos.js';
import { textoDoDia } from '../logic/expediente.js';
import { escolher } from '../core/modais.js';
import { combina } from '../core/busca.js';
import { nomesDoTutor, nomesParaBusca, telefonesDoTutor } from '../logic/contatos.js';

/* NOVO AGENDAMENTO (e edição). A agenda é sempre manual: o app sugere a
   duração pelo histórico do pet, mas quem decide o horário é o groomer. */

const ui = { chave: null };

function proximoHorario() {
  const d = new Date();
  d.setMinutes(d.getMinutes() < 30 ? 30 : 60, 0, 0);
  return d.getTime();
}

function reiniciar(params, vm) {
  const inicio = params.inicio ? Number(params.inicio) : vm.ag?.inicio || proximoHorario();
  Object.assign(ui, {
    chave: vm.chave,
    petId: vm.ag?.petId || params.petId || null,
    busca: '',
    tutorFiltro: vm.ag ? null : params.tutorId || null,
    listaAberta: !(vm.ag?.petId || params.petId),
    selecionados: params.servicos ? params.servicos.split(',').filter(Boolean) : [],
    avulsos: [],
    data: valorData(inicio),
    hora: valorHora(inicio),
    desconto: centavosParaCampo(vm.ag?.descontoCentavos),
    acrescimo: centavosParaCampo(vm.ag?.acrescimoCentavos),
    forma: vm.ag?.formaPagamento && vm.ag.formaPagamento !== 'Incluso no plano' ? vm.ag.formaPagamento : null,
    lembrete: vm.ag ? !!vm.ag.lembrete : vm.chaves.whats,
    incluso: vm.ag?.origem === 'plano',
    repetir: false,
    // repetição: toda semana (7 dias) ou a cada 2 semanas (14 dias, quinzenal), sempre no mesmo dia da semana
    repetirCada: 7,
    repetirVezes: 4,
    // outros pets do mesmo tutor marcados junto (mesmo dia, horário e serviços; cada um com o seu agendamento)
    juntos: [],
    preselecionou: !!(vm.ag || params.servicos),
  });
  if (vm.itensAg) {
    ui.selecionados = vm.itensAg.filter((i) => i.servicoId).map((i) => i.servicoId);
    ui.avulsos = vm.itensAg
      .filter((i) => !i.servicoId)
      .map((i) => ({ chave: i.id, nome: i.nome, precoCentavos: i.precoCentavos, duracaoPrevistaMin: i.duracaoPrevistaMin }));
  }
}

async function carregar(params) {
  const chave = [params.id, params.petId, params.tutorId, params.inicio, params.servicos].join('|');
  const ag = params.id ? await agendamentos.obter(params.id) : null;
  const itensAg = ag ? await agendamentos.itens(ag.id) : null;
  const chaves = await config.obter('chaves');
  const vmBase = { chave, ag, itensAg, chaves };
  if (ui.chave !== chave) reiniciar(params, vmBase);

  const listaPets = await pets.listar();
  const mapaTutores = new Map((await tutores.listar()).map((t) => [t.id, t]));
  const comPlano = new Set((await planos.listar()).filter((p) => planoVigente(p)).map((p) => p.petId));
  const catalogo = await servicos.ativos();

  const pet = ui.petId ? listaPets.find((p) => p.id === ui.petId) || (await pets.obter(ui.petId)) : null;
  const tutor = pet ? mapaTutores.get(pet.tutorId) : null;

  // serviços da última visita viram a sugestão inicial para um pet recém-escolhido
  if (pet && !ui.preselecionou) {
    ui.preselecionou = true;
    const ultima = (await agendamentos.doPet(pet.id)).find((a) => a.status === 'concluido');
    if (ultima) ui.selecionados = (await agendamentos.itens(ultima.id)).map((i) => i.servicoId).filter((id) => catalogo.some((s) => s.id === id));
  }

  const info = new Map();
  for (const s of catalogo) {
    const loja = await tempos.mediaDaLoja(s.id);
    const estimativa = pet ? await tempos.estimar(pet, s) : { minutos: s.duracaoPadraoMin || 30, origem: 'padrao', amostras: 0 };
    info.set(s.id, { estimativa, realLoja: loja?.mediaMin || null, precoCentavos: pet ? precoParaPorte(s, pet.porte) : s.precoCentavos || 0 });
  }

  // pets do mesmo tutor que podem ser marcados junto (só em agendamento novo)
  const irmaos = pet && pet.tutorId && !ag ? listaPets.filter((p) => p.tutorId === pet.tutorId && p.id !== pet.id) : [];
  ui.juntos = ui.juntos.filter((id) => irmaos.some((p) => p.id === id));
  const extras = [];
  for (const outro of irmaos.filter((p) => ui.juntos.includes(p.id))) {
    const infoOutro = new Map();
    for (const s of catalogo.filter((x) => ui.selecionados.includes(x.id))) {
      infoOutro.set(s.id, { estimativa: await tempos.estimar(outro, s), precoCentavos: precoParaPorte(s, outro.porte) });
    }
    extras.push({ pet: outro, info: infoOutro, cobertos: await servicosInclusosNoPlano(outro.id) });
  }

  const inicio = deCampos(ui.data, ui.hora);
  const doDia = inicio ? await agendamentos.porPeriodo(inicioDoDia(inicio), fimDoDia(inicio)) : [];
  const nomesPets = new Map(listaPets.map((p) => [p.id, p.nome]));

  return {
    ...vmBase,
    listaPets: listaPets.map((p) => ({ pet: p, tutor: mapaTutores.get(p.tutorId), plano: comPlano.has(p.id) })),
    pet,
    tutor,
    irmaos: irmaos.map((p) => ({ pet: p, plano: comPlano.has(p.id) })),
    extras,
    tutorFiltro: ui.tutorFiltro ? mapaTutores.get(ui.tutorFiltro) || null : null,
    temPlano: pet ? comPlano.has(pet.id) : false,
    cobertos: pet ? await servicosInclusosNoPlano(pet.id) : new Set(),
    catalogo,
    info,
    doDia,
    nomesPets,
    formas: [...(await config.lista('Formas de pagamento')).filter((f) => f !== 'Incluso no plano' && f !== 'Fiado'), 'A definir'],
    exp: await config.expediente(),
    loja: await config.lojaComHorario(),
  };
}

/* Repetir: até o tamanho máximo do pacote (6 meses) = 24 vezes toda semana ou 12 a cada 2 semanas. */
const maxVezes = () => (ui.repetirCada === 7 ? 24 : 12);
const opcoesDeVezes = () => (ui.repetirCada === 7 ? [2, 3, 4, 5, 6, 8, 12, 16, 20, 24] : [2, 3, 4, 5, 6, 8, 10, 12]);

/**
 * Datas da repetição (sem contar a primeira): a cada 7 ou 14 dias, no mesmo dia da semana e horário.
 * Uma data em dia que a loja não abre vai para o próximo dia aberto (e é avisada).
 */
function datasDaRepeticao(inicio, exp) {
  const saida = [];
  for (let n = 1; n < ui.repetirVezes; n++) {
    let ts = addDias(inicio, ui.repetirCada * n);
    let movido = false;
    for (let i = 0; i < 6 && exp?.dias && !exp.dias.includes(new Date(ts).getDay()); i++) {
      ts = addDias(ts, 1);
      movido = true;
    }
    saida.push({ ts, movido });
  }
  return saida;
}

/* "Incluso no plano": se o pet tem plano ativo, só os serviços do plano saem sem custo
   (extras continuam cobrados); sem plano, o groomer está dizendo que nada é cobrado. */
const inclusoNoPlano = (vm, servicoId) => ui.incluso && (!vm.cobertos.size || vm.cobertos.has(servicoId));
const avulsoIncluso = (vm) => ui.incluso && !vm.cobertos.size;

function totais(vm) {
  const escolhidos = vm.catalogo.filter((s) => ui.selecionados.includes(s.id));
  const subtotal =
    escolhidos.reduce((t, s) => t + (inclusoNoPlano(vm, s.id) ? 0 : vm.info.get(s.id).precoCentavos), 0) +
    ui.avulsos.reduce((t, a) => t + (avulsoIncluso(vm) ? 0 : a.precoCentavos || 0), 0);
  const duracao = escolhidos.reduce((t, s) => t + vm.info.get(s.id).estimativa.minutos, 0) + ui.avulsos.reduce((t, a) => t + (a.duracaoPrevistaMin || 0), 0);
  const semCobranca = ui.incluso && !subtotal;
  const total = semCobranca ? 0 : Math.max(0, subtotal - paraCentavos(ui.desconto) + paraCentavos(ui.acrescimo));
  return { qtd: escolhidos.length + ui.avulsos.length, subtotal, duracao, total, semCobranca };
}

/* Pet marcado junto: os mesmos serviços, com o preço do porte e o tempo dele. Desconto e
   acréscimo ficam só no pet principal; "incluso no plano" vale para quem tem plano. */
const inclusoExtra = (ex, servicoId) => ui.incluso && ex.cobertos.has(servicoId);
function itensDoExtra(vm, ex) {
  return [
    ...vm.catalogo
      .filter((s) => ui.selecionados.includes(s.id))
      .map((s) => {
        const inf = ex.info.get(s.id);
        const minutos = inf?.estimativa.minutos || s.duracaoPadraoMin || 30;
        return { servicoId: s.id, nome: s.nome, categoria: s.categoria, precoCentavos: inclusoExtra(ex, s.id) ? 0 : inf?.precoCentavos || 0, duracaoPrevistaMin: minutos, mediaSeg: minutos * 60 };
      }),
    ...ui.avulsos.map((a) => ({ servicoId: null, nome: a.nome, categoria: 'Avulso', precoCentavos: a.precoCentavos || 0, duracaoPrevistaMin: a.duracaoPrevistaMin, mediaSeg: a.duracaoPrevistaMin * 60 })),
  ];
}
function totaisDoExtra(vm, ex) {
  const itens = itensDoExtra(vm, ex);
  const total = itens.reduce((t, i) => t + i.precoCentavos, 0);
  return { itens, total, duracao: itens.reduce((t, i) => t + (i.duracaoPrevistaMin || 0), 0), semCobranca: ui.incluso && !total && ex.cobertos.size > 0 };
}

const rotuloTotal = (t) => (t.semCobranca ? 'Incluso no plano' : fmtBRL(t.total));

function filtrarPets(vm) {
  // vindo do cartão do tutor, mostra só os pets dele até o usuário pedir todos
  const base = ui.tutorFiltro ? vm.listaPets.filter((l) => l.pet.tutorId === ui.tutorFiltro) : vm.listaPets;
  return base.filter(({ pet, tutor }) => combina(ui.busca, [pet.nome, pet.raca, ...nomesParaBusca(tutor)], telefonesDoTutor(tutor)));
}

function blocoPet(vm) {
  const lista = filtrarPets(vm);
  return html`<div class="painel">
    <div class="cab-card">
      <div class="titulo-card">Pet</div>
      <button class="link-acao" data-acao="lista">${icon(ui.listaAberta ? 'chevron-up' : 'list', 14)}<span>${ui.listaAberta ? 'Fechar lista' : 'Ver lista de pets'}</span></button>
    </div>
    <div class="busca" style="margin-bottom:12px">
      ${icon('search', 16)}
      <input data-campo="busca" value="${ui.busca}" placeholder="Buscar por pet, tutor ou telefone…">
      ${ui.busca ? html`<button data-acao="limpar-busca" style="color:var(--texto-3);display:flex" aria-label="Limpar">${icon('x', 15)}</button>` : ''}
    </div>

    ${vm.tutorFiltro
      ? html`<div class="filtro-tutor">
          ${icon('user-round', 14)}<span>Pets de <strong>${vm.tutorFiltro.nome || 'tutor'}</strong></span>
          <button class="link-acao" data-acao="ver-todos">Ver todos os pets</button>
        </div>`
      : ''}
    ${ui.listaAberta || ui.busca
      ? html`<div class="lista-pets">
          ${lista.length
            ? lista.map(
                ({ pet, tutor, plano }) => html`<button class="item-pet${pet.id === ui.petId ? ' on' : ''}" data-acao="escolher-pet" data-id="${pet.id}">
                  ${avPet(pet, 42, { borda: 0 })}
                  <span style="flex:1;min-width:0">
                    <span class="item-pet-nome" style="display:block">${pet.nome}</span>
                    <span class="item-pet-det truncar" style="display:block">${[pet.raca, pet.porte, nomesDoTutor(tutor)].filter(Boolean).join(' · ')}</span>
                  </span>
                  ${plano ? html`<span class="selo-plano">PLANO</span>` : ''}
                  <span style="color:var(--roxo-escuro)">${icon(pet.id === ui.petId ? 'check' : 'chevron-right', 16)}</span>
                </button>`
              )
            : html`<div class="vazio compacto">Nenhum pet encontrado para “${ui.busca}”.</div>`}
          <button class="lista-pets-rodape" data-acao="cadastrar">${icon('user-plus', 14)}<span>Cadastrar novo pet</span></button>
        </div>`
      : ''}

    ${vm.pet
      ? html`<div class="pet-escolhido">
          ${avPet(vm.pet, 56)}
          <div style="flex:1;min-width:0">
            <div class="pet-escolhido-titulo">${vm.pet.nome}${vm.pet.raca ? ` · ${vm.pet.raca}` : ''}</div>
            <div class="pet-escolhido-det">${[vm.tutor?.nome, vm.tutor?.telefone, vm.temPlano ? 'plano ativo' : ''].filter(Boolean).join(' · ') || 'Sem tutor cadastrado'}</div>
          </div>
          <div class="pet-escolhido-tags">${tagsPet(vm.pet).map((t) => selo(t.label, t.tom))}</div>
        </div>
        ${vm.irmaos.length
          ? html`<div class="juntos">
              <div class="rotulo-campo" style="margin:12px 0 7px">Marcar junto outro pet de ${vm.tutor?.nome || 'mesmo tutor'}</div>
              <div class="chips" style="gap:8px">${vm.irmaos.map(({ pet, plano }) => chip(pet.nome, ui.juntos.includes(pet.id), 'junto', { id: pet.id }, { suave: true, cls: 'mini', sub: plano ? 'plano' : null }))}</div>
              ${ui.juntos.length ? html`<div class="mutado" style="font-size:12px;margin-top:7px">Mesmo dia, horário e serviços. Cada pet fica com o seu agendamento, o seu atendimento e a sua cobrança.</div>` : ''}
            </div>`
          : ''}`
      : html`<div class="pet-escolhido" style="background:var(--superficie-3);border-style:dashed;border-color:var(--lavanda-forte);color:var(--texto-3)">
          ${icon('paw-print', 22)}<span style="font-size:13px">Escolha o pet na lista acima para ver serviços e tempos dele.</span>
        </div>`}
  </div>`;
}

function blocoServicos(vm, t) {
  return html`<div class="painel">
    <div class="cab-card">
      <div class="titulo-card">Serviços</div>
      <button class="link-acao" data-acao="avulso">+ Serviço não catalogado</button>
    </div>
    ${vm.catalogo.map((s) => {
      const on = ui.selecionados.includes(s.id);
      const inf = vm.info.get(s.id);
      const real = inf.realLoja ? fmtDur(inf.realLoja) : fmtDur(s.duracaoPadraoMin);
      return html`<button class="serv-opcao${on ? ' on' : ''}" data-acao="servico" data-id="${s.id}">
        <span class="caixa-check${on ? ' on' : ''}">${on ? icon('check', 13) : ''}</span>
        <span style="min-width:0">
          <span class="serv-opcao-nome" style="display:block">${s.nome}</span>
          <span class="serv-opcao-sub" style="display:block">${s.categoria} · tempo real médio ${real}</span>
        </span>
        <span class="pilula">${inclusoNoPlano(vm, s.id) ? 'Plano' : fmtBRL(inf.precoCentavos)}</span>
        <span class="pilula duracao" title="${vm.pet ? 'Estimativa para este pet' : 'Duração de referência'}">${fmtDur(inf.estimativa.minutos)}</span>
      </button>`;
    })}
    ${ui.avulsos.map(
      (a) => html`<div class="serv-opcao on">
        <button class="caixa-check on" data-acao="remover-avulso" data-chave="${a.chave}" aria-label="Remover">${icon('x', 13)}</button>
        <span style="min-width:0">
          <span class="serv-opcao-nome" style="display:block">${a.nome}</span>
          <span class="serv-opcao-sub" style="display:block">Não catalogado</span>
        </span>
        <span class="pilula">${avulsoIncluso(vm) ? 'Plano' : fmtBRL(a.precoCentavos)}</span>
        <span class="pilula duracao">${fmtDur(a.duracaoPrevistaMin)}</span>
      </div>`
    )}
    ${!vm.catalogo.length && !ui.avulsos.length ? vazio({ icone: 'scissors', titulo: 'Nenhum serviço ativo no catálogo', compacto: true }) : ''}
    <div class="serv-rodape">
      <div class="mutado" style="font-size:12.5px">${t.qtd} ${t.qtd === 1 ? 'serviço selecionado' : 'serviços selecionados'} · estimativa ${fmtDur(t.duracao)}</div>
      <div style="font-size:15.5px;font-weight:600;color:var(--tinta-2)">${fmtBRL(t.subtotal)}</div>
    </div>
  </div>`;
}

function blocoHorario(vm, t) {
  const inicio = deCampos(ui.data, ui.hora);
  const choques = inicio ? conflitos(inicio, t.duracao || 60, vm.doDia, vm.ag?.id) : [];
  const fora = inicio && foraDoExpediente(inicio, t.duracao || 60, vm.exp);

  return html`<div class="painel">
    <div class="titulo-card" style="margin-bottom:12px">Data e horário</div>
    <div class="grade-horario">
      <div>
        <div class="rotulo-campo" style="font-weight:500">Data</div>
        <input class="campo-data" type="date" data-campo="data" value="${ui.data}">
      </div>
      <div>
        <div class="rotulo-campo" style="font-weight:500">Horário de chegada</div>
        <input class="campo-data" type="time" data-campo="hora" value="${ui.hora}" step="300">
      </div>
    </div>
    ${vm.chaves.conflito && choques.length
      ? html`<div class="alerta-conflito">${icon('info', 15)}<span>Também marcado às ${fmtHora(inicio)}: ${choques
          .map((c) => vm.nomesPets.get(c.petId) || 'outro pet')
          .join(', ')}. Pode salvar normalmente.</span></div>`
      : ''}
    ${fora
      ? html`<div class="alerta-conflito${vm.chaves.foraExpediente ? '' : ' rosa'}">${icon('clock-alert', 15)}<span>${
          vm.chaves.foraExpediente
            ? `Fora do expediente (${textoDoDia(vm.exp.porDia, new Date(inicio).getDay())}). Pode salvar assim mesmo.`
            : `Fora do expediente (${textoDoDia(vm.exp.porDia, new Date(inicio).getDay())}). Para permitir, ative em Ajustes.`
        }</span></div>`
      : ''}
  </div>`;
}

function blocoValores(vm, t) {
  return html`<div class="painel">
    <div class="titulo-card" style="margin-bottom:10px">Valores</div>
    <div class="linha"><span class="l-rotulo">Subtotal</span><span class="l-valor" style="color:var(--texto-2)">${fmtBRL(t.subtotal)}</span></div>
    <div class="linha"><span class="l-rotulo">Desconto</span><input class="campo-inline" data-campo="desconto" value="${ui.desconto}" placeholder="—" inputmode="decimal" data-formato="moeda" ${t.semCobranca ? 'disabled' : ''}></div>
    <div class="linha"><span class="l-rotulo">Acréscimo</span><input class="campo-inline" data-campo="acrescimo" value="${ui.acrescimo}" placeholder="—" inputmode="decimal" data-formato="moeda" ${t.semCobranca ? 'disabled' : ''}></div>
    <div class="linha"><span class="l-rotulo">Total${vm.extras.length ? ` · ${vm.pet?.nome || ''}` : ''}</span><span class="l-valor" id="novo-total" style="font-weight:700">${rotuloTotal(t)}</span></div>
    ${vm.extras.map((ex) => {
      const te = totaisDoExtra(vm, ex);
      return html`<div class="linha"><span class="l-rotulo">${ex.pet.nome} · ${fmtDur(te.duracao)}</span><span class="l-valor" style="font-weight:600">${te.semCobranca ? 'Incluso no plano' : fmtBRL(te.total)}</span></div>`;
    })}
    ${vm.extras.length && (paraCentavos(ui.desconto) || paraCentavos(ui.acrescimo)) ? html`<div class="mutado" style="font-size:11.5px">Desconto e acréscimo valem só para ${vm.pet?.nome || 'o primeiro pet'}.</div>` : ''}
    ${t.semCobranca
      ? ''
      : html`<div style="margin-top:12px;font-size:12px;color:var(--texto-3);font-weight:500;margin-bottom:7px">Forma de pagamento prevista</div>
        <div class="chips">${vm.formas.map((f) => chip(f, ui.forma === f, 'forma', { forma: f }, { suave: true, cls: 'mini' }))}</div>`}
  </div>`;
}

export default {
  titulo: (vm) => (vm?.ag ? 'Editar agendamento' : 'Novo agendamento'),
  // aberto a partir do "Atendimento do dia", esse item continua aceso no menu e o salvar volta para lá
  menu: (params) => (params.origem === 'atendimento-dia' ? 'atendimento-dia' : 'agenda'),

  carregar,

  render(vm) {
    if (vm.ag && ['em_atendimento', 'concluido'].includes(vm.ag.status)) {
      return html`<div class="card pad-18">${vazio({
        icone: vm.ag.status === 'concluido' ? 'circle-check-big' : 'timer',
        titulo: vm.ag.status === 'concluido' ? 'Este atendimento já foi concluído' : 'Este pet já está em atendimento',
        texto: 'Horário e serviços não podem mais ser alterados por aqui.',
        acao: html`<button class="btn btn-branco" data-acao="${vm.ag.status === 'concluido' ? 'ficha' : 'atendimento'}">${vm.ag.status === 'concluido' ? 'Ver ficha do pet' : 'Abrir atendimento'}</button>`,
      })}</div>`;
    }

    const t = totais(vm);
    return html`<div class="card r24 cortar">
      <div class="hero">
        ${patinhasHero('padrao')}
        <div class="hero-conteudo novo-topo">
          <button class="voltar" style="margin:0;font-size:12.5px" data-acao="voltar">${icon('arrow-left', 14)}<span>Voltar para a agenda</span></button>
          <div class="novo-hero-acoes">
            <button class="btn btn-branco" data-acao="salvar" data-modo="iniciar">Salvar e iniciar</button>
            ${vm.ag ? '' : html`<button class="btn btn-branco" data-acao="salvar" data-modo="outro">Salvar e criar outro</button>`}
            <button class="btn btn-roxo" data-acao="salvar" data-modo="salvar">${icon('check', 15)}<span>${vm.ag ? 'Salvar alterações' : 'Salvar'}</span></button>
          </div>
        </div>
      </div>

      <div class="novo-grade">
        <div class="at-col">
          ${blocoPet(vm)}
          ${blocoServicos(vm, t)}
          ${blocoHorario(vm, t)}
        </div>
        <div class="at-col">
          ${blocoValores(vm, t)}
          <div class="painel" style="padding-top:8px">
            ${linhaToggle({ rotulo: 'Enviar lembrete pelo WhatsApp · 1 dia antes', ligado: ui.lembrete, acao: 'sw', attrs: { chave: 'lembrete' }, compacta: true })}
            ${linhaToggle({
              rotulo: 'Este atendimento está incluso no plano',
              dica: ui.incluso ? (vm.cobertos.size ? 'Serviços fora do plano continuam cobrados' : 'Este pet não tem plano ativo: nada será cobrado') : '',
              ligado: ui.incluso,
              acao: 'sw',
              attrs: { chave: 'incluso' },
              compacta: true,
            })}
            ${vm.ag ? '' : linhaToggle({ rotulo: 'Repetir este horário', dica: ui.repetir ? `${ui.repetirVezes} vezes no total, ${ui.repetirCada === 7 ? 'toda semana' : 'a cada 2 semanas'}, no mesmo dia e horário` : 'Semanal ou quinzenal, várias vezes de uma vez', ligado: ui.repetir, acao: 'sw', attrs: { chave: 'repetir' }, compacta: true })}
            ${!vm.ag && ui.repetir
              ? html`<div class="chips" style="gap:8px;margin:2px 0 6px">${[[7, 'Toda semana'], [14, 'A cada 2 semanas (quinzenal)']].map(([d, r]) => chip(r, ui.repetirCada === d, 'repetir-cada', { dias: d }, { suave: true, cls: 'mini' }))}</div>
                <div class="rotulo-campo" style="margin:4px 0 6px">Quantas vezes (contando esta)</div>
                <div class="chips" style="gap:8px;margin-bottom:6px">${opcoesDeVezes().map((n) => chip(String(n), ui.repetirVezes === n, 'repetir-vezes', { vezes: n }, { suave: true, cls: 'mini' }))}</div>
                <div class="mutado" style="font-size:11.5px;margin:-2px 0 6px">${ui.repetirCada === 7 ? '24 vezes toda semana = 6 meses' : '12 vezes a cada 2 semanas = 6 meses'}</div>
                ${(() => {
                  const inicioRep = deCampos(ui.data, ui.hora);
                  if (!inicioRep) return '';
                  const datas = datasDaRepeticao(inicioRep, vm.exp);
                  return html`<div class="mutado" style="font-size:12px;line-height:1.6">Também em: ${datas.map((d, i) => html`${i ? ', ' : ''}<strong>${DIAS_CURTOS[new Date(d.ts).getDay()]} ${fmtDataCurta(d.ts)}</strong>${d.movido ? ' (a loja não abre no dia certo: passou para o próximo dia aberto)' : ''}`)}</div>`;
                })()}`
              : ''}
          </div>
          ${vm.ag
            ? html`<div class="painel" style="display:flex;flex-direction:column;gap:12px;align-items:flex-start">
                <div class="titulo-card">Este agendamento</div>
                ${['agendado', 'confirmado'].includes(vm.ag.status) ? html`<button class="link-acao" style="color:var(--texto-2)" data-acao="falta">${icon('user-x', 14)}<span>Marcar que não compareceu</span></button>` : ''}
                <button class="link-perigo" data-acao="excluir">${icon('trash-2', 14)}<span>Excluir agendamento</span></button>
              </div>`
            : ''}
        </div>
      </div>
    </div>`;
  },

  aoDigitar(campo, valor, ctx) {
    ui[campo] = valor;
    if (campo === 'busca') {
      ui.listaAberta = true;
      ctx.redesenhar();
    } else if (campo === 'desconto' || campo === 'acrescimo') {
      const el = $('#novo-total');
      if (el) el.textContent = rotuloTotal(totais(ctx.vm));
    }
  },

  aoAlterar(campo, valor, ctx) {
    if (campo === 'data' || campo === 'hora') {
      ui[campo] = valor;
      ctx.recarregar();
    }
  },

  acoes: {
    'repetir-cada': ({ dias }, ctx) => {
      ui.repetirCada = Number(dias);
      // a cada 2 semanas vai até 12 vezes (6 meses): ajusta se estava acima
      ui.repetirVezes = Math.min(ui.repetirVezes, maxVezes());
      ctx.redesenhar();
    },
    'repetir-vezes': ({ vezes }, ctx) => {
      ui.repetirVezes = Number(vezes);
      ctx.redesenhar();
    },
    lista: (_, ctx) => {
      ui.listaAberta = !ui.listaAberta;
      ctx.redesenhar();
    },
    'limpar-busca': (_, ctx) => {
      ui.busca = '';
      ctx.redesenhar();
    },
    'escolher-pet': ({ id }, ctx) => {
      if (ui.petId !== id) {
        ui.petId = id;
        ui.preselecionou = false;
        ui.selecionados = [];
        ui.juntos = [];
      }
      ui.busca = '';
      if (window.matchMedia('(max-width: 760px)').matches) ui.listaAberta = false;
      ctx.recarregar();
    },
    'ver-todos': (_, ctx) => {
      ui.tutorFiltro = null;
      ui.listaAberta = true;
      ctx.recarregar();
    },
    cadastrar: (_, ctx) => ctx.navegar('cadastro', ui.tutorFiltro ? { tutorId: ui.tutorFiltro } : {}),
    servico: ({ id }, ctx) => {
      ui.selecionados = ui.selecionados.includes(id) ? ui.selecionados.filter((x) => x !== id) : [...ui.selecionados, id];
      // os pets marcados junto precisam do preço e do tempo deste serviço
      if (ui.juntos.length) ctx.recarregar();
      else ctx.redesenhar();
    },
    junto: ({ id }, ctx) => {
      ui.juntos = ui.juntos.includes(id) ? ui.juntos.filter((x) => x !== id) : [...ui.juntos, id];
      ctx.recarregar();
    },
    avulso: async (_, ctx) => {
      const novo = await servicoAvulso(ctx);
      if (!novo) return;
      ui.avulsos = [...ui.avulsos, { ...novo, chave: String(Date.now()) }];
      ctx.redesenhar();
    },
    'remover-avulso': ({ chave }, ctx) => {
      ui.avulsos = ui.avulsos.filter((a) => a.chave !== chave);
      ctx.redesenhar();
    },
    forma: ({ forma }, ctx) => {
      ui.forma = ui.forma === forma ? null : forma;
      ctx.redesenhar();
    },
    sw: ({ chave }, ctx) => {
      ui[chave] = !ui[chave];
      ctx.redesenhar();
    },
    salvar: ({ modo }, ctx) => salvar(ctx, modo),
    falta: async (_, ctx) => {
      await agendamentos.mudarStatus(ctx.vm.ag.id, 'nao_compareceu');
      ctx.toast('Marcado como não compareceu');
      ctx.navegar('agenda', {}, { substituir: true });
    },
    excluir: async (_, ctx) => {
      const nome = ctx.vm.pet?.nome || 'pet';
      const ok = await ctx.confirmar({
        titulo: `Excluir o agendamento de ${nome}?`,
        texto: 'Ele vai para a lixeira por 30 dias e pode ser restaurado em Ajustes.',
        botao: 'Mover para lixeira',
      });
      if (!ok) return;
      await agendamentos.excluir(ctx.vm.ag.id);
      ctx.toast('Agendamento movido para a lixeira');
      ctx.navegar('agenda', {}, { substituir: true });
    },
    ficha: (_, ctx) => ctx.navegar('ficha-pet', { id: ctx.vm.ag.petId }),
    atendimento: (_, ctx) => ctx.navegar('atendimento', { id: ctx.vm.ag.id }),
  },
};

async function salvar(ctx, modo) {
  const vm = ctx.vm;
  if (!vm.pet) return ctx.toast('Escolha o pet antes de salvar', { erro: true });
  const inicio = deCampos(ui.data, ui.hora);
  if (!inicio) return ctx.toast('Informe a data e o horário', { erro: true });

  const t = totais(vm);
  if (!vm.chaves.foraExpediente && foraDoExpediente(inicio, t.duracao || 60, vm.exp)) {
    return ctx.toast('Horário fora do expediente. Permita em Ajustes para salvar.', { erro: true });
  }

  const itens = [
    ...vm.catalogo
      .filter((s) => ui.selecionados.includes(s.id))
      .map((s) => {
        const inf = vm.info.get(s.id);
        return {
          servicoId: s.id,
          nome: s.nome,
          categoria: s.categoria,
          precoCentavos: inclusoNoPlano(vm, s.id) ? 0 : inf.precoCentavos,
          duracaoPrevistaMin: inf.estimativa.minutos,
          mediaSeg: inf.estimativa.minutos * 60,
        };
      }),
    ...ui.avulsos.map((a) => ({
      servicoId: null,
      nome: a.nome,
      categoria: 'Avulso',
      precoCentavos: avulsoIncluso(vm) ? 0 : a.precoCentavos,
      duracaoPrevistaMin: a.duracaoPrevistaMin,
      mediaSeg: a.duracaoPrevistaMin * 60,
    })),
  ];

  const base = vm.ag || {};
  const status = !vm.ag || ['cancelado', 'nao_compareceu'].includes(vm.ag.status) ? 'agendado' : vm.ag.status;
  const dados = {
    ...base,
    petId: vm.pet.id,
    tutorId: vm.pet.tutorId || null,
    inicio,
    status,
    origem: ui.incluso ? 'plano' : 'avulso',
    descontoCentavos: t.semCobranca ? 0 : paraCentavos(ui.desconto),
    acrescimoCentavos: t.semCobranca ? 0 : paraCentavos(ui.acrescimo),
    formaPagamento: t.semCobranca ? 'Incluso no plano' : ui.forma && ui.forma !== 'A definir' ? ui.forma : null,
    lembrete: ui.lembrete,
    lembreteEnviadoEm: base.inicio === inicio ? base.lembreteEnviadoEm || null : null,
    observacoes: base.observacoes || [],
  };

  // banho de plano mudou de dia: só ele, ou ele e os seguintes do plano
  let mover = 0;
  const dias = vm.ag?.planoId ? Math.round((inicioDoDia(inicio) - inicioDoDia(vm.ag.inicio)) / 86400000) : 0;
  if (dias) {
    const seguintes = await agendamentos.seguintesDoPlano(vm.ag.planoId, vm.ag.inicio, vm.ag.id);
    if (seguintes.length) {
      const resposta = await escolher({
        titulo: 'Mudar só este banho?',
        texto: `Este banho do plano passa para ${fmtDataCurta(inicio)}. Os próximos ${seguintes.length} banhos do plano podem continuar nas datas de hoje ou andar junto.`,
        opcoes: [
          { valor: 'so', rotulo: 'Só este banho', sub: 'Os outros banhos continuam nas mesmas datas' },
          { valor: 'seguintes', rotulo: 'Este e os seguintes', sub: `Os próximos ${seguintes.length} banhos passam a contar a partir deste, no ritmo do plano (sempre ${DIAS_LONGOS[new Date(inicio).getDay()].toLowerCase()}, no mesmo horário)` },
        ],
      });
      if (!resposta) return;
      if (resposta === 'seguintes') {
        mover = dias;
        dados.planoAncora = true;
      } else {
        // só este: deixa de ser o ponto de onde os seguintes contam
        dados.planoAncora = false;
        dados.planoManual = true;
      }
    }
  }

  const ag = await agendamentos.gravarComItens(dados, itens);
  // confere as datas que andaram ou foram criadas: dia fechado e horário ocupado viram aviso
  const avisosDatas = [];
  const conferir = async (ts, duracao, ignorar = []) => {
    const doDia = await agendamentos.porPeriodo(inicioDoDia(ts), fimDoDia(ts));
    const choque = conflitos(ts, duracao, doDia.filter((a) => !ignorar.includes(a.id)));
    if (!vm.exp.dias.includes(new Date(ts).getDay())) avisosDatas.push(`${fmtDataCurta(ts)}: a loja não abre`);
    else if (choque.length) avisosDatas.push(`${fmtDataCurta(ts)}: outro pet no mesmo horário`);
  };
  let movidos = [];
  if (mover) {
    movidos = await agendamentos.alinharSeguintesDoPlano(vm.ag.planoId, ag.id);
    movidos = (await agendamentos.doPlano(vm.ag.planoId)).filter((v) => movidos.some((x) => x.id === v.id));
    for (const v of movidos) await conferir(v.inicio, v.duracaoPrevistaMin || 60, [v.id]);
  }
  const repeticao = ui.repetir && !vm.ag ? datasDaRepeticao(inicio, vm.exp) : [];
  for (const d of repeticao) {
    await conferir(d.ts, t.duracao || 60);
    const { id, criadoEm, ...semId } = dados;
    await agendamentos.gravarComItens({ ...semId, inicio: d.ts }, itens);
  }
  const repetidos = repeticao.length;
  // pets do mesmo tutor marcados junto: um agendamento para cada, no mesmo horário (e nas mesmas repetições)
  const criadosJuntos = [];
  for (const ex of vm.extras) {
    const te = totaisDoExtra(vm, ex);
    const dadosEx = {
      petId: ex.pet.id,
      tutorId: ex.pet.tutorId || null,
      inicio,
      status: 'agendado',
      origem: ui.incluso && ex.cobertos.size ? 'plano' : 'avulso',
      descontoCentavos: 0,
      acrescimoCentavos: 0,
      formaPagamento: te.semCobranca ? 'Incluso no plano' : ui.forma && ui.forma !== 'A definir' ? ui.forma : null,
      lembrete: ui.lembrete,
      lembreteEnviadoEm: null,
      observacoes: [],
    };
    criadosJuntos.push(await agendamentos.gravarComItens(dadosEx, te.itens));
    for (const d of repeticao) await agendamentos.gravarComItens({ ...dadosEx, inicio: d.ts }, te.itens);
  }
  ui.chave = null;
  const extra = [
    criadosJuntos.length ? `junto com ${vm.extras.map((ex) => ex.pet.nome).join(' e ')}` : '',
    repetidos ? `e mais ${repetidos} ${repetidos === 1 ? 'vez' : 'vezes'}, ${ui.repetirCada === 7 ? 'toda semana' : 'a cada 2 semanas'}` : '',
    mover ? `${movidos.length} ${movidos.length === 1 ? 'banho seguinte do plano ajustado' : 'banhos seguintes do plano ajustados'}` : '',
    avisosDatas.length ? `atenção: ${avisosDatas.join('; ')}` : '',
  ].filter(Boolean).join(' · ');

  if (modo === 'iniciar') {
    await agendamentos.registrarChegada(ag.id);
    for (const outro of criadosJuntos) await agendamentos.registrarChegada(outro.id);
    if (criadosJuntos.length) {
      ctx.toast(`Agendamentos salvos · atendimentos iniciados${extra ? ' · ' + extra : ''}`);
      return ctx.navegar('atendimento-dia', {}, { substituir: true });
    }
    ctx.toast(`Agendamento salvo · atendimento iniciado${extra ? ' · ' + extra : ''}`);
    return ctx.navegar('atendimento', { id: ag.id }, { substituir: true });
  }
  if (modo === 'outro') {
    ctx.toast(`Agendamento salvo${extra ? ' · ' + extra : ''} · formulário limpo para o próximo`);
    return ctx.navegar('novo-agendamento', { inicio: inicio + t.duracao * 60000, origem: ctx.params.origem }, { substituir: true });
  }
  ctx.toast(`Agendamento salvo${extra ? ' · ' + extra : ''}`, { erro: avisosDatas.length > 0 });
  ctx.navegar(ctx.params.origem === 'atendimento-dia' ? 'atendimento-dia' : 'agenda', {}, { substituir: true });
}
