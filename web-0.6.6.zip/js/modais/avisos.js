import { html, icon, fmtHora, fmtBRL, fmtDataCurta, mesmoDia, addDias, inicioDoDia, fimDoDia, DIA_MS, DIAS_LONGOS } from '../core/dom.js';
import { aniversariosProximos } from '../logic/aniversarios.js';
import { agendamentos, pets, tutores, servicos, tempos, faturamento, dataDoAtendimento } from '../data/repo.js';
import * as config from '../data/config.js';
import { estatisticasPet } from '../logic/metricas.js';
import { atualizarModal } from '../core/modais.js';
import { abrirWhatsapp } from './whatsapp.js';
import { NOVIDADES, DIAS_NO_SINO } from '../logic/novidades.js';

/* Avisos do sino: pontos que precisam de atenção hoje, calculados dos dados. */

const TONS = {
  ambar: ['var(--ambar-fundo)', 'var(--ambar)'],
  rosa: ['var(--rosa-fundo)', 'var(--rosa)'],
  roxo: ['var(--lavanda-2)', 'var(--roxo-escuro)'],
};

export async function calcularAvisos() {
  const avisos = [];
  const agora = Date.now();
  // 0. a atualização que entrou e o que mudou nela
  const atualizado = await config.obter('atualizadoPara');
  if (atualizado && NOVIDADES[atualizado.versao] && agora - atualizado.em < DIAS_NO_SINO * DIA_MS) {
    avisos.push({
      icone: 'sparkles', tom: 'roxo', titulo: `App atualizado para a versão ${atualizado.versao}`,
      texto: NOVIDADES[atualizado.versao].join(' '),
      botao: 'Ver agenda', tipo: 'rota', rota: 'agenda',
    });
  }
  const amanha = addDias(agora, 1);
  const mapaPets = new Map((await pets.listar()).map((p) => [p.id, p]));
  const mapaTutores = new Map((await tutores.listar()).map((t) => [t.id, t]));
  const artigo = (pet) => (pet.sexo === 'Fêmea' ? 'da' : 'do');

  // 1. rascunhos de plano de hoje e amanhã ainda não confirmados
  const proximos = await agendamentos.porPeriodo(inicioDoDia(agora), fimDoDia(amanha));
  for (const ag of proximos.filter((a) => a.status === 'rascunho_plano')) {
    const pet = mapaPets.get(ag.petId);
    if (!pet) continue;
    avisos.push({
      icone: 'file-clock', tom: 'ambar', titulo: 'Rascunho de plano sem confirmação',
      texto: `${pet.nome} · ${mesmoDia(ag.inicio, agora) ? 'hoje' : 'amanhã'} ${fmtHora(ag.inicio)} · confirme o horário com o tutor.`,
      botao: 'Confirmar', tipo: 'confirmar', agId: ag.id,
    });
  }

  // 2. lembretes de amanhã ainda não enviados
  const chaves = await config.obter('chaves');
  if (chaves.whats) {
    const deAmanha = proximos.filter((a) => mesmoDia(a.inicio, amanha) && ['agendado', 'confirmado'].includes(a.status) && !a.lembreteEnviadoEm && a.lembrete !== false);
    for (const ag of deAmanha.slice(0, 5)) {
      const pet = mapaPets.get(ag.petId);
      if (!pet) continue;
      avisos.push({
        icone: 'message-circle', tom: 'roxo', titulo: `Lembrar tutor ${artigo(pet)} ${pet.nome}`,
        texto: `Atendimento amanhã às ${fmtHora(ag.inicio)}.`,
        botao: 'Avisar', tipo: 'lembrete', agId: ag.id, petId: pet.id,
      });
    }
  }

  // 3. concluídos sem forma de pagamento / pendentes antigos
  const concluidos = await agendamentos.concluidos();
  for (const ag of concluidos.filter((a) => !a.formaPagamento && !a.pagamentoPendente && (a.valorCentavos || 0) > 0 && (a.finalizadoEm || 0) > addDias(agora, -7))) {
    const pet = mapaPets.get(ag.petId);
    if (!pet) continue;
    avisos.push({
      icone: 'circle-dollar-sign', tom: 'rosa', titulo: 'Atendimento sem forma de pagamento',
      texto: `${pet.nome} foi concluído às ${fmtHora(ag.finalizadoEm || ag.inicio)} sem forma de pagamento.`,
      botao: 'Ver', tipo: 'rota', rota: 'historico',
    });
  }
  // conta pela data do atendimento (a mesma do Faturamento)
  const antigos = concluidos.filter((a) => a.pagamentoPendente && (a.valorCentavos || 0) > 0 && agora - dataDoAtendimento(a) > 15 * DIA_MS);
  if (antigos.length) {
    avisos.push({
      icone: 'circle-dollar-sign', tom: 'rosa',
      titulo: `${antigos.length} ${antigos.length === 1 ? 'atendimento não pago' : 'atendimentos não pagos'} há mais de 15 dias`,
      texto: `Total de ${fmtBRL(antigos.reduce((s, a) => s + (a.valorCentavos || 0), 0))} · marque como pago no Faturamento ou no Histórico.`,
      botao: 'Ver', tipo: 'rota', rota: 'faturamento',
    });
  }

  // 3b. mensalidades de plano vencidas e ainda não recebidas
  const mensalidades = await faturamento.mensalidadesAbertas();
  if (mensalidades.length) {
    avisos.push({
      icone: 'repeat', tom: 'rosa',
      titulo: `${mensalidades.length} ${mensalidades.length === 1 ? 'mensalidade de plano em aberto' : 'mensalidades de plano em aberto'}`,
      texto: `Total de ${fmtBRL(mensalidades.reduce((s, m) => s + m.valorCentavos, 0))} · marque como paga no Faturamento ou no Histórico.`,
      botao: 'Ver', tipo: 'rota', rota: 'faturamento',
    });
  }

  // 3c. correção das datas quinzenais (0.5.8): o que mudou, para avisar os clientes (14 dias)
  const ajuste = (await config.obter('migracoes'))?.quinzenal14;
  if (ajuste && agora - ajuste.em < 14 * DIA_MS && ((ajuste.lista || []).length || (ajuste.naoMovidos || []).length)) {
    const fmt = (ts) => `${DIAS_LONGOS[new Date(ts).getDay()].slice(0, 3).toLowerCase()} ${fmtDataCurta(ts)}`;
    const itens = (ajuste.lista || []).map((x) => `${x.pet}: ${fmt(x.de)} → ${fmt(x.para)}`);
    const ficaram = (ajuste.naoMovidos || []).map((x) => `${x.pet} em ${fmt(x.de)} (${x.motivo})`);
    avisos.push({
      icone: 'calendar-check', tom: 'ambar',
      titulo: `Quinzenal agora é a cada 2 semanas · ${itens.length} ${itens.length === 1 ? 'banho mudou' : 'banhos mudaram'} de dia`,
      texto: [itens.length ? `Avise os clientes: ${itens.join('; ')}.` : '', ficaram.length ? ` Ficaram na data antiga, ajuste na folha do plano: ${ficaram.join('; ')}.` : ''].join('').trim(),
      botao: 'Ver agenda', tipo: 'rota', rota: 'agenda',
    });
  }

  // 3d. datas dos planos de volta ao ritmo (0.6.0): o que mudou, para avisar os clientes (14 dias)
  const ritmo = (await config.obter('migracoes'))?.ritmoDosPlanos;
  if (ritmo && agora - ritmo.em < 14 * DIA_MS && ((ritmo.lista || []).length || (ritmo.naoMovidos || []).length)) {
    const fmt = (ts) => `${DIAS_LONGOS[new Date(ts).getDay()].slice(0, 3).toLowerCase()} ${fmtDataCurta(ts)}`;
    const itens = (ritmo.lista || []).filter((x) => x.para >= inicioDoDia(agora)).map((x) => `${x.pet}: ${fmt(x.de)} → ${fmt(x.para)}${x.junto ? ` (mesmo horário de ${x.junto})` : ''}`);
    const ficaram = (ritmo.naoMovidos || []).filter((x) => x.de >= inicioDoDia(agora)).map((x) => `${x.pet} em ${fmt(x.de)} (${x.motivo}; o certo seria ${fmt(x.para)})`);
    if (itens.length || ficaram.length) {
      avisos.push({
        icone: 'calendar-check', tom: 'ambar',
        titulo: `Datas dos planos acertadas · ${itens.length} ${itens.length === 1 ? 'banho mudou' : 'banhos mudaram'} de dia`,
        texto: [itens.length ? `Todos os planos voltaram ao ritmo do 1º banho, sempre no mesmo dia da semana. Avise os clientes: ${itens.join('; ')}.` : '', ficaram.length ? ` Não mudaram, confira: ${ficaram.join('; ')}.` : ''].join('').trim(),
        botao: 'Ver agenda', tipo: 'rota', rota: 'agenda',
      });
    }
  }

  // 4. retorno atrasado (sem nada marcado para frente)
  const porPet = new Map();
  for (const ag of concluidos) {
    if (!porPet.has(ag.petId)) porPet.set(ag.petId, []);
    porPet.get(ag.petId).push(ag);
  }
  const futuros = new Set(
    (await agendamentos.porPeriodo(inicioDoDia(agora), addDias(agora, 60))).filter((a) => a.status !== 'cancelado').map((a) => a.petId)
  );
  const atrasados = [];
  for (const [petId, lista] of porPet) {
    const pet = mapaPets.get(petId);
    if (!pet || futuros.has(petId)) continue;
    const st = estatisticasPet(lista, new Map());
    if (st.retornoAtrasado) atrasados.push({ pet, st });
  }
  atrasados
    .sort((a, b) => b.st.diasDesdeUltima - b.st.frequenciaDias - (a.st.diasDesdeUltima - a.st.frequenciaDias))
    .slice(0, 3)
    .forEach(({ pet, st }) =>
      avisos.push({
        icone: 'clock-alert', tom: 'ambar', titulo: 'Retorno atrasado',
        texto: `${pet.nome} costuma vir a cada ${st.frequenciaDias} dias — último atendimento há ${st.diasDesdeUltima} dias.`,
        botao: 'Avisar', tipo: 'retorno', petId: pet.id,
      })
    );

  // 5. aniversários: os próximos 7 dias e os que passaram há até 7 dias sem parabéns enviado.
  // Todos os pets com nascimento entram; o sino não depende de o app ter sido aberto no dia.
  for (const { pet, dias, ts, idade } of aniversariosProximos([...mapaPets.values()], agora)) {
    const nome = `${artigo(pet)} ${pet.nome}`;
    const quando =
      dias === 0 ? `Hoje é aniversário ${nome}`
      : dias === 1 ? `Amanhã é aniversário ${nome}`
      : dias > 1 ? `Aniversário ${nome} ${DIAS_LONGOS[new Date(ts).getDay()].toLowerCase()}, ${fmtDataCurta(ts)}`
      : dias === -1 ? `Ontem foi aniversário ${nome}`
      : `Aniversário ${nome} foi em ${fmtDataCurta(ts)}`;
    avisos.push({
      icone: 'cake', tom: dias < 0 ? 'ambar' : 'roxo', titulo: quando,
      texto: `${idade} ${idade === 1 ? 'ano' : 'anos'}${dias < 0 ? ' · parabéns ainda não enviado' : ' · mande um carinho para o tutor'}`,
      botao: 'Enviar', tipo: 'aniversario', petId: pet.id, aniversarioTs: ts,
    });
  }

  // 5b. serviços ativos sem preço (ex.: os de exemplo zerados): some quando ele cadastra
  const semPreco = (await servicos.ativos()).filter((sv) => !sv.precoCentavos && !Object.values(sv.precoPorPorte || {}).some(Boolean));
  if (semPreco.length) {
    avisos.push({
      icone: 'tag', tom: 'ambar',
      titulo: semPreco.length === 1 ? '1 serviço sem preço' : `${semPreco.length} serviços sem preço`,
      texto: `${semPreco.map((sv) => sv.nome).join(', ')} · cadastre em Serviços (ou ajuste o preço ao finalizar).`,
      botao: 'Abrir', tipo: 'rota', rota: 'servicos',
    });
  }

  // 6. tempo de referência do catálogo muito diferente do real
  for (const s of await servicos.ativos()) {
    const loja = await tempos.mediaDaLoja(s.id);
    if (!loja || loja.qtd < 5 || !s.duracaoPadraoMin) continue;
    if (Math.abs(loja.mediaMin - s.duracaoPadraoMin) / s.duracaoPadraoMin >= 0.25) {
      const f = (m) => (m >= 60 ? `${Math.floor(m / 60)}h${String(m % 60).padStart(2, '0')}` : `${m}min`);
      avisos.push({
        icone: 'timer', tom: 'roxo', titulo: 'Tempo padrão desatualizado',
        texto: `${s.nome} leva em média ${f(loja.mediaMin)}, o catálogo diz ${f(s.duracaoPadraoMin)}.`,
        botao: 'Ajustar', tipo: 'rota', rota: 'servicos',
      });
    }
  }

  // guarda os mapas para as ações do modal
  avisos.forEach((a) => {
    a.pet = mapaPets.get(a.petId);
    a.tutor = a.pet ? mapaTutores.get(a.pet.tutorId) : null;
  });
  return avisos;
}

export const modalAvisos = {
  render: (e) => html`<div class="modal-fundo topo-direita">
    <div class="modal m-430">
      <div class="modal-cab">
        <div>
          <div class="modal-titulo" style="font-size:16.5px">Avisos</div>
          <div class="modal-sub">Pontos que precisam da sua atenção hoje</div>
        </div>
        <button class="modal-fechar" data-acao="fechar-modal" aria-label="Fechar">${icon('x', 16)}</button>
      </div>
      <div style="display:flex;flex-direction:column;gap:9px">
        ${!e.lista
          ? html`<div class="vazio compacto">Carregando…</div>`
          : e.lista.length
            ? e.lista.map((a, i) => {
                const [fundo, cor] = TONS[a.tom] || TONS.roxo;
                return html`<div class="aviso-item">
                  <div class="aviso-icone" style="background:${fundo};color:${cor}">${icon(a.icone, 16)}</div>
                  <div style="flex:1;min-width:0">
                    <div class="aviso-item-titulo">${a.titulo}</div>
                    <div class="aviso-item-texto">${a.texto}</div>
                  </div>
                  <button class="aviso-botao" data-acao="executar" data-indice="${i}">${a.botao}</button>
                </div>`;
              })
            : html`<div class="vazio compacto">${icon('circle-check-big', 22)}<div class="vazio-titulo">Tudo em dia</div><div>Nenhum ponto de atenção agora.</div></div>`}
      </div>
    </div>
  </div>`,

  aoMontar: (_, estado) => {
    if (estado.lista || estado.carregando) return;
    estado.carregando = true;
    calcularAvisos().then((lista) => atualizarModal({ lista }));
  },

  acoes: {
    executar: async ({ indice }, { estado, fechar, ctx }) => {
      const a = estado.lista[Number(indice)];
      fechar(null);
      if (a.tipo === 'confirmar') {
        await agendamentos.mudarStatus(a.agId, 'confirmado');
        ctx.toast('Agendamento confirmado');
        ctx.recarregar();
      } else if (a.tipo === 'rota') {
        ctx.navegar(a.rota);
      } else if (a.tipo === 'lembrete') {
        await abrirWhatsapp(ctx, { tutor: a.tutor, pet: a.pet, ag: await agendamentos.obter(a.agId) });
      } else if (a.tipo === 'retorno') {
        await abrirWhatsapp(ctx, { tutor: a.tutor, pet: a.pet, modelo: 'Retorno atrasado' });
      } else if (a.tipo === 'aniversario') {
        // enviado: sai do sino (vale para este aniversário; no ano que vem avisa de novo)
        if (await abrirWhatsapp(ctx, { tutor: a.tutor, pet: a.pet, modelo: 'Aniversário', aniversarioTs: a.aniversarioTs })) {
          const pet = await pets.obter(a.petId);
          if (pet) await pets.salvar({ ...pet, parabensEnviadoPara: a.aniversarioTs });
        }
      }
      ctx.atualizarAvisos();
    },
  },
};
