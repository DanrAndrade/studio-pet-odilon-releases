import { STORES, obter as obterRegistro, put } from './db.js';
import { ordemAlfabetica } from '../core/busca.js';

/* Preferências e dados da loja, guardados como pares chave/valor. */

export const LISTAS_PADRAO = {
  'Tipos de ocorrência': ['Comportamento', 'Machucado / pele', 'Atraso do tutor', 'Equipamento', 'Outro'],
  'Categorias de serviço': ['Banho', 'Tosa', 'Estética', 'Adicional', 'Saúde'],
  'Lista de raças': ['SRD', 'Golden Retriever', 'Labrador', 'Poodle', 'Shih Tzu', 'Yorkshire', 'Lhasa Apso', 'Spitz Alemão', 'Persa', 'Siamês'],
  'Alertas de saúde': ['Pele sensível', 'Alergia a shampoo comum', 'Cardíaco', 'Idoso', 'Epilepsia', 'Pós-cirúrgico'],
  Temperamentos: ['Calmo', 'Agitado', 'Morde', 'Arranha', 'Estressa no secador', 'Medroso', 'Dócil', 'Territorial', 'Brincalhão'],
  'Formas de pagamento': ['Dinheiro', 'PIX', 'Débito', 'Crédito', 'Boleto', 'Fiado', 'Incluso no plano'],
};

const PADROES = {
  loja: {
    nome: 'Studio Pet Odilon Groomer',
    endereco: '',
    expediente: 'Seg a sáb · 08:00 às 18:00',
    cnpj: '',
    telefone: '',
    pix: '',
  },
  perfil: {
    nome: 'Odilon',
    funcao: 'Groomer responsável',
    email: '',
    telefone: '',
    foto: null,
    desde: null,
  },
  chaves: {
    conflito: true,
    foraExpediente: true,
    whats: true,
  },
  listas: LISTAS_PADRAO,
  ultimoBackup: null,
  // correções de dados que rodam uma única vez
  migracoes: {},
};

const cache = new Map();

// JSON em vez de structuredClone: roda também em WebViews antigos de tablet.
const clonar = (v) => (v === undefined || v === null ? null : JSON.parse(JSON.stringify(v)));

export async function obter(chave) {
  if (cache.has(chave)) return cache.get(chave);
  const registro = await obterRegistro(STORES.config, chave);
  const padrao = PADROES[chave];
  let valor = registro ? registro.valor : clonar(padrao);
  // novos campos adicionados em versões futuras entram com o valor padrão
  if (valor && padrao && typeof padrao === 'object' && !Array.isArray(padrao) && chave !== 'listas') {
    valor = { ...clonar(padrao), ...valor };
  }
  cache.set(chave, valor);
  return valor;
}

export async function salvar(chave, valor) {
  cache.set(chave, valor);
  await put(STORES.config, { chave, valor });
  return valor;
}

export async function atualizar(chave, parcial) {
  const atual = await obter(chave);
  return salvar(chave, { ...atual, ...parcial });
}

export const limparCache = () => cache.clear();

// listas que ficam na ordem em que foram cadastradas (as outras saem em ordem alfabética)
const ORDEM_DE_CADASTRO = new Set(['Formas de pagamento']);

export async function lista(nome) {
  const listas = await obter('listas');
  const itens = [...(listas[nome] || LISTAS_PADRAO[nome] || [])];
  return ORDEM_DE_CADASTRO.has(nome) ? itens : itens.sort(ordemAlfabetica);
}

export async function salvarLista(nome, itens) {
  const listas = await obter('listas');
  return salvar('listas', { ...listas, [nome]: itens });
}

/** Lê "Seg a sáb · 08:00 às 18:00" → { abre, fecha, dias } em minutos do dia. */
export function lerExpediente(texto) {
  const s = String(texto || '').toLowerCase();
  const horas = [...s.matchAll(/(\d{1,2}):(\d{2})/g)].map((m) => parseInt(m[1], 10) * 60 + parseInt(m[2], 10));
  const abre = horas[0] ?? 8 * 60;
  const fecha = horas[1] ?? 18 * 60;
  let dias = [1, 2, 3, 4, 5, 6];
  if (/seg\w* a sex/.test(s)) dias = [1, 2, 3, 4, 5];
  else if (/todos|dom\w* a s[áa]b|seg\w* a dom/.test(s)) dias = [0, 1, 2, 3, 4, 5, 6];
  return { abre, fecha: fecha > abre ? fecha : abre + 10 * 60, dias };
}

export async function expediente() {
  return lerExpediente((await obter('loja')).expediente);
}
