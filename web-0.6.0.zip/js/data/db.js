/* Banco local (IndexedDB). Tudo fica no próprio aparelho, sem internet.
   Regras que valem para todas as coleções:
   - ids são UUID em texto;
   - dinheiro SEMPRE em centavos (inteiro), duração SEMPRE em minutos;
   - exclusão é lógica (campo excluidoEm) e reversível pela Lixeira por 30 dias. */

const NOME_BANCO = 'studio_pet_odilon';
const VERSAO = 2;

export const STORES = {
  tutores: 'tutores',
  pets: 'pets',
  servicos: 'servicos',
  planos: 'planos',
  agendamentos: 'agendamentos',
  itens: 'agendamento_servicos',
  config: 'config',
};

const INDICES = {
  tutores: [],
  pets: ['tutorId'],
  servicos: [],
  planos: ['petId', 'tutorId'],
  agendamentos: ['inicio', 'petId', 'planoId', 'status'],
  agendamento_servicos: ['agendamentoId', 'servicoId'],
  config: [],
};

let conexao = null;

export function abrir() {
  if (conexao) return conexao;
  conexao = new Promise((resolve, reject) => {
    const req = indexedDB.open(NOME_BANCO, VERSAO);
    req.onupgradeneeded = () => {
      const db = req.result;
      const tx = req.transaction;
      for (const nome of Object.values(STORES)) {
        const chave = nome === STORES.config ? 'chave' : 'id';
        const store = db.objectStoreNames.contains(nome)
          ? tx.objectStore(nome)
          : db.createObjectStore(nome, { keyPath: chave });
        for (const indice of INDICES[nome] || []) {
          if (!store.indexNames.contains(indice)) store.createIndex(indice, indice);
        }
      }
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
  return conexao;
}

const promessa = (req) =>
  new Promise((resolve, reject) => {
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });

async function store(nome, modo = 'readonly') {
  const db = await abrir();
  return db.transaction(nome, modo).objectStore(nome);
}

export async function put(nome, registro) {
  await promessa((await store(nome, 'readwrite')).put(registro));
  return registro;
}

export async function putVarios(nome, registros) {
  if (!registros.length) return registros;
  const db = await abrir();
  const tx = db.transaction(nome, 'readwrite');
  const s = tx.objectStore(nome);
  registros.forEach((r) => s.put(r));
  await new Promise((resolve, reject) => {
    tx.oncomplete = resolve;
    tx.onerror = () => reject(tx.error);
    tx.onabort = () => reject(tx.error);
  });
  return registros;
}

export async function obter(nome, id) {
  if (id === null || id === undefined) return null;
  return (await promessa((await store(nome)).get(id))) || null;
}

export async function todos(nome) {
  return promessa((await store(nome)).getAll());
}

export async function porIndice(nome, indice, valor) {
  if (valor === null || valor === undefined) return [];
  return promessa((await store(nome)).index(indice).getAll(valor));
}

export async function porIntervalo(nome, indice, de, ate) {
  return promessa((await store(nome)).index(indice).getAll(IDBKeyRange.bound(de, ate)));
}

export async function remover(nome, id) {
  return promessa((await store(nome, 'readwrite')).delete(id));
}

export async function removerVarios(nome, ids) {
  if (!ids.length) return;
  const db = await abrir();
  const tx = db.transaction(nome, 'readwrite');
  const s = tx.objectStore(nome);
  ids.forEach((id) => s.delete(id));
  await new Promise((resolve, reject) => {
    tx.oncomplete = resolve;
    tx.onerror = () => reject(tx.error);
  });
}

/** Conteúdo completo do banco, para backup. */
export async function exportarTudo() {
  const dadosPorStore = {};
  for (const nome of Object.values(STORES)) dadosPorStore[nome] = await todos(nome);
  return dadosPorStore;
}

/** Substitui todo o conteúdo do banco pelo de um backup, numa única transação. */
export async function importarTudo(dadosPorStore) {
  const db = await abrir();
  const nomes = Object.values(STORES);
  const tx = db.transaction(nomes, 'readwrite');
  for (const nome of nomes) {
    const s = tx.objectStore(nome);
    s.clear();
    (dadosPorStore[nome] || []).forEach((r) => s.put(r));
  }
  await new Promise((resolve, reject) => {
    tx.oncomplete = resolve;
    tx.onerror = () => reject(tx.error);
    tx.onabort = () => reject(tx.error);
  });
}

export const uuid = () =>
  crypto.randomUUID
    ? crypto.randomUUID()
    : 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (c) => {
        const r = (Math.random() * 16) | 0;
        return (c === 'x' ? r : (r & 0x3) | 0x8).toString(16);
      });

export const vivos = (lista) => lista.filter((r) => !r.excluidoEm);
