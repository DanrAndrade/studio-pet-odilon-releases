import { exportarTudo, importarTudo, STORES } from './db.js';
import * as config from './config.js';
import { compartilharArquivo } from '../core/nativo.js';
import { valorData } from '../core/dom.js';
import { abrirSeletorArquivo } from '../core/foto.js';

/* Backup em arquivo JSON com todo o banco (fotos incluídas). No tablet o
   arquivo vai para o compartilhamento do Android: Drive, WhatsApp, e-mail. */

const FORMATO = 'studio-pet-odilon/backup';
const VERSAO = 1;

export async function gerarBackup() {
  const conteudo = JSON.stringify({
    formato: FORMATO,
    versao: VERSAO,
    geradoEm: new Date().toISOString(),
    dados: await exportarTudo(),
  });
  const nome = `studio-pet-backup-${valorData(Date.now())}.json`;
  compartilharArquivo(nome, conteudo, 'application/json');
  const bytes = new Blob([conteudo]).size;
  await config.salvar('ultimoBackup', { em: Date.now(), bytes });
  return { nome, bytes };
}

/** Valida e aplica um backup. Lança erro com mensagem legível se o arquivo não servir. */
export async function restaurarBackup(texto) {
  let json;
  try {
    json = JSON.parse(texto);
  } catch {
    throw new Error('O arquivo não é um backup válido.');
  }
  if (json?.formato !== FORMATO || !json.dados) throw new Error('Este arquivo não é um backup do Studio Pet.');
  if ((json.versao || 0) > VERSAO) throw new Error('Backup feito numa versão mais nova do app. Atualize o app primeiro.');

  const faltando = [STORES.pets, STORES.agendamentos].filter((s) => !Array.isArray(json.dados[s]));
  if (faltando.length) throw new Error('Backup incompleto: faltam dados de ' + faltando.join(', ') + '.');

  await importarTudo(json.dados);
  config.limparCache();
}

/** Abre o seletor de arquivo e devolve o texto do .json escolhido (null se cancelar). */
export async function escolherArquivoBackup() {
  // sem filtro de tipo: no Android o .json salvo pelo Drive/WhatsApp costuma vir como
  // "application/octet-stream" e ficaria bloqueado no seletor. O conteúdo é validado depois.
  const arquivo = await abrirSeletorArquivo();
  return arquivo ? arquivo.text() : null;
}

export const fmtTamanho = (bytes) =>
  bytes >= 1024 * 1024 ? (bytes / 1024 / 1024).toFixed(1).replace('.', ',') + ' MB' : Math.max(1, Math.round(bytes / 1024)) + ' KB';
