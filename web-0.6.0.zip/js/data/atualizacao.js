import { VERSAO } from '../versao.js';
import { versaoNativa } from '../core/nativo.js';

/* Atualização à distância: um arquivo público diz qual é a versão mais nova e
   onde está o APK. O app só precisa de internet na hora de verificar/baixar. */

export const URL_VERSAO = 'https://raw.githubusercontent.com/DanrAndrade/studio-pet-odilon-releases/main/versao.json';

const partes = (v) => String(v || '0').split('.').map((n) => parseInt(n, 10) || 0);
/** true se `a` é mais nova que `b` ("0.10.0" > "0.9.1"). */
export function versaoMaisNova(a, b) {
  const x = partes(a);
  const y = partes(b);
  for (let i = 0; i < Math.max(x.length, y.length); i++) {
    if ((x[i] || 0) !== (y[i] || 0)) return (x[i] || 0) > (y[i] || 0);
  }
  return false;
}

/**
 * @returns {{versao, url, notas}|null|undefined} objeto se há versão nova, null se
 *   já está na mais nova, undefined se não deu para verificar (sem rede).
 */
export async function verificarAtualizacao({ silencioso = false } = {}) {
  const controle = new AbortController();
  const limite = setTimeout(() => controle.abort(), 8000);
  try {
    const resp = await fetch(URL_VERSAO + '?t=' + Date.now(), { cache: 'no-store', signal: controle.signal });
    if (!resp.ok) throw new Error('HTTP ' + resp.status);
    const json = await resp.json();
    if (!json?.versao || !json?.url) throw new Error('arquivo de versão inválido');
    // o APK compara com a parte Android instalada; as telas se atualizam sozinhas
    return versaoMaisNova(json.versao, versaoNativa() || VERSAO) ? { versao: json.versao, url: json.url, notas: json.notas || '' } : null;
  } catch (erro) {
    if (!silencioso) console.warn('verificação de atualização falhou:', erro.message);
    return silencioso ? null : undefined;
  } finally {
    clearTimeout(limite);
  }
}
