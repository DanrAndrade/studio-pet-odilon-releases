import { html, icon, fmtDataCurta, deDataBR, proximoAniversario, MESES, DIAS_LONGOS, digitos } from '../core/dom.js';
import { avPet, vazio } from '../core/ui.js';
import { pets, tutores } from '../data/repo.js';
import { aniversariosProximos, semNascimento } from '../logic/aniversarios.js';
import { abrirWhatsapp } from '../modais/whatsapp.js';
import { combina } from '../core/busca.js';
import { nomesParaBusca, telefonesDoTutor } from '../logic/contatos.js';

/* ANIVERSÁRIOS — todos os pets com data de nascimento, mês a mês, e os que
   ainda não têm a data (esses não entram nos avisos: é preciso completar). */

const ui = { busca: '' };

const idadeTexto = (n) => `${n} ${n === 1 ? 'ano' : 'anos'}`;

function quandoTexto(dias, ts) {
  if (dias === 0) return 'Hoje';
  if (dias === 1) return 'Amanhã';
  if (dias === -1) return 'Ontem';
  if (dias < 0) return `Foi ${fmtDataCurta(ts)}`;
  return `${DIAS_LONGOS[new Date(ts).getDay()]}, ${fmtDataCurta(ts)}`;
}

export default {
  titulo: 'Aniversários',
  menu: 'aniversarios',

  async carregar() {
    const lista = await pets.listar();
    const mapaTutores = new Map((await tutores.listar()).map((t) => [t.id, t]));
    const comTutor = (pet) => ({ pet, tutor: mapaTutores.get(pet.tutorId) || null });

    const proximos = aniversariosProximos(lista).map((a) => ({ ...a, ...comTutor(a.pet) }));

    // todos os aniversários, do mês atual em diante (o ano "dá a volta")
    const mesAtual = new Date().getMonth();
    const porMes = Array.from({ length: 12 }, (_, i) => ({ mes: (mesAtual + i) % 12, linhas: [] }));
    for (const pet of lista) {
      const nasc = deDataBR(pet.nascimento);
      if (!nasc) continue;
      const d = new Date(nasc);
      const prox = proximoAniversario(nasc);
      porMes.find((g) => g.mes === d.getMonth()).linhas.push({ pet, tutor: mapaTutores.get(pet.tutorId) || null, dia: d.getDate(), prox });
    }
    porMes.forEach((g) => g.linhas.sort((a, b) => a.dia - b.dia));

    return {
      total: lista.length,
      proximos,
      porMes,
      sem: semNascimento(lista).map(comTutor),
    };
  },

  render(vm) {
    const termo = ui.busca.trim();
    const passa = (l) => combina(termo, [l.pet.nome, ...nomesParaBusca(l.tutor)], telefonesDoTutor(l.tutor));
    const meses = vm.porMes.map((g) => ({ ...g, linhas: g.linhas.filter(passa) })).filter((g) => g.linhas.length);
    const sem = vm.sem.filter(passa);
    const comData = vm.total - vm.sem.length;

    if (!vm.total) {
      return html`<div class="card pad-18">${vazio({ icone: 'cake', titulo: 'Nenhum pet cadastrado ainda', texto: 'Os aniversários aparecem aqui assim que os pets tiverem a data de nascimento.' })}</div>`;
    }

    return html`
      <div class="aniv-topo">
        <div class="busca branca">
          ${icon('search', 16)}
          <input data-campo="busca" value="${ui.busca}" placeholder="Buscar por pet, tutor ou telefone…">
          ${ui.busca ? html`<button data-acao="limpar" style="display:flex;color:var(--texto-3)" aria-label="Limpar">${icon('x', 15)}</button>` : ''}
        </div>
        <div class="aniv-contagem"><strong>${comData}</strong> de ${vm.total} pets com data de nascimento</div>
      </div>

      ${vm.sem.length
        ? html`<div class="card r22 aniv-sem">
            <div class="aniv-sem-cab">
              <span class="aniv-sem-icone">${icon('triangle-alert', 17)}</span>
              <div style="flex:1;min-width:0">
                <div class="aniv-sem-titulo">${vm.sem.length} ${vm.sem.length === 1 ? 'pet sem data de nascimento' : 'pets sem data de nascimento'}</div>
                <div class="aniv-sem-sub">Sem a data, o app não tem como avisar do aniversário. Complete para ninguém ficar de fora.</div>
              </div>
            </div>
            ${sem.length
              ? sem.map(
                  (l) => html`<div class="aniv-linha">
                    ${avPet(l.pet, 36, { borda: 0, sombra: false })}
                    <div class="aniv-nomes"><span class="aniv-pet">${l.pet.nome}</span><span class="aniv-tutor">${l.tutor?.nome || 'Sem tutor'}</span></div>
                    <button class="btn btn-branco aniv-btn" data-acao="completar" data-id="${l.pet.id}">${icon('pencil', 13)}<span>Completar</span></button>
                  </div>`
                )
              : html`<div class="mutado" style="font-size:12.5px;padding:8px 0">Nenhum com esse nome.</div>`}
          </div>`
        : html`<div class="aniv-tudo-ok">${icon('circle-check-big', 16)}<span>Todos os pets têm data de nascimento: o sino avisa de cada aniversário.</span></div>`}

      ${vm.proximos.length && !termo
        ? html`<div class="rotulo-secao" style="margin:18px 4px 10px">Próximos dias</div>
            <div class="aniv-proximos">
              ${vm.proximos.map(
                (a) => html`<div class="card r22 aniv-prox${a.dias === 0 ? ' hoje' : ''}${a.dias < 0 ? ' atrasado' : ''}">
                  ${avPet(a.pet, 46, { borda: 0, sombra: false })}
                  <div class="aniv-nomes">
                    <span class="aniv-quando">${quandoTexto(a.dias, a.ts)}</span>
                    <span class="aniv-pet">${a.pet.nome} · ${idadeTexto(a.idade)}</span>
                    <span class="aniv-tutor">${a.tutor?.nome || 'Sem tutor'}</span>
                  </div>
                  <button class="btn ${a.dias < 0 ? 'btn-branco' : 'btn-roxo'} aniv-btn" data-acao="parabens" data-id="${a.pet.id}" data-ts="${a.ts}">${icon('message-circle', 14)}<span>Parabéns</span></button>
                </div>`
              )}
            </div>`
        : ''}

      <div class="rotulo-secao" style="margin:18px 4px 10px">Todos os aniversários</div>
      ${meses.length
        ? html`<div class="aniv-meses">
            ${meses.map(
              (g) => html`<div class="card r22 aniv-mes">
                <div class="aniv-mes-cab"><span>${MESES[g.mes].charAt(0).toUpperCase() + MESES[g.mes].slice(1)}</span><span class="mutado">${g.linhas.length} ${g.linhas.length === 1 ? 'pet' : 'pets'}</span></div>
                ${g.linhas.map(
                  (l) => html`<div class="aniv-linha">
                    <span class="aniv-dia">${String(l.dia).padStart(2, '0')}</span>
                    ${avPet(l.pet, 34, { borda: 0, sombra: false })}
                    <button class="aniv-nomes aniv-abrir" data-acao="ficha" data-id="${l.pet.id}">
                      <span class="aniv-pet">${l.pet.nome}</span>
                      <span class="aniv-tutor">${l.tutor?.nome || 'Sem tutor'} · faz ${idadeTexto(l.prox.idade)}${l.prox.dias === 0 ? ' hoje' : l.prox.dias <= 7 ? ` em ${l.prox.dias} ${l.prox.dias === 1 ? 'dia' : 'dias'}` : ''}</span>
                    </button>
                    <button class="cli-icone verde" data-acao="parabens" data-id="${l.pet.id}" data-ts="${l.prox.ts}" aria-label="Enviar parabéns">${icon('message-circle', 15)}</button>
                  </div>`
                )}
              </div>`
            )}
          </div>`
        : html`<div class="card pad-18">${vazio({ icone: 'cake', titulo: termo ? 'Nenhum aniversário encontrado' : 'Nenhum pet com data de nascimento', texto: termo ? 'Tente outro nome.' : 'Complete a data na ficha de cada pet.', compacto: true })}</div>`}`;
  },

  aoDigitar(campo, valor, ctx) {
    if (campo !== 'busca') return;
    ui.busca = valor;
    ctx.redesenhar();
  },

  acoes: {
    limpar: (_, ctx) => {
      ui.busca = '';
      ctx.redesenhar();
    },
    completar: ({ id }, ctx) => ctx.navegar('editar-pet', { id }),
    ficha: ({ id }, ctx) => ctx.navegar('ficha-pet', { id }),
    parabens: async ({ id, ts }, ctx) => {
      const pet = await pets.obter(id);
      const tutor = pet?.tutorId ? await tutores.obter(pet.tutorId) : null;
      const aniversarioTs = Number(ts);
      if (await abrirWhatsapp(ctx, { tutor, pet, modelo: 'Aniversário', aniversarioTs })) {
        // enviado: sai dos avisos do sino deste aniversário
        await pets.salvar({ ...(await pets.obter(id)), parabensEnviadoPara: aniversarioTs });
        ctx.atualizarAvisos?.();
        ctx.recarregar();
      }
    },
  },
};
