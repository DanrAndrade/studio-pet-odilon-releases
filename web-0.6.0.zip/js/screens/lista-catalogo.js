import { html, icon } from '../core/dom.js';
import { voltar } from '../core/ui.js';
import { combina, normalizar, ordemAlfabetica } from '../core/busca.js';
import * as config from '../data/config.js';

/* LISTAS DO CATÁLOGO — raças, temperamentos, formas de pagamento etc.
   Cada alteração é salva na hora (ao sair do campo). A tela mostra em ordem
   alfabética e com busca; a ordem gravada (a dos botões nos cadastros) não muda. */

const ui = { nome: null, itens: [], novo: '', busca: '' };

const limpar = (itens) => [...new Set(itens.map((i) => i.trim()).filter(Boolean))];

async function gravar(ctx) {
  ui.itens = limpar(ui.itens);
  await config.salvarLista(ui.nome, ui.itens);
  ctx.redesenhar();
}

export default {
  titulo: (_, params) => params.nome || 'Listas do catálogo',
  menu: 'ajustes',

  async carregar({ nome }) {
    if (ui.nome !== nome) {
      ui.nome = nome;
      ui.itens = [...(await config.lista(nome))];
      ui.novo = '';
      ui.busca = '';
    }
    return { nome };
  },

  render(vm) {
    const origemServicos = vm.nome === 'Categorias de serviço';
    return html`
      ${voltar(origemServicos ? 'Voltar para serviços' : 'Voltar para ajustes')}
      <div class="card r22 pad-18 lista-cat">
        <div class="lista-cat-add">
          <input class="entrada" data-campo="novo" value="${ui.novo}" placeholder="Adicionar novo item…" enterkeyhint="done">
          <button class="btn btn-roxo" style="white-space:nowrap;padding:11px 18px" data-acao="adicionar">Adicionar</button>
        </div>
        ${ui.itens.length > 8 ? html`<div class="busca branca lista-busca" style="margin-bottom:12px">
          ${icon('search', 16)}
          <input data-campo="busca" value="${ui.busca}" placeholder="Buscar na lista…">
          ${ui.busca ? html`<button data-acao="limpar-busca" style="display:flex;color:var(--texto-3)" aria-label="Limpar">${icon('x', 15)}</button>` : ''}
        </div>` : ''}
        <div style="display:flex;flex-direction:column;gap:8px">
          ${ui.itens
            .map((item, i) => ({ item, i }))
            .filter(({ item }) => combina(ui.busca, [item]))
            .sort((a, b) => ordemAlfabetica(a.item, b.item))
            .map(({ item, i }) => html`<div style="display:flex;gap:10px;align-items:center">
              <input class="entrada" data-campo="item-${i}" value="${item}">
              <button class="lista-cat-del" data-acao="remover" data-indice="${i}" aria-label="Remover">${icon('trash-2', 15)}</button>
            </div>`
          )}
          ${ui.itens.length ? '' : html`<div class="vazio compacto">Lista vazia. Adicione o primeiro item acima.</div>`}
          ${ui.itens.length && ui.busca && !ui.itens.some((item) => combina(ui.busca, [item])) ? html`<div class="vazio compacto">Nada encontrado para “${ui.busca}”.</div>` : ''}
        </div>
      </div>`;
  },

  aoMontar(el, _, ctx) {
    const campo = el.querySelector('[data-campo="novo"]');
    // a tela pode reaproveitar o mesmo campo ao atualizar: liga o Enter uma vez só
    if (!campo || campo.__enterLigado) return;
    campo.__enterLigado = true;
    campo.addEventListener('keydown', (ev) => {
      if (ev.key === 'Enter') {
        ev.preventDefault();
        adicionar(ctx);
      }
    });
  },

  aoDigitar(nome, valor, ctx) {
    if (nome === 'busca') {
      ui.busca = valor;
      return ctx.redesenhar();
    }
    if (nome === 'novo') ui.novo = valor;
    const m = /^item-(\d+)$/.exec(nome);
    if (m) ui.itens[Number(m[1])] = valor;
  },

  async aoAlterar(nome, _, ctx) {
    if (nome.startsWith('item-')) {
      await gravar(ctx);
      ctx.toast('Lista atualizada');
    }
  },

  acoes: {
    'limpar-busca': (_, ctx) => {
      ui.busca = '';
      ctx.redesenhar();
    },
    adicionar: (_, ctx) => adicionar(ctx),
    remover: async ({ indice }, ctx) => {
      const [removido] = ui.itens.splice(Number(indice), 1);
      await gravar(ctx);
      ctx.toast(`“${removido}” removido`);
    },
  },
};

async function adicionar(ctx) {
  const valor = ui.novo.trim();
  if (!valor) return ctx.toast('Digite o item antes de adicionar', { erro: true });
  if (ui.itens.some((i) => normalizar(i.trim()) === normalizar(valor))) return ctx.toast('Esse item já está na lista', { erro: true });
  ui.itens.push(valor);
  ui.novo = '';
  await gravar(ctx);
  ctx.toast(`“${valor}” adicionado`);
}
