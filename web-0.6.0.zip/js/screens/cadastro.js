import { html, icon, mascaraTelefone, mascaraCpf, mascaraData, formatarPeso, cpfValido, emailValido, telefoneValido, deDataBR, paraDataBR, nascimentoValido } from '../core/dom.js';
import { chip, campo, voltar } from '../core/ui.js';
import { pets, tutores, PORTES } from '../data/repo.js';
import { CAMPOS_ENDERECO, camposDe, temEnderecoSeparado, buscarCep, aplicarCep } from '../logic/endereco.js';
import * as config from '../data/config.js';
import { escolherFoto } from '../core/foto.js';

/* NOVO CADASTRO — tutor e pet numa tela só. Só o nome do pet é obrigatório:
   muita gente não quer passar CPF, e o cadastro não pode travar por isso. */

const ORIGENS = ['Indicação', 'Instagram', 'Passou na porta', 'Google'];
const ESPECIES = ['Cão', 'Gato', 'Outro'];
const SEXOS = ['Macho', 'Fêmea'];

const ui = { chave: null, cad: {} };

function limpo(tutor) {
  return {
    tutorNome: tutor?.nome || '', fone: tutor?.telefone || '', nome2: tutor?.nome2 || '', fone2: tutor?.telefone2 || '',
    cpf: tutor?.cpf || '', email: tutor?.email || '',
    ...camposDe(tutor), origem: tutor?.origem || 'Indicação',
    petNome: '', especie: 'Cão', raca: '', porte: 'Médio', sexo: 'Macho', nasc: '', peso: '',
    alergias: '', obs: '', temperamento: ['Calmo'], foto: null,
  };
}

/**
 * CEP completo: busca o endereço e preenche o que ainda está em branco.
 * Sem internet, o app segue em silêncio com o preenchimento manual.
 */
async function procurarCep(valor, destino, ctx) {
  const digitos8 = String(valor || '').replace(/\D/g, '');
  if (digitos8.length !== 8 || destino.cepBuscado === digitos8) return;
  destino.cepBuscado = digitos8;
  const achado = await buscarCep(digitos8);
  if (destino.cep.replace(/\D/g, '') !== digitos8) return; // ele já mudou o CEP
  const mudou = aplicarCep(achado, destino);
  if (!Object.keys(mudou).length) return;
  Object.assign(destino, mudou);
  ctx?.redesenhar?.();
  ctx?.toast?.('Endereço preenchido pelo CEP · confira o número');
}

export default {
  titulo: 'Novo cadastro',
  menu: 'clientes',

  async carregar({ tutorId }) {
    const tutor = tutorId ? await tutores.obter(tutorId) : null;
    const chave = tutorId || 'novo';
    if (ui.chave !== chave) {
      ui.chave = chave;
      ui.cad = limpo(tutor);
    }
    const temperamentos = await config.lista('Temperamentos');
    const alertas = await config.lista('Alertas de saúde');
    return {
      tutor,
      racas: await config.lista('Lista de raças'),
      marcadores: [...new Set([...temperamentos, ...alertas])],
    };
  },

  render(vm) {
    const c = ui.cad;
    const grupo = (rotulo, opcoes, chave) =>
      html`<div><div class="rotulo-campo">${rotulo}</div><div class="chips">${opcoes.map((o) => chip(o, c[chave] === o, 'opcao', { chave, valor: o }, { suave: true, cls: 'forte' }))}</div></div>`;

    return html`
      ${voltar(vm.tutor ? `Voltar para a ficha de ${vm.tutor.nome}` : 'Voltar para clientes')}
      <div style="display:flex;flex-direction:column;gap:14px">
        <div class="card r22 pad-18">
          <div class="titulo-card g" style="margin-bottom:14px">Tutor</div>
          <div class="grade-2" style="grid-template-columns:1.3fr 1fr">
            ${campo({ rotulo: 'Nome completo', nome: 'tutorNome', valor: c.tutorNome, placeholder: 'Ex.: Marina Alves' })}
            ${campo({ rotulo: 'Telefone / WhatsApp', nome: 'fone', valor: c.fone, placeholder: '(73) 90000-0000', tipo: 'tel', formato: 'telefone' })}
          </div>
          <div class="grade-2 mt-12" style="grid-template-columns:1.3fr 1fr">
            ${campo({ rotulo: 'Segundo responsável (opcional)', nome: 'nome2', valor: c.nome2, placeholder: 'Ex.: João Alves' })}
            ${campo({ rotulo: 'Telefone 2 (opcional)', nome: 'fone2', valor: c.fone2, placeholder: '(73) 90000-0000', tipo: 'tel', formato: 'telefone' })}
          </div>
          <div class="grade-2 mt-12" style="grid-template-columns:1fr 1.3fr">
            ${campo({ rotulo: 'CPF', nome: 'cpf', valor: c.cpf, placeholder: 'opcional', formato: 'cpf' })}
            ${campo({ rotulo: 'E-mail', nome: 'email', valor: c.email, placeholder: 'opcional', tipo: 'email', formato: 'email' })}
          </div>
          <div class="rotulo-campo" style="margin:14px 0 7px">Endereço</div>
          <div class="grade-endereco">
            ${CAMPOS_ENDERECO.map((e) => campo({ ...e, valor: c[e.nome] }))}
          </div>
          <div class="rotulo-campo" style="margin:14px 0 7px">Como conheceu a loja</div>
          <div class="chips">${ORIGENS.map((o) => chip(o, c.origem === o, 'opcao', { chave: 'origem', valor: o }, { suave: true, cls: 'forte' }))}</div>
        </div>

        <div class="card r22 pad-18">
          <div class="titulo-card g" style="margin-bottom:14px">Pet</div>
          <div class="grade-3" style="grid-template-columns:1.2fr 1fr 1fr">
            ${campo({ rotulo: 'Nome do pet', nome: 'petNome', valor: c.petNome, placeholder: 'Ex.: Thor' })}
            ${campo({ rotulo: 'Raça', nome: 'raca', valor: c.raca, placeholder: 'Ex.: Golden Retriever', attrs: 'list="lista-racas"' })}
            ${campo({ rotulo: 'Nascimento', nome: 'nasc', valor: c.nasc, placeholder: 'dd/mm/aaaa', formato: 'data' })}
          </div>
          <datalist id="lista-racas">${vm.racas.map((r) => html`<option value="${r}"></option>`)}</datalist>
          <div class="grade-2 mt-14" style="gap:16px">
            ${grupo('Espécie', ESPECIES, 'especie')}
            ${grupo('Sexo', SEXOS, 'sexo')}
          </div>
          <div class="grade-2 mt-14" style="grid-template-columns:1.6fr 1fr;gap:16px">
            ${grupo('Porte', PORTES, 'porte')}
            ${campo({ rotulo: 'Peso aproximado', nome: 'peso', valor: c.peso, placeholder: 'Ex.: 32 kg', formato: 'peso' })}
          </div>
          <div class="rotulo-campo" style="margin:14px 0 7px">Temperamento e alertas</div>
          <div class="chips">${vm.marcadores.map((m) => chip(m, c.temperamento.includes(m), 'marcador', { valor: m }, { suave: true, cls: 'forte' }))}</div>
          <div class="grade-2 mt-14">
            ${campo({ rotulo: 'Alergias e cuidados', nome: 'alergias', valor: c.alergias, placeholder: 'Ex.: shampoo comum' })}
            ${campo({ rotulo: 'Observações do groomer', nome: 'obs', valor: c.obs, placeholder: 'Ex.: prefere banho de manhã' })}
          </div>

          <div class="foto-linha">
            ${c.foto ? html`<div class="av borda-3" style="width:96px;height:96px;min-width:96px;background:var(--borda-3)"><img src="${c.foto}" alt=""></div>` : ''}
            <div style="flex:1">
              <div class="rotulo-campo" style="margin-bottom:8px">Foto do pet</div>
              <div class="foto-botoes">
                <button class="btn-foto" data-acao="foto" data-camera="1">${icon('camera', 16)}<span>Câmera</span></button>
                <button class="btn-foto" data-acao="foto">${icon('image-plus', 16)}<span>Galeria</span></button>
                ${c.foto ? html`<button class="link-perigo" data-acao="sem-foto">Remover foto</button>` : ''}
              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="cad-rodape">
        <button class="btn btn-rosa" style="min-width:140px;padding:13px" data-acao="voltar">Cancelar</button>
        <button class="btn btn-branco" style="padding:13px 18px" data-acao="salvar" data-depois="agendar">Salvar e agendar</button>
        <button class="btn btn-roxo" style="flex:1;padding:13px" data-acao="salvar">Salvar cadastro</button>
      </div>`;
  },

  aoDigitar(campoNome, valor, _, el) {
    // telefone e CPF ganham a máscara enquanto digita
    const mascara = { fone: mascaraTelefone, fone2: mascaraTelefone, cpf: mascaraCpf, nasc: mascaraData }[campoNome] || null;
    if (mascara && el) {
      const antes = valor;
      valor = mascara(valor);
      if (valor !== antes) el.value = valor;
    }
    ui.cad[campoNome] = valor;
    if (campoNome === 'cep') procurarCep(valor, ui.cad, _);
  },

  acoes: {
    opcao: ({ chave, valor }, ctx) => {
      ui.cad[chave] = valor;
      ctx.redesenhar();
    },
    marcador: ({ valor }, ctx) => {
      const lista = ui.cad.temperamento;
      ui.cad.temperamento = lista.includes(valor) ? lista.filter((x) => x !== valor) : [...lista, valor];
      ctx.redesenhar();
    },
    foto: async ({ camera }, ctx) => {
      const foto = await escolherFoto({ camera: !!camera });
      if (!foto) return;
      ui.cad.foto = foto;
      ctx.redesenhar();
    },
    'sem-foto': (_, ctx) => {
      ui.cad.foto = null;
      ctx.redesenhar();
    },
    salvar: async ({ depois }, ctx) => {
      const c = ui.cad;
      if (!c.petNome.trim()) return ctx.toast('O nome do pet é o único campo obrigatório', { erro: true });
      const problema = validarTutor(c.fone, c.cpf, c.email);
      if (problema) return ctx.toast(problema, { erro: true });
      if (!telefoneValido(c.fone2)) return ctx.toast('Telefone 2 incompleto: use DDD + número, ex.: (73) 99811-2030', { erro: true });
      if (!nascimentoValido(c.nasc)) return ctx.toast('Data de nascimento inválida. Use dia/mês/ano, por exemplo 15/03/2020', { erro: true });

      let tutor = ctx.vm.tutor;
      const temDadosTutor = [c.tutorNome, c.fone, c.nome2, c.fone2, c.cpf, c.email, ...CAMPOS_ENDERECO.map((e) => c[e.nome])].some((v) => v.trim());

      if (!tutor && (c.fone.trim() || c.fone2.trim())) {
        const existente = (c.fone.trim() && (await tutores.porTelefone(c.fone))) || (c.fone2.trim() && (await tutores.porTelefone(c.fone2))) || null;
        if (existente) {
          const vincular = await ctx.confirmar({
            titulo: `Já existe ${existente.nome || 'um tutor'} com esse telefone`,
            texto: 'Vincular este pet ao cadastro existente em vez de criar outro tutor?',
            botao: 'Vincular ao existente',
            cancelar: 'Criar novo',
            perigo: false,
            icone: 'user-round',
          });
          if (vincular) tutor = existente;
        }
      }

      if (tutor || temDadosTutor) {
        tutor = await tutores.salvar({
          ...(tutor || {}),
          nome: c.tutorNome.trim() || tutor?.nome || '',
          telefone: c.fone.trim() || tutor?.telefone || '',
          nome2: c.nome2.trim() || tutor?.nome2 || '',
          telefone2: c.fone2.trim() || tutor?.telefone2 || '',
          cpf: c.cpf.trim() || tutor?.cpf || '',
          email: c.email.trim() || tutor?.email || '',
          ...camposDe(c),
          // o texto antigo sai quando o endereço é preenchido nos campos novos
          endereco: temEnderecoSeparado(c) ? '' : tutor?.endereco || '',
          origem: c.origem,
        });
      }

      const pet = await pets.salvar({
        tutorId: tutor?.id || null,
        nome: c.petNome.trim(),
        especie: c.especie,
        raca: c.raca.trim(),
        porte: c.porte,
        sexo: c.sexo,
        nascimento: c.nasc.trim() ? paraDataBR(deDataBR(c.nasc)) : '',
        peso: formatarPeso(c.peso),
        alergias: c.alergias.trim(),
        obs: c.obs.trim(),
        temperamentos: c.temperamento,
        foto: c.foto,
        rotina: [],
        ocorrencias: [],
      });

      ui.chave = null;
      ctx.toast(`${pet.nome} cadastrado`);
      if (depois === 'agendar') ctx.navegar('novo-agendamento', { petId: pet.id }, { substituir: true });
      else ctx.navegar('ficha-pet', { id: pet.id }, { substituir: true });
    },
  },
};

/** Campos opcionais, mas se preenchidos precisam estar certos. Devolve a mensagem do primeiro erro. */
export function validarTutor(telefone, cpf, email) {
  if (!telefoneValido(telefone)) return 'Telefone incompleto: use DDD + número, ex.: (73) 99811-2030';
  if (!cpfValido(cpf)) return 'CPF inválido: confira os dígitos';
  if (!emailValido(email)) return 'E-mail inválido: confira o endereço';
  return '';
}
