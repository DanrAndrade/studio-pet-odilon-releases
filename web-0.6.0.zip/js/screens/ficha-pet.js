import { html, icon, fmtBRL, fmtBRLCurto, fmtDur, fmtData, fmtDataCurta, fmtDiaHora, MESES, inicioDoDia } from '../core/dom.js';
import { avPet, avTutor, tagsPet, selo, vazio, voltar, patinhasHero, secao } from '../core/ui.js';
import { agendamentos, pets, tutores, planos, tempos, mensalidadesDosPets, mensalidadesDoPlano } from '../data/repo.js';
import { situacaoPagamento, ehBanhoDePlano } from '../logic/pagamento.js';
import { ligar } from '../core/nativo.js';
import { estatisticasPet, minutosDaVisita } from '../logic/metricas.js';
import { abrirWhatsapp } from '../modais/whatsapp.js';
import { registrarOcorrencia } from '../modais/ocorrencia.js';
import { planoVigente } from '../logic/planos.js';
import { contatosDoTutor, nomesDoTutor, telefonesDoTutor } from '../logic/contatos.js';
import { escolherContato } from '../modais/contato.js';

/* FICHA DO PET — saúde, destaques, tempos por procedimento, histórico e cuidados. */

const ABAS = ['Resumo', 'Tempos', 'Histórico', 'Saúde'];

/** "hoje", "ontem", "há 5 dias". */
const haDias = (d) => (d <= 0 ? 'hoje' : d === 1 ? 'ontem' : `há ${d} dias`);

const valorOuPendente = (v) => (String(v || '').trim() ? v : 'Não informado');

async function carregar({ id }) {
  const pet = await pets.obter(id);
  if (!pet || pet.excluidoEm) return { pet: null };
  const tutor = pet.tutorId ? await tutores.obter(pet.tutorId) : null;
  const plano = (await planos.doPet(id)).find((p) => planoVigente(p)) || null;
  const historico = await agendamentos.doPet(id);
  const itensPorAg = await agendamentos.itensDe(historico);
  const stats = estatisticasPet(historico, itensPorAg);

  const agora = inicioDoDia(Date.now());
  const proximos = historico
    .filter((a) => a.inicio >= agora && !['concluido', 'cancelado', 'nao_compareceu'].includes(a.status))
    .sort((a, b) => a.inicio - b.inicio);

  // média de visita completa na loja inteira, para comparar
  const concluidosLoja = await agendamentos.concluidos();
  const itensLoja = await agendamentos.itensDe(concluidosLoja.slice(-120));
  const visitasLoja = [...itensLoja.values()].map(minutosDaVisita).filter((m) => m > 0);
  const visitaLojaMin = visitasLoja.length ? Math.round(visitasLoja.reduce((a, b) => a + b, 0) / visitasLoja.length) : null;

  // dinheiro do pet: atendimentos pagos + mensalidades pagas; não pago = atendimentos + mensalidades em aberto
  const mens = await mensalidadesDosPets([id]);
  const mensPagasCentavos = mens.pagas.reduce((s, m) => s + m.valorCentavos, 0);
  const mensAbertasCentavos = mens.abertas.reduce((s, m) => s + m.valorCentavos, 0);
  const proximaCobranca = plano ? (await mensalidadesDoPlano(plano)).find((m) => !m.pagamento) || null : null;
  return {
    pet, tutor, plano, historico, itensPorAg, stats, proximos, tempos: await tempos.doPet(pet), visitaLojaMin,
    mensPagasCentavos, mensAbertasCentavos, qtdMensAbertas: mens.abertas.length, proximaCobranca,
    totalPagoCentavos: stats.totalGastoCentavos + mensPagasCentavos,
    naoPagoCentavos: stats.pendenteCentavos + mensAbertasCentavos,
  };
}

/* ------------------------------ Blocos ------------------------------ */

function hero(vm) {
  const { pet, tutor, plano } = vm;
  const tags = tagsPet(pet);
  const sub = [pet.raca, pet.porte, pet.idade, pet.sexo, pet.peso].filter(Boolean).join(' · ');
  return html`<div class="hero ficha-hero">
    ${patinhasHero('ficha', 0.18)}
    <div class="hero-conteudo ficha-topo">
      ${avPet(pet, 132, { borda: 0, extra: 'border:5px solid rgba(255,255,255,0.9);box-shadow:0 3px 9px rgba(91,76,240,0.30)' })}
      <div style="flex:1;min-width:0">
        <div class="ficha-nome-linha">
          <span class="ficha-nome">${pet.nome}</span>
          ${plano ? html`<span class="selo selo-roxo ficha-selo">PLANO ${plano.tipo?.split(' ')[0].toUpperCase() || ''}${plano.valorCentavos ? ` · ${fmtBRLCurto(plano.valorCentavos)}/MÊS` : ''}</span>` : ''}
          ${tags.map((t) => html`<span class="selo selo-${t.tom} ficha-selo">${t.label.toUpperCase()}</span>`)}
        </div>
        <div class="ficha-sub">${sub || 'Complete o cadastro com raça, porte e peso'}</div>
        ${tutor
          ? html`<button class="tutor-pilula" data-acao="tutor">
              ${avTutor(30)}
              <span style="text-align:left"><span class="tp-nome">${nomesDoTutor(tutor) || 'Tutor'}</span><span class="tp-fone">${telefonesDoTutor(tutor).join(' · ') || 'Sem telefone'}</span></span>
              <span style="color:var(--texto-5)">${icon('chevron-right', 15)}</span>
            </button>`
          : html`<button class="tutor-pilula" data-acao="editar">${icon('user-plus', 15)}<span class="tp-nome">Sem tutor vinculado</span></button>`}
      </div>
      <div class="ficha-acoes">
        <button class="btn btn-roxo sombra bloco" data-acao="novo">Novo agendamento</button>
        <div style="display:flex;gap:8px">
          <button class="ficha-icone" style="color:var(--verde-escuro)" data-acao="whats" aria-label="WhatsApp">${icon('message-circle', 16)}</button>
          <button class="ficha-icone" style="color:var(--texto-4)" data-acao="ligar" aria-label="Ligar">${icon('phone', 16)}</button>
          <button class="ficha-icone" style="color:var(--roxo)" data-acao="editar" aria-label="Editar">${icon('pencil', 16)}</button>
        </div>
      </div>
    </div>
  </div>`;
}

function saude(vm) {
  const { pet, stats } = vm;
  const alergia = String(pet.alergias || '').trim() && !/nenhum/i.test(pet.alergias);
  const itens = [
    { rotulo: 'Peso registrado', valor: pet.peso ? `${pet.peso}${pet.pesoData ? ' · ' + pet.pesoData : ''}` : 'Não informado', icone: 'weight', cor: pet.peso ? '' : 'var(--ambar)' },
    { rotulo: 'Castrado', valor: pet.castrado || 'Não informado', icone: 'stethoscope', cor: pet.castrado ? '' : 'var(--ambar)' },
    { rotulo: 'Alergias', valor: alergia ? pet.alergias : 'Nenhuma conhecida', icone: 'triangle-alert', cor: alergia ? 'var(--rosa)' : '' },
    { rotulo: 'Última vacina', valor: valorOuPendente(pet.vacina), icone: 'syringe', cor: pet.vacina ? '' : 'var(--ambar)' },
    { rotulo: 'Veterinário', valor: valorOuPendente(pet.vet), icone: 'building-2', cor: pet.vet ? '' : 'var(--ambar)' },
  ];
  const tag = tagsPet(pet)[0];
  const destaques = [
    { icone: 'timer', rotulo: 'Visita típica', valor: stats.visitaTipicaMin ? fmtDur(stats.visitaTipicaMin) : '—', dica: stats.comboTipico ? stats.comboTipico.toLowerCase() : 'sem visitas medidas', estilo: 'lavanda' },
    { icone: 'calendar-heart', rotulo: 'Frequência', valor: stats.frequenciaDias ? `${stats.frequenciaDias} dias` : '—', dica: stats.diasDesdeUltima !== null ? `última visita ${haDias(stats.diasDesdeUltima)}` : 'nenhuma visita ainda', estilo: 'ambar' },
    { icone: 'wallet', rotulo: 'Ticket médio', valor: stats.ticketMedioCentavos ? fmtBRLCurto(stats.ticketMedioCentavos) : '—', dica: `${stats.atendimentos} ${stats.atendimentos === 1 ? 'atendimento' : 'atendimentos'}`, estilo: 'branco' },
    { icone: 'triangle-alert', rotulo: 'Atenção', valor: tag ? tag.label : 'Nenhum alerta', dica: tag ? 'confirmar antes de iniciar' : 'pet tranquilo', estilo: 'rosa' },
  ];

  return html`<div class="ficha-corpo">
    <div class="cab-card" style="margin-bottom:11px">
      ${secao('heart-pulse', 'Saúde e cuidados')}
      <button class="btn btn-branco pequeno" style="border-radius:14px;padding:9px 14px" data-acao="editar">${icon('pencil', 13)}<span>Editar ficha</span></button>
    </div>
    <div class="ficha-saude">
      ${itens.map(
        (s) => html`<div class="stat"><div class="stat-rotulo">${icon(s.icone, 12)}<span>${s.rotulo}</span></div><div class="stat-valor" style="${s.cor ? `color:${s.cor}` : ''}">${s.valor}</div></div>`
      )}
    </div>
    <div class="ficha-destaques">
      ${destaques.map(
        (d) => html`<div class="destaque destaque-${d.estilo}">
          <div class="destaque-rotulo">${icon(d.icone, 14)}<span>${d.rotulo}</span></div>
          <div class="destaque-valor">${d.valor}</div>
          <div class="destaque-dica">${d.dica}</div>
        </div>`
      )}
    </div>
  </div>`;
}

const servicosDe = (vm, ag) => (vm.itensPorAg.get(ag.id) || []).map((i) => i.nome).join(' + ') || '—';
const valorDe = (ag) => (ehBanhoDePlano(ag) && !ag.valorCentavos ? 'Incluso' : fmtBRLCurto(ag.valorCentavos));
const duracaoDe = (vm, ag) => {
  const m = minutosDaVisita(vm.itensPorAg.get(ag.id) || []);
  return m ? fmtDur(m) : '—';
};

function abaResumo(vm) {
  const { stats, proximos, pet } = vm;
  const ultimas = stats.concluidos.slice(0, 3);
  return html`<div class="grade-lateral">
    <div class="at-col" style="gap:16px">
      <div class="card r22 pad-18">
        <div class="cab-card" style="margin-bottom:6px">
          <div class="titulo-card g">Últimas visitas</div>
          ${stats.concluidos.length > 3 ? html`<button class="link-acao" data-acao="aba" data-aba="Histórico">Ver histórico completo</button>` : ''}
        </div>
        ${ultimas.length
          ? ultimas.map(
              (ag) => html`<div class="hist-linha hist-resumo">
                <div class="hl-data">${fmtData(ag.chegadaEm || ag.inicio)}</div>
                <div class="hl-serv">${servicosDe(vm, ag)}</div>
                <div class="hl-forte">${duracaoDe(vm, ag)}</div>
                <div class="hl-forte" style="text-align:right">${valorDe(ag)}</div>
              </div>`
            )
          : vazio({ icone: 'scissors', titulo: 'Nenhuma visita ainda', texto: 'O histórico aparece aqui depois do primeiro atendimento.', compacto: true })}
      </div>
    </div>

    <div class="at-col">
      ${stats.retornoAtrasado && !proximos.length
        ? html`<div class="aviso-ambar">
            <div class="aviso-titulo">${icon('clock-alert', 15)}<span>Retorno atrasado</span></div>
            <div class="aviso-texto">Frequência habitual de ${stats.frequenciaDias} dias · último atendimento ${haDias(stats.diasDesdeUltima)}.</div>
            <button class="btn btn-branco bloco" style="margin-top:11px;border:0;color:var(--roxo-escuro);font-size:12.5px;padding:10px 12px" data-acao="lembrar">Lembrar tutor pelo WhatsApp</button>
          </div>`
        : ''}
      <div class="card r22 pad-18">
        <div class="titulo-card g" style="margin-bottom:10px">Próximos agendamentos</div>
        ${proximos.length
          ? proximos.slice(0, 4).map(
              (ag) => html`<button class="linha" style="width:100%;border-top-color:var(--borda)" data-acao="abrir-ag" data-id="${ag.id}">
                <span style="color:var(--texto-2);font-weight:500">${fmtDiaHora(ag.inicio)}</span>
                ${ag.status === 'rascunho_plano' ? html`<span style="color:var(--ambar);font-weight:600">Rascunho</span>` : html`<span class="mutado truncar" style="max-width:50%">${servicosDe(vm, ag)}</span>`}
              </button>`
            )
          : html`<div class="linha" style="border-top-color:var(--borda)"><span class="mutado">Nada marcado</span><button class="link-acao" data-acao="novo">Agendar</button></div>`}
      </div>
      <div class="card r22 pad-18">
        <div class="titulo-card g" style="margin-bottom:10px">Observações do groomer</div>
        <div class="texto-longo">${pet.obs || 'Sem observações. Toque em editar para anotar preferências e cuidados.'}</div>
      </div>
    </div>
  </div>`;
}

function abaTempos(vm) {
  const { tempos: linhas, stats, visitaLojaMin } = vm;
  if (!linhas.length) {
    return html`<div class="card r22 pad-18">${vazio({ icone: 'timer', titulo: 'Ainda sem tempos medidos', texto: 'Os tempos aparecem depois do primeiro atendimento cronometrado.' })}</div>`;
  }
  const maisLongo = [...linhas].sort((a, b) => b.mediaMin - a.mediaMin)[0];
  const deltaVisita = stats.visitaTipicaMin && visitaLojaMin ? stats.visitaTipicaMin - visitaLojaMin : null;
  const deltaLongo = maisLongo.mediaMin - maisLongo.lojaMin;
  const fmtDelta = (d, sufixo = ' vs. loja') => (d === null ? 'sem comparação' : d === 0 ? `igual à loja` : `${d > 0 ? '+' : '−'}${Math.abs(d)}min${sufixo}`);
  const corDelta = (d) => (d === null || d === 0 ? 'var(--texto-3)' : d > 0 ? 'var(--rosa)' : 'var(--verde-escuro)');
  const tendencia = stats.tendenciaMin;
  const escala = Math.max(...linhas.flatMap((l) => [l.mediaMin, l.lojaMin]), 1) * 1.1;
  const primeiro = stats.concluidos[stats.concluidos.length - 1];

  return html`
    <div class="grade-4" style="gap:14px;margin-bottom:16px">
      <div class="stat-g"><div class="stat-rotulo">${icon('timer', 13)}<span>Visita típica</span></div><div class="stat-valor">${stats.visitaTipicaMin ? fmtDur(stats.visitaTipicaMin) : '—'}</div><div class="stat-dica" style="color:${corDelta(deltaVisita)}">${fmtDelta(deltaVisita)}</div></div>
      <div class="stat-g"><div class="stat-rotulo">${icon('activity', 13)}<span>Procedimento mais longo</span></div><div class="stat-valor" style="font-size:22px">${maisLongo.servico.nome.split(' ')[0]} ${fmtDur(maisLongo.mediaMin)}</div><div class="stat-dica" style="color:${corDelta(deltaLongo)}">${fmtDelta(deltaLongo)}</div></div>
      <div class="stat-g"><div class="stat-rotulo">${icon('repeat-2', 13)}<span>Atendimentos medidos</span></div><div class="stat-valor">${stats.atendimentos}</div><div class="stat-dica">${primeiro ? `desde ${MESES[new Date(primeiro.inicio).getMonth()]} de ${new Date(primeiro.inicio).getFullYear()}` : '—'}</div></div>
      <div class="stat-g"><div class="stat-rotulo">${icon(tendencia > 0 ? 'trending-up' : 'trending-down', 13)}<span>Tendência</span></div><div class="stat-valor" style="font-size:22px">${tendencia === null ? '—' : tendencia < -1 ? 'Melhorando' : tendencia > 1 ? 'Mais lento' : 'Estável'}</div><div class="stat-dica" style="color:${corDelta(tendencia)}">${tendencia === null ? 'precisa de 6 visitas' : fmtDelta(tendencia, ' nas últimas 3')}</div></div>
    </div>

    <div class="card r22 pad-18" style="margin-bottom:16px">
      <div class="titulo-card g" style="margin-bottom:14px">Tempo por procedimento · pet vs. média da loja</div>
      <div style="display:flex;flex-direction:column;gap:14px">
        ${linhas.map(
          (l) => html`<div>
            <div style="display:flex;justify-content:space-between;align-items:center;font-size:12.5px;margin-bottom:6px;gap:10px">
              <span style="font-weight:600;color:var(--tinta-2)">${l.servico.nome}</span>
              <span class="mutado">${fmtDur(l.mediaMin)} · loja ${fmtDur(l.lojaMin)}</span>
            </div>
            <div class="barra" style="height:10px;background:var(--divisor);border-radius:10px"><div style="width:${((l.mediaMin / escala) * 100).toFixed(1)}%;background:${l.mediaMin > l.lojaMin ? 'var(--ambar-barra)' : 'var(--roxo)'};border-radius:10px"></div></div>
            <div class="barra" style="height:5px;background:var(--divisor-2);margin-top:4px"><div style="width:${((l.lojaMin / escala) * 100).toFixed(1)}%;background:var(--lavanda-forte)"></div></div>
          </div>`
        )}
      </div>
    </div>

    <div class="card r22" style="padding:6px 18px 16px">
      <div class="cab-tabela tempos-colunas" style="font-weight:600;padding:16px 0 12px;border-bottom-color:var(--borda)"><div>Procedimento</div><div>Média do pet</div><div>Média loja</div><div>Menor / maior</div><div style="text-align:right">Base</div></div>
      ${linhas.map(
        (l) => html`<div class="linha-tabela tempos-colunas" style="padding:14px 0;border-bottom-color:#f6f4fb">
          <div style="font-weight:600;color:var(--tinta-2)">${l.servico.nome}</div>
          <div style="display:flex;align-items:center;gap:6px;font-weight:600;color:var(--roxo)">${fmtDur(l.mediaMin)}<span style="color:${l.tendencia > 0 ? 'var(--rosa)' : l.tendencia < 0 ? 'var(--verde-escuro)' : 'var(--texto-3)'}">${icon(l.tendencia > 0 ? 'trending-up' : l.tendencia < 0 ? 'trending-down' : 'minus', 13)}</span></div>
          <div class="mutado">${fmtDur(l.lojaMin)}</div>
          <div class="mutado">${l.amostras > 1 ? `${fmtDur(l.menorMin)} / ${fmtDur(l.maiorMin)}` : '—'}</div>
          <div style="text-align:right">${l.estimado ? selo('estimado', 'ambar', 'p') : selo(`${l.amostras} atend.`, 'verde', 'p')}</div>
        </div>`
      )}
      <div class="mutado" style="font-size:13px;padding-top:14px">Visita completa típica: <strong style="color:var(--tinta-2)">${stats.visitaTipicaMin ? fmtDur(stats.visitaTipicaMin) : '—'}</strong> · o tempo é medido pelo cronômetro em cada atendimento.</div>
    </div>`;
}

function abaHistorico(vm) {
  const { stats } = vm;
  const primeiro = stats.concluidos[stats.concluidos.length - 1];
  const kpis = [
    { icone: 'scissors', rotulo: 'Atendimentos', valor: String(stats.atendimentos), dica: primeiro ? `desde ${MESES[new Date(primeiro.inicio).getMonth()]} de ${new Date(primeiro.inicio).getFullYear()}` : '—' },
    { icone: 'wallet', rotulo: 'Total pago', valor: fmtBRLCurto(vm.totalPagoCentavos), dica: vm.mensPagasCentavos ? `inclui ${fmtBRLCurto(vm.mensPagasCentavos)} de mensalidades` : `ticket médio ${stats.ticketMedioCentavos ? fmtBRLCurto(stats.ticketMedioCentavos) : '—'}` },
    { icone: 'timer', rotulo: 'Tempo total', valor: fmtDur(stats.tempoTotalMin), dica: stats.visitaTipicaMin ? `média ${fmtDur(stats.visitaTipicaMin)} por visita` : '—' },
    { icone: 'calendar-check', rotulo: 'Última visita', valor: stats.ultimaVisita ? fmtDataCurta(stats.ultimaVisita) : '—', dica: stats.diasDesdeUltima !== null ? haDias(stats.diasDesdeUltima) : '—' },
  ];
  return html`
    <div class="grade-4" style="gap:14px;margin-bottom:16px">
      ${kpis.map((k) => html`<div class="stat-g"><div class="stat-rotulo">${icon(k.icone, 13)}<span>${k.rotulo}</span></div><div class="stat-valor">${k.valor}</div><div class="stat-dica">${k.dica}</div></div>`)}
    </div>
    <div class="grade-lateral">
      <div class="card r22 pad-18">
        <div class="titulo-card g" style="margin-bottom:6px">Histórico de atendimentos</div>
        ${stats.concluidos.length
          ? stats.concluidos.map(
              (ag) => html`<div class="hist-linha hist-completo">
                <div class="hl-data">${fmtData(ag.chegadaEm || ag.inicio)}</div>
                <div class="hl-serv">${servicosDe(vm, ag)}</div>
                <div class="hl-forte">${duracaoDe(vm, ag)}</div>
                <div class="hl-forte">${valorDe(ag)}</div>
                <div style="text-align:right">${(() => { const sp = situacaoPagamento(ag); return selo(sp.texto, sp.cls === 'ambar' ? 'rosa' : sp.cls === 'verde' ? 'verde' : 'roxo'); })()}</div>
              </div>`
            )
          : vazio({ icone: 'scissors', titulo: 'Nenhum atendimento concluído', compacto: true })}
      </div>
      <div class="card r22 pad-18">
        <div class="titulo-card g" style="margin-bottom:10px">Resumo financeiro</div>
        <div class="linha" style="padding:10px 0;border-top-color:var(--borda)"><span class="l-rotulo">Total pago</span><span class="l-valor">${fmtBRLCurto(vm.totalPagoCentavos)}</span></div>
        ${vm.mensPagasCentavos ? html`<div class="linha" style="padding:10px 0;border-top-color:var(--borda)"><span class="l-rotulo">· em mensalidades</span><span class="l-valor">${fmtBRLCurto(vm.mensPagasCentavos)}</span></div>` : ''}
        <div class="linha" style="padding:10px 0;border-top-color:var(--borda)"><span class="l-rotulo">Ticket médio</span><span class="l-valor">${stats.ticketMedioCentavos ? fmtBRLCurto(stats.ticketMedioCentavos) : '—'}</span></div>
        <div class="linha" style="padding:10px 0;border-top-color:var(--borda)"><span class="l-rotulo">Atendimentos</span><span class="l-valor">${stats.atendimentos}</span></div>
        <div class="linha" style="padding:10px 0;border-top-color:var(--borda)"><span class="l-rotulo">Não pago</span><span class="l-valor" style="color:${vm.naoPagoCentavos ? 'var(--rosa)' : 'var(--tinta-2)'}">${fmtBRL(vm.naoPagoCentavos)}</span></div>
        ${vm.qtdMensAbertas ? html`<div class="mutado" style="font-size:12px">inclui ${vm.qtdMensAbertas} ${vm.qtdMensAbertas === 1 ? 'mensalidade' : 'mensalidades'} do plano em aberto</div>` : ''}
        ${vm.plano
          ? html`<button class="linha" style="width:100%;padding:10px 0;border-top-color:var(--borda)" data-acao="plano" data-id="${vm.plano.id}">
              <span class="l-rotulo">${vm.plano.nome}${vm.plano.valorCentavos ? ` · ${fmtBRLCurto(vm.plano.valorCentavos)}/mês` : ''}</span>
              <span class="l-valor" style="font-weight:500;font-size:12.5px">${vm.proximaCobranca ? `cobrar em ${fmtDataCurta(vm.proximaCobranca.ts)}` : 'mensalidades em dia'}</span>
            </button>`
          : ''}
      </div>
    </div>`;
}

function abaSaude(vm) {
  const { pet } = vm;
  const rotina = pet.rotina || [];
  const ocorrencias = pet.ocorrencias || [];
  return html`<div class="grade-lateral">
    <div class="card r22 pad-18">
      <div class="cab-card" style="margin-bottom:6px">
        <div class="titulo-card g">Cuidados e rotina no banho</div>
        <button class="link-acao" data-acao="editar">${icon('pencil', 13)}<span>Editar cuidados</span></button>
      </div>
      ${rotina.length
        ? rotina.map(
            (r) => html`<div class="rotina-linha">
              <span class="rotina-icone">${icon(r.icone || 'sparkles', 16)}</span>
              <div style="min-width:0"><div class="rotina-titulo">${r.titulo}</div><div class="rotina-texto">${r.texto}</div></div>
            </div>`
          )
        : vazio({ icone: 'sparkles', titulo: 'Nenhum cuidado registrado', texto: 'Anote shampoo, secagem, tosa e o que acalma o pet.', compacto: true })}
    </div>
    <div class="at-col">
      <div class="card r22 pad-18">
        <div class="titulo-card g" style="margin-bottom:8px">Observações do groomer</div>
        <div class="texto-longo">${pet.obs || 'Sem observações.'}</div>
      </div>
      <div class="card r22 pad-18">
        <div class="titulo-card g" style="margin-bottom:4px">Ocorrências registradas</div>
        ${ocorrencias.slice(0, 6).map(
          (o) => html`<div class="linha" style="padding:11px 0;border-top-color:var(--borda);align-items:flex-start">
            <span style="color:var(--texto-2)">${o.tipo} · ${fmtDataCurta(o.em)}</span>
            <span class="mutado" style="font-size:12px;text-align:right;max-width:55%">${o.texto}</span>
          </div>`
        )}
        ${ocorrencias.length ? '' : html`<div class="mutado" style="font-size:12.5px;padding:8px 0">Nenhuma ocorrência.</div>`}
        <button class="btn btn-lavanda bloco" style="margin-top:12px;padding:11px" data-acao="ocorrencia">Registrar ocorrência</button>
      </div>
    </div>
  </div>`;
}

/* ------------------------------- Tela ------------------------------- */

export default {
  titulo: 'Ficha do pet',
  menu: 'clientes',
  carregar,

  render(vm, params) {
    if (!vm.pet) return html`${voltar('Voltar para clientes')}<div class="card pad-18">${vazio({ icone: 'search', titulo: 'Pet não encontrado', texto: 'Ele pode ter sido movido para a lixeira.' })}</div>`;
    const aba = ABAS.includes(params.aba) ? params.aba : 'Resumo';
    const conteudo = { Resumo: abaResumo, Tempos: abaTempos, Histórico: abaHistorico, Saúde: abaSaude }[aba](vm);

    return html`
      ${voltar('Voltar para clientes', 'clientes')}
      <div class="card r22 cortar" style="margin-bottom:16px">
        ${hero(vm)}
        ${saude(vm)}
      </div>
      <div class="abas-pet">${ABAS.map((a) => html`<button class="${a === aba ? 'on' : ''}" data-acao="aba" data-aba="${a}">${a}</button>`)}</div>
      ${conteudo}`;
  },

  acoes: {
    plano: ({ id }, ctx) => ctx.navegar('plano-rec', { id }),
    clientes: (_, ctx) => ctx.navegar('clientes'),
    aba: ({ aba }, ctx) => ctx.navegar('ficha-pet', { id: ctx.vm.pet.id, aba }, { substituir: true }),
    novo: (_, ctx) => ctx.navegar('novo-agendamento', { petId: ctx.vm.pet.id }),
    editar: (_, ctx) => ctx.navegar('editar-pet', { id: ctx.vm.pet.id }),
    tutor: (_, ctx) => ctx.navegar('ficha-tutor', { id: ctx.vm.tutor.id, petId: ctx.vm.pet.id }),
    ligar: async (_, ctx) => {
      const contato = await escolherContato(ctx, ctx.vm.tutor);
      if (contato) ligar(contato.telefone);
      else if (!contatosDoTutor(ctx.vm.tutor).length) ctx.toast('Este tutor não tem telefone cadastrado', { erro: true });
    },
    whats: (_, ctx) => {
      const { tutor, pet, proximos, stats } = ctx.vm;
      const ag = proximos[0] || null;
      abrirWhatsapp(ctx, { tutor, pet, ag, modelo: ag ? 'Lembrete de agendamento' : stats.retornoAtrasado ? 'Retorno atrasado' : 'Mensagem livre' });
    },
    lembrar: (_, ctx) => abrirWhatsapp(ctx, { tutor: ctx.vm.tutor, pet: ctx.vm.pet, modelo: 'Retorno atrasado' }),
    'abrir-ag': ({ id }, ctx) => ctx.navegar('novo-agendamento', { id }),
    ocorrencia: async (_, ctx) => {
      if (await registrarOcorrencia(ctx, { petId: ctx.vm.pet.id })) ctx.recarregar();
    },
  },
};
