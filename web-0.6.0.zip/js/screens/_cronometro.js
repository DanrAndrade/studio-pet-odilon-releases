import { html, fmtCron } from '../core/dom.js';

/* Marcação dos cronômetros. O app atualiza estes elementos a cada segundo
   (ver tickCronometros em app.js) sem redesenhar a tela. */

export const segundosItem = (item, agora = Date.now()) => (item.accSeg || 0) + (item.t0 ? (agora - item.t0) / 1000 : 0);

export const cronItem = (item) =>
  html`<span class="num" data-cron="item" data-acc="${item.accSeg || 0}" data-t0="${item.t0 || ''}">${fmtCron(segundosItem(item))}</span>`;

/** Tempo do atendimento: desde a chegada, sem contar as pausas (nem o tempo entre finalizar e reabrir). */
export const segundosSessao = (ag, agora = Date.now()) => {
  const chegada = ag.chegadaEm || ag.inicio;
  return Math.max(0, ((ag.pausadoEm || agora) - chegada) / 1000 - (ag.pausaSeg || 0));
};

export const cronSessao = (ag) =>
  html`<span class="num" data-cron="sessao" data-desde="${ag.chegadaEm || ag.inicio}" data-pausa="${ag.pausaSeg || 0}" data-parado="${ag.pausadoEm || ''}">${fmtCron(segundosSessao(ag))}</span>`;

export const cronDesde = (ts) => html`<span class="num" data-cron="desde" data-desde="${ts}">${fmtCron((Date.now() - ts) / 1000)}</span>`;

export const cronSoma = (itens) =>
  html`<span class="num" data-cron="soma" data-itens="${JSON.stringify(itens.map((i) => [i.accSeg || 0, i.t0 || 0]))}">${fmtCron(
    itens.reduce((s, i) => s + segundosItem(i), 0)
  )}</span>`;

export function barraItem(item, classe = 'at-barra') {
  const seg = segundosItem(item);
  const media = item.mediaSeg || 0;
  const pct = media ? Math.min(100, (seg / media) * 100) : 0;
  const cor = media && seg > media ? 'var(--ambar-barra)' : 'var(--roxo)';
  return html`<div class="${classe}" data-cron="barra" data-acc="${item.accSeg || 0}" data-t0="${item.t0 || ''}" data-media="${media}"><div style="width:${pct.toFixed(1)}%;background:${cor}"></div></div>`;
}

/** Aparência de cada estado do cronômetro de um serviço (valores da referência). */
export function estadoItem(item) {
  if (item.done) return { cor: 'var(--verde-escuro)', tag: 'Concluído', tom: 'verde', botao: 'Reabrir', icone: 'rotate-ccw' };
  if (item.t0) return { cor: 'var(--roxo)', tag: 'Em execução', tom: 'roxo', botao: 'Pausar', icone: 'pause' };
  return { cor: 'var(--texto-5)', tag: 'Não iniciado', tom: 'neutro', botao: 'Iniciar', icone: 'play' };
}
