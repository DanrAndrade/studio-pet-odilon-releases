import {
  html, icon, fmtBRL, fmtBRLCurto, fmtData, fmtDataCurta, fmtHora, mesmoDia, DIA_MS,
  inicioDoDia, fimDoDia, inicioDaSemana, inicioDoMes, fimDoMes, valorData,
} from '../core/dom.js';
import { vazio, barra, CORES_TRACO } from '../core/ui.js';
import { agendamentos, faturamento, planos, tutores, servicos, dataDoAtendimento, nomesParaRelatorio } from '../data/repo.js';
import { compartilharArquivo } from '../core/nativo.js';
import { minutosDaVisita } from '../logic/metricas.js';
import { escolherFormaRecebimento, descreverRecebimento } from '../modais/recebimento.js';

/* FATURAMENTO — o relatório fecha pelo que foi PAGO: atendimentos e
   mensalidades entram no período pela data do pagamento (um atendimento de
   setembro pago em outubro conta em outubro). O que foi atendido e ainda não
   foi pago aparece à parte e em "A receber", até ser marcado como pago. */

const PERIODOS = ['Hoje', 'Semana', 'Este mês', 'Mês passado'];
const ICONES_PAGAMENTO = { PIX: 'qr-code', Dinheiro: 'banknote', Débito: 'credit-card', Crédito: 'credit-card', Boleto: 'receipt', Fiado: 'wallet' };
const MAX_FATIAS = 5;
const MAX_LINHAS_RECEBER = 10;
const COR_PLANOS = 'var(--roxo-claro)';

// recebimentos feitos nesta visita à tela (chave → forma anterior): permitem desfazer sem a linha sumir
const ui = { periodo: 'Este mês', recebidos: new Map(), receberTodos: false };

function intervalo(periodo, agora = Date.now()) {
  switch (periodo) {
    case 'Hoje':
      return { de: inicioDoDia(agora), ate: fimDoDia(agora) };
    case 'Semana':
      return { de: inicioDaSemana(agora), ate: fimDoDia(agora) };
    case 'Mês passado': {
      const d = new Date(agora);
      const ref = new Date(d.getFullYear(), d.getMonth() - 1, 15).getTime();
      return { de: inicioDoMes(ref), ate: fimDoMes(ref) };
    }
    default:
      return { de: inicioDoMes(agora), ate: fimDoDia(agora) };
  }
}

/** Reparte o valor cobrado entre os serviços, proporcional ao preço de cada um (desconto incluso). */
function porServico(concluidos, itensPorAg, cores) {
  const mapa = new Map();
  for (const ag of concluidos) {
    const itens = itensPorAg.get(ag.id) || [];
    const bruto = itens.reduce((s, i) => s + (i.precoCentavos || 0), 0);
    if (!ag.valorCentavos) continue;
    if (!bruto) {
      const outros = mapa.get('Outros') || { nome: 'Outros', valor: 0, cor: 'var(--texto-6)' };
      outros.valor += ag.valorCentavos;
      mapa.set('Outros', outros);
      continue;
    }
    // o arredondamento de cada parte vai para o último serviço: a soma bate com o valor cobrado
    let distribuido = 0;
    itens.forEach((i, n) => {
      const parte = n === itens.length - 1 ? ag.valorCentavos - distribuido : Math.round(((i.precoCentavos || 0) / bruto) * ag.valorCentavos);
      distribuido += parte;
      const atual = mapa.get(i.nome) || { nome: i.nome, valor: 0, cor: cores.get(i.servicoId) };
      atual.valor += parte;
      mapa.set(i.nome, atual);
    });
  }
  const outrosAvulsos = mapa.get('Outros')?.valor || 0;
  mapa.delete('Outros');
  const lista = [...mapa.values()].sort((a, b) => b.valor - a.valor);
  const principais = lista.slice(0, MAX_FATIAS);
  const resto = lista.slice(MAX_FATIAS).reduce((s, x) => s + x.valor, 0) + outrosAvulsos;
  if (resto) principais.push({ nome: 'Outros', valor: resto, cor: 'var(--texto-6)' });
  principais.forEach((x, i) => (x.cor = x.cor || CORES_TRACO[i % CORES_TRACO.length]));
  return principais;
}

/** Percentuais inteiros que sempre somam 100 (o arredondamento sobra para as maiores partes). */
function percentuais(valores) {
  const total = valores.reduce((s, v) => s + v, 0);
  if (!total) return valores.map(() => 0);
  const brutos = valores.map((v) => (v / total) * 100);
  const saida = brutos.map(Math.floor);
  let falta = 100 - saida.reduce((s, v) => s + v, 0);
  const ordem = brutos.map((b, i) => [b - Math.floor(b), i]).sort((x, y) => y[0] - x[0]);
  for (const [, i] of ordem) if (falta-- > 0) saida[i]++;
  return saida;
}

export default {
  titulo: 'Faturamento',
  menu: 'faturamento',

  async carregar() {
    const { de, ate } = intervalo(ui.periodo);
    const { concluidos, itensPorAg, recebimentos, mensalidades } = await faturamento.periodo(de, ate);
    // nomes inclusive de pets e tutores excluídos: o histórico não perde quem foi
    const { pets: nomesPets, tutores: nomesTutores } = await nomesParaRelatorio();
    const listaTutores = await tutores.listar();
    // "Como conheceu a loja": de onde vêm os clientes (tutores ativos)
    const ativos = listaTutores.filter((x) => x.ativo !== false);
    const origens = new Map();
    for (const t of ativos) {
      const o = (t.origem || '').trim() || 'Não informado';
      origens.set(o, (origens.get(o) || 0) + 1);
    }
    const cores = new Map((await servicos.listar()).map((s) => [s.id, s.cor]));

    // o que foi pago no período (pela data do pagamento)
    const pagosAg = recebimentos.filter((r) => r.tipo === 'atendimento').map((r) => r.ag);
    const itensPagos = await agendamentos.itensDe(pagosAg);
    const mensalidadesPagas = recebimentos.filter((r) => r.tipo === 'mensalidade');
    const planosCentavos = mensalidadesPagas.reduce((s, r) => s + r.valorCentavos, 0);
    const totalCentavos = recebimentos.reduce((s, r) => s + r.valorCentavos, 0);
    // horas trabalhadas no período (atendimentos feitos nele, pagos ou não)
    const minutos = [...itensPorAg.values()].reduce((s, itens) => s + minutosDaVisita(itens), 0);
    // atendido no período e ainda não pago: não entra no faturamento até ser pago
    const naoPagos = concluidos.filter((a) => a.pagamentoPendente && a.valorCentavos > 0);

    const formas = new Map();
    for (const r of recebimentos) formas.set(r.forma, (formas.get(r.forma) || 0) + r.valorCentavos);

    const fatias = porServico(pagosAg, itensPagos, cores);
    if (planosCentavos) fatias.push({ nome: 'Mensalidades de planos', valor: planosCentavos, cor: COR_PLANOS });

    // "A receber" é o saldo em aberto de sempre, independente do período escolhido
    const receber = [
      ...(await faturamento.pendentes()).map((a) => ({
        chave: `ag:${a.id}`,
        tipo: 'ag',
        id: a.id,
        ts: dataDoAtendimento(a),
        valor: a.valorCentavos || 0,
        titulo: nomesPets.get(a.petId) || 'Pet',
        sub: nomesTutores.get(a.tutorId) || 'Sem tutor',
        forma: a.formaPagamento || null,
      })),
      ...(await faturamento.mensalidadesAbertas()).map((m) => ({
        chave: `plano:${m.plano.id}:${m.mes}`,
        tipo: 'plano',
        planoId: m.plano.id,
        mes: m.mes,
        ts: m.ts,
        valor: m.valorCentavos,
        titulo: `${nomesPets.get(m.plano.petId) || 'Pet'} · mensalidade${m.k ? ` ${m.k}/${m.total}` : ''}`,
        sub: m.plano.nome,
      })),
    ];
    // recebidos agora há pouco continuam na lista (com "desfazer") até sair da tela
    for (const [chave, { linha }] of ui.recebidos) if (!receber.some((r) => r.chave === chave)) receber.push(linha);
    receber.sort((a, b) => a.ts - b.ts);

    return {
      de,
      ate,
      concluidos,
      itensPorAg,
      recebimentos,
      nomesPets,
      nomesTutores,
      totalCentavos,
      qtdAtendimentos: pagosAg.length,
      qtdMensalidades: mensalidadesPagas.length,
      naoPagosCentavos: naoPagos.reduce((s, a) => s + a.valorCentavos, 0),
      qtdNaoPagos: naoPagos.length,
      ticketCentavos: pagosAg.length ? Math.round(pagosAg.reduce((s, a) => s + a.valorCentavos, 0) / pagosAg.length) : 0,
      // as mensalidades pagam os banhos dos planos, que também gastam horas de cronômetro
      // valor por hora: o que foi atendido no período (pago ou não) + mensalidades cobradas nele,
      // dividido pelas horas de cronômetro do período (não depende de quando o cliente pagou)
      porHoraCentavos: minutos
        ? Math.round((concluidos.reduce((s, a) => s + (a.valorCentavos || 0), 0) + mensalidades.reduce((s, m) => s + m.valorCentavos, 0)) / (minutos / 60) / 100) * 100
        : 0,
      itensPagos,
      fatias,
      formas: [...formas.entries()].sort((a, b) => b[1] - a[1]),
      receber,
      origens: [...origens.entries()].sort((a, b) => b[1] - a[1]),
      totalTutores: ativos.length,
    };
  },

  render(vm) {
    const somaFatias = vm.fatias.reduce((s, f) => s + f.valor, 0);
    const pcts = percentuais(vm.fatias.map((f) => f.valor));
    let acumulado = 0;
    const gradiente = somaFatias
      ? `conic-gradient(${vm.fatias
          .map((f) => {
            const ini = (acumulado / somaFatias) * 100;
            acumulado += f.valor;
            return `${f.cor} ${ini.toFixed(2)}% ${((acumulado / somaFatias) * 100).toFixed(2)}%`;
          })
          .join(', ')})`
      : 'var(--borda)';

    const abertos = vm.receber.filter((r) => !ui.recebidos.has(r.chave));
    const totalAberto = abertos.reduce((s, r) => s + r.valor, 0);
    const atrasados = abertos.filter((r) => Date.now() - r.ts > 15 * DIA_MS).length;
    const quando = (ts) => (mesmoDia(ts, Date.now()) ? `hoje · ${fmtHora(ts)}` : fmtDataCurta(ts));
    const lancamentos = (n) => `${n} ${n === 1 ? 'lançamento' : 'lançamentos'}`;

    return html`
      <div class="fat-topo">
        <div class="segmento">${PERIODOS.map((p) => html`<button class="${ui.periodo === p ? 'on' : ''}" data-acao="periodo" data-periodo="${p}">${p}</button>`)}</div>
        <button class="btn btn-branco" style="font-weight:500;padding:10px 15px" data-acao="exportar">${icon('download', 15)}<span>Exportar</span></button>
      </div>

      <div class="grade-4 fat-kpis">
        <div class="kpi"><div class="kpi-rotulo">Faturamento</div><div class="kpi-valor" style="color:var(--verde-escuro)">${fmtBRLCurto(vm.totalCentavos)}</div><div class="kpi-sub">pago no período · ${vm.qtdAtendimentos} ${vm.qtdAtendimentos === 1 ? 'atendimento' : 'atendimentos'}${vm.qtdMensalidades ? ` + ${vm.qtdMensalidades} ${vm.qtdMensalidades === 1 ? 'mensalidade' : 'mensalidades'}` : ''}</div></div>
        <div class="kpi"><div class="kpi-rotulo">Atendido e não pago</div><div class="kpi-valor" style="color:${vm.naoPagosCentavos ? 'var(--rosa)' : 'var(--tinta-2)'}">${fmtBRLCurto(vm.naoPagosCentavos)}</div><div class="kpi-sub">${vm.qtdNaoPagos ? `${vm.qtdNaoPagos} ${vm.qtdNaoPagos === 1 ? 'atendimento' : 'atendimentos'} · entra quando pagar` : 'tudo pago no período'}</div></div>
        <div class="kpi"><div class="kpi-rotulo">Ticket médio</div><div class="kpi-valor">${vm.ticketCentavos ? fmtBRLCurto(vm.ticketCentavos) : '—'}</div><div class="kpi-sub">dos atendimentos pagos</div></div>
        <div class="kpi"><div class="kpi-rotulo">Valor por hora</div><div class="kpi-valor">${vm.porHoraCentavos ? fmtBRLCurto(vm.porHoraCentavos) : '—'}</div><div class="kpi-sub">atendido no período ÷ horas</div></div>
      </div>

      <div class="grade-2 fat-grade">
        <div class="card pad-18 fat-donut-card">
          <div class="fat-donut" style="background:${gradiente}">
            <div class="fat-donut-miolo">
              <div style="font-size:11px;color:var(--texto-3);font-weight:500">Total</div>
              <div style="font-size:17px;font-weight:600;color:var(--tinta-2)">${fmtBRLCurto(somaFatias)}</div>
            </div>
          </div>
          <div style="display:flex;flex-direction:column;gap:9px;flex:1;min-width:0">
            <div class="titulo-card" style="margin-bottom:2px">Faturamento por serviço</div>
            ${vm.fatias.length
              ? vm.fatias.map(
                  (f, i) => html`<div class="fat-legenda">
                    <span class="fat-ponto" style="background:${f.cor}"></span>
                    <span class="truncar" style="color:var(--texto-2);font-weight:500;flex:1;min-width:0">${f.nome}</span>
                    <span style="color:var(--tinta-2);font-weight:600;white-space:nowrap">${fmtBRLCurto(f.valor)}</span>
                    <span style="color:var(--texto-5);white-space:nowrap;width:34px;text-align:right">${pcts[i]}%</span>
                  </div>`
                )
              : html`<div class="mutado" style="font-size:12.5px">Nada pago no período.</div>`}
          </div>
        </div>

        <div class="painel">
          <div class="titulo-card" style="margin-bottom:2px">Recebido por forma de pagamento</div>
          <div class="mutado" style="font-size:12px;margin-bottom:10px">O que foi pago no período · total ${fmtBRL(vm.totalCentavos)}</div>
          ${vm.formas.length
            ? vm.formas.map(
                ([nome, valor]) => html`<div class="linha">
                  <span style="display:flex;align-items:center;gap:8px;color:var(--texto-2)"><span style="color:var(--texto-3);display:flex">${icon(ICONES_PAGAMENTO[nome] || 'wallet', 14)}</span>${nome}</span>
                  <span style="font-weight:600;color:var(--tinta-2)">${fmtBRLCurto(valor)}</span>
                </div>`
              )
            : html`<div class="mutado" style="font-size:12.5px;padding:9px 0;border-top:1px solid var(--divisor)">Nada foi pago neste período.</div>`}
        </div>
      </div>

      <div class="fat-grade">
        <div class="painel">
          <div style="display:flex;justify-content:space-between;align-items:baseline;margin-bottom:2px;gap:10px">
            <div class="titulo-card">A receber · não pagos</div>
            <div style="font-size:17px;font-weight:600;color:var(--rosa)">${fmtBRL(totalAberto)}</div>
          </div>
          <div class="mutado" style="font-size:12px;margin-bottom:4px">${lancamentos(abertos.length)} aguardando pagamento${atrasados ? ` · ${atrasados} há mais de 15 dias` : ''}</div>
          ${vm.receber.length
            ? html`${(ui.receberTodos ? vm.receber : vm.receber.slice(0, MAX_LINHAS_RECEBER)).map((r) => {
                const recebido = ui.recebidos.has(r.chave);
                return html`<div class="fat-receber">
                  <div style="min-width:0">
                    <div class="truncar" style="font-size:13px;font-weight:600;color:var(--tinta-2)">${r.titulo} · ${fmtBRL(r.valor)}</div>
                    <div class="truncar mutado" style="font-size:11.5px;margin-top:2px">${r.sub} · ${r.tipo === 'plano' ? `cobrada no banho de ${fmtDataCurta(r.ts)}` : `atendido ${quando(r.ts)}`}</div>
                  </div>
                  <button class="aviso-botao${recebido ? ' recebido' : ' pagar'}" data-acao="receber" data-chave="${r.chave}">${recebido ? 'Pago · desfazer' : 'Marcar pago'}</button>
                </div>`;
              })}
              ${vm.receber.length > MAX_LINHAS_RECEBER
                ? html`<button class="link-acao" style="margin-top:10px" data-acao="receber-todos">${ui.receberTodos ? 'Mostrar só os 10 mais antigos' : `Mostrar todos (mais ${lancamentos(vm.receber.length - MAX_LINHAS_RECEBER)})`}</button>`
                : ''}`
            : vazio({ icone: 'circle-check-big', titulo: 'Nada a receber', texto: 'Atendimentos e mensalidades estão pagos.', compacto: true })}
        </div>
      </div>

      <div class="painel">
        <div class="cab-card" style="margin-bottom:10px">
          <div class="titulo-card">Como os clientes chegaram</div>
          <span class="mutado" style="font-size:12px">${vm.totalTutores} ${vm.totalTutores === 1 ? 'tutor' : 'tutores'}</span>
        </div>
        ${vm.origens.length
          ? vm.origens.map(([nome, qtd]) => {
              const pct = Math.round((qtd / vm.totalTutores) * 100);
              return html`<div style="padding:8px 0;border-top:1px solid var(--divisor)">
                <div style="display:flex;justify-content:space-between;font-size:12.5px;margin-bottom:6px"><span style="color:var(--texto-2);font-weight:500">${nome}</span><span style="font-weight:600;color:var(--tinta-2)">${qtd} · ${pct}%</span></div>
                ${barra(pct, nome === 'Não informado' ? 'var(--texto-6)' : 'var(--roxo)', 7)}
              </div>`;
            })
          : html`<div class="mutado" style="font-size:12.5px;padding:9px 0;border-top:1px solid var(--divisor)">Cadastre tutores marcando “Como conheceu a loja”.</div>`}
      </div>`;
  },

  acoes: {
    periodo: ({ periodo }, ctx) => {
      ui.periodo = periodo;
      ui.recebidos.clear();
      ctx.recarregar();
    },
    receber: async ({ chave }, ctx) => {
      const r = ctx.vm.receber.find((x) => x.chave === chave);
      if (!r) return;
      if (ui.recebidos.has(chave)) {
        if (r.tipo === 'ag') await agendamentos.desfazerRecebimento(r.id, ui.recebidos.get(chave).formaAnterior);
        else await planos.desfazerPagamento(r.planoId, r.mes);
        ui.recebidos.delete(chave);
        ctx.toast('Marcado como não pago');
        return ctx.recarregar();
      }
      const rec = await escolherFormaRecebimento(ctx, { valorCentavos: r.valor, detalhe: r.titulo });
      if (!rec) return;
      if (r.tipo === 'ag') await agendamentos.registrarRecebimento(r.id, rec.forma, rec.quando);
      else await planos.registrarPagamento(r.planoId, r.mes, rec.forma, rec.quando);
      ui.recebidos.set(chave, { linha: r, formaAnterior: r.forma ?? null });
      ctx.toast(`Marcado como pago · ${descreverRecebimento(rec)}`);
      // o recebido entra no faturamento do período: recarrega os números (a linha continua para poder desfazer)
      ctx.recarregar();
    },
    exportar: (_, ctx) => exportarCsv(ctx),
    'receber-todos': (_, ctx) => {
      ui.receberTodos = !ui.receberTodos;
      ctx.redesenhar();
    },
  },

  aoSair() {
    ui.recebidos.clear();
  },
};

function exportarCsv(ctx) {
  const vm = ctx.vm;
  const celula = (v) => `"${String(v ?? '').replace(/"/g, '""')}"`;
  const reais = (c) => ((c || 0) / 100).toFixed(2).replace('.', ',');
  const quando = (ts) => (ts ? `${fmtData(ts)} ${fmtHora(ts)}` : '');
  const linhas = [['Pago em', 'Tipo', 'Pet', 'Tutor', 'Serviços / plano', 'Subtotal (R$)', 'Desconto (R$)', 'Acréscimo (R$)', 'Valor (R$)', 'Forma de pagamento', 'Data do atendimento']];

  // faturamento: o que foi pago no período, pela data do pagamento
  for (const r of [...vm.recebimentos].sort((a, b) => a.ts - b.ts)) {
    if (r.tipo === 'atendimento') {
      const ag = r.ag;
      linhas.push([
        quando(r.ts),
        'Atendimento',
        vm.nomesPets.get(ag.petId) || '',
        vm.nomesTutores.get(ag.tutorId) || '',
        (vm.itensPagos.get(ag.id) || vm.itensPorAg.get(ag.id) || []).map((i) => i.nome).join(' + '),
        reais(ag.subtotalCentavos),
        reais(ag.descontoCentavos),
        reais(ag.acrescimoCentavos),
        reais(ag.valorCentavos),
        r.forma,
        quando(dataDoAtendimento(ag)),
      ]);
    } else {
      const { plano } = r.mensalidade;
      const [ano, mes] = String(r.mensalidade.mes).split('-');
      linhas.push([quando(r.ts), 'Mensalidade de plano', vm.nomesPets.get(plano.petId) || '', vm.nomesTutores.get(plano.tutorId) || '', `${plano.nome} · ${mes}/${ano}`, reais(r.valorCentavos), reais(0), reais(0), reais(r.valorCentavos), r.forma, `mensalidade de ${mes}/${ano}`]);
    }
  }
  const naoPagos = vm.concluidos.filter((a) => a.pagamentoPendente && a.valorCentavos > 0).sort((a, b) => dataDoAtendimento(a) - dataDoAtendimento(b));
  if (linhas.length === 1 && !naoPagos.length) return ctx.toast('Nada para exportar neste período', { erro: true });
  linhas.push([]);
  linhas.push(['Faturamento do período (pago)', '', '', '', '', '', '', '', reais(vm.totalCentavos)]);
  if (naoPagos.length) {
    linhas.push([]);
    linhas.push(['Atendidos no período e ainda não pagos (não entram no faturamento)']);
    for (const ag of naoPagos) {
      linhas.push(['', 'Atendimento', vm.nomesPets.get(ag.petId) || '', vm.nomesTutores.get(ag.tutorId) || '', (vm.itensPorAg.get(ag.id) || []).map((i) => i.nome).join(' + '), reais(ag.subtotalCentavos), reais(ag.descontoCentavos), reais(ag.acrescimoCentavos), reais(ag.valorCentavos), 'A receber', quando(dataDoAtendimento(ag))]);
    }
  }

  // ; e BOM: abre certo no Excel em português
  const csv = '\ufeff' + linhas.map((l) => l.map(celula).join(';')).join('\r\n');
  compartilharArquivo(`faturamento-${valorData(vm.de)}-a-${valorData(vm.ate)}.csv`, csv, 'text/csv');
  ctx.toast(`Planilha gerada · ${vm.recebimentos.length} ${vm.recebimentos.length === 1 ? 'pagamento' : 'pagamentos'}`);
}
