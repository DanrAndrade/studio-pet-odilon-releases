import { html, icon, fmtData } from '../core/dom.js';
import { voltar, vazio, chip } from '../core/ui.js';
import { lixeira } from '../data/repo.js';
import { combina } from '../core/busca.js';

/* LIXEIRA — exclusões ficam 30 dias antes de sumir de vez. */

const corDias = (d) => (d <= 7 ? 'var(--rosa)' : d <= 14 ? 'var(--ambar)' : 'var(--texto-3)');
const ui = { busca: '', tipo: 'Todos' };
const rotuloDias = (d) => (d === 0 ? 'hoje' : d === 1 ? '1 dia' : `${d} dias`);

export default {
  titulo: 'Lixeira',
  menu: 'ajustes',

  async carregar() {
    return { itens: await lixeira.listar() };
  },

  render(vm) {
    const visiveis = vm.itens.map((it, i) => ({ it, i })).filter(({ it }) => (ui.tipo === 'Todos' || it.tipo === ui.tipo) && combina(ui.busca, [it.nome, it.tipo]));
    const tipos = ['Todos', ...new Set(vm.itens.map((it) => it.tipo))];
    return html`
      ${voltar('Voltar para ajustes', 'ir', { rota: 'ajustes' })}
      <div class="lix-topo">
        <div class="mutado" style="font-size:13px">Itens excluídos há mais de 30 dias são apagados automaticamente.</div>
        <button class="btn btn-rosa" style="padding:10px 15px" data-acao="esvaziar" ${vm.itens.length ? '' : 'disabled'}>${icon('trash-2', 15)}<span>Esvaziar lixeira</span></button>
      </div>
      ${vm.itens.length > 5 ? html`<div class="busca branca lista-busca" style="margin-bottom:12px">
          ${icon('search', 16)}
          <input data-campo="busca" value="${ui.busca}" placeholder="Buscar na lixeira…">
          ${ui.busca ? html`<button data-acao="limpar-busca" style="display:flex;color:var(--texto-3)" aria-label="Limpar">${icon('x', 15)}</button>` : ''}
        </div>` : ''}
      ${tipos.length > 2 ? html`<div class="chips" style="gap:8px;margin-bottom:12px">${tipos.map((t) => chip(t, ui.tipo === t, 'tipo', { tipo: t }, { suave: true }))}</div>` : ''}
      <div class="card" style="padding:6px 18px 12px">
        ${vm.itens.length
          ? html`<div class="cab-tabela lix-colunas"><div>Tipo</div><div>Registro</div><div>Excluído em</div><div>Dias restantes</div><div style="text-align:right">Ações</div></div>
              ${visiveis.map(
                ({ it, i }) => html`<div class="linha-tabela lix-colunas">
                  <div><span class="selo selo-neutro">${it.tipo}</span></div>
                  <div class="lix-nome">${it.nome}</div>
                  <div class="mutado lix-data">${fmtData(it.excluidoEm)}</div>
                  <div class="lix-dias" style="color:${corDias(it.diasRestantes)};font-weight:600">${rotuloDias(it.diasRestantes)}</div>
                  <div class="lix-acoes">
                    <button class="lix-btn" data-acao="restaurar" data-i="${i}">Restaurar</button>
                    <button class="lix-btn rosa" data-acao="excluir" data-i="${i}">Excluir</button>
                  </div>
                </div>`
              )}`
          : vazio({ icone: 'trash-2', titulo: 'A lixeira está vazia', texto: 'O que você excluir fica aqui por 30 dias e pode ser restaurado.' })}
      </div>`;
  },

  aoDigitar(campo, valor, ctx) {
    if (campo !== 'busca') return;
    ui.busca = valor;
    ctx.redesenhar();
  },

  acoes: {
    'limpar-busca': (_, ctx) => {
      ui.busca = '';
      ctx.redesenhar();
    },
    tipo: ({ tipo }, ctx) => {
      ui.tipo = tipo;
      ctx.redesenhar();
    },
    restaurar: async ({ i }, ctx) => {
      const item = ctx.vm.itens[Number(i)];
      await lixeira.restaurar(item);
      ctx.toast(`${item.nome} restaurado`);
      ctx.recarregar();
    },
    excluir: async ({ i }, ctx) => {
      const item = ctx.vm.itens[Number(i)];
      const ok = await ctx.confirmar({
        titulo: `Excluir “${item.nome}” de vez?`,
        texto: 'Essa ação não pode ser desfeita.',
        botao: 'Excluir definitivamente',
      });
      if (!ok) return;
      await lixeira.excluirDefinitivo(item);
      ctx.toast(`${item.nome} excluído definitivamente`);
      ctx.recarregar();
    },
    esvaziar: async (_, ctx) => {
      const ok = await ctx.confirmar({
        titulo: 'Esvaziar a lixeira?',
        texto: `${ctx.vm.itens.length} ${ctx.vm.itens.length === 1 ? 'registro será apagado' : 'registros serão apagados'} para sempre. Essa ação não pode ser desfeita.`,
        botao: 'Esvaziar lixeira',
      });
      if (!ok) return;
      await lixeira.esvaziar();
      ctx.toast('Lixeira esvaziada');
      ctx.recarregar();
    },
  },
};
