import { html, icon, fmtData, fmtDataCurta, digitos, deDataBR, proximoAniversario, DIA_MS } from '../core/dom.js';
import { avPet, avTutor, descricaoPet, vazio, chip } from '../core/ui.js';
import { agendamentos, pets, tutores, planos, PORTES, faturamento } from '../data/repo.js';
import { ligar } from '../core/nativo.js';
import { cadastroPetIncompleto, cadastroTutorIncompleto, estatisticasPet } from '../logic/metricas.js';
import { abrirWhatsapp } from '../modais/whatsapp.js';
import { combina, ordemAlfabetica } from '../core/busca.js';
import { contatosDoTutor, nomesDoTutor, nomesParaBusca, telefonesDoTutor } from '../logic/contatos.js';
import { escolherContato } from '../modais/contato.js';
import { planoVigente } from '../logic/planos.js';

/* CLIENTES — por padrão, um cartão por tutor com os pets dele (é assim que
   o Odilon pensa no cliente). A visão "Pets" lista um cartão por animal. */

const VISOES = ['Tutores', 'Pets'];
const FILTROS = ['Todos', 'Com plano ativo', 'Aniversariantes do mês', 'Sem data de nascimento', 'Sem atendimento há 90 dias', 'Cadastro incompleto', 'Não pago'];
const SEM_TUTOR = '__sem_tutor__';
const ESPECIES = ['Todas', 'Cão', 'Gato', 'Outro'];
const ui = { visao: 'Tutores', filtro: 'Todos', busca: '', especie: 'Todas', porte: 'Todos' };

/** Espécie e porte valem para o pet; na visão por tutor, basta um dos pets dele. */
const petPassa = (pet) =>
  (ui.especie === 'Todas' || (ui.especie === 'Outro' ? !['Cão', 'Gato'].includes(pet.especie) : pet.especie === ui.especie)) &&
  (ui.porte === 'Todos' || pet.porte === ui.porte);

const semVisitaHa90 = (ultima) => !ultima || Date.now() - ultima > 90 * DIA_MS;

/** Um "cliente" genérico (pet ou tutor) com os campos que busca e filtros usam. */
function passaNosFiltros(item) {
  if (!combina(ui.busca, item.textos, item.telefones)) return false;
  if (ui.especie !== 'Todas' || ui.porte !== 'Todos') {
    const lista = item.pet ? [item.pet] : (item.pets || []).map((l) => l.pet);
    if (!lista.some(petPassa)) return false;
  }
  switch (ui.filtro) {
    case 'Com plano ativo':
      return item.plano;
    case 'Sem atendimento há 90 dias':
      return semVisitaHa90(item.ultima);
    case 'Cadastro incompleto':
      return item.incompleto;
    case 'Não pago':
      return item.pendente > 0;
    case 'Aniversariantes do mês':
      return item.aniversarioMes;
    case 'Sem data de nascimento':
      return item.semNascimento;
    default:
      return true;
  }
}

export default {
  titulo: 'Clientes',
  menu: 'clientes',
  fab: true,

  async carregar() {
    const listaPets = await pets.listar();
    const listaTutores = await tutores.listar();
    const comPlano = new Set((await planos.listar()).filter((p) => planoVigente(p)).map((p) => p.petId));
    const porPet = new Map();
    for (const ag of await agendamentos.concluidos()) {
      if (!porPet.has(ag.petId)) porPet.set(ag.petId, []);
      porPet.get(ag.petId).push(ag);
    }
    const mapaTutores = new Map(listaTutores.map((t) => [t.id, t]));
    // não pago: atendimentos (inclusive de pet já excluído, pelo tutor) + mensalidades em aberto
    const abertasPorPet = new Map();
    for (const m of await faturamento.mensalidadesAbertas()) abertasPorPet.set(m.plano.petId, (abertasPorPet.get(m.plano.petId) || 0) + m.valorCentavos);
    const idsPetsVivos = new Set(listaPets.map((p) => p.id));
    const dividaOrfaPorTutor = new Map();
    for (const ag of await agendamentos.concluidos()) {
      if (!ag.pagamentoPendente || !(ag.valorCentavos > 0) || idsPetsVivos.has(ag.petId) || !ag.tutorId) continue;
      dividaOrfaPorTutor.set(ag.tutorId, (dividaOrfaPorTutor.get(ag.tutorId) || 0) + ag.valorCentavos);
    }

    const linhasPets = listaPets.map((pet) => {
      const tutor = mapaTutores.get(pet.tutorId) || null;
      const st = estatisticasPet(porPet.get(pet.id) || [], new Map());
      const nasc = deDataBR(pet.nascimento);
      const aniversario = nasc ? proximoAniversario(nasc) : null;
      return {
        nasc,
        aniversario,
        aniversarioMes: !!nasc && new Date(nasc).getMonth() === new Date().getMonth(),
        semNascimento: !nasc,
        pet,
        tutor,
        plano: comPlano.has(pet.id),
        ultima: st.ultimaVisita,
        atrasado: st.retornoAtrasado,
        pendente: st.pendenteCentavos + (abertasPorPet.get(pet.id) || 0),
        incompleto: cadastroPetIncompleto(pet),
        inativo: tutor?.ativo === false,
        textos: [pet.nome, pet.raca, ...nomesParaBusca(tutor)],
        telefones: telefonesDoTutor(tutor),
      };
    });

    const grupos = new Map(listaTutores.map((t) => [t.id, { tutor: t, pets: [] }]));
    for (const l of linhasPets) {
      const chave = l.tutor ? l.tutor.id : SEM_TUTOR;
      if (!grupos.has(chave)) grupos.set(chave, { tutor: null, pets: [] });
      grupos.get(chave).pets.push(l);
    }
    const linhasTutores = [...grupos.values()].map(({ tutor, pets: doTutor }) => ({
      tutor,
      pets: doTutor,
      plano: doTutor.some((l) => l.plano),
      ultima: Math.max(0, ...doTutor.map((l) => l.ultima || 0)) || null,
      atrasado: doTutor.find((l) => l.atrasado) || null,
      pendente: doTutor.reduce((s, l) => s + l.pendente, 0) + (tutor ? dividaOrfaPorTutor.get(tutor.id) || 0 : 0),
      incompleto: (tutor ? cadastroTutorIncompleto(tutor) : true) || doTutor.some((l) => l.incompleto),
      inativo: tutor?.ativo === false,
      aniversarioMes: doTutor.some((l) => l.aniversarioMes),
      semNascimento: doTutor.some((l) => l.semNascimento),
      textos: [...nomesParaBusca(tutor), ...doTutor.map((l) => l.pet.nome)],
      telefones: telefonesDoTutor(tutor),
    }));

    const ordenar = (nome) => (a, b) => Number(a.inativo) - Number(b.inativo) || ordemAlfabetica(nome(a), nome(b));
    linhasPets.sort(ordenar((l) => l.pet.nome));
    // "sem tutor" vai para o fim da lista
    linhasTutores.sort((a, b) => Number(!a.tutor) - Number(!b.tutor) || ordenar((l) => l.tutor?.nome || '')(a, b));
    return { linhasPets, linhasTutores };
  },

  render(vm) {
    const tutoresVisao = ui.visao === 'Tutores';
    const total = tutoresVisao ? vm.linhasTutores.length : vm.linhasPets.length;
    const lista = (tutoresVisao ? vm.linhasTutores : vm.linhasPets).filter(passaNosFiltros);
    // aniversariantes em ordem de dia do mês
    if (ui.filtro === 'Aniversariantes do mês' && !tutoresVisao) lista.sort((a, b) => new Date(a.nasc).getDate() - new Date(b.nasc).getDate());

    return html`
      <div class="cli-topo">
        <div class="busca branca">
          ${icon('search', 16)}
          <input data-campo="busca" value="${ui.busca}" placeholder="${tutoresVisao ? 'Buscar por tutor, pet ou telefone…' : 'Buscar por pet, tutor ou telefone…'}">
          ${ui.busca ? html`<button data-acao="limpar" style="display:flex;color:var(--texto-3)" aria-label="Limpar">${icon('x', 15)}</button>` : ''}
        </div>
        <div class="segmento">${VISOES.map((v) => html`<button class="${ui.visao === v ? 'on' : ''}" data-acao="visao" data-visao="${v}">${icon(v === 'Tutores' ? 'user-round' : 'paw-print', 14)} ${v}</button>`)}</div>
        <button class="btn btn-roxo" style="padding:10px 16px" data-acao="ir" data-rota="cadastro">${icon('user-plus', 15)}<span>Novo cadastro · tutor + pet</span></button>
      </div>

      <div class="chips" style="margin-bottom:10px;gap:8px">${FILTROS.map((f) => chip(f, ui.filtro === f, 'filtro', { filtro: f }, { suave: true }))}</div>
      <div class="cli-filtros-pet">
        <label>Espécie <select class="entrada" data-campo="especie">${ESPECIES.map((e) => html`<option ${ui.especie === e ? 'selected' : ''}>${e}</option>`)}</select></label>
        <label>Porte <select class="entrada" data-campo="porte">${['Todos', ...PORTES].map((p) => html`<option ${ui.porte === p ? 'selected' : ''}>${p}</option>`)}</select></label>
        ${ui.especie !== 'Todas' || ui.porte !== 'Todos' ? html`<button class="link-acao" data-acao="limpar-pet">Limpar</button>` : ''}
      </div>

      ${!total
        ? html`<div class="card pad-18">${vazio({
            icone: 'users',
            titulo: 'Nenhum cliente cadastrado ainda',
            texto: 'Cadastre o tutor e o pet de uma vez só.',
            acao: html`<button class="btn btn-roxo" data-acao="ir" data-rota="cadastro">${icon('user-plus', 15)}<span>Novo cadastro</span></button>`,
          })}</div>`
        : !lista.length
          ? html`<div class="card pad-18">${vazio({ icone: 'search', titulo: 'Nenhum cliente encontrado', texto: 'Tente outro filtro ou termo de busca.' })}</div>`
          : html`<div class="cli-grade">${lista.map(tutoresVisao ? cartaoTutor : cartaoPet)}</div>`}`;
  },

  aoDigitar(campo, valor, ctx) {
    ui[campo] = valor;
    ctx.redesenhar();
  },

  acoes: {
    visao: ({ visao }, ctx) => {
      ui.visao = visao;
      ctx.redesenhar();
    },
    filtro: ({ filtro }, ctx) => {
      ui.filtro = filtro;
      ctx.redesenhar();
    },
    limpar: (_, ctx) => {
      ui.busca = '';
      ctx.redesenhar();
    },
    'limpar-pet': (_, ctx) => {
      ui.especie = 'Todas';
      ui.porte = 'Todos';
      ctx.redesenhar();
    },
    abrir: ({ id }, ctx) => ctx.navegar('ficha-pet', { id }),
    tutor: ({ id }, ctx) => ctx.navegar('ficha-tutor', { id }),
    'novo-pet': ({ id }, ctx) => ctx.navegar('cadastro', { tutorId: id }),
    agendar: ({ id }, ctx) => ctx.navegar('novo-agendamento', { petId: id }),
    'agendar-tutor': ({ id }, ctx) => {
      const grupo = ctx.vm.linhasTutores.find((g) => g.tutor?.id === id);
      if (grupo?.pets.length === 1) return ctx.navegar('novo-agendamento', { petId: grupo.pets[0].pet.id });
      ctx.navegar('novo-agendamento', { tutorId: id });
    },
    whats: ({ id, tipo }, ctx) => {
      if (tipo === 'tutor') {
        const g = ctx.vm.linhasTutores.find((x) => x.tutor?.id === id);
        const alvo = g.atrasado || g.pets[0];
        return abrirWhatsapp(ctx, { tutor: g.tutor, pet: alvo?.pet, modelo: g.atrasado ? 'Retorno atrasado' : 'Mensagem livre' });
      }
      const l = ctx.vm.linhasPets.find((x) => x.pet.id === id);
      abrirWhatsapp(ctx, { tutor: l.tutor, pet: l.pet, modelo: l.atrasado ? 'Retorno atrasado' : 'Mensagem livre' });
    },
    ligar: async ({ tutor: id }, ctx) => {
      const tutor = ctx.vm.linhasTutores.find((g) => g.tutor?.id === id)?.tutor;
      const contato = tutor ? await escolherContato(ctx, tutor) : null;
      if (contato) ligar(contato.telefone);
      else if (!tutor || !contatosDoTutor(tutor).length) ctx.toast('Este tutor não tem telefone cadastrado', { erro: true });
    },
  },
};

/* ------------------------------ Cartões ------------------------------ */

/** Bolo no cartão quando o aniversário é neste mês ou nos próximos 7 dias. */
function seloAniversario(l) {
  if (!l.aniversario || (!l.aniversarioMes && l.aniversario.dias > 7)) return '';
  const quando = l.aniversario.dias === 0 ? 'hoje' : fmtDataCurta(l.nasc).slice(0, 5);
  return html`<span class="selo-aniversario" title="Aniversário">${icon('cake', 11)}${quando}</span>`;
}

function cartaoTutor(g) {
  const { tutor } = g;
  const nomePets = g.pets.length === 1 ? '1 pet' : `${g.pets.length} pets`;
  return html`<div class="cli-card${g.inativo ? ' inativo' : ''}" ${tutor ? html`data-acao="tutor" data-id="${tutor.id}"` : ''}>
    <div class="cli-cab">
      ${avTutor(54)}
      <div style="min-width:0;flex:1">
        <div style="display:flex;align-items:center;gap:7px">
          <span class="cli-pet truncar">${tutor ? nomesDoTutor(tutor) || 'Tutor sem nome' : 'Pets sem tutor'}</span>
          ${g.plano ? html`<span class="selo-plano">PLANO</span>` : ''}
          ${g.inativo ? html`<span class="selo-plano" style="background:var(--divisor);color:var(--texto-3)">INATIVO</span>` : ''}
        </div>
        <div class="cli-raca truncar">${tutor ? `${nomePets}${tutor.origem ? ' · ' + tutor.origem.toLowerCase() : ''}` : 'Vincule um tutor na ficha do pet'}</div>
      </div>
    </div>

    <div class="cli-pets">
      ${g.pets.map(
        (l) => html`<button class="cli-pet-item" data-acao="abrir" data-id="${l.pet.id}" title="Ficha de ${l.pet.nome}">
          ${avPet(l.pet, 30, { borda: 0, sombra: false })}
          <span class="cli-pet-texto">
            <span class="cli-pet-nome truncar">${l.pet.nome}</span>
            <span class="cli-pet-sub truncar">${descricaoPet(l.pet)}</span>
          </span>
          ${l.plano ? html`<span class="selo-plano">PLANO</span>` : ''}
          ${seloAniversario(l)}
          ${l.atrasado ? html`<span class="cli-alerta" title="Retorno atrasado">${icon('clock-alert', 13)}</span>` : ''}
        </button>`
      )}
      ${g.pets.length ? '' : html`<div class="cli-pet-vazio">Nenhum pet cadastrado</div>`}
      ${tutor ? html`<button class="cli-pet-add" data-acao="novo-pet" data-id="${tutor.id}">${icon('plus', 13)}<span>Adicionar pet</span></button>` : ''}
    </div>

    <div class="cli-dados">
      <div class="cli-dado">${icon('phone', 13)}<span>${telefonesDoTutor(tutor).join(' · ') || 'Sem telefone'}</span></div>
      <div class="cli-dado">${icon('clock', 13)}<span>Último: ${g.ultima ? fmtData(g.ultima) : 'nenhum atendimento'}</span></div>
    </div>
    ${tutor
      ? html`<div class="cli-rodape">
          <button class="cli-agendar" data-acao="agendar-tutor" data-id="${tutor.id}">Agendar</button>
          <button class="cli-icone verde" data-acao="whats" data-tipo="tutor" data-id="${tutor.id}" aria-label="WhatsApp">${icon('message-circle', 15)}</button>
          <button class="cli-icone" data-acao="ligar" data-tutor="${tutor.id}" aria-label="Ligar">${icon('phone', 15)}</button>
        </div>`
      : ''}
  </div>`;
}

function cartaoPet(l) {
  return html`<div class="cli-card${l.inativo ? ' inativo' : ''}" data-acao="abrir" data-id="${l.pet.id}">
    <div class="cli-cab">
      ${avPet(l.pet, 54)}
      <div style="min-width:0;flex:1">
        <div style="display:flex;align-items:center;gap:7px">
          <span class="cli-pet truncar">${l.pet.nome}</span>
          ${l.plano ? html`<span class="selo-plano">PLANO</span>` : ''}
          ${seloAniversario(l)}
          ${l.inativo ? html`<span class="selo-plano" style="background:var(--divisor);color:var(--texto-3)">INATIVO</span>` : ''}
        </div>
        <div class="cli-raca truncar">${descricaoPet(l.pet)}</div>
      </div>
    </div>
    <div class="cli-dados">
      <div class="cli-dado">${icon('user-round', 13)}<span>${nomesDoTutor(l.tutor) || 'Sem tutor'}</span></div>
      <div class="cli-dado">${icon('phone', 13)}<span>${telefonesDoTutor(l.tutor).join(' · ') || 'Sem telefone'}</span></div>
      <div class="cli-dado">${icon('clock', 13)}<span>Último: ${l.ultima ? fmtData(l.ultima) : 'nenhum atendimento'}</span></div>
    </div>
    <div class="cli-rodape">
      <button class="cli-agendar" data-acao="agendar" data-id="${l.pet.id}">Agendar</button>
      <button class="cli-icone verde" data-acao="whats" data-id="${l.pet.id}" aria-label="WhatsApp">${icon('message-circle', 15)}</button>
      <button class="cli-icone" data-acao="ligar" data-tutor="${l.tutor?.id || ''}" aria-label="Ligar">${icon('phone', 15)}</button>
    </div>
  </div>`;
}
