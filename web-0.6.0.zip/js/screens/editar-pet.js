import { html, icon, mascaraData, deDataBR, paraDataBR, nascimentoValido, formatarPeso, FORMATOS } from '../core/dom.js';
import { avPet, chip, campo, voltar } from '../core/ui.js';
import { pets, PORTES } from '../data/repo.js';
import * as config from '../data/config.js';
import { escolherFoto } from '../core/foto.js';

/* EDITAR FICHA DO PET */

const SEXOS = ['Macho', 'Fêmea'];
const ESPECIES = ['Cão', 'Gato', 'Outro'];
const CAMPOS_TEXTO = ['nome', 'raca', 'idade', 'nascimento', 'peso', 'pesoData', 'vacina', 'vet', 'alergias', 'obs'];

const ui = { id: null, form: null };

export default {
  titulo: 'Editar ficha do pet',
  menu: 'clientes',

  async carregar({ id }) {
    const pet = await pets.obter(id);
    if (pet && ui.id !== id) {
      ui.id = id;
      ui.form = { ...pet, rotina: (pet.rotina || []).map((r) => ({ ...r })), temperamentos: [...(pet.temperamentos || [])] };
    }
    const temperamentos = await config.lista('Temperamentos');
    const alertas = await config.lista('Alertas de saúde');
    return { pet, marcadores: [...new Set([...temperamentos, ...alertas, ...(pet?.temperamentos || [])])], racas: await config.lista('Lista de raças') };
  },

  render(vm) {
    if (!vm.pet) return html`${voltar('Voltar')}<div class="card pad-18">Pet não encontrado.</div>`;
    const f = ui.form;
    const grupo = (rotulo, opcoes, chave, extra = '') =>
      html`<div><div class="rotulo-campo">${rotulo}</div><div class="chips">${opcoes.map((o) => chip(o, f[chave] === o, 'opcao', { chave, valor: o }, { cls: extra }))}</div></div>`;

    return html`
      ${voltar(`Voltar para a ficha ${f.sexo === 'Fêmea' ? 'da' : 'do'} ${vm.pet.nome}`, 'cancelar')}
      <div class="editar-topo">
        <button class="btn btn-branco" data-acao="cancelar">Cancelar</button>
        <button class="btn btn-roxo" data-acao="salvar">${icon('check', 15)}<span>Salvar alterações</span></button>
      </div>

      <div class="grade-lateral largo">
        <div class="at-col">
          <div class="card r22 pad-18">
            <div class="titulo-card g" style="margin-bottom:14px">Identificação</div>
            <div class="grade-3" style="grid-template-columns:1.2fr 1.4fr 1fr">
              ${campo({ rotulo: 'Nome', nome: 'nome', valor: f.nome })}
              ${campo({ rotulo: 'Raça', nome: 'raca', valor: f.raca, attrs: 'list="lista-racas-edit"' })}
              ${campo({ rotulo: 'Idade', nome: 'idade', valor: f.idade, placeholder: 'Ex.: 4 anos' })}
            </div>
            <datalist id="lista-racas-edit">${vm.racas.map((r) => html`<option value="${r}"></option>`)}</datalist>
            <div class="grade-2 mt-14" style="grid-template-columns:1.6fr 1fr;gap:16px">
              ${grupo('Porte', PORTES, 'porte')}
              ${grupo('Sexo', SEXOS, 'sexo')}
            </div>
            <div class="grade-2 mt-14" style="grid-template-columns:1.6fr 1fr;gap:16px">
              ${grupo('Espécie', ESPECIES, 'especie')}
              ${campo({ rotulo: 'Nascimento', nome: 'nascimento', valor: f.nascimento, placeholder: 'dd/mm/aaaa', formato: 'data' })}
            </div>
          </div>

          <div class="card r22 pad-18">
            <div class="titulo-card g" style="margin-bottom:14px">Saúde</div>
            <div class="grade-2">
              ${campo({ rotulo: 'Peso atual', nome: 'peso', valor: f.peso, placeholder: 'Ex.: 32 kg', formato: 'peso' })}
              ${campo({ rotulo: 'Data da pesagem', nome: 'pesoData', valor: f.pesoData, placeholder: 'dd/mm/aaaa', formato: 'data' })}
            </div>
            <div class="mt-14">
              <div class="rotulo-campo">Castrado</div>
              <div class="chips">${['Sim', 'Não'].map((o) => chip(o, f.castrado === o, 'opcao', { chave: 'castrado', valor: o }, { cls: 'largo' }))}</div>
            </div>
            <div class="grade-2 mt-14">
              ${campo({ rotulo: 'Última vacina', nome: 'vacina', valor: f.vacina, placeholder: 'dd/mm/aaaa', formato: 'data' })}
              ${campo({ rotulo: 'Veterinário', nome: 'vet', valor: f.vet, placeholder: 'Clínica' })}
            </div>
            <div class="mt-14">${campo({ rotulo: 'Alergias e restrições', nome: 'alergias', valor: f.alergias, placeholder: 'Ex.: shampoo comum' })}</div>
          </div>

          <div class="card r22 pad-18">
            <div class="titulo-card g" style="margin-bottom:12px">Temperamento e alertas</div>
            <div class="chips">${vm.marcadores.map((m) => chip(m, f.temperamentos.includes(m), 'marcador', { valor: m }, { suave: true, cls: 'forte' }))}</div>
          </div>

          <div class="card r22 pad-18">
            <div class="cab-card">
              <div class="titulo-card g">Cuidados e rotina no banho</div>
              <button class="btn btn-lavanda pequeno" data-acao="add-rotina">${icon('plus', 13)}<span>Adicionar cuidado</span></button>
            </div>
            <div style="display:flex;flex-direction:column;gap:10px">
              ${f.rotina.map(
                (r, i) => html`<div class="rotina-edit">
                  <input class="entrada rotina-edit-titulo" data-campo="rotina-titulo-${i}" value="${r.titulo}" placeholder="Título do cuidado">
                  <input class="entrada" data-campo="rotina-texto-${i}" value="${r.texto}" placeholder="Como fazer">
                  <button class="btn-lixo" data-acao="del-rotina" data-indice="${i}" aria-label="Remover">${icon('trash-2', 15)}</button>
                </div>`
              )}
              ${f.rotina.length ? '' : html`<div class="mutado" style="font-size:12.5px">Nenhum cuidado ainda. Ex.: “Secador só no corpo — no rosto, toalha”.</div>`}
            </div>
          </div>
        </div>

        <div class="at-col">
          <div class="card r22 pad-18">
            <div class="titulo-card g" style="margin-bottom:12px">Foto do pet</div>
            <div style="display:flex;gap:14px;align-items:center">
              ${avPet(f, 84, { borda: 3 })}
              <div style="display:flex;flex-direction:column;gap:8px;flex:1">
                <button class="btn-foto" data-acao="foto" data-camera="1">${icon('camera', 15)}<span>Câmera</span></button>
                <button class="btn-foto" data-acao="foto">${icon('image-plus', 15)}<span>Galeria</span></button>
              </div>
            </div>
            ${f.foto ? html`<button class="link-perigo" style="margin-top:12px" data-acao="sem-foto">Remover foto</button>` : ''}
          </div>
          <div class="card r22 pad-18">
            <div class="titulo-card g" style="margin-bottom:8px">Observações do groomer</div>
            <textarea class="entrada" data-campo="obs" style="height:120px" placeholder="O que a equipe precisa saber…">${f.obs || ''}</textarea>
          </div>
          <div class="aviso-ambar">
            <div class="aviso-titulo">${icon('info', 15)}<span>Cadastro completo evita retrabalho</span></div>
            <div class="aviso-texto">Peso e data da última vacina alimentam os alertas de saúde e a média de tempo por porte.</div>
          </div>
          <button class="btn btn-rosa-contorno bloco" data-acao="excluir">${icon('trash-2', 15)}<span>Excluir pet</span></button>
        </div>
      </div>`;
  },

  aoDigitar(nome, valor, _, el) {
    if (nome === 'nascimento' && el) {
      const antes = valor;
      valor = mascaraData(valor);
      if (valor !== antes) el.value = valor;
    }
    if (CAMPOS_TEXTO.includes(nome)) ui.form[nome] = valor;
    const m = /^rotina-(titulo|texto)-(\d+)$/.exec(nome);
    if (m) ui.form.rotina[Number(m[2])][m[1]] = valor;
  },

  acoes: {
    opcao: ({ chave, valor }, ctx) => {
      ui.form[chave] = valor;
      ctx.redesenhar();
    },
    marcador: ({ valor }, ctx) => {
      const lista = ui.form.temperamentos;
      ui.form.temperamentos = lista.includes(valor) ? lista.filter((x) => x !== valor) : [...lista, valor];
      ctx.redesenhar();
    },
    'add-rotina': (_, ctx) => {
      ui.form.rotina.push({ icone: 'sparkles', titulo: '', texto: '' });
      ctx.redesenhar();
    },
    'del-rotina': ({ indice }, ctx) => {
      ui.form.rotina.splice(Number(indice), 1);
      ctx.redesenhar();
    },
    foto: async ({ camera }, ctx) => {
      const foto = await escolherFoto({ camera: !!camera });
      if (!foto) return;
      ui.form.foto = foto;
      ctx.redesenhar();
    },
    'sem-foto': (_, ctx) => {
      ui.form.foto = null;
      ctx.redesenhar();
    },
    cancelar: (_, ctx) => {
      ui.id = null;
      ctx.navegar('ficha-pet', { id: ctx.vm.pet.id }, { substituir: true });
    },
    salvar: async (_, ctx) => {
      const f = ui.form;
      if (!String(f.nome || '').trim()) return ctx.toast('O pet precisa de um nome', { erro: true });
      if (!nascimentoValido(f.nascimento)) return ctx.toast('Data de nascimento inválida. Use dia/mês/ano, por exemplo 15/03/2020', { erro: true });
      if (!FORMATOS.data.valido(f.pesoData)) return ctx.toast('Data da pesagem inválida. Use dia/mês/ano', { erro: true });
      if (!FORMATOS.data.valido(f.vacina)) return ctx.toast('Data da última vacina inválida. Use dia/mês/ano', { erro: true });
      await pets.salvar({
        ...ctx.vm.pet,
        ...f,
        nome: f.nome.trim(),
        nascimento: String(f.nascimento || '').trim() ? paraDataBR(deDataBR(f.nascimento)) : '',
        pesoData: FORMATOS.data.finalizar(String(f.pesoData || '').trim()),
        vacina: FORMATOS.data.finalizar(String(f.vacina || '').trim()),
        peso: formatarPeso(f.peso),
        rotina: f.rotina.filter((r) => r.titulo.trim() || r.texto.trim()).map((r) => ({ ...r, titulo: r.titulo.trim(), texto: r.texto.trim() })),
      });
      ui.id = null;
      ctx.toast('Ficha atualizada');
      ctx.navegar('ficha-pet', { id: ctx.vm.pet.id }, { substituir: true });
    },
    excluir: async (_, ctx) => {
      const pet = ctx.vm.pet;
      const ok = await ctx.confirmar({
        titulo: `Excluir ${pet.nome}?`,
        texto: 'A ficha e os agendamentos futuros vão para a lixeira por 30 dias. O histórico de atendimentos continua no faturamento.',
        botao: 'Mover para lixeira',
      });
      if (!ok) return;
      await pets.excluir(pet.id);
      ui.id = null;
      ctx.toast(`${pet.nome} foi para a lixeira`);
      ctx.navegar('clientes', {}, { substituir: true });
    },
  },
};
