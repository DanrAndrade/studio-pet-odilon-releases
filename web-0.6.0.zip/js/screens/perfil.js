import { html, icon, fmtBRLCurto, inicioDoMes, fimDoDia, MESES } from '../core/dom.js';
import { patinhasHero, secao } from '../core/ui.js';
import { faturamento } from '../data/repo.js';
import * as config from '../data/config.js';
import { minutosDaVisita } from '../logic/metricas.js';
import { escolherFoto } from '../core/foto.js';
import { copiar, colar } from '../core/nativo.js';
import { editarLoja } from '../modais/editar-loja.js';
import { editarPerfil } from '../modais/editar-perfil.js';

/* PERFIL — groomer, dados da loja e PIX. */

const ui = { copiado: false };
let temporizadorCopia = null;

export default {
  titulo: 'Perfil',
  menu: null,

  async carregar() {
    const { concluidos, itensPorAg, recebimentos } = await faturamento.periodo(inicioDoMes(Date.now()), fimDoDia(Date.now()));
    const minutos = [...itensPorAg.values()].reduce((s, itens) => s + minutosDaVisita(itens), 0);
    return {
      perfil: await config.obter('perfil'),
      loja: await config.obter('loja'),
      kpis: [
        { rotulo: 'Pets atendidos no mês', valor: String(new Set(concluidos.map((a) => a.petId)).size) },
        { rotulo: 'Horas na tesoura', valor: `${Math.round(minutos / 60)}h` },
        // faturamento = o que foi pago no mês (como no Faturamento)
        { rotulo: 'Faturamento do mês', valor: fmtBRLCurto(recebimentos.reduce((s, r) => s + r.valorCentavos, 0)) },
      ],
    };
  },

  render(vm) {
    const { perfil: p, loja } = vm;
    const desde = p.desde ? new Date(p.desde) : null;
    const dadosLoja = [
      { rotulo: 'Nome da loja', valor: loja.nome },
      { rotulo: 'Endereço', valor: loja.endereco },
      { rotulo: 'Expediente', valor: loja.expediente },
      { rotulo: 'CNPJ', valor: loja.cnpj },
    ];

    return html`<div class="card r24 cortar">
      <div class="hero perfil-hero">
        ${patinhasHero('perfil', 0.18)}
        <button class="perfil-foto" data-acao="foto" aria-label="Trocar foto">
          ${p.foto ? html`<img src="${p.foto}" alt="">` : html`<span class="perfil-foto-vazia">${icon('user-round', 44)}</span>`}
          <span class="perfil-foto-trocar">Trocar</span>
        </button>
        <div class="perfil-info">
          <div class="perfil-nome">${p.nome || 'Seu nome'}</div>
          <div style="display:flex;align-items:center;gap:8px;margin-top:7px;flex-wrap:wrap">
            ${p.funcao ? html`<span class="selo selo-lavanda redondo">${p.funcao}</span>` : ''}
            ${desde ? html`<span class="mutado" style="font-size:12.5px">Desde ${MESES[desde.getMonth()]} de ${desde.getFullYear()}</span>` : ''}
          </div>
          <div class="perfil-contatos">
            <span>${icon('mail', 14)}${p.email || 'E-mail não informado'}</span>
            <span>${icon('phone', 14)}${p.telefone || 'Telefone não informado'}</span>
          </div>
        </div>
        <button class="btn btn-roxo perfil-editar" data-acao="editar-perfil">${icon('pencil', 14)}<span>Editar perfil</span></button>
      </div>

      <div style="padding:22px 26px 8px" class="perfil-bloco">
        <div class="grade-3">
          ${vm.kpis.map((k) => html`<div class="stat" style="padding:14px 16px"><div class="stat-rotulo" style="font-size:11px">${k.rotulo}</div><div style="font-size:22px;font-weight:700;color:var(--tinta-2);margin-top:4px;letter-spacing:-0.02em">${k.valor}</div></div>`)}
        </div>
      </div>

      <div style="padding:16px 22px 0" class="perfil-bloco">
        <div class="cab-card" style="margin-bottom:12px">
          ${secao('store', 'Dados da loja')}
          <button class="btn btn-branco pequeno" style="border-radius:14px;padding:9px 14px" data-acao="editar-loja">${icon('pencil', 13)}<span>Editar dados da loja</span></button>
        </div>
        <div class="grade-4 perfil-loja">
          ${dadosLoja.map((d) => html`<div class="stat"><div class="stat-rotulo">${d.rotulo}</div><div class="stat-valor">${d.valor || '—'}</div></div>`)}
        </div>
        <div class="perfil-pix">
          <div style="min-width:0;flex:1">
            <div class="stat-rotulo">${icon('qr-code', 12)}<span>Chave PIX</span></div>
            <input class="entrada mono" style="margin-top:6px;padding:10px 12px;border-radius:12px" data-campo="pix" value="${loja.pix || ''}" placeholder="CPF, CNPJ, e-mail, telefone ou chave aleatória">
          </div>
          <button class="btn btn-branco perfil-pix-btn" data-acao="copiar-pix">${icon(ui.copiado ? 'check' : 'copy', 14)}<span>${ui.copiado ? 'Copiado!' : 'Copiar chave'}</span></button>
          <button class="btn btn-branco perfil-pix-btn" data-acao="colar-pix">${icon('clipboard-paste', 14)}<span>Colar</span></button>
        </div>
      </div>

      <div class="perfil-rodape">
        <div>
          <div style="margin-bottom:4px">${secao('zap', 'Atalhos')}</div>
          <button class="linha-nav" style="padding:12px 0" data-acao="ir" data-rota="servicos">
            <span class="ln-esq">${icon('scissors', 16)}<span>Catálogo de serviços</span></span>
            <span class="ln-dir" style="color:var(--texto-5)">${icon('chevron-right', 15)}</span>
          </button>
          <button class="linha-nav" style="padding:12px 0" data-acao="ir" data-rota="ajustes">
            <span class="ln-esq">${icon('hard-drive-download', 16)}<span>Backup e restauração</span></span>
            <span class="ln-dir" style="color:var(--texto-5)">${icon('chevron-right', 15)}</span>
          </button>
        </div>
      </div>
    </div>`;
  },

  async aoAlterar(nome, valor, ctx) {
    if (nome !== 'pix') return;
    await config.atualizar('loja', { pix: valor.trim() });
    if (ctx.vm?.loja) ctx.vm.loja.pix = valor.trim();
    ctx.toast('Chave PIX salva');
  },

  acoes: {
    foto: async (_, ctx) => {
      const foto = await escolherFoto({ lado: 400 });
      if (!foto) return;
      await config.atualizar('perfil', { foto });
      ctx.atualizarPerfilTopo();
      ctx.recarregar();
    },
    'editar-perfil': async (_, ctx) => {
      if (await editarPerfil(ctx, ctx.vm.perfil)) ctx.recarregar();
    },
    'editar-loja': async (_, ctx) => {
      if (await editarLoja(ctx, ctx.vm.loja)) ctx.recarregar();
    },
    'copiar-pix': async (_, ctx) => {
      const chave = (document.querySelector('[data-campo="pix"]')?.value || '').trim();
      if (!chave) return ctx.toast('Cadastre a chave PIX primeiro', { erro: true });
      if (!(await copiar(chave))) return ctx.toast('Não foi possível copiar', { erro: true });
      ui.copiado = true;
      ctx.redesenhar();
      clearTimeout(temporizadorCopia);
      temporizadorCopia = setTimeout(() => {
        ui.copiado = false;
        ctx.redesenhar();
      }, 2000);
    },
    'colar-pix': async (_, ctx) => {
      const texto = (await colar()).trim();
      if (!texto) return ctx.toast('A área de transferência está vazia', { erro: true });
      await config.atualizar('loja', { pix: texto });
      ctx.toast('Chave PIX colada da área de transferência');
      ctx.recarregar();
    },
  },

  aoSair() {
    clearTimeout(temporizadorCopia);
    ui.copiado = false;
  },
};
