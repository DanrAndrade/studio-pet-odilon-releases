import { html, icon, fmtDur, DIA_MS } from '../core/dom.js';
import { chip, vazio } from '../core/ui.js';
import { agendamentos, pets, servicos, tempos } from '../data/repo.js';
import * as config from '../data/config.js';

/* TEMPOS MÉDIOS — o que os cronômetros mediram nos últimos 90 dias. */

const JANELA_DIAS = 90;
const ui = { cat: 'Todas' };

export default {
  titulo: 'Tempos médios',
  menu: 'tempos',

  async carregar() {
    const de = Date.now() - JANELA_DIAS * DIA_MS;
    const categorias = ['Todas', ...(await config.lista('Categorias de serviço'))];
    if (!categorias.includes(ui.cat)) ui.cat = 'Todas';
    const naCategoria = (categoria) => ui.cat === 'Todas' || categoria === ui.cat;

    const linhas = [];
    for (const s of (await servicos.listar()).filter((x) => naCategoria(x.categoria))) {
      const m = await tempos.mediaDaLoja(s.id, { de });
      if (m) linhas.push({ nome: s.nome, ...m });
    }
    linhas.sort((a, b) => b.mediaMin - a.mediaMin);

    // tempo por visita de cada pet, só com os serviços da categoria escolhida
    const concluidos = (await agendamentos.concluidos()).filter((a) => a.inicio >= de);
    const itensPorAg = await agendamentos.itensDe(concluidos);
    const porPet = new Map();
    for (const ag of concluidos) {
      const minutos = (itensPorAg.get(ag.id) || [])
        .filter((i) => naCategoria(i.categoria) && Number.isFinite(i.duracaoRealMin) && i.usarNaMedia !== false)
        .reduce((s, i) => s + i.duracaoRealMin, 0);
      if (!minutos) continue;
      if (!porPet.has(ag.petId)) porPet.set(ag.petId, []);
      porPet.get(ag.petId).push(minutos);
    }
    const mapaPets = new Map((await pets.listar()).map((p) => [p.id, p]));
    const petsMedias = [...porPet.entries()]
      .filter(([id]) => mapaPets.has(id))
      .map(([id, xs]) => {
        const p = mapaPets.get(id);
        return { nome: p.raca ? `${p.nome} · ${p.raca.split(' ')[0]}` : p.nome, minutos: Math.round(xs.reduce((a, b) => a + b, 0) / xs.length) };
      })
      .sort((a, b) => b.minutos - a.minutos);

    const execucoes = linhas.reduce((s, l) => s + l.qtd, 0);
    return {
      categorias,
      linhas,
      execucoes,
      mediaGeral: execucoes ? Math.round(linhas.reduce((s, l) => s + l.mediaMin * l.qtd, 0) / execucoes) : null,
      lentos: petsMedias.slice(0, 3),
      rapidos: petsMedias.length > 3 ? petsMedias.slice(-3).reverse() : [],
    };
  },

  render(vm) {
    const maior = vm.linhas[0];
    const menor = vm.linhas[vm.linhas.length - 1];
    const resumo = [
      { rotulo: 'Execuções no período', valor: String(vm.execucoes), icone: 'activity' },
      { rotulo: 'Média geral', valor: vm.mediaGeral ? fmtDur(vm.mediaGeral) : '—', icone: 'timer' },
      { rotulo: 'Serviço mais demorado', valor: maior ? fmtDur(maior.mediaMin) : '—', icone: 'trending-up', dica: maior?.nome },
      { rotulo: 'Serviço mais rápido', valor: menor ? fmtDur(menor.mediaMin) : '—', icone: 'trending-down', dica: menor?.nome },
    ];
    const escala = Math.max(...vm.linhas.map((l) => l.mediaMin), 1);
    const listaPets = (lista, cor, trilho, barra) =>
      lista.length
        ? lista.map((p) => {
            const topo = lista[0].minutos >= lista[lista.length - 1].minutos ? lista[0].minutos : lista[lista.length - 1].minutos;
            return html`<div style="padding:9px 0;border-top:1px solid var(--divisor)">
              <div style="display:flex;justify-content:space-between;font-size:12.5px;margin-bottom:6px;gap:10px">
                <span class="truncar" style="color:var(--texto-2);font-weight:500">${p.nome}</span><span style="font-weight:600;color:${cor}">${fmtDur(p.minutos)}</span>
              </div>
              <div class="barra" style="height:7px;background:${trilho};border-radius:8px"><div style="width:${((p.minutos / topo) * 100).toFixed(0)}%;background:${barra};border-radius:8px"></div></div>
            </div>`;
          })
        : html`<div class="mutado" style="font-size:12.5px;padding:9px 0;border-top:1px solid var(--divisor)">Precisa de mais pets com atendimentos medidos.</div>`;

    return html`
      <div class="tempos-topo">
        <div class="chips tempos-cats">${vm.categorias.map((c) => chip(c, ui.cat === c, 'cat', { cat: c }, { suave: true, cls: 'redondo' }))}</div>
      </div>

      <div class="grade-4 fat-kpis">
        ${resumo.map(
          (r) => html`<div class="kpi compacto">
            <div class="kpi-rotulo"><span class="kpi-icone">${icon(r.icone, 13)}</span><span>${r.rotulo}</span></div>
            <div class="kpi-valor">${r.valor}</div>
            ${r.dica ? html`<div class="kpi-dica truncar">${r.dica}</div>` : ''}
          </div>`
        )}
      </div>

      <div class="tempos-grade">
        <div class="card" style="padding:18px 20px 14px;align-self:start">
          <div style="margin-bottom:4px">
            <div class="titulo-card gg">Tempo médio real por serviço</div>
            <div style="font-size:12px;color:var(--texto-5);margin-top:3px">Medido pelos cronômetros dos atendimentos · últimos ${JANELA_DIAS} dias</div>
          </div>
          ${vm.linhas.length
            ? vm.linhas.map(
                (l) => html`<div class="tempo-linha">
                  <div style="min-width:0">
                    <div class="truncar" style="font-size:13.5px;font-weight:600;color:var(--tinta-2)">${l.nome}</div>
                    <div style="font-size:11px;color:var(--texto-5);margin-top:2px">${l.qtd} ${l.qtd === 1 ? 'execução' : 'execuções'}</div>
                  </div>
                  <div style="display:flex;align-items:center;gap:11px">
                    <div class="barra" style="flex:1;height:18px;border-radius:14px;background:var(--divisor)"><div style="width:${((l.mediaMin / escala) * 100).toFixed(1)}%;border-radius:14px;background:var(--roxo)"></div></div>
                    <span style="width:56px;font-size:14px;font-weight:600;color:var(--roxo);text-align:right">${fmtDur(l.mediaMin)}</span>
                  </div>
                  <div class="tempo-extremos">mais rápido ${fmtDur(l.menorMin)} · mais longo ${fmtDur(l.maiorMin)}</div>
                </div>`
              )
            : vazio({ icone: 'timer', titulo: 'Nenhum tempo medido ainda', texto: 'Use os cronômetros no atendimento: cada serviço finalizado entra aqui.' })}
        </div>

        <div class="at-col">
          <div class="painel">
            <div style="display:flex;align-items:center;gap:7px;margin-bottom:12px;color:var(--rosa)">${icon('trending-up', 14)}<span class="titulo-card">Pets mais demorados</span></div>
            ${listaPets(vm.lentos, 'var(--rosa)', 'var(--rosa-trilho)', 'var(--rosa-barra)')}
          </div>
          <div class="painel">
            <div style="display:flex;align-items:center;gap:7px;margin-bottom:12px;color:var(--verde)">${icon('trending-down', 14)}<span class="titulo-card">Pets mais rápidos</span></div>
            ${listaPets(vm.rapidos, 'var(--verde-escuro)', 'var(--verde-fundo-2)', 'var(--verde-barra)')}
          </div>
        </div>
      </div>`;
  },

  acoes: {
    cat: ({ cat }, ctx) => {
      ui.cat = cat;
      ctx.recarregar();
    },
  },
};
