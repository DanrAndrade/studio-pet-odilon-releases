import { html, icon, fmtHora, fmtDur, inicioDoDia, fimDoDia } from '../core/dom.js';
import { avPet, vazio } from '../core/ui.js';
import { agendamentos, pets, tutores } from '../data/repo.js';
import { cronSessao, cronItem, estadoItem } from './_cronometro.js';

/* ATENDIMENTO DO DIA — todos os pets na loja agora, com cronômetros ao vivo. */

function cartaoSessao({ ag, pet, tutor, itens }) {
  const chegada = ag.chegadaEm || ag.inicio;
  return html`<div class="sessao">
    <div class="bolha" style="right:-40px;top:-46px;width:150px;height:150px;background:rgba(91,50,224,0.07)"></div>
    <div class="bolha" style="left:-16px;bottom:-18px;width:72px;height:72px;background:rgba(91,50,224,0.05)"></div>

    <div class="sessao-cab">
      ${avPet(pet, 56)}
      <div style="flex:1;min-width:0">
        <div class="sessao-nome truncar">${pet.nome}</div>
        <div class="sessao-sub truncar">${tutor?.nome || 'Sem tutor'} · chegou às ${fmtHora(chegada)}</div>
      </div>
      <div style="text-align:right">
        <div class="sessao-total-rotulo">${ag.pausadoEm ? 'Pausado' : 'Atendimento'}</div>
        <div class="sessao-total">${cronSessao(ag)}</div>
      </div>
    </div>

    <div class="sessao-servicos">
      ${itens.length
        ? itens.map((item) => {
            const e = estadoItem(item);
            return html`<div class="sessao-serv">
              <div style="min-width:0">
                <div class="serv-nome truncar">${item.nome}</div>
                <div class="serv-media">média ${item.mediaSeg ? fmtDur(item.mediaSeg / 60) : '—'}</div>
              </div>
              <div class="serv-tempo" style="color:${e.cor}">${cronItem(item)}</div>
              <div class="serv-botoes">
                <button class="btn-cron" data-acao="alternar" data-item="${item.id}" aria-label="${e.botao}">${icon(e.icone, 14)}</button>
                ${item.done ? '' : html`<button class="btn-concluir" data-acao="concluir-item" data-item="${item.id}">${icon('check', 13)}<span>Concluir</span></button>`}
              </div>
            </div>`;
          })
        : html`<div class="serv-media" style="padding:10px 0;border-top:1px solid var(--divisor)">Nenhum serviço neste atendimento.</div>`}
    </div>

    <div class="sessao-rodape">
      <button class="btn btn-branco" data-acao="abrir" data-id="${ag.id}">Abrir detalhe</button>
      <button class="btn btn-roxo" data-acao="finalizar" data-id="${ag.id}">Finalizar e cobrar</button>
    </div>
  </div>`;
}

export default {
  titulo: 'Atendimento do dia',
  menu: 'atendimento-dia',
  fab: true,

  async carregar() {
    const comDetalhes = async (ag) => {
      const pet = await pets.obter(ag.petId);
      if (!pet || pet.excluidoEm) return null;
      const tutor = pet.tutorId ? await tutores.obter(pet.tutorId) : null;
      return { ag, pet, tutor, itens: await agendamentos.itens(ag.id) };
    };

    const sessoes = (await Promise.all((await agendamentos.emAtendimento()).map(comDetalhes))).filter(Boolean);
    const agora = Date.now();
    const deHoje = (await agendamentos.porPeriodo(inicioDoDia(agora), fimDoDia(agora))).filter((a) =>
      ['agendado', 'confirmado', 'rascunho_plano'].includes(a.status)
    );
    const chegam = (await Promise.all(deHoje.map(comDetalhes))).filter(Boolean);
    const finalizadosHoje = (await agendamentos.concluidos()).filter((a) => (a.finalizadoEm || a.inicio) >= inicioDoDia(agora)).length;
    return { sessoes, chegam, finalizadosHoje };
  },

  render(vm) {
    const qtd = vm.sessoes.length;
    return html`
      <div class="emat-topo">
        <div class="fila-contagem">${qtd ? `${qtd} ${qtd === 1 ? 'pet' : 'pets'} na loja agora` : ''}</div>
        <button class="btn btn-roxo" style="font-size:13px;padding:10px 16px;border:1px solid var(--roxo)" data-acao="novo-agendamento">${icon('plus', 15)}<span>Encaixar pet</span></button>
      </div>

      <div style="display:flex;flex-direction:column;gap:18px">
        <div style="display:flex;flex-direction:column;gap:10px">
          <div class="rotulo-secao">Cronômetros ativos</div>
          ${qtd
            ? html`<div class="sessoes">${vm.sessoes.map(cartaoSessao)}</div>`
            : html`<div class="card pad-18">${vazio({
                icone: 'timer',
                titulo: 'Nenhum pet em atendimento agora',
                texto: 'Quando um pet chegar, toque em “Registrar chegada” para ligar os cronômetros.',
              })}</div>`}
        </div>

        ${vm.chegam.length
          ? html`<div style="display:flex;flex-direction:column;gap:10px">
              <div class="rotulo-secao">Chegam hoje</div>
              <div class="card chegam">
                ${vm.chegam.map(
                  ({ ag, pet, itens }) => html`<div class="chegam-linha">
                    <div class="chegam-hora">${fmtHora(ag.inicio)}</div>
                    ${avPet(pet, 40)}
                    <div style="flex:1;min-width:0">
                      <div class="chegam-pet truncar">${pet.nome}</div>
                      <div class="chegam-serv truncar">${itens.map((i) => i.nome).join(' + ') || 'Sem serviço'}</div>
                    </div>
                    <button class="btn btn-branco pequeno" style="color:var(--roxo-escuro);border-color:var(--lavanda-borda)" data-acao="chegada" data-id="${ag.id}">Registrar chegada</button>
                  </div>`
                )}
              </div>
            </div>`
          : ''}

        ${vm.finalizadosHoje
          ? html`<button class="card fin-hoje" data-acao="historico">
              <span class="fin-hoje-icone">${icon('history', 17)}</span>
              <span style="flex:1;min-width:0;text-align:left">
                <span class="fin-hoje-titulo">${vm.finalizadosHoje} ${vm.finalizadosHoje === 1 ? 'atendimento finalizado hoje' : 'atendimentos finalizados hoje'}</span>
                <span class="fin-hoje-sub">Finalizou por engano? Reabra ou desfaça no Histórico.</span>
              </span>
              <span style="color:var(--texto-5);display:flex">${icon('chevron-right', 16)}</span>
            </button>`
          : ''}
      </div>`;
  },

  acoes: {
    alternar: async ({ item }, ctx) => {
      await agendamentos.alternarItem(item);
      ctx.recarregar();
    },
    'concluir-item': async ({ item }, ctx) => {
      await agendamentos.concluirItem(item);
      ctx.recarregar();
    },
    abrir: ({ id }, ctx) => ctx.navegar('atendimento', { id }),
    historico: (_, ctx) => ctx.navegar('historico'),
    finalizar: ({ id }, ctx) => ctx.navegar('finalizar', { id }),
    chegada: async ({ id }, ctx) => {
      await agendamentos.registrarChegada(id);
      ctx.toast('Chegada registrada · cronômetro ligado');
      ctx.recarregar();
    },
  },
};
