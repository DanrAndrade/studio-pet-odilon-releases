import { $, $$, html, icon, fmtDataExtenso, fmtCron, debounce, FORMATOS, morfar } from './core/dom.js';
import { ligarModais, abrirModal, confirmar, toast, modalAberto, fecharModal } from './core/modais.js';
import * as config from './data/config.js';
import { abrir } from './data/db.js';
import { prepararPrimeiroUso } from './data/seed.js';
import { lixeira } from './data/repo.js';
import { calcularAvisos, modalAvisos } from './modais/avisos.js';
import { verificarAtualizacao } from './data/atualizacao.js';
import { confirmarVersao, avisarCampo } from './core/nativo.js';
import { VERSAO } from './versao.js';

import agenda from './screens/agenda.js';
import novoAgendamento from './screens/novo-agendamento.js';
import atendimentoDia from './screens/atendimento-dia.js';
import atendimento from './screens/atendimento.js';
import historico from './screens/historico.js';
import finalizar from './screens/finalizar.js';
import clientes from './screens/clientes.js';
import aniversarios from './screens/aniversarios.js';
import cadastro from './screens/cadastro.js';
import fichaPet from './screens/ficha-pet.js';
import editarPet from './screens/editar-pet.js';
import fichaTutor from './screens/ficha-tutor.js';
import planos from './screens/planos.js';
import planoRec from './screens/plano-rec.js';
import planoPet from './screens/plano-pet.js';
import catalogo from './screens/catalogo.js';
import listaCatalogo from './screens/lista-catalogo.js';
import faturamento from './screens/faturamento.js';
import tempos from './screens/tempos.js';
import ajustes from './screens/ajustes.js';
import lixeiraTela from './screens/lixeira.js';
import perfil from './screens/perfil.js';

const TELAS = {
  agenda,
  'novo-agendamento': novoAgendamento,
  'atendimento-dia': atendimentoDia,
  atendimento,
  historico,
  finalizar,
  clientes,
  aniversarios,
  cadastro,
  'ficha-pet': fichaPet,
  'editar-pet': editarPet,
  'ficha-tutor': fichaTutor,
  planos,
  'plano-rec': planoRec,
  'plano-pet': planoPet,
  servicos: catalogo,
  lista: listaCatalogo,
  faturamento,
  tempos,
  ajustes,
  lixeira: lixeiraTela,
  perfil,
};

const MENU = [
  { chave: 'agenda', rotulo: 'Agenda', curto: 'Agenda', icone: 'calendar-days' },
  { chave: 'atendimento-dia', rotulo: 'Atendimento do dia', curto: 'Atendimento', icone: 'clock' },
  { chave: 'historico', rotulo: 'Histórico', curto: 'Histórico', icone: 'history' },
  { chave: 'clientes', rotulo: 'Clientes', curto: 'Clientes', icone: 'users' },
  { chave: 'aniversarios', rotulo: 'Aniversários', curto: 'Aniversários', icone: 'cake' },
  { chave: 'planos', rotulo: 'Planos', curto: 'Planos', icone: 'repeat' },
  { chave: 'servicos', rotulo: 'Serviços', curto: 'Serviços', icone: 'scissors' },
  { chave: 'faturamento', rotulo: 'Faturamento', curto: 'Faturamento', icone: 'wallet' },
  { chave: 'tempos', rotulo: 'Tempos médios', curto: 'Tempos', icone: 'timer' },
  { chave: 'ajustes', rotulo: 'Ajustes', curto: 'Ajustes', icone: 'settings' },
];

const estado = { rota: null, params: {}, tela: null, vm: null, chaveParams: '' };

/* =============================== Rotas =============================== */

function lerHash() {
  const bruto = (location.hash || '').replace(/^#\/?/, '');
  const [rota, qs] = bruto.split('?');
  const params = Object.fromEntries(new URLSearchParams(qs || ''));
  return { rota: TELAS[rota] ? rota : 'agenda', params };
}

function montarHash(rota, params = {}) {
  const limpos = Object.entries(params).filter(([, v]) => v !== undefined && v !== null && v !== '');
  const qs = new URLSearchParams(limpos).toString();
  return '#/' + rota + (qs ? '?' + qs : '');
}

export function navegar(rota, params = {}, { substituir = false } = {}) {
  const alvo = montarHash(rota, params);
  if (location.hash === alvo) return renderizar({ manterRolagem: true });
  if (substituir) {
    history.replaceState(null, '', alvo);
    return renderizar();
  }
  location.hash = alvo;
}

function voltar(padrao = 'agenda', params = {}) {
  if (history.length > 1) history.back();
  else navegar(padrao, params, { substituir: true });
}

/* ============================== Contexto ============================= */

function criarCtx() {
  return {
    get params() {
      return estado.params;
    },
    get vm() {
      return estado.vm;
    },
    navegar,
    voltar,
    recarregar: () => renderizar({ manterRolagem: true }),
    redesenhar,
    toast,
    confirmar,
    abrirModal: (def, inicial) => abrirModal(def, inicial, criarCtx()),
    atualizarAvisos,
    atualizarPerfilTopo: pintarAvatarTopo,
  };
}

/* ============================== Render =============================== */

let sequencia = 0;

async function renderizar({ manterRolagem = false } = {}) {
  const minha = ++sequencia;
  const { rota, params } = lerHash();
  const tela = TELAS[rota];
  const chaveParams = rota + JSON.stringify(params);
  const mesmaTela = chaveParams === estado.chaveParams;

  if (estado.tela && estado.tela !== tela) estado.tela.aoSair?.();
  Object.assign(estado, { rota, params, tela, chaveParams });

  // o menu pode depender de onde a tela foi aberta (ex.: novo agendamento vindo do atendimento do dia)
  pintarMenu(typeof tela.menu === 'function' ? tela.menu(params) : tela.menu);
  $('#fab').hidden = !tela.fab;

  const ctx = criarCtx();
  let vm;
  try {
    vm = tela.carregar ? await tela.carregar(params, ctx) : null;
  } catch (erro) {
    console.error(erro);
    if (minha !== sequencia) return;
    $('#tela').innerHTML = String(
      html`<div class="card pad-18"><div class="vazio">${icon('triangle-alert', 30)}<div class="vazio-titulo">Não foi possível abrir esta tela</div><div>${erro.message}</div></div></div>`
    );
    return;
  }
  if (minha !== sequencia) return; // uma navegação mais nova já assumiu

  estado.vm = vm;
  estado.vmDe = chaveParams;
  $('#titulo').textContent = typeof tela.titulo === 'function' ? tela.titulo(vm, params) : tela.titulo;

  const conteudo = $('#conteudo');
  const rolagem = manterRolagem && mesmaTela ? conteudo.scrollTop : 0;
  $('#tela').innerHTML = String(tela.render(vm, params, ctx));
  tela.aoMontar?.($('#tela'), vm, ctx);
  conteudo.scrollTop = rolagem;
  avisarCampo();

  pintarPatinhas();
  tickCronometros();
  atualizarAvisos();
}

/** Redesenha a tela atual com o que já está carregado (sem ir ao banco). */
function redesenhar() {
  const { tela, vm, params } = estado;
  // a tela nova ainda está carregando: o vm é o da anterior
  if (!tela || estado.vmDe !== estado.chaveParams) return;
  const conteudo = $('#conteudo');
  const rolagem = conteudo.scrollTop;
  const foco = document.activeElement;
  const campo = foco && $('#tela').contains(foco) ? foco.dataset.campo : null;
  const posicao = campo ? foco.selectionStart : null;

  const html = String(tela.render(vm, params, criarCtx()));
  // mesma tela: atualiza só o que mudou e mantém os campos (evita letra repetida no
  // Android e o teclado fechando ao passar de um campo para outro)
  morfar($('#tela'), html);
  tela.aoMontar?.($('#tela'), vm, criarCtx());
  conteudo.scrollTop = rolagem;

  if (campo && document.activeElement !== foco && !$('#tela').contains(document.activeElement)) {
    const novo = $(`#tela [data-campo="${campo}"]`);
    if (novo) {
      novo.focus();
      try {
        if (posicao !== null) novo.setSelectionRange(posicao, posicao);
      } catch {
        /* date/time não aceitam seleção */
      }
    }
  }
  pintarPatinhas();
  tickCronometros();
}

/* =============================== Cromo =============================== */

function pintarMenu(ativo) {
  $('#nav').innerHTML = MENU.map(
    (m) =>
      `<button class="nav-item${m.chave === ativo ? ' ativo' : ''}" data-acao="ir" data-rota="${m.chave}" title="${m.rotulo}">${icon(m.icone, 22)}<span>${m.rotulo}</span></button>`
  ).join('');
  $('#abas').innerHTML = MENU.map(
    (m) =>
      `<button class="aba${m.chave === ativo ? ' ativo' : ''}" data-acao="ir" data-rota="${m.chave}">${icon(m.icone, 20)}<span>${m.curto}</span></button>`
  ).join('');
  // no celular, mantém a aba ativa visível na barra rolável
  const abaAtiva = $('#abas .aba.ativo');
  if (abaAtiva) abaAtiva.scrollIntoView({ block: 'nearest', inline: 'nearest' });
}

function pintarCromo() {
  $('#btn-recolher').innerHTML = `${icon('panel-left', 17)}<span>Recolher</span>`;
  $('#sidebar-novo').innerHTML = `${icon('plus', 16)}<span>Novo agendamento</span>`;
  $('#topo-data').innerHTML = `${icon('calendar-days', 15)}<span>${fmtDataExtenso()}</span>`;
  $('#fab').innerHTML = icon('plus', 24);
  pintarSino(0);
}

function pintarSino(qtd) {
  $('#topo-sino').innerHTML = `${icon('bell', 17)}${qtd ? `<span class="topo-sino-contador">${qtd > 9 ? '9+' : qtd}</span>` : ''}`;
}

async function pintarAvatarTopo() {
  const p = await config.obter('perfil');
  $('#topo-avatar').innerHTML = p.foto ? `<img src="${p.foto}" alt="">` : icon('user-round', 18);
}

const atualizarAvisos = debounce(async () => {
  try {
    pintarSino((await calcularAvisos()).length);
  } catch (erro) {
    console.error(erro);
  }
}, 400);

/* Textura de patinhas da área de conteúdo (grade da referência, opacidade 0,1). */
function pintarPatinhas() {
  const conteudo = $('#conteudo');
  const camada = $('#patinhas');
  // zera antes de medir: a altura da tela anterior viraria rolagem vazia na tela nova
  camada.style.height = '0px';
  const altura = Math.max(conteudo.scrollHeight, conteudo.clientHeight);
  const largura = conteudo.clientWidth;
  const ICONES = ['paw-print', 'bone', 'dog', 'cat'];
  const ROTACOES = [-22, 22, 11, 0, -11];
  const linhas = Math.ceil(altura / 97) + 1;
  const colunas = Math.ceil(largura / 124) + 1;

  let saida = '';
  for (let l = 0; l < linhas; l++) {
    for (let c = 0; c < colunas; c++) {
      const i = l + c;
      const tamanho = [30, 35, 40][(l + c * 2) % 3];
      const esquerda = c * 124 + (l % 2 ? 70 : 4);
      saida += `<span style="top:${4 + l * 97}px;left:${esquerda}px;transform:rotate(${ROTACOES[i % 5]}deg)">${icon(ICONES[i % 4], tamanho)}</span>`;
    }
  }
  camada.style.height = altura + 'px';
  camada.innerHTML = saida;
}

/* ============================ Cronômetros ============================ */

const segundosDe = (d, agora) => Number(d.acc || 0) + (d.t0 ? (agora - Number(d.t0)) / 1000 : 0);

function tickCronometros() {
  const agora = Date.now();
  for (const el of $$('[data-cron]')) {
    const d = el.dataset;
    if (d.cron === 'desde') el.textContent = fmtCron((agora - Number(d.desde)) / 1000);
    else if (d.cron === 'sessao') el.textContent = fmtCron(Math.max(0, ((Number(d.parado) || agora) - Number(d.desde)) / 1000 - (Number(d.pausa) || 0)));
    else if (d.cron === 'item') el.textContent = fmtCron(segundosDe(d, agora));
    else if (d.cron === 'soma') {
      const itens = JSON.parse(d.itens || '[]');
      el.textContent = fmtCron(itens.reduce((s, [acc, t0]) => s + acc + (t0 ? (agora - t0) / 1000 : 0), 0));
    } else if (d.cron === 'barra') {
      const seg = segundosDe(d, agora);
      const media = Number(d.media) || 0;
      const barra = el.firstElementChild;
      if (!barra) continue;
      barra.style.width = media ? Math.min(100, (seg / media) * 100).toFixed(1) + '%' : '0%';
      barra.style.background = media && seg > media ? 'var(--ambar-barra)' : 'var(--roxo)';
    }
  }
}

/* ============================== Eventos ============================== */

const ACOES_GLOBAIS = {
  ir: ({ rota }) => navegar(rota),
  voltar: () => voltar(),
  'novo-agendamento': () => navegar('novo-agendamento', estado.tela?.menu === 'atendimento-dia' ? { origem: 'atendimento-dia' } : {}),
  perfil: () => navegar('perfil'),
  recolher: () => {
    const recolhido = $('#app').classList.toggle('recolhido');
    try {
      localStorage.setItem('sp.recolhido', recolhido ? '1' : '');
    } catch {
      /* armazenamento indisponível: só não lembra a preferência */
    }
    setTimeout(pintarPatinhas, 400);
  },
  avisos: () => abrirModal(modalAvisos, {}, criarCtx()),
};

// ação em andamento por "nome|registro": o toque duplo não salva duas vezes
const acoesEmCurso = new Set();

function ligarEventos() {
  $('#app').addEventListener('click', async (ev) => {
    const alvo = ev.target.closest('[data-acao]');
    if (!alvo) return;
    const nome = alvo.dataset.acao;
    const fn = estado.tela?.acoes?.[nome] || ACOES_GLOBAIS[nome];
    if (!fn) return;
    ev.preventDefault();
    ev.stopPropagation();
    const chave = `${nome}|${alvo.dataset.id || alvo.dataset.item || alvo.dataset.chave || ''}`;
    if (acoesEmCurso.has(chave)) return;
    acoesEmCurso.add(chave);
    try {
      await fn({ ...alvo.dataset }, criarCtx(), ev, alvo);
    } catch (erro) {
      console.error(erro);
      toast('Não deu certo: ' + erro.message, { erro: true });
    } finally {
      acoesEmCurso.delete(chave);
    }
  });

  // formato dos campos (máscara ao digitar, arrumação e checagem ao sair) em
  // qualquer tela ou janela; roda antes dos ouvintes das telas (fase de captura)
  document.addEventListener(
    'input',
    (ev) => {
      const f = FORMATOS[ev.target?.dataset?.formato];
      if (!f) return;
      ev.target.classList.remove('campo-invalido');
      // no meio de uma palavra do teclado (Gboard) não mexe: reescrever ali repete letras
      if (ev.isComposing) return;
      const depois = f.digitar(ev.target.value);
      if (depois !== ev.target.value) ev.target.value = depois;
    },
    true
  );
  document.addEventListener(
    'compositionend',
    (ev) => {
      const f = FORMATOS[ev.target?.dataset?.formato];
      if (!f) return;
      const depois = f.digitar(ev.target.value);
      if (depois === ev.target.value) return;
      ev.target.value = depois;
      ev.target.dispatchEvent(new Event('input', { bubbles: true }));
    },
    true
  );
  document.addEventListener(
    'change',
    (ev) => {
      const f = FORMATOS[ev.target?.dataset?.formato];
      if (!f) return;
      const depois = f.finalizar(ev.target.value);
      if (depois !== ev.target.value) ev.target.value = depois;
      ev.target.classList.toggle('campo-invalido', !f.valido(ev.target.value));
    },
    true
  );

  $('#tela').addEventListener('input', (ev) => {
    const campo = ev.target.dataset?.campo;
    if (campo) estado.tela?.aoDigitar?.(campo, ev.target.value, criarCtx(), ev.target);
  });

  $('#tela').addEventListener('change', (ev) => {
    const campo = ev.target.dataset?.campo;
    if (campo) estado.tela?.aoAlterar?.(campo, ev.target.value, criarCtx(), ev.target);
  });

  window.addEventListener('hashchange', () => {
    // navegar (inclusive pelo "voltar" do sistema) nunca deixa um modal órfão sobre outra tela
    if (modalAberto()) fecharModal(null);
    renderizar();
  });

  /* Botão "voltar" do Android: o MainActivity pergunta aqui antes de voltar
     no histórico. true = o app tratou (fechou modal ou está bloqueado). */
  window.__studioPetVoltar = () => {
    if (modalAberto()) {
      fecharModal(null);
      return true;
    }
    return false;
  };
  window.addEventListener('resize', debounce(pintarPatinhas, 150));
  document.addEventListener('visibilitychange', () => {
    if (document.visibilityState === 'visible') tickCronometros();
  });
}

/* =============================== Início ============================== */

async function iniciar() {
  try {
    if (localStorage.getItem('sp.recolhido')) $('#app').classList.add('recolhido');
  } catch {
    /* sem localStorage */
  }
  pintarCromo();
  ligarEventos();
  ligarModais();

  await abrir();
  // pede armazenamento persistente: o sistema não apaga o banco para liberar espaço
  try {
    await navigator.storage?.persist?.();
  } catch {
    /* sem suporte: segue com o armazenamento padrão */
  }
  await prepararPrimeiroUso();
  await lixeira.purgarVencidos();
  await pintarAvatarTopo();

  await renderizar();
  setInterval(tickCronometros, 1000);
  // abriu bem: o Android mantém esta versão das telas
  confirmarVersao(VERSAO);
  // telas atualizadas sozinhas: avisa uma vez
  try {
    const vista = await config.obter('versaoVista');
    if (vista && vista !== VERSAO) toast(`Studio Pet atualizado para a versão ${VERSAO}`);
    if (vista !== VERSAO) await config.salvar('versaoVista', VERSAO);
  } catch {
    /* só o aviso */
  }
  // o Android só troca as telas com o app parado na agenda, sem janela aberta nem campo em uso
  window.__studioPetPodeAtualizar = () => {
    const f = document.activeElement;
    const digitando = f && (f.tagName === 'INPUT' || f.tagName === 'TEXTAREA');
    return estado.rota === 'agenda' && !modalAberto() && !digitando;
  };

  // avisa (sem atrapalhar) quando há versão nova publicada
  setTimeout(async () => {
    const nova = await verificarAtualizacao({ silencioso: true });
    if (nova) toast(`Versão ${nova.versao} disponível · atualize em Ajustes`);
  }, 4000);
}

iniciar().catch((erro) => {
  console.error(erro);
  $('#tela').innerHTML = String(
    html`<div class="card pad-18"><div class="vazio">${icon('triangle-alert', 30)}<div class="vazio-titulo">O app não conseguiu iniciar</div><div>${erro.message}</div></div></div>`
  );
});
