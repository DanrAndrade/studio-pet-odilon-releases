/* Endereço do tutor em campos separados (CEP, rua, número...).
   Cadastros feitos antes disso têm só o campo antigo `endereco`, um texto
   único: eles continuam valendo e aparecem normalmente. Ao editar o tutor, o
   app mostra o texto antigo e pede o endereço nos campos novos. */

const CACHE_CEP = new Map();
const TEMPO_LIMITE_MS = 7000;

export const CAMPOS_ENDERECO = [
  { nome: 'cep', rotulo: 'CEP', placeholder: '00000-000', formato: 'cep' },
  { nome: 'rua', rotulo: 'Rua / logradouro', placeholder: 'Ex.: Rua das Flores' },
  { nome: 'numero', rotulo: 'Número', placeholder: 'Ex.: 123 ou s/n' },
  { nome: 'complemento', rotulo: 'Complemento', placeholder: 'Apto, bloco, ponto de referência' },
  { nome: 'bairro', rotulo: 'Bairro', placeholder: 'Ex.: Centro' },
  { nome: 'cidade', rotulo: 'Cidade', placeholder: 'Ex.: Itabuna' },
  { nome: 'uf', rotulo: 'UF', placeholder: 'BA', formato: 'uf' },
];

const NOMES = CAMPOS_ENDERECO.map((c) => c.nome);
const texto = (v) => String(v || '').trim();

/** Só os campos de endereço de um tutor, já limpos. */
export function camposDe(tutor) {
  return Object.fromEntries(NOMES.map((n) => [n, texto(tutor?.[n])]));
}

/** O tutor já tem o endereço nos campos separados? */
export const temEnderecoSeparado = (tutor) => NOMES.some((n) => texto(tutor?.[n]));

/** Cadastro antigo: tem o endereço em texto único e ainda não foi separado. */
export const temEnderecoAntigo = (tutor) => !!texto(tutor?.endereco) && !temEnderecoSeparado(tutor);

/** "Rua das Flores, 123 · Apto 2 · Centro · Itabuna/BA · CEP 45600-000" */
export function enderecoTexto(tutor) {
  if (!temEnderecoSeparado(tutor)) return texto(tutor?.endereco);
  const e = camposDe(tutor);
  const cidadeUf = [e.cidade, e.uf].filter(Boolean).join('/');
  return [
    [e.rua, e.numero].filter(Boolean).join(', '),
    e.complemento,
    e.bairro,
    cidadeUf,
    e.cep ? `CEP ${e.cep}` : '',
  ]
    .filter(Boolean)
    .join(' · ');
}

/**
 * Busca o endereço pelo CEP (ViaCEP). Precisa de internet; sem ela, ou com CEP
 * inexistente, devolve null e o Odilon preenche à mão.
 * @returns {Promise<{rua, bairro, cidade, uf}|null>}
 */
export async function buscarCep(cep) {
  const d = String(cep || '').replace(/\D/g, '');
  if (d.length !== 8) return null;
  if (CACHE_CEP.has(d)) return CACHE_CEP.get(d);
  const parar = new AbortController();
  const relogio = setTimeout(() => parar.abort(), TEMPO_LIMITE_MS);
  try {
    const resposta = await fetch(`https://viacep.com.br/ws/${d}/json/`, { signal: parar.signal });
    const dados = await resposta.json();
    const achado = dados && !dados.erro
      ? { rua: dados.logradouro || '', bairro: dados.bairro || '', cidade: dados.localidade || '', uf: dados.uf || '' }
      : null;
    CACHE_CEP.set(d, achado);
    return achado;
  } catch {
    return null; // sem internet: segue no preenchimento manual
  } finally {
    clearTimeout(relogio);
  }
}

/**
 * Preenche rua, bairro, cidade e UF a partir do CEP, sem apagar o que já foi
 * escrito à mão. Devolve os campos que mudaram (vazio = nada a mudar).
 */
export function aplicarCep(achado, atuais) {
  const mudou = {};
  if (!achado) return mudou;
  for (const nome of ['rua', 'bairro', 'cidade', 'uf']) {
    const novo = texto(achado[nome]);
    if (novo && !texto(atuais?.[nome])) mudou[nome] = novo;
  }
  return mudou;
}
