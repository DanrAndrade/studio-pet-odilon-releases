/* Regras de horário: sobreposição, janelas livres e encaixe. Tudo em
   timestamps (ms) e minutos; nada aqui acessa o banco. */

const MIN = 60 * 1000;

const ativo = (ag) => !ag.excluidoEm && ag.status !== 'cancelado' && ag.status !== 'nao_compareceu';

export const fimDe = (ag) => ag.inicio + (ag.duracaoPrevistaMin || 60) * MIN;

/** Agendamentos do mesmo período que se sobrepõem a [inicio, inicio+duração). */
export function conflitos(inicio, duracaoMin, agendamentos, ignorarId = null) {
  const fim = inicio + (duracaoMin || 60) * MIN;
  return agendamentos.filter((ag) => ag.id !== ignorarId && ativo(ag) && ag.inicio < fim && fimDe(ag) > inicio);
}

/** Janelas livres de pelo menos `minimo` minutos dentro do expediente do dia. */
export function horariosLivres(diaTs, agendamentos, { abre, fecha, minimo = 30 }) {
  const base = new Date(diaTs);
  base.setHours(0, 0, 0, 0);
  const t = (minutos) => base.getTime() + minutos * MIN;

  const ocupados = agendamentos
    .filter(ativo)
    .map((ag) => ({ ini: ag.inicio, fim: fimDe(ag) }))
    .sort((a, b) => a.ini - b.ini);

  const livres = [];
  let cursor = t(abre);
  const limite = t(fecha);
  const janela = (de, ate) => {
    const minutos = Math.round((ate - de) / MIN);
    if (minutos >= minimo) livres.push({ inicio: de, fim: ate, minutos });
  };

  for (const o of ocupados) {
    if (o.ini > cursor) janela(cursor, Math.min(o.ini, limite));
    cursor = Math.max(cursor, o.fim);
    if (cursor >= limite) break;
  }
  if (cursor < limite) janela(cursor, limite);
  return livres;
}

/**
 * Primeiro horário livre a partir de `inicio`, no mesmo dia, antes do
 * fechamento. Se não houver, devolve o horário pedido (aviso, nunca bloqueio).
 */
export function encaixar(inicio, duracaoMin, agendamentos, { fecha }) {
  const base = new Date(inicio);
  base.setHours(0, 0, 0, 0);
  const limite = base.getTime() + fecha * MIN;
  let tentativa = inicio;

  for (let i = 0; i < 48; i++) {
    const choque = conflitos(tentativa, duracaoMin, agendamentos);
    if (!choque.length) return tentativa;
    tentativa = Math.max(...choque.map(fimDe));
    if (tentativa + duracaoMin * MIN > limite) break;
  }
  return inicio;
}

export function foraDoExpediente(inicio, duracaoMin, { abre, fecha, dias }) {
  const d = new Date(inicio);
  const minutos = d.getHours() * 60 + d.getMinutes();
  return !dias.includes(d.getDay()) || minutos < abre || minutos + duracaoMin > fecha;
}
