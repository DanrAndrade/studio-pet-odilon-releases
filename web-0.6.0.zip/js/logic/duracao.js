/* Estimativa de duração de um serviço para um pet específico.
 *
 * Prioridade (a regra que o Odilon validou):
 *  1. média das últimas N execuções DESSE serviço NESSE pet;
 *  2. média de pets de mesmo porte/espécie;
 *  3. duração padrão do catálogo.
 *
 * Tempos muito fora do padrão são descartados: um cronômetro esquecido
 * ligado durante o almoço não pode envenenar a média do pet. */

export const JANELA_HISTORICO = 5;
export const MINIMO_AMOSTRAS = 2;
const TOLERANCIA_OUTLIER = 0.5; // ±50% da mediana

export const ORIGEM = {
  HISTORICO_PET: 'historico_pet',
  PETS_SEMELHANTES: 'pets_semelhantes',
  PADRAO: 'padrao',
};

export function descartarOutliers(valores) {
  if (valores.length < 3) return valores;
  const ordenado = [...valores].sort((a, b) => a - b);
  const mediana = ordenado[Math.floor(ordenado.length / 2)];
  return valores.filter((v) => Math.abs(v - mediana) <= mediana * TOLERANCIA_OUTLIER);
}

const media = (xs) => Math.round(xs.reduce((a, b) => a + b, 0) / xs.length);

/**
 * @param {{duracaoRealMin:number}[]} execucoesDoPet  mais recentes primeiro
 * @param {{duracaoRealMin:number}[]} execucoesSemelhantes
 * @param {{duracaoPadraoMin:number}} servico
 */
export function estimarDuracao(execucoesDoPet, execucoesSemelhantes, servico) {
  const doPet = execucoesDoPet.slice(0, JANELA_HISTORICO).map((e) => e.duracaoRealMin).filter(Number.isFinite);
  if (doPet.length >= MINIMO_AMOSTRAS) {
    const filtrado = descartarOutliers(doPet);
    if (filtrado.length) {
      return { minutos: media(filtrado), origem: ORIGEM.HISTORICO_PET, amostras: filtrado.length };
    }
  }

  const semelhantes = execucoesSemelhantes.map((e) => e.duracaoRealMin).filter(Number.isFinite);
  if (semelhantes.length >= MINIMO_AMOSTRAS) {
    const filtrado = descartarOutliers(semelhantes);
    if (filtrado.length) {
      return { minutos: media(filtrado), origem: ORIGEM.PETS_SEMELHANTES, amostras: filtrado.length };
    }
  }

  return { minutos: servico.duracaoPadraoMin || 60, origem: ORIGEM.PADRAO, amostras: 0 };
}

/** Texto que aparece na tela explicando de onde veio a estimativa. */
export function explicar(estimativa, nomePet, fmtDur) {
  const dur = fmtDur(estimativa.minutos);
  switch (estimativa.origem) {
    case ORIGEM.HISTORICO_PET:
      return `${dur} — média dos últimos ${estimativa.amostras} atendimentos ${nomePet ? 'do ' + nomePet : 'deste pet'}`;
    case ORIGEM.PETS_SEMELHANTES:
      return `${dur} — média de pets de porte semelhante`;
    default:
      return `${dur} — duração padrão do serviço`;
  }
}
