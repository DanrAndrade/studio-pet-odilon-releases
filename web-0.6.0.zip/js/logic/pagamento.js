/* Situação de pagamento de um atendimento — o mesmo texto em todas as telas
   (Histórico, fichas do tutor e do pet, atendimento concluído). */

/** Banho que faz parte de um plano (pelo plano ou marcado como incluso). */
export const ehBanhoDePlano = (ag) => !!(ag?.planoId || ag?.origem === 'plano');

/**
 * @returns {{ chave: 'plano'|'semCobranca'|'naoPago'|'pago', texto: string, cls: string }}
 *   cls é o tom do selo: lavanda (plano/sem cobrança), ambar (não pago), verde (pago)
 */
export function situacaoPagamento(ag) {
  const valor = ag?.valorCentavos || 0;
  if (!valor && ehBanhoDePlano(ag)) return { chave: 'plano', texto: 'Incluso no plano', cls: 'lavanda' };
  if (!valor) return { chave: 'semCobranca', texto: 'Sem cobrança', cls: 'lavanda' };
  if (ag.pagamentoPendente) return { chave: 'naoPago', texto: 'Não pago', cls: 'ambar' };
  return { chave: 'pago', texto: `Pago${ag.formaPagamento ? ' · ' + ag.formaPagamento : ''}`, cls: 'verde' };
}

/** Atendimento com valor e já pago (é o que conta como "pago" nos totais). */
export const foiPago = (ag) => (ag?.valorCentavos || 0) > 0 && !ag.pagamentoPendente;
