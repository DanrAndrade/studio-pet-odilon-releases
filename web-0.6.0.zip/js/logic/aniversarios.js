import { deDataBR, proximoAniversario, inicioDoDia, DIA_MS } from '../core/dom.js';

/* Aniversários dos pets. Todo pet com nascimento válido entra: o objetivo é
   nenhum ser esquecido (o app antigo avisava só de alguns). */

export const JANELA_DIAS = 7;

/** Último aniversário (antes de hoje) e próximo (hoje em diante) do pet. */
function aniversariosDoPet(nascTs, agora) {
  const proximo = proximoAniversario(nascTs, agora);
  const anterior = proximoAniversario(nascTs, new Date(proximo.ts).setFullYear(new Date(proximo.ts).getFullYear() - 1));
  const hoje = inicioDoDia(agora);
  return [
    { ts: anterior.ts, dias: Math.round((anterior.ts - hoje) / DIA_MS), idade: anterior.idade },
    proximo,
  ];
}

/**
 * Aniversários de hoje até +7 dias, e os de até 7 dias atrás cujo parabéns não
 * foi enviado. Mais antigos e já enviados saem da lista. Ordem: atrasados, hoje, próximos.
 */
export function aniversariosProximos(listaPets, agora = Date.now()) {
  const saida = [];
  for (const pet of listaPets) {
    const nasc = deDataBR(pet.nascimento);
    if (!nasc) continue;
    for (const a of aniversariosDoPet(nasc, agora)) {
      if (a.idade < 1 || a.dias < -JANELA_DIAS || a.dias > JANELA_DIAS) continue;
      if (pet.parabensEnviadoPara === a.ts) continue;
      if (a.dias < 0 && pet.parabensEnviadoPara && pet.parabensEnviadoPara >= a.ts) continue;
      saida.push({ pet, ...a });
    }
  }
  return saida.sort((x, y) => x.dias - y.dias);
}

/** Pets que fazem aniversário no mês `mes` (0-11), em ordem de dia. */
export function aniversariantesDoMes(listaPets, mes) {
  return listaPets
    .map((pet) => ({ pet, nasc: deDataBR(pet.nascimento) }))
    .filter((x) => x.nasc && new Date(x.nasc).getMonth() === mes)
    .sort((a, b) => new Date(a.nasc).getDate() - new Date(b.nasc).getDate());
}

/** Pets sem data de nascimento válida (não entram nos avisos). */
export function semNascimento(listaPets) {
  return listaPets.filter((p) => !deDataBR(p.nascimento));
}
