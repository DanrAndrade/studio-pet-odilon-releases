/* Contatos do tutor. Um cadastro pode ter dois responsáveis (ex.: um casal),
   cada um com nome e telefone: `nome`/`telefone` e, opcionais, `nome2`/`telefone2`.
   Cadastros antigos só têm o primeiro e continuam funcionando igual. */

const texto = (v) => String(v || '').trim();

/** Nomes do tutor ("Marina Alves e João Alves"). */
export function nomesDoTutor(tutor) {
  return [texto(tutor?.nome), texto(tutor?.nome2)].filter(Boolean).join(' e ');
}

/** Textos e telefones que a busca deve considerar para este tutor. */
export const nomesParaBusca = (tutor) => [texto(tutor?.nome), texto(tutor?.nome2)].filter(Boolean);
export const telefonesDoTutor = (tutor) => [texto(tutor?.telefone), texto(tutor?.telefone2)].filter(Boolean);

/**
 * Pessoas com telefone, na ordem do cadastro: [{ nome, telefone, rotulo }].
 * Sem nome no segundo contato, usa "Telefone 2".
 */
export function contatosDoTutor(tutor) {
  const lista = [];
  if (texto(tutor?.telefone)) lista.push({ nome: texto(tutor.nome), telefone: texto(tutor.telefone), rotulo: texto(tutor.nome) || 'Telefone 1' });
  if (texto(tutor?.telefone2)) lista.push({ nome: texto(tutor.nome2), telefone: texto(tutor.telefone2), rotulo: texto(tutor.nome2) || 'Telefone 2' });
  return lista;
}
