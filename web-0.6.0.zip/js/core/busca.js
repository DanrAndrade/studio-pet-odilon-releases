import { digitos } from './dom.js';

/* Busca e ordem usadas em todas as listas do app.
   - ignora acento e maiúscula: "joao" acha "João", "MEL" acha "Mel";
   - cada palavra digitada precisa aparecer, em qualquer ordem: "marina thor";
   - 3 dígitos ou mais também procuram nos telefones: "99881". */

const SEM_ACENTO = /[̀-ͯ]/g;

export const normalizar = (texto) =>
  String(texto ?? '')
    .normalize('NFD')
    .replace(SEM_ACENTO, '')
    .toLowerCase()
    .replace(/\s+/g, ' ')
    .trim();

/**
 * @param {string} termo    o que foi digitado na busca
 * @param {string[]} textos nomes, raça, categoria... do item
 * @param {string[]} telefones telefones do item (comparados só pelos dígitos)
 */
export function combina(termo, textos = [], telefones = []) {
  const t = normalizar(termo);
  if (!t) return true;
  const alvo = normalizar(textos.filter(Boolean).join(' '));
  const palavras = t.split(' ');
  const ehNumero = (p) => /^[\d()+\-./]+$/.test(p);
  // palavras com letras: todas precisam estar nos textos
  if (!palavras.filter((p) => !ehNumero(p)).every((p) => alvo.includes(p))) return false;
  const numeros = palavras.filter(ehNumero);
  if (!numeros.length) return true;
  // números: valem se estão no texto (ex.: "Pet 10") ou, com 3+ dígitos, num telefone
  if (numeros.every((p) => alvo.includes(p))) return true;
  const d = digitos(numeros.join(''));
  return d.length >= 3 && telefones.some((f) => digitos(f).includes(d));
}

const COLADOR = new Intl.Collator('pt-BR', { sensitivity: 'base', numeric: true });

/** Compara dois textos em ordem alfabética do português (acento e maiúscula não mudam a ordem). */
export const ordemAlfabetica = (a, b) => COLADOR.compare(String(a ?? ''), String(b ?? ''));

/** Ordena uma cópia da lista pelo texto que `chave` devolve; vazios vão para o fim. */
export function ordenarPor(lista, chave) {
  return [...lista].sort((x, y) => {
    const a = String(chave(x) ?? '').trim();
    const b = String(chave(y) ?? '').trim();
    if (!a !== !b) return a ? -1 : 1;
    return ordemAlfabetica(a, b);
  });
}
