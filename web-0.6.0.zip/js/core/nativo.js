import { digitos } from './dom.js';

/* Ponte com o Android. Dentro do app, `window.StudioPetAndroid` é injetado
   pelo MainActivity. No navegador (desenvolvimento) cada função tem um
   equivalente web, para o app continuar utilizável fora do tablet. */

const ponte = () => window.StudioPetAndroid || null;

export const noAndroid = () => !!ponte();

export function abrirExterno(url) {
  const p = ponte();
  if (p?.abrirUrl) return p.abrirUrl(url);
  if (url.startsWith('http')) window.open(url, '_blank', 'noopener');
  else window.location.href = url;
}

/** DDD de um telefone brasileiro ("(73) 99811-2030" → "73"), ou '' se não der para saber. */
export function dddDe(telefone) {
  const n = digitos(telefone).replace(/^0+/, '').replace(/^55(?=\d{10,11}$)/, '');
  return n.length === 10 || n.length === 11 ? n.slice(0, 2) : '';
}

/**
 * Número no formato do WhatsApp (55 + DDD + número). Aceita "(73) 99811-2030",
 * "073 99811-2030" e "+55 73 99811-2030"; sem DDD, usa o DDD da loja.
 * Devolve '' quando não dá para montar um número válido.
 */
export function numeroWhatsapp(telefone, dddPadrao = '') {
  let n = digitos(telefone).replace(/^0+/, '');
  if ((n.length === 8 || n.length === 9) && dddPadrao) n = dddPadrao + n;
  // decide pelo comprimento, não pelo prefixo: DDD 55 (RS) também é número brasileiro
  if (n.length === 10 || n.length === 11) n = '55' + n;
  return n.length === 12 || n.length === 13 ? n : '';
}

/** Abre conversa no WhatsApp com a mensagem já escrita. */
export function whatsapp(telefone, mensagem = '', dddPadrao = '') {
  const numero = numeroWhatsapp(telefone, dddPadrao);
  const base = numero ? `https://wa.me/${numero}` : 'https://wa.me/';
  abrirExterno(mensagem ? `${base}?text=${encodeURIComponent(mensagem)}` : base);
}

export function ligar(telefone) {
  const numero = digitos(telefone);
  if (numero) abrirExterno(`tel:${numero}`);
}

export async function copiar(texto) {
  const p = ponte();
  if (p?.copiarTexto) {
    p.copiarTexto(String(texto));
    return true;
  }
  try {
    await navigator.clipboard.writeText(String(texto));
    return true;
  } catch {
    return false;
  }
}

export async function colar() {
  const p = ponte();
  if (p?.lerAreaTransferencia) return p.lerAreaTransferencia() || '';
  try {
    return (await navigator.clipboard.readText()) || '';
  } catch {
    return '';
  }
}

/** Entrega um arquivo ao usuário: no tablet abre o compartilhamento do Android
    (WhatsApp, Drive, e-mail); no navegador, baixa o arquivo. */
export function compartilharArquivo(nome, conteudo, mime = 'application/json') {
  const p = ponte();
  if (p?.compartilharArquivo) {
    p.compartilharArquivo(nome, conteudo, mime);
    return;
  }
  const blob = new Blob([conteudo], { type: mime });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = nome;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

/* Atualização do app: o Android baixa o APK e abre o instalador. O andamento
   chega por window.__studioPetAtualizacao(estado, detalhe). */
let ouvinteAtualizacao = null;
window.__studioPetAtualizacao = (estado, detalhe) => ouvinteAtualizacao?.(estado, detalhe);

/* Teclado físico: o Android trata as teclas (e os acentos) enquanto há um campo
   de texto em uso. Datas, horas e números ficam com o tratamento normal. */
const TIPOS_TEXTO = new Set(['text', 'search', 'tel', 'email', 'url', 'password']);
const campoDeTexto = (el) => !!el && (el.tagName === 'TEXTAREA' || (el.tagName === 'INPUT' && TIPOS_TEXTO.has((el.type || 'text').toLowerCase())) || el.isContentEditable);
let avisado = null;
let ultimoCampo = null;
/** Avisa o Android do campo em uso (a cada troca de campo, e quando o campo some da tela). */
export function avisarCampo() {
  const el = document.activeElement;
  const emUso = campoDeTexto(el);
  if (emUso === avisado && el === ultimoCampo) return;
  avisado = emUso;
  ultimoCampo = el;
  try {
    ponte()?.campoEmUso?.(emUso);
  } catch {
    /* APK sem o tratamento do teclado físico */
  }
}
document.addEventListener('focusin', avisarCampo, true);
document.addEventListener('focusout', () => setTimeout(avisarCampo, 0), true);
// campo que sumiu da tela (troca de tela) não dispara focusout em todo Android
setInterval(avisarCampo, 1000);

/** Versão do APK instalado (a parte Android). As telas podem ter sido atualizadas sozinhas. */
export const versaoNativa = () => ponte()?.versaoNativa?.() || null;

/** Avisa o Android que esta versão das telas abriu bem (senão ele volta para a anterior). */
export function confirmarVersao(versao) {
  try {
    ponte()?.confirmarVersao?.(versao);
  } catch {
    /* APK antigo, sem atualização automática */
  }
}

export function instalarAtualizacao(url, aoMudar) {
  const p = ponte();
  if (!p?.instalarAtualizacao) {
    abrirExterno(url);
    return false;
  }
  ouvinteAtualizacao = aoMudar;
  p.instalarAtualizacao(url);
  return true;
}
