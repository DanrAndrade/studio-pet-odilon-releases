import { html, raw, icon, dados, esc, FORMATOS } from './dom.js';

/* Peças de interface compartilhadas. Retornam fragmentos seguros de HTML. */

/* ------------------------------ Pets ------------------------------- */

const CORES_CAO = ['#8b7bee', '#6b6590', '#bd8450'];
const CORES_GATO = ['#f0339b', '#bd8450'];

function hash(texto) {
  let h = 0;
  for (const c of String(texto || '')) h = (h * 31 + c.charCodeAt(0)) | 0;
  return Math.abs(h);
}

export const ehGato = (pet) => (pet?.especie || '').toLowerCase().startsWith('gat');
export const iconePet = (pet) => (ehGato(pet) ? 'cat' : 'dog');
export function corPet(pet) {
  const paleta = ehGato(pet) ? CORES_GATO : CORES_CAO;
  return paleta[hash(pet?.id || pet?.nome) % paleta.length];
}

/** Avatar circular do pet: foto quando houver, ícone sobre a cor do pet quando não. */
export function avPet(pet, tamanho = 48, { borda = 2, sombra = true, extra = '' } = {}) {
  const cls = borda === 3 ? 'av borda-3' : borda ? 'av borda' : 'av';
  const estilo = `width:${tamanho}px;height:${tamanho}px;min-width:${tamanho}px;background:${corPet(pet)};${sombra ? '' : 'box-shadow:none;'}${extra}`;
  const miolo = pet?.foto ? html`<img src="${pet.foto}" alt="">` : icon(iconePet(pet), Math.round(tamanho * 0.4));
  return html`<div class="${cls}" style="${estilo}">${miolo}</div>`;
}

export function avTutor(tamanho = 30) {
  return html`<div class="av av-tutor" style="width:${tamanho}px;height:${tamanho}px;min-width:${tamanho}px">${icon('user-round', Math.round(tamanho * 0.5))}</div>`;
}

/* Temperamentos e alertas viram etiquetas coloridas na ficha e na agenda. */
const TAGS_PERIGO = ['morde', 'arranha', 'agitado', 'territorial'];
const TAGS_NEUTRAS = ['calmo', 'dócil', 'docil', 'brincalhão', 'brincalhao'];

export function tagsPet(pet) {
  const lista = [...(pet?.temperamentos || [])];
  return lista
    .filter((t) => t && !TAGS_NEUTRAS.includes(t.toLowerCase()))
    .map((t) => ({ label: t, tom: TAGS_PERIGO.includes(t.toLowerCase()) ? 'rosa' : 'ambar' }))
    .sort((a, b) => (a.tom === b.tom ? 0 : a.tom === 'rosa' ? -1 : 1));
}

export const descricaoPet = (pet) => [pet?.raca, pet?.porte].filter(Boolean).join(' · ') || 'Sem raça informada';

/* --------------------------- Agendamentos -------------------------- */

export const STATUS = {
  agendado: { rotulo: 'Agendado', tom: 'neutro' },
  confirmado: { rotulo: 'Confirmado', tom: 'roxo' },
  em_atendimento: { rotulo: 'Em atendimento', tom: 'roxo' },
  concluido: { rotulo: 'Concluído', tom: 'verde' },
  rascunho_plano: { rotulo: 'Rascunho de plano', tom: 'ambar' },
  cancelado: { rotulo: 'Cancelado', tom: 'rosa' },
  nao_compareceu: { rotulo: 'Não compareceu', tom: 'rosa' },
};

export const CORES_TRACO = ['#5b32e0', '#f0339b', '#1e9c62', '#a97a1c', '#8b7bee'];

/* ------------------------------ Blocos ----------------------------- */

export const selo = (texto, tom = 'neutro', extra = '') =>
  html`<span class="selo selo-${tom} ${extra}">${texto}</span>`;

export function chip(rotulo, ligado, acao, attrs = {}, { suave = false, cls = '', sub = null } = {}) {
  const base = suave ? 'chip-s' : 'chip';
  return html`<button class="${base}${ligado ? ' on' : ''} ${cls}" data-acao="${acao}"${dados(attrs)}>${rotulo}${
    sub ? html`<span class="chip-sub">${sub}</span>` : ''
  }</button>`;
}

export const toggle = (ligado, acao, attrs = {}) =>
  html`<button class="toggle${ligado ? ' on' : ''}" data-acao="${acao}"${dados(attrs)} aria-pressed="${ligado ? 'true' : 'false'}"></button>`;

export function linhaToggle({ rotulo, dica, ligado, acao, attrs = {}, compacta = false }) {
  return html`<div class="linha-toggle${compacta ? ' compacta' : ''}">
    <div><div class="lt-rotulo">${rotulo}</div>${dica ? html`<div class="lt-dica">${dica}</div>` : ''}</div>
    ${toggle(ligado, acao, attrs)}
  </div>`;
}

export function campo({ rotulo, nome, valor = '', placeholder = '', tipo = 'text', cls = '', attrs = '', modo = '', formato = '' }) {
  // formato: máscara e checagem automáticas (ver FORMATOS em dom.js)
  const inputmode = modo || FORMATOS[formato]?.modo ? ` inputmode="${modo || FORMATOS[formato].modo}"` : '';
  const fmt = formato ? ` data-formato="${formato}"` : '';
  return html`<div>
    ${rotulo ? html`<div class="rotulo-campo">${rotulo}</div>` : ''}
    <input class="entrada ${cls}" type="${tipo}" data-campo="${nome}" value="${valor ?? ''}" placeholder="${placeholder}"${raw(inputmode)}${raw(fmt)} ${raw(attrs)}>
  </div>`;
}

export function areaTexto({ rotulo, nome, valor = '', placeholder = '', altura = 100 }) {
  return html`<div>
    ${rotulo ? html`<div class="rotulo-campo">${rotulo}</div>` : ''}
    <textarea class="entrada" data-campo="${nome}" placeholder="${placeholder}" style="height:${altura}px">${valor ?? ''}</textarea>
  </div>`;
}

export function vazio({ icone = 'paw-print', titulo, texto = '', compacto = false, acao = null }) {
  return html`<div class="vazio${compacto ? ' compacto' : ''}">
    ${icon(icone, compacto ? 22 : 30)}
    ${titulo ? html`<div class="vazio-titulo">${titulo}</div>` : ''}
    ${texto ? html`<div>${texto}</div>` : ''}
    ${acao || ''}
  </div>`;
}

export const secao = (icone, titulo) =>
  html`<div class="secao"><span class="secao-icone">${icon(icone, 14)}</span><span class="titulo-card gg">${titulo}</span></div>`;

export const voltar = (rotulo, acao = 'voltar', attrs = {}) =>
  html`<button class="voltar" data-acao="${acao}"${dados(attrs)}>${icon('arrow-left', 15)}<span>${rotulo}</span></button>`;

/* Patinhas decorativas dos cabeçalhos de destaque (posições da referência). */
const PATINHAS = {
  padrao: [
    ['paw-print', 6, 236, 30, 0], ['bone', 34, 308, 26, -18], ['dog', 4, 392, 34, 0],
    ['cat', 36, 468, 30, 0], ['paw-print', 8, 544, 24, 14], ['bone', 38, 608, 28, 24],
  ],
  agenda: [
    ['paw-print', 10, 236, 32, 0], ['bone', 62, 304, 28, -18], ['dog', 8, 392, 38, 0],
    ['cat', 66, 470, 34, 0], ['paw-print', 12, 548, 26, 14], ['bone', 68, 614, 30, 24], ['dog', 10, 700, 34, 0],
  ],
  ficha: [
    ['paw-print', 14, 230, 34, 0], ['bone', 78, 300, 30, -18], ['dog', 12, 392, 40, 0],
    ['cat', 84, 470, 36, 0], ['paw-print', 18, 552, 28, 14], ['bone', 88, 620, 32, 24],
  ],
  perfil: [
    ['paw-print', 12, 180, 34, 0], ['dog', 74, 250, 42, 0], ['bone', 20, 330, 30, -18], ['cat', 86, 410, 38, 0],
    ['paw-print', 16, 490, 28, 14], ['bone', 92, 560, 34, 24], ['dog', 10, 640, 40, 0], ['paw-print', 80, 716, 32, 0],
  ],
};

export function patinhasHero(conjunto = 'padrao', opacidade = 0.15) {
  const itens = (PATINHAS[conjunto] || PATINHAS.padrao)
    .map(([nome, topo, esquerda, tam, rot]) =>
      `<span style="top:${topo}px;left:${esquerda}px;transform:rotate(${rot}deg)">${icon(nome, tam)}</span>`
    )
    .join('');
  return raw(`<div class="hero-patinhas" style="opacity:${opacidade}">${itens}</div>`);
}

export const barra = (pct, cor = 'var(--roxo)', altura = 6, trilho = 'var(--borda)') =>
  raw(
    `<div class="barra" style="height:${altura}px;background:${trilho}"><div style="width:${Math.max(0, Math.min(100, pct)).toFixed(1)}%;background:${cor}"></div></div>`
  );

export { esc };
