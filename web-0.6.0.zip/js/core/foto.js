/* Foto de pet/perfil: abre câmera ou galeria, recorta em quadrado central
   (os avatares são círculos) e reduz para no máximo `lado` px em JPEG.
   Guardar a imagem já pequena mantém o banco e o backup leves. */

/**
 * Abre o seletor de arquivo do sistema e devolve o File escolhido, ou null.
 * Fechar o seletor sem escolher também devolve null: WebViews novos disparam
 * "cancel"; nos antigos, o sinal é a página voltar a ficar visível sem "change".
 */
export function abrirSeletorArquivo({ accept = '', capture = null } = {}) {
  return new Promise((resolve) => {
    const input = document.createElement('input');
    input.type = 'file';
    if (accept) input.accept = accept;
    if (capture) input.setAttribute('capture', capture);
    input.style.display = 'none';
    document.body.appendChild(input);

    let terminou = false;
    const terminar = (arquivo) => {
      if (terminou) return;
      terminou = true;
      document.removeEventListener('visibilitychange', aoVoltar);
      input.remove();
      resolve(arquivo);
    };
    function aoVoltar() {
      if (document.visibilityState !== 'visible') return;
      setTimeout(() => {
        if (!input.files?.length) terminar(null);
      }, 1500);
    }

    input.addEventListener('change', () => terminar(input.files?.[0] || null), { once: true });
    input.addEventListener('cancel', () => terminar(null), { once: true });
    document.addEventListener('visibilitychange', aoVoltar);
    input.click();
  });
}

export async function escolherFoto({ camera = false, lado = 640 } = {}) {
  const arquivo = await abrirSeletorArquivo({ accept: 'image/*', capture: camera ? 'environment' : null });
  if (!arquivo) return null;
  try {
    return await reduzir(arquivo, lado);
  } catch {
    // ex.: formato que o WebView não decodifica (HEIC de alguns celulares)
    throw new Error('não foi possível ler esta imagem. Tente outra foto ou tire pela câmera.');
  }
}

function carregar(url) {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = reject;
    img.src = url;
  });
}

async function reduzir(arquivo, ladoMax) {
  const url = URL.createObjectURL(arquivo);
  try {
    const img = await carregar(url);
    const lado = Math.min(img.naturalWidth, img.naturalHeight);
    const sx = (img.naturalWidth - lado) / 2;
    const sy = (img.naturalHeight - lado) / 2;
    const destino = Math.min(ladoMax, lado);

    const canvas = document.createElement('canvas');
    canvas.width = destino;
    canvas.height = destino;
    const ctx = canvas.getContext('2d');
    ctx.imageSmoothingQuality = 'high';
    ctx.drawImage(img, sx, sy, lado, lado, 0, 0, destino, destino);
    return canvas.toDataURL('image/jpeg', 0.84);
  } finally {
    URL.revokeObjectURL(url);
  }
}
