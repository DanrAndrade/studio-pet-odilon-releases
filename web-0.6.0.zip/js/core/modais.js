import { html, icon, $, morfar, digitandoEm } from './dom.js';
import { avisarCampo } from './nativo.js';

/* Camada de modais, confirmação e toast. Um modal por vez; cada modal é um
   objeto { render(estado) -> html, acoes, aoDigitar?, aoMontar? } com estado
   próprio, e resolve uma Promise quando fecha. */

let atual = null;

const raiz = () => $('#camada-modal');

function pintar() {
  const el = raiz();
  if (!atual) {
    el.innerHTML = '';
    return;
  }
  const foco = document.activeElement;
  const campoFocado = foco && el.contains(foco) ? foco.dataset.campo : null;
  const posicao = foco && campoFocado ? foco.selectionStart : null;

  const conteudo = String(atual.def.render(atual.estado, atual.ctx));
  // digitando num campo da janela: atualiza só o que mudou (evita letra repetida no Android)
  const preservar = digitandoEm(el);
  if (preservar) morfar(el, conteudo);
  else el.innerHTML = conteudo;
  atual.def.aoMontar?.(el, atual.estado, atual.ctx);
  setTimeout(avisarCampo, 0);

  if (campoFocado && !preservar) {
    const novo = el.querySelector(`[data-campo="${campoFocado}"]`);
    if (novo) {
      novo.focus();
      try {
        if (posicao !== null) novo.setSelectionRange(posicao, posicao);
      } catch {
        /* inputs sem seleção (date/time) */
      }
    }
  }
}

export function abrirModal(def, estadoInicial = {}, ctx = {}) {
  if (atual) fecharModal(null);
  return new Promise((resolve) => {
    atual = { def, estado: { ...estadoInicial }, ctx, resolve };
    pintar();
  });
}

export function fecharModal(resultado = null) {
  if (!atual) return;
  const { resolve } = atual;
  atual = null;
  pintar();
  resolve(resultado);
}

export const modalAberto = () => !!atual;

/** Atualiza o estado do modal aberto e redesenha. */
export function atualizarModal(parcial) {
  if (!atual) return;
  atual.estado = { ...atual.estado, ...parcial };
  pintar();
}

export function ligarModais() {
  const el = raiz();
  const emCurso = new Set(); // mesma proteção contra toque duplo das telas

  el.addEventListener('click', async (ev) => {
    if (!atual) return;
    // clique no fundo escuro fecha
    if (ev.target.classList.contains('modal-fundo') && atual.def.fecharNoFundo !== false) {
      fecharModal(null);
      return;
    }
    const alvo = ev.target.closest('[data-acao]');
    if (!alvo || !el.contains(alvo)) return;
    ev.preventDefault();
    const nome = alvo.dataset.acao;
    if (nome === 'fechar-modal') return fecharModal(null);
    const fn = atual.def.acoes?.[nome];
    if (!fn || emCurso.has(nome)) return;
    emCurso.add(nome);
    try {
      await fn({ ...alvo.dataset }, { estado: atual.estado, atualizar: atualizarModal, fechar: fecharModal, ctx: atual.ctx, alvo });
    } catch (erro) {
      console.error(erro);
      toast('Não deu certo: ' + erro.message, { erro: true });
    } finally {
      emCurso.delete(nome);
    }
  });

  el.addEventListener('input', (ev) => {
    if (!atual) return;
    const campo = ev.target.dataset?.campo;
    if (!campo) return;
    atual.estado[campo] = ev.target.value;
    atual.def.aoDigitar?.(campo, ev.target.value, { estado: atual.estado, atualizar: atualizarModal, el: ev.target });
  });

  document.addEventListener('keydown', (ev) => {
    if (ev.key === 'Escape' && atual) fecharModal(null);
  });
}

/* ------------------------------ Confirmar ---------------------------- */

const modalConfirmar = {
  render: (e) => html`<div class="modal-fundo">
    <div class="modal m-400">
      <div style="width:40px;height:40px;border-radius:14px;background:${e.perigo ? 'var(--rosa-fundo)' : 'var(--lavanda)'};display:flex;align-items:center;justify-content:center;color:${e.perigo ? 'var(--rosa)' : 'var(--roxo)'}">${icon(e.icone || 'triangle-alert', 19)}</div>
      <div style="font-size:16px;font-weight:600;color:var(--tinta-2);margin-top:13px">${e.titulo}</div>
      ${e.texto ? html`<div style="font-size:13px;color:var(--texto-3);margin-top:6px;line-height:1.5">${e.texto}</div>` : ''}
      <div style="display:flex;gap:9px;margin-top:18px">
        <button class="btn btn-branco" style="flex:1" data-acao="fechar-modal">${e.cancelar || 'Cancelar'}</button>
        <button class="btn ${e.perigo ? 'btn-rosa' : 'btn-roxo'}" style="flex:1" data-acao="ok">${e.botao || 'Confirmar'}</button>
      </div>
    </div>
  </div>`,
  acoes: { ok: (_, { fechar }) => fechar(true) },
};

export async function confirmar({ titulo, texto = '', botao = 'Confirmar', perigo = true, icone = 'triangle-alert', cancelar }) {
  return !!(await abrirModal(modalConfirmar, { titulo, texto, botao, perigo, icone, cancelar }));
}

/* ------------------------------ Escolher ----------------------------- */

const modalEscolher = {
  render: (e) => html`<div class="modal-fundo">
    <div class="modal m-400">
      <div style="font-size:16px;font-weight:600;color:var(--tinta-2)">${e.titulo}</div>
      ${e.texto ? html`<div style="font-size:13px;color:var(--texto-3);margin-top:6px;line-height:1.5">${e.texto}</div>` : ''}
      <div style="display:flex;flex-direction:column;gap:9px;margin-top:16px">
        ${e.opcoes.map((o, i) => html`<button class="btn ${i === 0 ? 'btn-roxo' : 'btn-branco'}" style="width:100%;flex-direction:column;align-items:flex-start;text-align:left;gap:2px;white-space:normal" data-acao="opcao" data-valor="${o.valor}">
          <span>${o.rotulo}</span>${o.sub ? html`<span style="font-size:12px;font-weight:400;opacity:.8">${o.sub}</span>` : ''}
        </button>`)}
        <button class="btn btn-branco" style="width:100%" data-acao="fechar-modal">Cancelar</button>
      </div>
    </div>
  </div>`,
  acoes: { opcao: ({ valor }, { fechar }) => fechar(valor) },
};

/** Pergunta com várias respostas: devolve o `valor` da opção tocada, ou null se cancelou. */
export async function escolher({ titulo, texto = '', opcoes }) {
  return (await abrirModal(modalEscolher, { titulo, texto, opcoes })) ?? null;
}

/* -------------------------------- Toast ------------------------------ */

let temporizador = null;

export function toast(mensagem, { erro = false } = {}) {
  const el = $('#camada-toast');
  clearTimeout(temporizador);
  el.innerHTML = String(
    html`<div class="toast${erro ? ' erro' : ''}">${icon(erro ? 'circle-alert' : 'circle-check-big', 16)}<span>${mensagem}</span></div>`
  );
  temporizador = setTimeout(() => {
    el.innerHTML = '';
  }, Math.max(2800, String(mensagem).length * 55));
}
