import { LUCIDE } from '../vendor/icons.js';

/* ------------------------------------------------------------------ *
 * HTML seguro
 *
 * `html` escapa tudo o que é interpolado, exceto outros fragmentos já
 * produzidos por `html`/`icon`/`raw`. Assim dá para compor componentes
 * sem nunca injetar texto digitado pelo usuário como marcação.
 * ------------------------------------------------------------------ */

class Seguro {
  constructor(valor) {
    this.valor = valor;
  }
  toString() {
    return this.valor;
  }
}

export const raw = (valor) => new Seguro(valor == null ? '' : String(valor));

export function esc(valor) {
  if (valor === null || valor === undefined) return '';
  return String(valor)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

function interpolar(v) {
  if (v === null || v === undefined || v === false || v === true) return '';
  if (v instanceof Seguro) return v.valor;
  if (Array.isArray(v)) return v.map(interpolar).join('');
  return esc(v);
}

export function html(partes, ...valores) {
  let saida = partes[0];
  for (let i = 0; i < valores.length; i++) saida += interpolar(valores[i]) + partes[i + 1];
  return new Seguro(saida);
}

/** Atributos data-* a partir de um objeto (valores escapados). */
export function dados(obj = {}) {
  return raw(
    Object.entries(obj)
      .filter(([, v]) => v !== undefined && v !== null)
      .map(([k, v]) => ` data-${k}="${esc(v)}"`)
      .join('')
  );
}

/** Ícone Lucide inline, com o traço do design (stroke 2, pontas arredondadas). */
export function icon(nome, tamanho = 16, estilo = '') {
  const interno = LUCIDE[nome];
  if (!interno) return raw('');
  const st = estilo ? ` style="${esc(estilo)}"` : '';
  return raw(
    `<svg xmlns="http://www.w3.org/2000/svg" width="${tamanho}" height="${tamanho}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"${st}>${interno}</svg>`
  );
}

export const $ = (seletor, raiz = document) => raiz.querySelector(seletor);
export const $$ = (seletor, raiz = document) => Array.from(raiz.querySelectorAll(seletor));

/* ------------------------------------------------------------------ *
 * Números e dinheiro (contrato do protótipo: centavos e minutos)
 * ------------------------------------------------------------------ */

const pad2 = (n) => String(n).padStart(2, '0');

export const fmtBRL = (centavos) =>
  'R$ ' +
  ((centavos || 0) / 100).toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 });

/** "R$ 320" quando não há centavos, "R$ 85,50" quando há. */
export const fmtBRLCurto = (centavos) => {
  const c = Math.round(centavos || 0);
  return c % 100 === 0 ? 'R$ ' + (c / 100).toLocaleString('pt-BR') : fmtBRL(c);
};

export const fmtDur = (minutos) => {
  const m = Math.max(0, Math.round(minutos || 0));
  return m >= 60 ? Math.floor(m / 60) + 'h' + pad2(m % 60) : m + 'min';
};

/** Cronômetro: "12:04" ou "1:02:09". */
export const fmtCron = (segundos) => {
  const s = Math.max(0, Math.round(segundos || 0));
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const r = s % 60;
  return h ? `${h}:${pad2(m)}:${pad2(r)}` : `${pad2(m)}:${pad2(r)}`;
};

export const digitos = (texto) => String(texto || '').replace(/\D/g, '');

/** Aceita "R$ 1.234,56", "85", "85,5", "R$ 320". Vazio vira 0. */
export function paraCentavos(texto) {
  if (texto === null || texto === undefined || texto === '') return 0;
  if (typeof texto === 'number') return Math.round(texto * 100);
  let s = String(texto).replace(/[^\d.,-]/g, '');
  if (!s) return 0;
  if (s.includes(',')) s = s.replace(/\./g, '').replace(',', '.');
  else if (/\.\d{3}$/.test(s)) s = s.replace(/\./g, '');
  const n = parseFloat(s);
  return Number.isFinite(n) ? Math.round(n * 100) : 0;
}

/** Texto de dinheiro para campo editável: 8500 → "R$ 85". */
export const centavosParaCampo = (centavos) => (centavos ? fmtBRLCurto(centavos) : '');

/** Aceita "1h30", "1h", "45min", "45". Retorna null se não entender. */
/* Máscaras de digitação e validações de cadastro (nada é obrigatório, mas o que
   for preenchido precisa fazer sentido). */

/** "73998112030" → "(73) 99811-2030"; "7332810000" → "(73) 3281-0000". */
export function mascaraTelefone(texto) {
  const d = digitos(texto).replace(/^55(?=\d{10,11}$)/, '').slice(0, 11);
  if (d.length <= 2) return d ? `(${d}` : '';
  if (d.length <= 6) return `(${d.slice(0, 2)}) ${d.slice(2)}`;
  if (d.length <= 10) return `(${d.slice(0, 2)}) ${d.slice(2, 6)}-${d.slice(6)}`;
  return `(${d.slice(0, 2)}) ${d.slice(2, 7)}-${d.slice(7)}`;
}
export const telefoneValido = (texto) => !digitos(texto) || [10, 11].includes(digitos(texto).replace(/^55(?=\d{10,11}$)/, '').length);

export function mascaraCpf(texto) {
  const d = digitos(texto).slice(0, 11);
  return d.replace(/(\d{3})(\d)/, '$1.$2').replace(/(\d{3})(\d)/, '$1.$2').replace(/(\d{3})(\d{1,2})$/, '$1-$2');
}
/** Dígitos verificadores do CPF (vazio conta como válido: o campo é opcional). */
export function cpfValido(texto) {
  const d = digitos(texto);
  if (!d) return true;
  if (d.length !== 11 || /^(\d)\1{10}$/.test(d)) return false;
  const dv = (n) => {
    let soma = 0;
    for (let i = 0; i < n; i++) soma += parseInt(d[i], 10) * (n + 1 - i);
    const r = (soma * 10) % 11;
    return r === 10 ? 0 : r;
  };
  return dv(9) === parseInt(d[9], 10) && dv(10) === parseInt(d[10], 10);
}
export const emailValido = (texto) => !String(texto || '').trim() || /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(String(texto).trim());

/** "1500" → "15:00", "930" → "09:30", "9" → "09:00", "15:00" → "15:00"; inválido → null. */
export function normalizarHora(texto) {
  const s = String(texto || '').trim();
  let h;
  let m;
  const comDoisPontos = /^(\d{1,2}):(\d{2})$/.exec(s);
  if (comDoisPontos) [h, m] = [+comDoisPontos[1], +comDoisPontos[2]];
  else {
    const d = digitos(s);
    if (!d || d.length > 4) return null;
    if (d.length <= 2) [h, m] = [+d, 0];
    else [h, m] = [+d.slice(0, -2), +d.slice(-2)];
  }
  if (h > 23 || m > 59) return null;
  return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}`;
}

export function paraMinutos(texto) {
  const s = String(texto || '').toLowerCase().trim();
  if (!s) return null;
  const h = /(\d+)\s*h\s*(\d*)/.exec(s);
  if (h) return parseInt(h[1], 10) * 60 + (parseInt(h[2] || '0', 10) || 0);
  const m = /(\d+)/.exec(s);
  return m ? parseInt(m[1], 10) : null;
}

/* ------------------------------------------------------------------ *
 * Datas
 * ------------------------------------------------------------------ */

export const DIA_MS = 24 * 60 * 60 * 1000;
export const DIAS_CURTOS = ['dom', 'seg', 'ter', 'qua', 'qui', 'sex', 'sáb'];
export const DIAS_LONGOS = ['Domingo', 'Segunda', 'Terça', 'Quarta', 'Quinta', 'Sexta', 'Sábado'];
export const MESES = ['janeiro', 'fevereiro', 'março', 'abril', 'maio', 'junho', 'julho', 'agosto', 'setembro', 'outubro', 'novembro', 'dezembro'];
export const MESES_CURTOS = ['jan', 'fev', 'mar', 'abr', 'mai', 'jun', 'jul', 'ago', 'set', 'out', 'nov', 'dez'];

export const fmtHora = (ts) => {
  const d = new Date(ts);
  return `${pad2(d.getHours())}:${pad2(d.getMinutes())}`;
};
export const fmtData = (ts) => {
  const d = new Date(ts);
  return `${pad2(d.getDate())}/${pad2(d.getMonth() + 1)}/${d.getFullYear()}`;
};
export const fmtDataCurta = (ts) => {
  const d = new Date(ts);
  return `${pad2(d.getDate())}/${pad2(d.getMonth() + 1)}`;
};
export const fmtDataExtenso = (ts = Date.now()) => {
  const d = new Date(ts);
  return `${DIAS_LONGOS[d.getDay()]}, ${d.getDate()} de ${MESES[d.getMonth()]}`;
};
/** "Qui, 20/08 · 10:30" */
export const fmtDiaHora = (ts) => {
  const d = new Date(ts);
  const dia = DIAS_CURTOS[d.getDay()];
  return `${dia.charAt(0).toUpperCase()}${dia.slice(1)}, ${fmtDataCurta(ts)} · ${fmtHora(ts)}`;
};

export const inicioDoDia = (ts) => {
  const d = new Date(ts);
  d.setHours(0, 0, 0, 0);
  return d.getTime();
};
export const fimDoDia = (ts) => inicioDoDia(ts) + DIA_MS - 1;
export const addDias = (ts, n) => {
  const d = new Date(ts);
  d.setDate(d.getDate() + n);
  return d.getTime();
};
/** Semana começa na segunda-feira. */
export const inicioDaSemana = (ts) => {
  const d = new Date(inicioDoDia(ts));
  d.setDate(d.getDate() - ((d.getDay() + 6) % 7));
  return d.getTime();
};
export const inicioDoMes = (ts) => {
  const d = new Date(ts);
  return new Date(d.getFullYear(), d.getMonth(), 1).getTime();
};
export const fimDoMes = (ts) => {
  const d = new Date(ts);
  return new Date(d.getFullYear(), d.getMonth() + 1, 1).getTime() - 1;
};
export const mesmoDia = (a, b) => inicioDoDia(a) === inicioDoDia(b);
export const diasEntre = (de, ate) => Math.round((inicioDoDia(ate) - inicioDoDia(de)) / DIA_MS);

/** Valores para <input type="date|time">. */
export const valorData = (ts) => {
  const d = new Date(ts);
  return `${d.getFullYear()}-${pad2(d.getMonth() + 1)}-${pad2(d.getDate())}`;
};
export const valorHora = (ts) => fmtHora(ts);
export function deCampos(data, hora) {
  const [a, m, d] = String(data || '').split('-').map((x) => parseInt(x, 10));
  const [h, mi] = String(hora || '09:00').split(':').map((x) => parseInt(x, 10));
  if (!a || !m || !d) return null;
  return new Date(a, m - 1, d, h || 0, mi || 0, 0, 0).getTime();
}

/** "21/08/2026" → timestamp (00:00). */
/**
 * Lê uma data digitada à mão: "15/03/2020", "15/3/20", "15-03-2020" ou só dígitos
 * ("15032020", "150320"). Ano com 2 dígitos vira 19xx/20xx pelo mais próximo do
 * passado. Data impossível (31/02) → null.
 */
export function deDataBR(texto) {
  const t = String(texto || '').trim();
  let dia, mes, ano;
  const m = /^(\d{1,2})\s*[/.\-]\s*(\d{1,2})\s*[/.\-]\s*(\d{2}|\d{4})$/.exec(t);
  if (m) [dia, mes, ano] = [m[1], m[2], m[3]];
  else if (/^\d{8}$/.test(t)) [dia, mes, ano] = [t.slice(0, 2), t.slice(2, 4), t.slice(4)];
  else if (/^\d{6}$/.test(t)) [dia, mes, ano] = [t.slice(0, 2), t.slice(2, 4), t.slice(4)];
  else return null;
  let a = parseInt(ano, 10);
  if (ano.length === 2) {
    const seculo = Math.floor(new Date().getFullYear() / 100) * 100;
    a = seculo + a > new Date().getFullYear() ? seculo - 100 + a : seculo + a;
  }
  const d = new Date(a, parseInt(mes, 10) - 1, parseInt(dia, 10));
  if (d.getDate() !== parseInt(dia, 10) || d.getMonth() !== parseInt(mes, 10) - 1 || a < 1900) return null;
  return d.getTime();
}

/** "15/03/2020" a partir de um timestamp. */
export function paraDataBR(ts) {
  const d = new Date(ts);
  return `${String(d.getDate()).padStart(2, '0')}/${String(d.getMonth() + 1).padStart(2, '0')}/${d.getFullYear()}`;
}

/** Máscara de data enquanto digita: 15032020 → 15/03/2020. */
export function mascaraData(texto) {
  const d = digitos(texto).slice(0, 8);
  if (d.length <= 2) return d;
  if (d.length <= 4) return `${d.slice(0, 2)}/${d.slice(2)}`;
  return `${d.slice(0, 2)}/${d.slice(2, 4)}/${d.slice(4)}`;
}

/** Nascimento opcional: vazio ou uma data válida que não está no futuro. */
export function nascimentoValido(texto) {
  if (!String(texto || '').trim()) return true;
  const ts = deDataBR(texto);
  return !!ts && ts <= Date.now();
}

/**
 * Próximo aniversário a partir de hoje (hoje conta): { ts, dias, idade }.
 * Quem nasceu em 29/02 comemora em 28/02 nos anos que não são bissextos.
 */
export function proximoAniversario(nascimentoTs, agora = Date.now()) {
  const n = new Date(nascimentoTs);
  const hoje = new Date(inicioDoDia(agora));
  const noAno = (ano) => {
    const ultimo = new Date(ano, n.getMonth() + 1, 0).getDate();
    return new Date(ano, n.getMonth(), Math.min(n.getDate(), ultimo)).getTime();
  };
  let ano = hoje.getFullYear();
  if (noAno(ano) < hoje.getTime()) ano++;
  const ts = noAno(ano);
  return { ts, dias: Math.round((ts - hoje.getTime()) / DIA_MS), idade: ano - n.getFullYear() };
}

/** Aplica "HH:MM" ao dia de `ts`. */
export function comHora(ts, hora) {
  const [h, m] = String(hora || '09:00').split(':').map((x) => parseInt(x, 10));
  const d = new Date(ts);
  d.setHours(Number.isFinite(h) ? h : 9, Number.isFinite(m) ? m : 0, 0, 0);
  return d.getTime();
}

export function debounce(fn, espera = 250) {
  let t;
  return (...args) => {
    clearTimeout(t);
    t = setTimeout(() => fn(...args), espera);
  };
}

/** "12345678000199" → "12.345.678/0001-99". */
export function mascaraCnpj(texto) {
  const d = digitos(texto).slice(0, 14);
  return d
    .replace(/^(\d{2})(\d)/, '$1.$2')
    .replace(/^(\d{2})\.(\d{3})(\d)/, '$1.$2.$3')
    .replace(/\.(\d{3})(\d)/, '.$1/$2')
    .replace(/(\d{4})(\d)/, '$1-$2');
}

/** "45600000" → "45600-000". */
export function mascaraCep(texto) {
  const d = digitos(texto).slice(0, 8);
  return d.length > 5 ? `${d.slice(0, 5)}-${d.slice(5)}` : d;
}

/* ------------------------- Formatos dos campos ------------------------- */
/* Todo campo com data-formato="..." ganha a máscara enquanto digita (digitar)
   e é arrumado ao sair (finalizar). "valido" diz se o que foi digitado faz
   sentido; campo vazio é sempre válido (nada é obrigatório). O app.js liga
   isso para todas as telas e janelas. */

/** "32" / "32,5kg" / "32.5" → "32,5 kg". */
export function formatarPeso(texto) {
  const m = /(\d+(?:[.,]\d+)?)/.exec(String(texto || ''));
  if (!m) return '';
  return `${m[1].replace('.', ',')} kg`;
}

export const FORMATOS = {
  data: { digitar: mascaraData, finalizar: (v) => (deDataBR(v) ? paraDataBR(deDataBR(v)) : v), valido: (v) => !String(v || '').trim() || !!deDataBR(v), modo: 'numeric', dica: 'dd/mm/aaaa' },
  telefone: { digitar: mascaraTelefone, finalizar: mascaraTelefone, valido: telefoneValido, modo: 'tel' },
  cpf: { digitar: mascaraCpf, finalizar: mascaraCpf, valido: cpfValido, modo: 'numeric' },
  email: {
    digitar: (v) => String(v || '').replace(/\s+/g, '').toLowerCase(),
    finalizar: (v) => String(v || '').trim().toLowerCase(),
    valido: emailValido,
    modo: 'email',
  },
  moeda: {
    digitar: (v) => String(v || '').replace(/[^\d.,R$\s]/g, ''),
    finalizar: (v) => (String(v || '').trim() ? fmtBRL(paraCentavos(v)) : ''),
    valido: (v) => !String(v || '').trim() || /\d/.test(v),
    modo: 'decimal',
  },
  peso: {
    digitar: (v) => String(v || '').replace(/[^\d.,kgKG\s]/g, ''),
    finalizar: formatarPeso,
    valido: (v) => !String(v || '').trim() || /\d/.test(v),
    modo: 'decimal',
  },
  duracao: {
    digitar: (v) => String(v || '').replace(/[^\dhmin\s]/gi, ''),
    finalizar: (v) => (paraMinutos(v) ? fmtDur(paraMinutos(v)) : String(v || '').trim()),
    valido: (v) => !String(v || '').trim() || !!paraMinutos(v),
    modo: 'text',
  },
  cnpj: {
    digitar: mascaraCnpj,
    finalizar: mascaraCnpj,
    valido: (v) => !digitos(v) || digitos(v).length === 14,
    modo: 'numeric',
  },
  cep: {
    digitar: mascaraCep,
    finalizar: mascaraCep,
    valido: (v) => !digitos(v) || digitos(v).length === 8,
    modo: 'numeric',
  },
  uf: {
    digitar: (v) => String(v || '').replace(/[^a-zA-Z]/g, '').toUpperCase().slice(0, 2),
    finalizar: (v) => String(v || '').replace(/[^a-zA-Z]/g, '').toUpperCase().slice(0, 2),
    valido: (v) => !String(v || '').trim() || String(v).trim().length === 2,
    modo: 'text',
  },
  inteiro: { digitar: (v) => digitos(v).slice(0, 3), finalizar: (v) => digitos(v), valido: () => true, modo: 'numeric' },
};

/* -------------------- Atualizar a tela sem recriar o campo -------------------- */
/* Redesenhar trocando todo o HTML recria também o campo em que a pessoa está
   digitando. No Android, se isso acontece no meio da "composição" do teclado,
   a letra é reenviada ao campo novo e aparece repetida ("a" vira "aaa").
   morfar() atualiza a tela comparando nó a nó e só troca o que mudou: o campo
   em uso continua o mesmo, com foco, cursor e o que o teclado está compondo. */

function mesmoNo(a, b) {
  if (a.nodeType !== b.nodeType) return false;
  if (a.nodeType !== 1) return true;
  if (a.tagName !== b.tagName) return false;
  if ((a.getAttribute('data-campo') || '') !== (b.getAttribute('data-campo') || '')) return false;
  if (a.tagName === 'INPUT' && (a.getAttribute('type') || 'text') !== (b.getAttribute('type') || 'text')) return false;
  return true;
}

function morfarElemento(velho, novo) {
  for (const { name } of [...velho.attributes]) if (!novo.hasAttribute(name)) velho.removeAttribute(name);
  for (const { name, value } of [...novo.attributes]) if (velho.getAttribute(name) !== value) velho.setAttribute(name, value);
  const editavel = velho.tagName === 'INPUT' || velho.tagName === 'TEXTAREA' || velho.tagName === 'SELECT';
  const emUso = velho === document.activeElement;
  // campo em uso: não é tocado enquanto a pessoa digita. Só muda quando o próprio app
  // limpou o campo (ex.: depois do Enter) ou preencheu um campo vazio (ex.: rua pelo CEP).
  const trocar = !emUso || (novo.value === '') !== (velho.value === '');
  if (velho.tagName === 'TEXTAREA') {
    if (velho.defaultValue !== novo.value) velho.defaultValue = novo.value;
    if (trocar && velho.value !== novo.value) velho.value = novo.value;
    return;
  }
  morfarFilhos(velho, novo);
  if (editavel) {
    if (velho.type === 'checkbox' || velho.type === 'radio') velho.checked = novo.hasAttribute('checked');
    else if (trocar && velho.value !== novo.value) velho.value = novo.value;
  }
}

function morfarFilhos(velho, novo) {
  const antigos = [...velho.childNodes];
  const novos = [...novo.childNodes];
  novos.forEach((n, i) => {
    const v = antigos[i];
    if (!v) velho.appendChild(n);
    else if (!mesmoNo(v, n)) velho.replaceChild(n, v);
    else if (v.nodeType === 1) morfarElemento(v, n);
    else if (v.nodeValue !== n.nodeValue) v.nodeValue = n.nodeValue;
  });
  for (let i = novos.length; i < antigos.length; i++) antigos[i].remove();
}

/** Coloca `html` dentro de `alvo` reaproveitando os nós que não mudaram. */
export function morfar(alvo, html) {
  const molde = alvo.cloneNode(false);
  molde.innerHTML = html;
  morfarFilhos(alvo, molde);
}

/** Há um campo de texto em uso dentro de `area`? */
export const digitandoEm = (area) => {
  const f = document.activeElement;
  return !!f && area.contains(f) && (f.tagName === 'INPUT' || f.tagName === 'TEXTAREA');
};
