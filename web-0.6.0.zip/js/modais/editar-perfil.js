import { html, icon, mascaraTelefone, telefoneValido, emailValido } from '../core/dom.js';
import { campo } from '../core/ui.js';
import * as config from '../data/config.js';

/* Dados do groomer que aparecem nos lembretes enviados aos tutores. */

const CAMPOS = [
  { nome: 'nome', rotulo: 'Nome' },
  { nome: 'funcao', rotulo: 'Função' },
  { nome: 'email', rotulo: 'E-mail', tipo: 'email', formato: 'email' },
  { nome: 'telefone', rotulo: 'Telefone', tipo: 'tel', formato: 'telefone' },
];

const modal = {
  render: (e) => html`<div class="modal-fundo">
    <div class="modal m-560">
      <div class="modal-cab">
        <div>
          <div class="modal-titulo">Editar perfil</div>
          <div class="modal-sub">Seus dados aparecem nos lembretes enviados aos tutores.</div>
        </div>
        <button class="modal-fechar" data-acao="fechar-modal" aria-label="Fechar">${icon('x', 16)}</button>
      </div>
      <div class="grade-2" style="margin-top:18px">${CAMPOS.map((c) => campo({ ...c, valor: e[c.nome] }))}</div>
      <div class="modal-rodape">
        <button class="btn btn-branco" data-acao="fechar-modal">Cancelar</button>
        <button class="btn btn-roxo" style="padding:11px 20px" data-acao="salvar">Salvar alterações</button>
      </div>
    </div>
  </div>`,

  aoDigitar: (nome, valor, { estado, el }) => {
    if (nome !== 'telefone') return;
    estado.telefone = mascaraTelefone(valor);
    if (el && el.value !== estado.telefone) el.value = estado.telefone;
  },

  acoes: {
    salvar: async (_, { estado, fechar, ctx }) => {
      const dados = Object.fromEntries(CAMPOS.map((c) => [c.nome, String(estado[c.nome] || '').trim()]));
      if (!telefoneValido(dados.telefone)) return ctx.toast('Telefone incompleto: use DDD + número', { erro: true });
      if (!emailValido(dados.email)) return ctx.toast('E-mail inválido: confira o endereço', { erro: true });
      await config.atualizar('perfil', dados);
      ctx.toast('Perfil atualizado');
      fechar(true);
    },
  },
};

export const editarPerfil = (ctx, perfil) => ctx.abrirModal(modal, { ...perfil });
