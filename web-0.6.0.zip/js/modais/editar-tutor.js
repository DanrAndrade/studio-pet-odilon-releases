import { html, icon, mascaraTelefone, mascaraCpf, telefoneValido } from '../core/dom.js';
import { validarTutor } from '../screens/cadastro.js';
import { campo, chip } from '../core/ui.js';
import { CAMPOS_ENDERECO, camposDe, temEnderecoSeparado, temEnderecoAntigo, buscarCep, aplicarCep } from '../logic/endereco.js';
import { tutores } from '../data/repo.js';

/* Editar dados do tutor (e excluir, com confirmação no próprio modal). */

const ORIGENS = ['Indicação', 'Instagram', 'Passou na porta', 'Google'];

const modal = {
  render: (e) =>
    e.confirmando
      ? html`<div class="modal-fundo"><div class="modal m-400">
          <div style="width:40px;height:40px;border-radius:14px;background:var(--rosa-fundo);display:flex;align-items:center;justify-content:center;color:var(--rosa)">${icon('triangle-alert', 19)}</div>
          <div style="font-size:16px;font-weight:600;color:var(--tinta-2);margin-top:13px">Excluir ${e.nome || 'este tutor'}?</div>
          <div style="font-size:13px;color:var(--texto-3);margin-top:6px;line-height:1.5">O tutor e os pets dele vão para a lixeira por 30 dias e podem ser restaurados juntos.</div>
          <div style="display:flex;gap:9px;margin-top:18px">
            <button class="btn btn-branco" style="flex:1" data-acao="desistir">Cancelar</button>
            <button class="btn btn-rosa" style="flex:1" data-acao="excluir">Mover para lixeira</button>
          </div>
        </div></div>`
      : html`<div class="modal-fundo">
          <div class="modal m-560">
            <div class="modal-cab">
              <div>
                <div class="modal-titulo">Editar tutor</div>
                <div class="modal-sub">O telefone é usado nos lembretes por WhatsApp.</div>
              </div>
              <button class="modal-fechar" data-acao="fechar-modal" aria-label="Fechar">${icon('x', 16)}</button>
            </div>
            <div class="grade-2 mt-16">
              ${campo({ rotulo: 'Nome', nome: 'nome', valor: e.nome })}
              ${campo({ rotulo: 'Telefone / WhatsApp', nome: 'telefone', valor: e.telefone, tipo: 'tel', formato: 'telefone' })}
              ${campo({ rotulo: 'Segundo responsável (opcional)', nome: 'nome2', valor: e.nome2, placeholder: 'Ex.: João Alves' })}
              ${campo({ rotulo: 'Telefone 2 (opcional)', nome: 'telefone2', valor: e.telefone2, placeholder: '(73) 90000-0000', tipo: 'tel', formato: 'telefone' })}
              ${campo({ rotulo: 'CPF', nome: 'cpf', valor: e.cpf, placeholder: 'opcional', formato: 'cpf' })}
              ${campo({ rotulo: 'E-mail', nome: 'email', valor: e.email, placeholder: 'opcional', tipo: 'email', formato: 'email' })}
            </div>
            <div class="rotulo-campo" style="margin:14px 0 7px">Endereço</div>
            ${e.enderecoAntigo
              ? html`<div class="aviso-ambar r16" style="margin-bottom:10px;padding:11px 13px">
                  <div class="aviso-titulo" style="font-size:12.5px">${icon('triangle-alert', 15)}<span>Endereço no formato antigo</span></div>
                  <div class="aviso-texto" style="font-size:12.5px;margin-top:4px">Estava tudo numa linha só: <strong>${e.enderecoAntigo}</strong>. Escreva de novo nos campos abaixo; ao salvar, o texto antigo sai.</div>
                </div>`
              : ''}
            <div class="grade-endereco">
              ${CAMPOS_ENDERECO.map((c) => campo({ ...c, valor: e[c.nome] }))}
            </div>
            <div class="rotulo-campo" style="margin:14px 0 7px">Como conheceu a loja</div>
            <div class="chips">${ORIGENS.map((o) => chip(o, e.origem === o, 'origem', { valor: o }, { suave: true, cls: 'forte' }))}</div>
            <div class="mt-14">
              <div class="rotulo-campo">Observações</div>
              <textarea class="entrada" data-campo="observacoes" style="height:84px;min-height:84px" placeholder="Ex.: prefere ser avisada de manhã">${e.observacoes || ''}</textarea>
            </div>
            <div class="modal-rodape separado">
              <button class="link-perigo" data-acao="confirmar-exclusao">${icon('trash-2', 14)}<span>Excluir tutor</span></button>
              <div style="display:flex;gap:9px">
                <button class="btn btn-branco" data-acao="fechar-modal">Cancelar</button>
                <button class="btn btn-roxo" style="font-size:13px" data-acao="salvar">Salvar alterações</button>
              </div>
            </div>
          </div>
        </div>`,

  aoDigitar: async (campo, valor, { estado, el, atualizar }) => {
    const mascara = campo === 'telefone' || campo === 'telefone2' ? mascaraTelefone : campo === 'cpf' ? mascaraCpf : null;
    if (mascara) {
      estado[campo] = mascara(valor);
      if (el && el.value !== estado[campo]) el.value = estado[campo];
      return;
    }
    if (campo !== 'cep') return;
    // CEP completo: busca o endereço e preenche o que está em branco
    const digitos8 = String(valor || '').replace(/\D/g, '');
    if (digitos8.length !== 8 || estado.cepBuscado === digitos8) return;
    estado.cepBuscado = digitos8;
    const mudou = aplicarCep(await buscarCep(digitos8), estado);
    if (Object.keys(mudou).length && String(estado.cep || '').replace(/\D/g, '') === digitos8) atualizar(mudou);
  },

  acoes: {
    origem: ({ valor }, { atualizar }) => atualizar({ origem: valor }),
    'confirmar-exclusao': (_, { atualizar }) => atualizar({ confirmando: true }),
    desistir: (_, { atualizar }) => atualizar({ confirmando: false }),
    excluir: async (_, { estado, fechar, ctx }) => {
      await tutores.excluir(estado.id);
      fechar('excluido');
      ctx.toast('Tutor movido para a lixeira');
    },
    salvar: async (_, { estado, fechar, ctx }) => {
      const { confirmando, ...dados } = estado;
      const problema = validarTutor(dados.telefone, dados.cpf, dados.email);
      if (problema) return ctx.toast(problema, { erro: true });
      if (!telefoneValido(dados.telefone2)) return ctx.toast('Telefone 2 incompleto: use DDD + número, ex.: (73) 99811-2030', { erro: true });
      const { enderecoAntigo, cepBuscado, ...limpos } = dados;
      await tutores.salvar({
        ...limpos,
        nome: (dados.nome || '').trim(),
        telefone: (dados.telefone || '').trim(),
        nome2: (dados.nome2 || '').trim(),
        telefone2: (dados.telefone2 || '').trim(),
        email: (dados.email || '').trim(),
        cpf: (dados.cpf || '').trim(),
        ...camposDe(dados),
        // o texto antigo sai quando o endereço é preenchido nos campos novos
        endereco: temEnderecoSeparado(dados) ? '' : (dados.endereco || '').trim(),
        observacoes: (dados.observacoes || '').trim(),
      });
      fechar('salvo');
      ctx.toast('Dados do tutor atualizados');
    },
  },
};

export const editarTutor = (ctx, tutor) =>
  ctx.abrirModal(modal, {
    ...tutor,
    ...camposDe(tutor),
    // cadastro antigo: o texto vira uma dica para ele preencher os campos separados
    enderecoAntigo: temEnderecoAntigo(tutor) ? tutor.endereco.trim() : '',
    confirmando: false,
  });
