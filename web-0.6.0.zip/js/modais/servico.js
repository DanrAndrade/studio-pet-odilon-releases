import { html, icon, paraCentavos, paraMinutos, centavosParaCampo, fmtDur } from '../core/dom.js';
import { chip, toggle, CORES_TRACO } from '../core/ui.js';
import { servicos, PORTES } from '../data/repo.js';
import * as config from '../data/config.js';

/* Cadastro/edição de serviço do catálogo, com preço por porte. */

const entrada = (rotulo, nome, valor, placeholder, extra = '') => html`<div>
  <div class="rotulo-campo" style="font-weight:500;font-size:11.5px;margin-bottom:5px">${rotulo}</div>
  <input class="entrada ${extra}" data-campo="${nome}" value="${valor || ''}" placeholder="${placeholder}" inputmode="decimal" data-formato="moeda">
</div>`;

const modal = {
  render: (e) => html`<div class="modal-fundo">
    <div class="modal m-640">
      <div class="modal-cab">
        <div>
          <div class="modal-titulo m">${e.servico ? 'Editar serviço' : 'Novo serviço'}</div>
          <div class="modal-sub">Preço e duração são referências — o tempo real vem do cronômetro.</div>
        </div>
        <button class="modal-fechar" data-acao="fechar-modal" aria-label="Fechar">${icon('x', 16)}</button>
      </div>

      <div class="grade-2" style="grid-template-columns:1.4fr 1fr;margin-top:18px">
        <div>
          <div class="rotulo-campo" style="font-weight:500">Nome do serviço</div>
          <input class="entrada" data-campo="nome" value="${e.nome}" placeholder="Ex.: Banho medicamentoso">
        </div>
        <div>
          <div class="rotulo-campo" style="font-weight:500">Duração de referência</div>
          <input class="entrada" data-campo="dur" value="${e.dur}" placeholder="30min" data-formato="duracao">
        </div>
      </div>

      <div class="rotulo-campo" style="font-weight:500;margin:16px 0 7px">Categoria</div>
      <div class="chips">${e.categorias.map((c) => chip(c, e.categoria === c, 'categoria', { valor: c }, { suave: true }))}</div>

      <div class="rotulo-campo" style="font-weight:500;margin:16px 0 7px">Preço por porte</div>
      <div class="grade-4 servico-precos">
        ${entrada('Padrão', 'preco', e.preco, 'R$ 70', 'destaque')}
        ${PORTES.map((porte, i) => entrada(porte, `porte${i}`, e[`porte${i}`], 'igual ao padrão'))}
      </div>
      <div class="mutado" style="font-size:12px;margin-top:8px">Porte sem preço usa o padrão.</div>

      <div class="modal-rodape separado">
        <div style="display:flex;align-items:center;gap:11px">
          ${toggle(e.ativo, 'ativo')}
          <span style="font-size:13px;color:var(--texto-2);font-weight:500">Serviço ativo no agendamento</span>
        </div>
        <div style="display:flex;gap:9px">
          <button class="btn btn-branco" data-acao="fechar-modal">Cancelar</button>
          <button class="btn btn-roxo" style="padding:11px 22px" data-acao="salvar">Salvar serviço</button>
        </div>
      </div>
    </div>
  </div>`,

  acoes: {
    categoria: ({ valor }, { atualizar }) => atualizar({ categoria: valor }),
    ativo: (_, { estado, atualizar }) => atualizar({ ativo: !estado.ativo }),
    salvar: async (_, { estado: e, fechar, ctx }) => {
      const nome = (e.nome || '').trim();
      if (!nome) return ctx.toast('Dê um nome ao serviço', { erro: true });
      const base = e.servico || {};
      const cor = base.cor || CORES_TRACO[(await servicos.listar()).length % CORES_TRACO.length];
      await servicos.salvar({
        ...base,
        nome,
        categoria: e.categoria || e.categorias[0] || 'Banho',
        duracaoPadraoMin: paraMinutos(e.dur) || 30,
        precoCentavos: paraCentavos(e.preco),
        precoPorPorte: Object.fromEntries(PORTES.map((porte, i) => [porte, paraCentavos(e[`porte${i}`])])),
        ativo: e.ativo,
        cor,
      });
      ctx.toast(e.servico ? 'Serviço atualizado' : `${nome} adicionado ao catálogo`);
      fechar(true);
    },
  },
};

export async function editarServico(ctx, servico) {
  const categorias = await config.lista('Categorias de serviço');
  if (servico?.categoria && !categorias.includes(servico.categoria)) categorias.push(servico.categoria);
  const porte = servico?.precoPorPorte || {};
  return ctx.abrirModal(modal, {
    servico,
    categorias,
    nome: servico?.nome || '',
    dur: servico ? fmtDur(servico.duracaoPadraoMin) : '',
    categoria: servico?.categoria || categorias[0] || '',
    preco: centavosParaCampo(servico?.precoCentavos),
    ...Object.fromEntries(PORTES.map((nome, i) => [`porte${i}`, centavosParaCampo(porte[nome])])),
    ativo: servico ? servico.ativo !== false : true,
  });
}
