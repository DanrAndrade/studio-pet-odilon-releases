import { html, icon, mascaraTelefone, telefoneValido } from '../core/dom.js';
import { campo } from '../core/ui.js';
import * as config from '../data/config.js';

/* Dados da loja: aparecem nos lembretes e definem o expediente da agenda. */

const CAMPOS = [
  { nome: 'nome', rotulo: 'Nome da loja', placeholder: 'Studio Pet Odilon Groomer' },
  { nome: 'endereco', rotulo: 'Endereço', placeholder: 'Rua, número · bairro' },
  { nome: 'expediente', rotulo: 'Expediente', placeholder: 'Seg a sáb · 08:00 às 18:00' },
  { nome: 'cnpj', rotulo: 'CNPJ', placeholder: 'opcional', formato: 'cnpj' },
  { nome: 'telefone', rotulo: 'Telefone da loja', placeholder: '(73) 90000-0000', tipo: 'tel', formato: 'telefone' },
];

const modal = {
  render: (e) => {
    const exp = config.lerExpediente(e.expediente);
    const hora = (m) => `${String(Math.floor(m / 60)).padStart(2, '0')}:${String(m % 60).padStart(2, '0')}`;
    return html`<div class="modal-fundo">
      <div class="modal m-620">
        <div class="modal-cab">
          <div>
            <div class="modal-titulo">Editar dados da loja</div>
            <div class="modal-sub">Aparecem nos lembretes e no cabeçalho dos relatórios.</div>
          </div>
          <button class="modal-fechar" data-acao="fechar-modal" aria-label="Fechar">${icon('x', 16)}</button>
        </div>
        <div class="grade-2" style="margin-top:18px">
          ${CAMPOS.map((c) => campo({ ...c, valor: e[c.nome] }))}
        </div>
        <div class="mutado" id="expediente-lido" style="font-size:12px;margin-top:10px">A agenda vai entender: ${exp.dias.length === 7 ? 'todos os dias' : exp.dias.length === 5 ? 'segunda a sexta' : 'segunda a sábado'}, das ${hora(exp.abre)} às ${hora(exp.fecha)}.</div>
        <div class="modal-rodape">
          <button class="btn btn-branco" data-acao="fechar-modal">Cancelar</button>
          <button class="btn btn-roxo" style="padding:11px 20px" data-acao="salvar">Salvar alterações</button>
        </div>
      </div>
    </div>`;
  },

  aoDigitar: (nome, valor, { estado, atualizar, el }) => {
    if (nome === 'expediente') atualizar({});
    if (nome === 'telefone') {
      estado.telefone = mascaraTelefone(valor);
      if (el && el.value !== estado.telefone) el.value = estado.telefone;
    }
  },

  acoes: {
    salvar: async (_, { estado, fechar, ctx }) => {
      const dados = Object.fromEntries(CAMPOS.map((c) => [c.nome, String(estado[c.nome] || '').trim()]));
      if (!dados.nome) return ctx.toast('A loja precisa de um nome', { erro: true });
      if (!telefoneValido(dados.telefone)) return ctx.toast('Telefone incompleto: use DDD + número', { erro: true });
      await config.atualizar('loja', dados);
      ctx.toast('Dados da loja atualizados');
      fechar(true);
    },
  },
};

export const editarLoja = (ctx, loja) => ctx.abrirModal(modal, { ...loja });
