import { html, icon } from '../core/dom.js';
import { contatosDoTutor } from '../logic/contatos.js';

/* Qual dos responsáveis? Aparece só quando o tutor tem dois telefones. */

const modal = {
  render: (e) => html`<div class="modal-fundo">
    <div class="modal m-430">
      <div class="modal-cab">
        <div>
          <div class="modal-titulo m">${e.titulo}</div>
          <div class="modal-sub">Este cliente tem dois responsáveis.</div>
        </div>
        <button class="modal-fechar" data-acao="fechar-modal" aria-label="Fechar">${icon('x', 16)}</button>
      </div>
      <div style="display:flex;flex-direction:column;gap:9px">
        ${e.contatos.map(
          (c, i) => html`<button class="contato-op" data-acao="escolher" data-i="${i}">
            <span class="contato-op-icone">${icon('user-round', 16)}</span>
            <span style="flex:1;min-width:0;text-align:left">
              <span class="contato-op-nome">${c.rotulo}</span>
              <span class="contato-op-fone">${c.telefone}</span>
            </span>
            <span style="color:var(--texto-5);display:flex">${icon('chevron-right', 16)}</span>
          </button>`
        )}
      </div>
    </div>
  </div>`,

  acoes: {
    escolher: ({ i }, { estado, fechar }) => fechar(estado.contatos[Number(i)]),
  },
};

/**
 * Devolve o contato escolhido ({ nome, telefone, rotulo }), ou null se cancelar.
 * Com um telefone só, devolve direto sem abrir nada; sem telefone, devolve null.
 */
export async function escolherContato(ctx, tutor, { titulo = 'Ligar para quem?' } = {}) {
  const contatos = contatosDoTutor(tutor);
  if (contatos.length <= 1) return contatos[0] || null;
  return ctx.abrirModal(modal, { titulo, contatos });
}
