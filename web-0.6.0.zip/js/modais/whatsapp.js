import { html, icon, fmtHora, fmtDataCurta, mesmoDia, addDias, DIAS_LONGOS } from '../core/dom.js';
import { chip } from '../core/ui.js';
import { whatsapp, copiar, numeroWhatsapp, dddDe } from '../core/nativo.js';
import { agendamentos } from '../data/repo.js';
import * as config from '../data/config.js';
import { contatosDoTutor } from '../logic/contatos.js';

/* Lembrete por WhatsApp: modelo pronto, editável, abre a conversa no app. */

export const MODELOS = ['Lembrete de agendamento', 'Pet pronto', 'Pet pronto (curto)', 'Retorno atrasado', 'Aniversário', 'Mensagem livre'];

const primeiroNome = (nome) => String(nome || '').trim().split(/\s+/)[0] || '';

/** "bom dia" / "boa tarde" / "boa noite" pela hora do envio. */
function saudacao(agora = new Date()) {
  const h = agora.getHours();
  return h < 12 ? 'bom dia' : h < 18 ? 'boa tarde' : 'boa noite';
}
const maiusculas = (texto) => texto.replace(/(^|\s)(\S)/g, (_, esp, letra) => esp + letra.toUpperCase());

/** Hora do jeito do Odilon: 15h, 15h30. */
function horaCurta(ts) {
  const d = new Date(ts);
  const m = d.getMinutes();
  return `${d.getHours()}h${m ? String(m).padStart(2, '0') : ''}`;
}

/* Os textos seguem as mensagens que o Odilon já usa no WhatsApp da loja. */
export function montarMensagem(modelo, { tutor, pet, ag, itens = [], loja = 'Studio Pet', aniversarioTs = null }) {
  const nome = primeiroNome(tutor?.nome);
  const femea = pet?.sexo === 'Fêmea';
  const o = femea ? 'a' : 'o';
  const art = femea ? 'da' : 'do';
  const petNome = pet?.nome || 'seu pet';
  const periodo = saudacao();
  // "Olá, Jeniffer" + "Bom Dia!" na linha de baixo: a abertura das mensagens mais formais dele
  const abertura = `${nome ? `Olá, ${nome}` : 'Olá!'}
${maiusculas(periodo)}!`;

  switch (modelo) {
    case 'Lembrete de agendamento': {
      if (!ag) return `Olá, ${periodo}!

Passando para lembrar do horário ${art} ${petNome}.

Por gentileza, confirme o comparecimento.`;
      const hoje = Date.now();
      const quando = mesmoDia(ag.inicio, hoje)
        ? 'hoje'
        : mesmoDia(ag.inicio, addDias(hoje, 1))
          ? 'amanhã'
          : `${DIAS_LONGOS[new Date(ag.inicio).getDay()].toLowerCase()}, ${fmtDataCurta(ag.inicio)}`;
      return `Olá, ${periodo}!

Passando para lembrar que o horário ${art} ${petNome} que está agendado para ${quando}, às ${horaCurta(ag.inicio)}.

Por gentileza, confirme o comparecimento.`;
    }
    case 'Pet pronto':
      return `${abertura}

Gostaria de informar que ${o} ${petNome} está ${femea ? 'pronta' : 'pronto'} 💜🐶

Agradecemos pela confiança!`;
    case 'Pet pronto (curto)':
      return `${nome ? `Oi ${nome}!` : 'Oi!'} ${femea ? 'A' : 'O'} ${petNome} já está ${femea ? 'prontinha' : 'prontinho'} e esperando por você aqui no ${loja}. 🐾`;
    case 'Retorno atrasado':
      return `${abertura}

Já faz um tempinho desde o último banho ${art} ${petNome} 🐶

Vamos agendar o próximo horário? 💜`;
    case 'Aniversário': {
      const hoje = !aniversarioTs || mesmoDia(aniversarioTs, Date.now());
      const frase = hoje ? `Hoje é aniversário ${art} ${petNome}! 🎉🐶` : `Parabéns pelo aniversário ${art} ${petNome}! 🎉🐶`;
      return `${abertura}

${frase}

Toda a equipe do ${loja} deseja muitos petiscos e carinho. 💜`;
    }
    default:
      return `${abertura}

`;
  }
}

const modal = {
  render: (e) => html`<div class="modal-fundo">
    <div class="modal">
      <div class="modal-cab">
        <div>
          <div class="modal-titulo m">${e.modelo === 'Lembrete de agendamento' ? 'Lembrete por WhatsApp' : 'Mensagem por WhatsApp'}</div>
          <div class="modal-sub">${[e.tutor?.nome, e.telefone].filter(Boolean).join(' · ') || 'Tutor sem telefone cadastrado'}</div>
        </div>
        <button class="modal-fechar" data-acao="fechar-modal" aria-label="Fechar">${icon('x', 16)}</button>
      </div>

      ${e.contatos.length > 1
        ? html`<div style="font-size:12px;color:var(--texto-3);font-weight:500;margin:16px 0 7px">Enviar para</div>
            <div class="chips">${e.contatos.map((c, i) => chip(c.rotulo, e.contato === i, 'contato', { i }, { suave: true, sub: c.telefone }))}</div>`
        : ''}
      <div style="font-size:12px;color:var(--texto-3);font-weight:500;margin:16px 0 7px">Modelo de mensagem</div>
      <div class="chips">${MODELOS.map((m) => chip(m, e.modelo === m, 'modelo', { modelo: m }, { suave: true }))}</div>

      <textarea class="caixa-texto" data-campo="texto" style="margin-top:14px;padding:14px;font-size:13.5px;line-height:1.55;min-height:190px;border-radius:14px" placeholder="Escreva a mensagem…">${e.texto}</textarea>

      ${e.numero
        ? ''
        : html`<div class="aviso-ambar r16" style="margin-top:12px;padding:11px 13px"><div class="aviso-titulo" style="font-size:12.5px">${icon('triangle-alert', 15)}${
            e.telefone
              ? 'Telefone incompleto: confira o DDD na ficha do tutor (ou cadastre o telefone da loja no Perfil).'
              : 'Cadastre um telefone na ficha do tutor para abrir a conversa.'
          }</div></div>`}

      <div style="display:flex;gap:9px;margin-top:16px;flex-wrap:wrap">
        <button class="btn btn-verde" style="flex:1;min-width:180px" data-acao="abrir" ${e.numero ? '' : 'disabled'}>Abrir no WhatsApp</button>
        <button class="btn btn-branco" data-acao="copiar">Copiar</button>
        <button class="btn btn-branco" data-acao="avisado">Marcar como avisado</button>
      </div>
    </div>
  </div>`,

  acoes: {
    modelo: ({ modelo }, { estado, atualizar }) => atualizar({ modelo, texto: montarMensagem(modelo, estado) }),
    // outro responsável: troca o número e o nome da saudação
    contato: ({ i }, { estado, atualizar }) => {
      const c = estado.contatos[Number(i)];
      const tutor = { ...estado.tutorCadastro, nome: c.nome || estado.tutorCadastro?.nome };
      atualizar({ contato: Number(i), telefone: c.telefone, numero: numeroWhatsapp(c.telefone, estado.ddd), tutor, texto: montarMensagem(estado.modelo, { ...estado, tutor }) });
    },
    abrir: async (_, { estado, fechar, ctx }) => {
      if (!estado.numero) return;
      whatsapp(estado.telefone, estado.texto, estado.ddd);
      await marcarAvisado(estado);
      fechar(true);
      ctx.toast?.('Conversa aberta no WhatsApp');
    },
    copiar: async (_, { estado, ctx }) => {
      const ok = await copiar(estado.texto);
      ctx.toast?.(ok ? 'Mensagem copiada' : 'Não foi possível copiar', { erro: !ok });
    },
    avisado: async (_, { estado, fechar, ctx }) => {
      await marcarAvisado(estado);
      fechar(true);
      ctx.toast?.('Marcado como avisado');
    },
  },
};

async function marcarAvisado({ ag }) {
  if (!ag) return;
  const atual = await agendamentos.obter(ag.id);
  if (atual) await agendamentos.salvar({ ...atual, lembreteEnviadoEm: Date.now() });
}

/** Abre o modal. `ag` e `itens` são opcionais (usados pelo lembrete). */
export async function abrirWhatsapp(ctx, { tutor, pet, ag = null, itens = null, modelo = 'Lembrete de agendamento', aniversarioTs = null }) {
  const dadosLoja = await config.obter('loja');
  const loja = dadosLoja.nome || 'Studio Pet';
  // telefone sem DDD usa o DDD da loja
  const ddd = dddDe(dadosLoja.telefone);
  const listaItens = itens || (ag ? await agendamentos.itens(ag.id) : []);
  // com dois responsáveis, começa pelo primeiro e o modal deixa trocar
  const contatos = contatosDoTutor(tutor);
  const primeiro = contatos[0] || null;
  const telefone = primeiro?.telefone || tutor?.telefone || '';
  const tutorMensagem = primeiro?.nome ? { ...tutor, nome: primeiro.nome } : tutor;
  const base = { tutor: tutorMensagem, pet, ag, itens: listaItens, loja, modelo, aniversarioTs };
  return ctx.abrirModal(modal, {
    ...base,
    tutorCadastro: tutor,
    contatos,
    contato: 0,
    telefone,
    ddd,
    numero: numeroWhatsapp(telefone, ddd),
    texto: montarMensagem(modelo, base),
  });
}
