import { html, icon, fmtBRL, valorData, deCampos, mesmoDia, fmtHora } from '../core/dom.js';
import { chip } from '../core/ui.js';
import * as config from '../data/config.js';

/* Registrar um recebimento: pergunta a forma realmente usada e o dia em que foi
   pago (padrão: hoje). O faturamento do mês conta pela data do pagamento, então
   um pagamento marcado depois pode ser lançado no dia certo. */

const FORMAS_RESERVA = ['Dinheiro', 'PIX', 'Débito', 'Crédito', 'Boleto'];

const modal = {
  render: (e) => html`<div class="modal-fundo">
    <div class="modal m-430">
      <div class="modal-cab">
        <div>
          <div class="modal-titulo m">${e.titulo}</div>
          <div class="modal-sub">${e.sub}</div>
        </div>
        <button class="modal-fechar" data-acao="fechar-modal" aria-label="Fechar">${icon('x', 16)}</button>
      </div>
      <div>
        <div class="rotulo-campo" style="margin-bottom:8px">Como foi pago?</div>
        <div class="chips">${e.formas.map((f) => chip(f, e.forma === f, 'forma', { forma: f }, { suave: true, cls: 'forte' }))}</div>
        <div class="rotulo-campo" style="margin:14px 0 7px">Dia do pagamento</div>
        <input class="entrada campo-data" type="date" data-campo="data" value="${e.data}" max="${e.hoje}">
      </div>
      <div class="modal-rodape" style="margin-top:6px">
        <button class="btn btn-branco" data-acao="fechar-modal">Cancelar</button>
        <button class="btn btn-roxo" data-acao="ok" ${e.forma ? '' : 'disabled'}>Registrar recebimento</button>
      </div>
    </div>
  </div>`,

  acoes: {
    forma: ({ forma }, { atualizar }) => atualizar({ forma }),
    ok: (_, { estado, fechar }) => {
      if (!estado.forma) return;
      // hoje: a hora de agora; outro dia: meio-dia (só o dia importa para o relatório)
      const agora = Date.now();
      const dia = deCampos(estado.data, '12:00');
      const quando = !dia || mesmoDia(dia, agora) || dia > agora ? agora : dia;
      fechar({ forma: estado.forma, quando });
    },
  },
};

/** Abre o modal e devolve { forma, quando } (ou null se cancelar). */
export async function escolherFormaRecebimento(ctx, { titulo = 'Registrar recebimento', valorCentavos = 0, detalhe = '' } = {}) {
  const configuradas = (await config.lista('Formas de pagamento')).filter((f) => f !== 'Incluso no plano' && f !== 'Fiado');
  const hoje = valorData(Date.now());
  return ctx.abrirModal(modal, {
    titulo,
    sub: [fmtBRL(valorCentavos), detalhe].filter(Boolean).join(' · '),
    formas: configuradas.length ? configuradas : FORMAS_RESERVA,
    forma: null,
    data: hoje,
    hoje,
  });
}

/** Texto curto do recebimento para o aviso: "PIX" ou "PIX · pago em 12/10". */
export const descreverRecebimento = (r) => (mesmoDia(r.quando, Date.now()) ? r.forma : `${r.forma} · pago em ${new Date(r.quando).toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit' })}`);
