import { html, icon, paraCentavos, paraMinutos } from '../core/dom.js';
import { campo } from '../core/ui.js';

/* Serviço fora do catálogo, só para este agendamento. */

const modal = {
  render: (e) => html`<div class="modal-fundo">
    <div class="modal">
      <div class="modal-cab">
        <div>
          <div class="modal-titulo m">Serviço não catalogado</div>
          <div class="modal-sub">Vale só para este agendamento. Para usar sempre, cadastre em Serviços.</div>
        </div>
        <button class="modal-fechar" data-acao="fechar-modal" aria-label="Fechar">${icon('x', 16)}</button>
      </div>
      <div class="grade-2 mt-16" style="grid-template-columns:1.4fr 1fr">
        ${campo({ rotulo: 'Nome do serviço', nome: 'nome', valor: e.nome, placeholder: 'Ex.: Remoção de nós' })}
        ${campo({ rotulo: 'Preço', nome: 'preco', valor: e.preco, placeholder: 'R$ 30', formato: 'moeda' })}
      </div>
      <div class="mt-12" style="max-width:220px">
        ${campo({ rotulo: 'Duração estimada', nome: 'duracao', valor: e.duracao, placeholder: '30min', formato: 'duracao' })}
      </div>
      <div class="modal-rodape">
        <button class="btn btn-branco" data-acao="fechar-modal">Cancelar</button>
        <button class="btn btn-roxo" data-acao="adicionar" style="font-size:13px">Adicionar</button>
      </div>
    </div>
  </div>`,

  acoes: {
    adicionar: (_, { estado, fechar, ctx }) => {
      const nome = (estado.nome || '').trim();
      if (!nome) return ctx.toast('Dê um nome ao serviço', { erro: true });
      fechar({
        nome,
        precoCentavos: paraCentavos(estado.preco),
        duracaoPrevistaMin: paraMinutos(estado.duracao) || 30,
      });
    },
  },
};

export const servicoAvulso = (ctx) => ctx.abrirModal(modal, { nome: '', preco: '', duracao: '' });
