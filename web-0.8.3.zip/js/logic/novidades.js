/* O que mudou em cada versão, em poucas palavras: aparece no sino por 10 dias depois
   que a atualização entra, para o Odilon saber que ela chegou e o que mudou. */

export const NOVIDADES = {
  '0.8.3': [
    '"Pagou com mais de uma forma" agora é um botão de verdade (borda roxa e ícone), na tela de finalizar e na janela de receber pagamento. O "Desfazer o pagamento adiantado" também.',
  ],
  '0.8.2': [
    'O botão "Receber adiantado" ficou roxo e passou para logo abaixo do Total, mais fácil de ver. Quando o banho já foi pago adiantado, aparece uma caixa verde "Pago adiantado".',
  ],
  '0.8.1': [
    'Cliente pagou adiantado um agendamento que ainda não aconteceu? Abra o agendamento e toque em "Receber adiantado" (ou, na ficha do tutor, "Receber agendamentos adiantados" para vários de uma vez). O valor entra no Faturamento no dia em que o cliente pagou e, no dia do atendimento, o pagamento já vem marcado.',
  ],
  '0.8.0': [
    'Serviços agora são Banho ou Complemento. O banho tem o preço e o tempo; os complementos (unhas, ouvidos, hidratação, tosa higiênica...) entram junto, com o valor, e não somam tempo. Confira a divisão em Serviços.',
    'Combos de banho: salve um conjunto de complementos (Serviços → Criar combo de banho) e marque tudo com um toque ao agendar ou montar um plano.',
    'O tempo previsto de cada visita agora conta só o banho. Antes somava todos os serviços e chegava a mais de 4 horas.',
    'Cliente fez um banho avulso e pediu o plano depois? No Histórico, toque em "Colocar num plano": o banho vira o 1º banho do Mês 1, sem refazer nada, e o que ele custou é abatido da mensalidade do Mês 1.',
  ],
  '0.7.1': [
    'O tempo agora é um só por atendimento: conta da chegada do pet até finalizar, sem as pausas. Os outros serviços (hidratação, corte de unha, tosa...) entram só com o valor.',
    'Serviços marcados como "Etapa comum do banho" (em Serviços) já vêm marcados no agendamento novo.',
    'Ao finalizar um banho de plano, a mensalidade recebida fica no dia do pagamento escolhido.',
    'Pets do mesmo tutor marcados juntos ficam cada um com o seu tempo estimado.',
  ],
  '0.6.6': [
    'No Histórico, cada atendimento mostra as duas datas: o dia em que foi atendido e o dia em que foi pago.',
    'Na ficha do pet, as últimas visitas mostram se foi pago e quando.',
  ],
  '0.6.5': [
    'O tempo de cada serviço não marca mais o horário como ocupado: o aviso aparece só quando outro pet está marcado para chegar no mesmo horário, e nunca impede de agendar.',
    'Dá para tirar um serviço que o pet não vai fazer no meio do atendimento (botão "Não fez").',
    'Horário da loja: seg a sex 8h às 18h com almoço 12h às 14h, sábado 8h às 12h30. Confira em Perfil → Editar dados da loja.',
  ],
};

export const DIAS_NO_SINO = 10;
