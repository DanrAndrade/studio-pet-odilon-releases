import { normalizar } from '../core/busca.js';

/* Banho e complementos (0.8.0). O atendimento é um BANHO (é ele que tem preço por porte e tempo) e o
   resto (corte de unhas, ouvidos, cauterização, tosa higiênica, hidratações, linha Hydra...) são
   COMPLEMENTOS do banho: entram com o valor, quase sempre R$ 0 (já estão no preço do banho), e não
   somam tempo. O que é banho e o que é complemento é um campo do serviço (`papel`): o app não adivinha
   pelo nome. Serviço sem `papel` (dados antigos, antes da organização) conta como banho, o
   comportamento de antes. */

export const ehComplemento = (servico) => servico?.papel === 'complemento';
export const ehBanho = (servico) => !ehComplemento(servico);

/**
 * Tempo de referência de um atendimento a partir dos serviços escolhidos: só os banhos contam
 * (complemento soma 0). Sem nenhum banho escolhido (ex.: só cortar as unhas), soma o que foi escolhido.
 * É só o ponto de partida: com histórico, vale a média do pet.
 */
export function duracaoDeReferencia(servicos) {
  const lista = servicos || [];
  const banhos = lista.filter(ehBanho);
  const base = banhos.length ? banhos : lista;
  return base.reduce((t, s) => t + (s.duracaoPadraoMin || 0), 0) || 60;
}

/**
 * Banho sugerido para o porte do pet, quando o nome do serviço termina no porte ("Banho Porte Pequeno"
 * para pet Pequeno). "Pequeno/Médio" não serve para "Médio": o porte inteiro precisa ser o fim do nome.
 * É só uma sugestão (vem marcado, dá para trocar); sem correspondência exata, não sugere nada.
 */
export function banhoDoPorte(catalogo, porte) {
  const p = normalizar(porte || '').trim();
  if (!p) return null;
  const casa = (s) => {
    const nome = normalizar(s.nome || '').trim();
    return nome === p || nome.endsWith(' ' + p);
  };
  const achados = (catalogo || []).filter((s) => ehBanho(s) && casa(s));
  return achados.length === 1 ? achados[0] : null;
}

/** Os mesmos serviços, em qualquer ordem. */
export const mesmoConjunto = (a, b) => a.length === b.length && a.every((x) => b.includes(x));

/** Combo (preset) só com serviços que ainda existem no catálogo. */
export const servicosDoCombo = (combo, catalogo) => (combo?.servicoIds || []).filter((id) => (catalogo || []).some((s) => s.id === id));

/**
 * Seleção depois de tocar num combo: os banhos escolhidos ficam e os complementos passam a ser os do
 * combo. Tocar de novo no combo que já está ligado tira os complementos.
 */
export function aplicarCombo(selecionados, combo, catalogo) {
  const banhos = selecionados.filter((id) => (catalogo || []).some((s) => s.id === id && ehBanho(s)));
  const complementos = selecionados.filter((id) => !banhos.includes(id));
  const doCombo = servicosDoCombo(combo, catalogo);
  return mesmoConjunto(complementos, doCombo) ? banhos : [...banhos, ...doCombo];
}

/** O combo está ligado: os complementos escolhidos são exatamente os dele. */
export function comboLigado(selecionados, combo, catalogo) {
  const doCombo = servicosDoCombo(combo, catalogo);
  if (!doCombo.length) return false;
  const complementos = selecionados.filter((id) => (catalogo || []).some((s) => s.id === id && ehComplemento(s)));
  return mesmoConjunto(complementos, doCombo);
}
