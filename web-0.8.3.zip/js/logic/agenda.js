/* Regras de horário: sobreposição, janelas livres e encaixe. Tudo em
   timestamps (ms) e minutos; nada aqui acessa o banco. */

const MIN = 60 * 1000;

const ativo = (ag) => !ag.excluidoEm && ag.status !== 'cancelado' && ag.status !== 'nao_compareceu';

export const fimDe = (ag) => ag.inicio + (ag.duracaoPrevistaMin || 60) * MIN;

/*
 * O tempo estimado de cada serviço NÃO decide se um horário está ocupado: cada pet
 * leva um tempo diferente para o mesmo serviço, e o tempo estimado serve só para
 * comparar com o tempo real (média anterior × duração real no atendimento).
 * Um horário está ocupado quando outro pet já está marcado para chegar nele.
 */

/** Agendamentos marcados para chegar no mesmo horário (mesmo dia e minuto). */
export function conflitos(inicio, _duracaoMin, agendamentos, ignorarId = null) {
  return agendamentos.filter((ag) => ag.id !== ignorarId && ativo(ag) && Math.abs(ag.inicio - inicio) < MIN);
}

/**
 * Horários de chegada livres do dia, em blocos de meia hora, dentro do expediente
 * e fora do almoço. Um bloco fica ocupado quando algum pet está marcado para chegar
 * nele. Blocos livres seguidos viram uma janela { inicio, fim, minutos }.
 */
export function horariosLivres(diaTs, agendamentos, { abre, fecha, pausaDe = null, pausaAte = null, aberto = true, minimo = 30 }) {
  if (!aberto) return [];
  const base = new Date(diaTs);
  base.setHours(0, 0, 0, 0);
  const t = (minutos) => base.getTime() + minutos * MIN;
  const chegadas = agendamentos.filter(ativo).map((ag) => ag.inicio);
  const livres = [];
  let janela = null;
  const fechar = () => {
    if (janela && janela.minutos >= minimo) livres.push(janela);
    janela = null;
  };
  for (let m = abre; m + 30 <= fecha; m += 30) {
    const noAlmoco = pausaDe != null && m < pausaAte && m + 30 > pausaDe;
    const ocupado = chegadas.some((c) => c >= t(m) && c < t(m + 30));
    if (noAlmoco || ocupado) { fechar(); continue; }
    if (janela) { janela.fim = t(m + 30); janela.minutos += 30; } else janela = { inicio: t(m), fim: t(m + 30), minutos: 30 };
  }
  fechar();
  return livres;
}

/**
 * Primeiro horário livre a partir de `inicio`, no mesmo dia, antes do
 * fechamento. Se não houver, devolve o horário pedido (aviso, nunca bloqueio).
 */
export function encaixar(inicio, duracaoMin, agendamentos, { fecha }) {
  const base = new Date(inicio);
  base.setHours(0, 0, 0, 0);
  const limite = base.getTime() + fecha * MIN;
  let tentativa = inicio;

  for (let i = 0; i < 48; i++) {
    const choque = conflitos(tentativa, duracaoMin, agendamentos);
    if (!choque.length) return tentativa;
    tentativa = Math.max(...choque.map(fimDe));
    if (tentativa + duracaoMin * MIN > limite) break;
  }
  return inicio;
}

/**
 * Horário de chegada fora do funcionamento: dia fechado, antes de abrir, depois de
 * fechar ou no intervalo de almoço. Usa o horário do próprio dia (sábado pode fechar
 * mais cedo). Só a hora de chegada conta, não o tempo estimado dos serviços.
 */
export function foraDoExpediente(inicio, _duracaoMin, exp) {
  const d = new Date(inicio);
  const minutos = d.getHours() * 60 + d.getMinutes();
  const h = exp.porDia ? exp.porDia[d.getDay()] : { aberto: exp.dias.includes(d.getDay()), abre: exp.abre, fecha: exp.fecha };
  if (!h.aberto) return true;
  if (minutos < h.abre || minutos >= h.fecha) return true;
  return h.pausaDe != null && minutos >= h.pausaDe && minutos < h.pausaAte;
}
