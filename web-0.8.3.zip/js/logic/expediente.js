/* Horário de funcionamento da loja, dia a dia: aberto ou fechado, abre, fecha e
   intervalo (almoço). Tudo em minutos desde a meia-noite. Nada aqui acessa o banco.

   horarios: lista de 7 dias (0 = domingo … 6 = sábado), cada um
     { aberto, abre, fecha, pausaDe, pausaAte }   (pausaDe/pausaAte = null: sem intervalo) */

export const NOMES_DIAS = ['Domingo', 'Segunda', 'Terça', 'Quarta', 'Quinta', 'Sexta', 'Sábado'];
const CURTOS = ['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb'];
const SIGLAS = { dom: 0, seg: 1, ter: 2, qua: 3, qui: 4, sex: 5, sab: 6 };

export const PADRAO = [0, 1, 2, 3, 4, 5, 6].map((d) => ({ aberto: d >= 1 && d <= 6, abre: 480, fecha: 1080, pausaDe: null, pausaAte: null }));

export const paraHora = (m) => (Number.isFinite(m) ? `${String(Math.floor(m / 60)).padStart(2, '0')}:${String(m % 60).padStart(2, '0')}` : '');
export function deHora(texto) {
  const m = /^(\d{1,2}):(\d{2})$/.exec(String(texto || '').trim());
  if (!m) return null;
  const h = Number(m[1]);
  const mi = Number(m[2]);
  return h < 24 && mi < 60 ? h * 60 + mi : null;
}

/**
 * Lê o expediente escrito à mão (versões antigas), por exemplo:
 *   "Seg a sáb · 08:00 às 18:00"
 *   "Seg a sex 08:00 às 18:00 (almoço 12:00 às 14:00) · Sáb 08:00 às 12:30"
 *   "Segunda a sexta das 8h às 12h e das 14h às 18h; sábado das 8h às 12h30"
 * Cada grupo de dias leva os horários escritos depois dele. Quatro horários seguidos
 * = abre, sai para o almoço, volta, fecha. Dia que não aparece fica fechado.
 */
export function lerHorarios(texto) {
  const s = String(texto || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '');
  const re = /\b(dom|seg|ter|qua|qui|sex|sab)[a-z]*(?:-feira)?\b|(\d{1,2})\s*(?::(\d{2})|h(\d{2})?)|\b(almoco|intervalo|pausa)\b|\b(todos os dias|todo dia|diariamente|todos)\b/g;
  const grupos = [];
  let g = null;
  let pausaAberta = false;
  let anterior = null; // { dia, fim }
  const novoGrupo = () => (g = { dias: new Set(), horas: [], pausa: [] }, grupos.push(g), g);
  for (const m of s.matchAll(re)) {
    if (m[1] || m[6]) {
      if (!g || g.horas.length || g.pausa.length) novoGrupo();
      if (m[6]) [0, 1, 2, 3, 4, 5, 6].forEach((d) => g.dias.add(d));
      else {
        const dia = SIGLAS[m[1]];
        const entre = anterior ? s.slice(anterior.fim, m.index) : '';
        if (anterior && g.dias.has(anterior.dia) && /^\s*(a|-|ate|ao)\s*$/.test(entre)) {
          for (let d = anterior.dia; d !== dia; d = (d + 1) % 7) g.dias.add(d);
        }
        g.dias.add(dia);
        anterior = { dia, fim: m.index + m[0].length };
      }
      pausaAberta = false;
    } else if (m[5]) {
      if (!g) novoGrupo();
      pausaAberta = true;
    } else {
      const minutos = Number(m[2]) * 60 + Number(m[3] || m[4] || 0);
      if (!g) novoGrupo();
      if (pausaAberta) {
        g.pausa.push(minutos);
        if (g.pausa.length >= 2) pausaAberta = false;
      } else g.horas.push(minutos);
    }
  }
  if (!grupos.some((x) => x.horas.length >= 2 || x.dias.size)) return PADRAO.map((d) => ({ ...d }));
  const saida = [0, 1, 2, 3, 4, 5, 6].map(() => ({ aberto: false, abre: 480, fecha: 1080, pausaDe: null, pausaAte: null }));
  const algumDia = grupos.some((x) => x.dias.size);
  const usados = new Set(grupos.flatMap((x) => [...x.dias]));
  let ultimoComHoras = null;
  for (const x of grupos) {
    // "almoço 12:00 às 14:00" sozinho: vale para o grupo anterior
    if (!x.dias.size && !x.horas.length && x.pausa.length >= 2 && ultimoComHoras) {
      for (const d of ultimoComHoras) Object.assign(saida[d], { pausaDe: x.pausa[0], pausaAte: x.pausa[1] });
      continue;
    }
    let dias = [...x.dias];
    if (!dias.length) dias = algumDia ? [1, 2, 3, 4, 5, 6].filter((d) => !usados.has(d)) : [1, 2, 3, 4, 5, 6];
    const h = x.horas;
    const dia = { aberto: true, abre: 480, fecha: 1080, pausaDe: null, pausaAte: null };
    if (h.length >= 2) {
      dia.abre = h[0];
      dia.fecha = h[h.length - 1];
      if (h.length >= 4) { dia.pausaDe = h[1]; dia.pausaAte = h[2]; }
    } else if (h.length === 1) dia.abre = h[0];
    if (x.pausa.length >= 2) { dia.pausaDe = x.pausa[0]; dia.pausaAte = x.pausa[1]; }
    if (dia.fecha <= dia.abre) dia.fecha = Math.min(dia.abre + 600, 1439);
    if (!(dia.pausaDe > dia.abre && dia.pausaAte > dia.pausaDe && dia.pausaAte < dia.fecha)) { dia.pausaDe = null; dia.pausaAte = null; }
    for (const d of dias) saida[d] = { ...dia };
    if (dias.length) ultimoComHoras = dias;
  }
  return saida;
}

/** Corrige um quadro de horários vindo do banco (campos faltando, valores fora do lugar). */
export function normalizar(horarios) {
  if (!Array.isArray(horarios) || horarios.length !== 7) return null;
  return horarios.map((h, d) => {
    const dia = { ...PADRAO[d], ...(h || {}) };
    dia.aberto = !!dia.aberto;
    if (!(dia.fecha > dia.abre)) dia.fecha = Math.min(dia.abre + 600, 1439);
    if (!(dia.pausaDe > dia.abre && dia.pausaAte > dia.pausaDe && dia.pausaAte < dia.fecha)) { dia.pausaDe = null; dia.pausaAte = null; }
    return dia;
  });
}

const faixa = (h) => `${paraHora(h.abre)} às ${paraHora(h.fecha)}${h.pausaDe != null ? ` (almoço ${paraHora(h.pausaDe)} às ${paraHora(h.pausaAte)})` : ''}`;

/** "sábado: 08:00 às 12:30" ou "a loja não abre no domingo" */
export function textoDoDia(horarios, d) {
  const h = horarios[d];
  const nome = NOMES_DIAS[d].toLowerCase();
  return h.aberto ? `${nome}: ${faixa(h)}` : `a loja não abre ${d === 0 || d === 6 ? 'no' : 'na'} ${nome}`;
}

/** "Seg a sex · 08:00 às 18:00 (almoço 12:00 às 14:00) · Sáb · 08:00 às 12:30" */
export function textoDoExpediente(horarios) {
  const ordem = [1, 2, 3, 4, 5, 6, 0];
  const blocos = [];
  for (const d of ordem) {
    const h = horarios[d];
    if (!h.aberto) continue;
    const ultimo = blocos[blocos.length - 1];
    const anteriorNaOrdem = ordem[ordem.indexOf(d) - 1];
    if (ultimo && ultimo.faixa === faixa(h) && ultimo.fim === anteriorNaOrdem) ultimo.fim = d;
    else blocos.push({ ini: d, fim: d, faixa: faixa(h) });
  }
  if (!blocos.length) return 'Fechado todos os dias';
  return blocos.map((b) => `${b.ini === b.fim ? CURTOS[b.ini] : `${CURTOS[b.ini]} a ${CURTOS[b.fim].toLowerCase()}`} · ${b.faixa}`).join(' · ');
}

/**
 * O expediente que a agenda usa: dias abertos, o horário de cada dia e, para quem
 * só precisa de um número, o mais cedo que abre e o mais tarde que fecha.
 */
export function montarExpediente(horarios) {
  const porDia = normalizar(horarios) || PADRAO.map((d) => ({ ...d }));
  const abertos = porDia.map((h, d) => (h.aberto ? d : null)).filter((d) => d !== null);
  const deDias = abertos.length ? abertos : [1, 2, 3, 4, 5, 6];
  return {
    dias: abertos,
    abre: Math.min(...deDias.map((d) => porDia[d].abre)),
    fecha: Math.max(...deDias.map((d) => porDia[d].fecha)),
    porDia,
    /** Horário do dia de `ts`: { aberto, abre, fecha, pausaDe, pausaAte } */
    dia: (ts) => porDia[new Date(ts).getDay()],
  };
}
