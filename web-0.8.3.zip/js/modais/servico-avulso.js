import { html, icon, paraCentavos } from '../core/dom.js';
import { campo } from '../core/ui.js';

/* Serviço fora do catálogo, só para este agendamento. Só nome e preço: o tempo é um
   só, o do atendimento inteiro (um cronômetro só, desde a 0.7.0). */

const modal = {
  render: (e) => html`<div class="modal-fundo">
    <div class="modal">
      <div class="modal-cab">
        <div>
          <div class="modal-titulo m">Serviço não catalogado</div>
          <div class="modal-sub">Vale só para este agendamento. Para usar sempre, cadastre em Serviços.</div>
        </div>
        <button class="modal-fechar" data-acao="fechar-modal" aria-label="Fechar">${icon('x', 16)}</button>
      </div>
      <div class="grade-2 mt-16" style="grid-template-columns:1.4fr 1fr">
        ${campo({ rotulo: 'Nome do serviço', nome: 'nome', valor: e.nome, placeholder: 'Ex.: Remoção de nós' })}
        ${campo({ rotulo: 'Preço', nome: 'preco', valor: e.preco, placeholder: 'R$ 30', formato: 'moeda' })}
      </div>
      <div class="modal-rodape">
        <button class="btn btn-branco" data-acao="fechar-modal">Cancelar</button>
        <button class="btn btn-roxo" data-acao="adicionar" style="font-size:13px">Adicionar</button>
      </div>
    </div>
  </div>`,

  acoes: {
    adicionar: (_, { estado, fechar, ctx }) => {
      const nome = (estado.nome || '').trim();
      if (!nome) return ctx.toast('Dê um nome ao serviço', { erro: true });
      fechar({ nome, precoCentavos: paraCentavos(estado.preco) });
    },
  },
};

export const servicoAvulso = (ctx) => ctx.abrirModal(modal, { nome: '', preco: '' });
