import { html, icon } from '../core/dom.js';
import { chip } from '../core/ui.js';
import { pets, agendamentos } from '../data/repo.js';
import * as config from '../data/config.js';
import { atualizarModal } from '../core/modais.js';

/* Registrar ocorrência (comportamento, pele, atraso...). Fica na ficha do pet
   e, se houver atendimento aberto, também nas observações dele. */

const modal = {
  render: (e) => html`<div class="modal-fundo">
    <div class="modal">
      <div class="modal-cab" style="align-items:center">
        <div class="modal-titulo">Registrar ocorrência</div>
        <button class="modal-fechar" data-acao="fechar-modal" aria-label="Fechar">${icon('x', 16)}</button>
      </div>
      <div class="rotulo-campo" style="margin:16px 0 7px">Tipo</div>
      <div class="chips">${(e.tipos || []).map((t) => chip(t, e.tipo === t, 'tipo', { tipo: t }, { suave: true, cls: 'forte' }))}</div>
      <textarea class="entrada" data-campo="texto" style="margin-top:14px;min-height:100px" placeholder="O que aconteceu…">${e.texto || ''}</textarea>
      <div class="modal-rodape">
        <button class="btn btn-branco" data-acao="fechar-modal">Cancelar</button>
        <button class="btn btn-roxo" data-acao="salvar" style="font-size:13px;padding:11px 22px">Registrar</button>
      </div>
    </div>
  </div>`,

  aoMontar: (_, estado) => {
    if (estado.tipos) return;
    config
      .lista('Tipos de ocorrência')
      .catch((erro) => {
        console.error(erro);
        return ['Outro'];
      })
      .then((tipos) => atualizarModal({ tipos, tipo: estado.tipo || tipos[0] }));
  },

  acoes: {
    tipo: ({ tipo }, { atualizar }) => atualizar({ tipo }),
    salvar: async (_, { estado, fechar, ctx }) => {
      const texto = (estado.texto || '').trim();
      if (!texto) return ctx.toast('Descreva o que aconteceu', { erro: true });
      await pets.registrarOcorrencia(estado.petId, { tipo: estado.tipo, texto, agendamentoId: estado.agendamentoId });
      if (estado.agendamentoId) await agendamentos.observar(estado.agendamentoId, `[${estado.tipo}] ${texto}`);
      fechar(true);
      ctx.toast('Ocorrência registrada');
    },
  },
};

export const registrarOcorrencia = (ctx, { petId, agendamentoId = null }) =>
  ctx.abrirModal(modal, { petId, agendamentoId, texto: '' });
