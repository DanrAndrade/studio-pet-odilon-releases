import { html, icon, fmtBRLCurto, fmtDur } from '../core/dom.js';
import { vazio } from '../core/ui.js';
import { servicos, precoParaPorte } from '../data/repo.js';
import { atualizarModal } from '../core/modais.js';

/* Escolher um serviço do catálogo para incluir no atendimento. */

const modal = {
  render: (e) => html`<div class="modal-fundo">
    <div class="modal">
      <div class="modal-cab">
        <div>
          <div class="modal-titulo">Adicionar serviço ao atendimento</div>
          <div class="modal-sub">O serviço entra no valor do atendimento. O tempo é o do atendimento inteiro.</div>
        </div>
        <button class="modal-fechar" data-acao="fechar-modal" aria-label="Fechar">${icon('x', 16)}</button>
      </div>
      <div style="margin-top:14px;max-height:320px;overflow:auto">
        ${e.erro
          ? html`<div class="vazio compacto">Não foi possível carregar os serviços: ${e.erro}. Feche e tente de novo.</div>`
          : !e.lista
          ? html`<div class="vazio compacto">Carregando…</div>`
          : e.lista.length
            ? e.lista.map(
                (s) => html`<button class="opcao-servico" data-acao="escolher" data-id="${s.id}">
                  <span class="opcao-ponto" style="background:${s.cor || 'var(--roxo)'}"></span>
                  <span style="flex:1;min-width:0">
                    <span class="opcao-nome">${s.nome}</span>
                    <span class="opcao-meta">${s.categoria} · ${fmtBRLCurto(precoParaPorte(s, e.porte))} · ref. ${fmtDur(s.duracaoPadraoMin)}</span>
                  </span>
                  <span style="color:var(--roxo-escuro)">${icon('plus', 16)}</span>
                </button>`
              )
            : vazio({ icone: 'scissors', titulo: 'Nenhum serviço ativo', texto: 'Cadastre serviços em Serviços.', compacto: true })}
      </div>
    </div>
  </div>`,

  aoMontar: (_, estado) => {
    if (estado.lista || estado.carregando) return;
    estado.carregando = true;
    servicos
      .ativos()
      .then((lista) => atualizarModal({ lista }))
      .catch((erro) => atualizarModal({ erro: erro?.message || 'erro desconhecido' }));
  },

  acoes: {
    escolher: ({ id }, { estado, fechar }) => fechar(estado.lista.find((s) => s.id === id) || null),
  },
};

/** `porte` do pet: o preço mostrado é o mesmo que será cobrado. */
export const escolherServico = (ctx, porte) => ctx.abrirModal(modal, { porte });
