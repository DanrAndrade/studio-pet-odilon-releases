import { html, icon } from '../core/dom.js';
import { agendamentos } from '../data/repo.js';
import { atualizarModal } from '../core/modais.js';

/* Observações do atendimento: tópicos curtos, adicionados e removidos na hora. */

const modal = {
  render: (e) => html`<div class="modal-fundo">
    <div class="modal">
      <div class="modal-cab" style="align-items:center">
        <div class="modal-titulo">Observações do atendimento</div>
        <button class="modal-fechar" data-acao="fechar-modal" aria-label="Fechar">${icon('x', 16)}</button>
      </div>
      <div style="display:flex;flex-direction:column;gap:8px;margin-top:14px;max-height:220px;overflow:auto">
        ${(e.lista || []).map(
          (texto, i) => html`<div class="topico">
            <span>${texto}</span>
            <button data-acao="remover" data-indice="${i}" aria-label="Remover">${icon('x', 14)}</button>
          </div>`
        )}
        ${e.lista && !e.lista.length ? html`<div class="modal-sub">Nenhuma observação ainda.</div>` : ''}
      </div>
      <div style="display:flex;gap:8px;margin-top:12px">
        <input class="entrada" data-campo="rascunho" value="${e.rascunho || ''}" placeholder="Adicionar um tópico…" style="flex:1" enterkeyhint="done">
        <button class="btn btn-roxo" style="font-size:13px;padding:0 18px" data-acao="adicionar">${icon('plus', 15)}Adicionar</button>
      </div>
      <div class="modal-rodape">
        <button class="btn btn-branco" data-acao="fechar-modal">Concluir</button>
      </div>
    </div>
  </div>`,

  aoMontar: (el, estado) => {
    if (!estado.lista) {
      agendamentos
        .obter(estado.agendamentoId)
        .then((ag) => atualizarModal({ lista: ag?.observacoes || [] }))
        .catch((erro) => {
          console.error(erro);
          atualizarModal({ lista: [] });
        });
    }
    const campo = el.querySelector('[data-campo="rascunho"]');
    // marca em propriedade (não em atributo): a janela pode reaproveitar o campo ao atualizar
    if (campo && !campo.__enterLigado) {
      campo.__enterLigado = true;
      campo.addEventListener('keydown', (ev) => {
        if (ev.key === 'Enter') el.querySelector('[data-acao="adicionar"]').click();
      });
    }
  },

  acoes: {
    adicionar: async (_, { estado, atualizar }) => {
      const texto = (estado.rascunho || '').trim();
      if (!texto) return;
      const ag = await agendamentos.observar(estado.agendamentoId, texto);
      atualizar({ lista: ag.observacoes, rascunho: '' });
    },
    remover: async ({ indice }, { estado, atualizar }) => {
      const ag = await agendamentos.removerObservacao(estado.agendamentoId, Number(indice));
      atualizar({ lista: ag.observacoes });
    },
  },
};

export const editarObservacoes = (ctx, { agendamentoId }) => ctx.abrirModal(modal, { agendamentoId, rascunho: '' });
