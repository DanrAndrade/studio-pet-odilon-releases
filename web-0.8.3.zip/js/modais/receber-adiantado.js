import { html, icon, fmtBRL, fmtDataCurta, DIAS_CURTOS } from '../core/dom.js';

/* Receber adiantado vários agendamentos do mesmo cliente de uma vez: lista os agendamentos
   futuros com valor ainda não pagos; o que for marcado entra no mesmo pagamento (uma forma e um dia). */

const marcados = (e) => e.lista.filter((x) => e.ids.includes(x.ag.id));
const totalDe = (e) => marcados(e).reduce((s, x) => s + (x.ag.valorCentavos || 0), 0);

const modal = {
  render: (e) => html`<div class="modal-fundo">
    <div class="modal m-500">
      <div class="modal-cab">
        <div>
          <div class="modal-titulo m">Receber adiantado</div>
          <div class="modal-sub">Marque os agendamentos que o cliente já pagou</div>
        </div>
        <button class="modal-fechar" data-acao="fechar-modal" aria-label="Fechar">${icon('x', 16)}</button>
      </div>
      <div style="display:flex;flex-direction:column;gap:7px;margin-top:14px;max-height:340px;overflow:auto">
        ${e.lista.map(({ ag, pet, servicos }) => {
          const on = e.ids.includes(ag.id);
          return html`<button class="serv-opcao${on ? ' on' : ''}" data-acao="marcar" data-id="${ag.id}">
            <span class="caixa-check${on ? ' on' : ''}">${on ? icon('check', 13) : ''}</span>
            <span style="min-width:0">
              <span class="serv-opcao-nome" style="display:block">${pet?.nome || 'Pet'} · ${DIAS_CURTOS[new Date(ag.inicio).getDay()]} ${fmtDataCurta(ag.inicio)}</span>
              <span class="serv-opcao-sub" style="display:block">${servicos || 'Sem serviço'}</span>
            </span>
            <span class="pilula">${fmtBRL(ag.valorCentavos)}</span>
          </button>`;
        })}
      </div>
      <div class="modal-rodape separado">
        <div style="font-weight:600;color:var(--tinta-2)">Total ${fmtBRL(totalDe(e))}</div>
        <div style="display:flex;gap:9px">
          <button class="btn btn-branco" data-acao="fechar-modal">Cancelar</button>
          <button class="btn btn-roxo" style="padding:11px 20px" data-acao="ok" ${e.ids.length ? '' : 'disabled'}>Continuar</button>
        </div>
      </div>
    </div>
  </div>`,

  acoes: {
    marcar: ({ id }, { estado, atualizar }) => atualizar({ ids: estado.ids.includes(id) ? estado.ids.filter((x) => x !== id) : [...estado.ids, id] }),
    ok: (_, { estado, fechar }) => {
      if (estado.ids.length) fechar(estado.ids);
    },
  },
};

/** lista: [{ ag, pet, servicos }]. Devolve os ids marcados (todos vêm marcados) ou null. */
export const escolherAdiantados = (ctx, lista) => ctx.abrirModal(modal, { lista, ids: lista.map((x) => x.ag.id) });
