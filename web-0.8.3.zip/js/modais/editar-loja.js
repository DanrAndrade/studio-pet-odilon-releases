import { html, icon, mascaraTelefone, telefoneValido, $ } from '../core/dom.js';
import { campo } from '../core/ui.js';
import * as config from '../data/config.js';
import { NOMES_DIAS, paraHora, deHora, textoDoExpediente } from '../logic/expediente.js';

/* Dados da loja: aparecem nos lembretes. O horário de cada dia define o expediente
   da agenda (dias abertos, horários livres e o aviso de "fora do expediente"). */

const CAMPOS = [
  { nome: 'nome', rotulo: 'Nome da loja', placeholder: 'Studio Pet Odilon Groomer' },
  { nome: 'endereco', rotulo: 'Endereço', placeholder: 'Rua, número · bairro' },
  { nome: 'cnpj', rotulo: 'CNPJ', placeholder: 'opcional', formato: 'cnpj' },
  { nome: 'telefone', rotulo: 'Telefone da loja', placeholder: '(73) 90000-0000', tipo: 'tel', formato: 'telefone' },
];

// segunda primeiro, domingo por último
const ORDEM = [1, 2, 3, 4, 5, 6, 0];

const hora = (nome, valor, rotulo) =>
  html`<input class="entrada hor-campo" type="time" step="300" data-campo="${nome}" value="${paraHora(valor)}" aria-label="${rotulo}">`;

function linhaDia(e, d) {
  const h = e.horarios[d];
  return html`<div class="hor-dia${h.aberto ? '' : ' fechado'}">
    <div class="hor-cab">
      <span class="hor-nome">${NOMES_DIAS[d]}</span>
      <button class="chip-s mini${h.aberto ? ' on' : ''}" data-acao="dia-aberto" data-dia="${d}">${h.aberto ? 'Aberto' : 'Fechado'}</button>
      ${d === 1 && h.aberto ? html`<button class="link-acao" data-acao="copiar-semana">Usar este horário de terça a sexta</button>` : ''}
    </div>
    ${h.aberto
      ? html`<div class="hor-faixas">
          <label>Abre ${hora(`h-${d}-abre`, h.abre, `${NOMES_DIAS[d]}: abre`)}</label>
          <label>Fecha ${hora(`h-${d}-fecha`, h.fecha, `${NOMES_DIAS[d]}: fecha`)}</label>
          <label>Almoço ${hora(`h-${d}-pausaDe`, h.pausaDe, `${NOMES_DIAS[d]}: sai para o almoço`)} até ${hora(`h-${d}-pausaAte`, h.pausaAte, `${NOMES_DIAS[d]}: volta do almoço`)}</label>
        </div>`
      : ''}
  </div>`;
}

/** Problema no horário de algum dia (texto para o aviso) ou null. */
function problema(horarios) {
  for (const d of ORDEM) {
    const h = horarios[d];
    if (!h.aberto) continue;
    const nome = NOMES_DIAS[d].toLowerCase();
    if (h.abre == null || h.fecha == null) return `Preencha a hora que abre e que fecha na ${nome}`;
    if (h.fecha <= h.abre) return `Na ${nome}, a hora de fechar tem que ser depois da de abrir`;
    if ((h.pausaDe == null) !== (h.pausaAte == null)) return `Na ${nome}, preencha as duas horas do almoço (ou deixe as duas vazias)`;
    if (h.pausaDe != null && !(h.pausaDe > h.abre && h.pausaAte > h.pausaDe && h.pausaAte < h.fecha)) return `Na ${nome}, o almoço tem que ficar entre a hora de abrir e a de fechar`;
  }
  if (!ORDEM.some((d) => horarios[d].aberto)) return 'Deixe pelo menos um dia aberto';
  return null;
}

const modal = {
  render: (e) => html`<div class="modal-fundo">
      <div class="modal m-620">
        <div class="modal-cab">
          <div>
            <div class="modal-titulo">Editar dados da loja</div>
            <div class="modal-sub">Aparecem nos lembretes e no cabeçalho dos relatórios.</div>
          </div>
          <button class="modal-fechar" data-acao="fechar-modal" aria-label="Fechar">${icon('x', 16)}</button>
        </div>
        <div class="grade-2" style="margin-top:18px">
          ${CAMPOS.map((c) => campo({ ...c, valor: e[c.nome] }))}
        </div>
        <div class="rotulo-campo" style="margin:18px 0 4px">Horário de funcionamento</div>
        <div class="mutado" style="font-size:12px;margin-bottom:8px">A agenda usa este horário para os dias em que a loja abre, os horários disponíveis e o aviso de fora do expediente. Almoço é opcional.</div>
        <div class="hor-lista">${ORDEM.map((d) => linhaDia(e, d))}</div>
        <div class="mutado" id="expediente-lido" style="font-size:12px;margin-top:10px">${textoDoExpediente(e.horarios)}</div>
        <div class="modal-rodape">
          <button class="btn btn-branco" data-acao="fechar-modal">Cancelar</button>
          <button class="btn btn-roxo" style="padding:11px 20px" data-acao="salvar">Salvar alterações</button>
        </div>
      </div>
    </div>`,

  aoDigitar: (nome, valor, { estado, el }) => {
    const m = /^h-(\d)-(abre|fecha|pausaDe|pausaAte)$/.exec(nome);
    if (m) {
      estado.horarios[Number(m[1])][m[2]] = valor ? deHora(valor) : null;
      const lido = $('#expediente-lido');
      if (lido) lido.textContent = problema(estado.horarios) || textoDoExpediente(estado.horarios);
      return;
    }
    if (nome === 'telefone') {
      estado.telefone = mascaraTelefone(valor);
      if (el && el.value !== estado.telefone) el.value = estado.telefone;
    }
  },

  acoes: {
    'dia-aberto': ({ dia }, { estado, atualizar }) => {
      const h = estado.horarios[Number(dia)];
      h.aberto = !h.aberto;
      atualizar({ horarios: estado.horarios });
    },
    'copiar-semana': (_, { estado, atualizar }) => {
      for (const d of [2, 3, 4, 5]) estado.horarios[d] = { ...estado.horarios[1] };
      atualizar({ horarios: estado.horarios });
    },
    salvar: async (_, { estado, fechar, ctx }) => {
      const dados = Object.fromEntries(CAMPOS.map((c) => [c.nome, String(estado[c.nome] || '').trim()]));
      if (!dados.nome) return ctx.toast('A loja precisa de um nome', { erro: true });
      if (!telefoneValido(dados.telefone)) return ctx.toast('Telefone incompleto: use DDD + número', { erro: true });
      const erro = problema(estado.horarios);
      if (erro) return ctx.toast(erro, { erro: true });
      const horarios = estado.horarios.map((h) => ({ ...h }));
      // o texto do expediente (lembretes, perfil) passa a ser montado do horário
      await config.atualizar('loja', { ...dados, horarios, expediente: textoDoExpediente(horarios) });
      ctx.toast('Dados da loja atualizados');
      fechar(true);
    },
  },
};

export const editarLoja = async (ctx, loja) => {
  const horarios = (await config.horariosDaLoja()).map((h) => ({ ...h }));
  return ctx.abrirModal(modal, { ...loja, horarios });
};
