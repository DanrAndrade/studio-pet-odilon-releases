import { html, icon } from '../core/dom.js';
import { chip } from '../core/ui.js';
import { uuid } from '../data/db.js';
import * as config from '../data/config.js';
import { ehComplemento } from '../logic/complementos.js';

/* Combo de banho: um conjunto de complementos salvo com nome (ex.: "Banho completo Hydra"). Ao marcar
   um atendimento ou montar um plano, um toque no combo marca todos os complementos de uma vez. */

const modal = {
  render: (e) => html`<div class="modal-fundo">
    <div class="modal m-620">
      <div class="modal-cab">
        <div>
          <div class="modal-titulo m">${e.combo ? 'Editar combo' : 'Novo combo'}</div>
          <div class="modal-sub">Escolha os complementos que sempre vão juntos no banho.</div>
        </div>
        <button class="modal-fechar" data-acao="fechar-modal" aria-label="Fechar">${icon('x', 16)}</button>
      </div>
      <div class="mt-16">
        <div class="rotulo-campo" style="font-weight:500">Nome do combo</div>
        <input class="entrada" data-campo="nome" value="${e.nome}" placeholder="Ex.: Banho completo Hydra">
      </div>
      <div class="rotulo-campo" style="font-weight:500;margin:16px 0 7px">Complementos <span class="mutado">· ${e.marcados.length} ${e.marcados.length === 1 ? 'marcado' : 'marcados'}</span></div>
      ${e.complementos.length
        ? html`<div class="chips" style="max-height:280px;overflow:auto">${e.complementos.map((s) => chip(s.nome, e.marcados.includes(s.id), 'marcar', { id: s.id }, { suave: true, cls: 'mini' }))}</div>`
        : html`<div class="vazio compacto">Nenhum complemento no catálogo. Marque o tipo "Complemento" ao editar um serviço.</div>`}
      <div class="modal-rodape separado">
        <div></div>
        <div style="display:flex;gap:9px">
          <button class="btn btn-branco" data-acao="fechar-modal">Cancelar</button>
          <button class="btn btn-roxo" style="padding:11px 22px" data-acao="salvar">Salvar combo</button>
        </div>
      </div>
    </div>
  </div>`,

  acoes: {
    marcar: ({ id }, { estado, atualizar }) => atualizar({ marcados: estado.marcados.includes(id) ? estado.marcados.filter((x) => x !== id) : [...estado.marcados, id] }),
    salvar: async (_, { estado: e, fechar, ctx }) => {
      const nome = (e.nome || '').trim();
      if (!nome) return ctx.toast('Dê um nome ao combo', { erro: true });
      if (!e.marcados.length) return ctx.toast('Marque ao menos um complemento', { erro: true });
      const lista = await config.presets();
      if (lista.some((c) => c.id !== e.combo?.id && c.nome.trim().toLowerCase() === nome.toLowerCase())) return ctx.toast('Já existe um combo com esse nome', { erro: true });
      const novo = { ...(e.combo || {}), id: e.combo?.id || uuid(), nome, servicoIds: e.marcados, criadoEm: e.combo?.criadoEm || Date.now() };
      await config.salvarPresets([...lista.filter((c) => c.id !== novo.id), novo]);
      ctx.toast(e.combo ? 'Combo atualizado' : `Combo “${nome}” criado`);
      fechar(true);
    },
  },
};

export async function editarCombo(ctx, combo, catalogo) {
  const complementos = catalogo.filter((s) => ehComplemento(s) && s.ativo !== false);
  return ctx.abrirModal(modal, {
    combo,
    nome: combo?.nome || '',
    complementos,
    marcados: (combo?.servicoIds || []).filter((id) => catalogo.some((s) => s.id === id)),
  });
}
