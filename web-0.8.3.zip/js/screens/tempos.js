import { html, icon, fmtDur, fmtDataCurta, DIA_MS } from '../core/dom.js';
import { vazio } from '../core/ui.js';
import { agendamentos, pets } from '../data/repo.js';
import { minutosDaVisita } from '../logic/metricas.js';

/* TEMPOS MÉDIOS — quanto tempo levou cada atendimento (um cronômetro só),
   medido da chegada do pet até finalizar, nos últimos 90 dias. */

const JANELA_DIAS = 90;

export default {
  titulo: 'Tempos médios',
  menu: 'tempos',

  async carregar() {
    const de = Date.now() - JANELA_DIAS * DIA_MS;
    const concluidos = (await agendamentos.concluidos()).filter((a) => (a.chegadaEm || a.inicio) >= de && a.usarNaMedia !== false);
    const itensPorAg = await agendamentos.itensDe(concluidos);
    const mapaPets = new Map((await pets.listar()).map((p) => [p.id, p]));

    const duracoes = [];
    const porPet = new Map();
    for (const ag of concluidos) {
      const min = minutosDaVisita(ag, itensPorAg.get(ag.id) || []);
      if (!(min > 0)) continue;
      duracoes.push(min);
      if (!porPet.has(ag.petId)) porPet.set(ag.petId, []);
      porPet.get(ag.petId).push(min);
    }
    const petsMedias = [...porPet.entries()]
      .filter(([id]) => mapaPets.has(id))
      .map(([id, xs]) => {
        const p = mapaPets.get(id);
        return { nome: p.raca ? `${p.nome} · ${p.raca.split(' ')[0]}` : p.nome, minutos: Math.round(xs.reduce((a, b) => a + b, 0) / xs.length), qtd: xs.length };
      })
      .sort((a, b) => b.minutos - a.minutos);

    const soma = duracoes.reduce((a, b) => a + b, 0);
    return {
      atendimentos: duracoes.length,
      mediaMin: duracoes.length ? Math.round(soma / duracoes.length) : null,
      menorMin: duracoes.length ? Math.min(...duracoes) : null,
      maiorMin: duracoes.length ? Math.max(...duracoes) : null,
      lentos: petsMedias.slice(0, 5),
      // os mais rápidos vêm só de quem não está entre os mais demorados (6 a 9 pets não repetem ninguém)
      rapidos: petsMedias.slice(Math.max(5, petsMedias.length - 5)).reverse(),
    };
  },

  render(vm) {
    const resumo = [
      { rotulo: 'Atendimentos medidos', valor: String(vm.atendimentos), icone: 'activity' },
      { rotulo: 'Atendimento médio', valor: vm.mediaMin ? fmtDur(vm.mediaMin) : '—', icone: 'timer' },
      { rotulo: 'Mais rápido', valor: vm.menorMin ? fmtDur(vm.menorMin) : '—', icone: 'trending-down' },
      { rotulo: 'Mais demorado', valor: vm.maiorMin ? fmtDur(vm.maiorMin) : '—', icone: 'trending-up' },
    ];
    const listaPets = (lista, cor, trilho, barra) =>
      lista.length
        ? lista.map((p) => {
            const topo = Math.max(...lista.map((x) => x.minutos), 1);
            return html`<div style="padding:9px 0;border-top:1px solid var(--divisor)">
              <div style="display:flex;justify-content:space-between;font-size:12.5px;margin-bottom:6px;gap:10px">
                <span class="truncar" style="color:var(--texto-2);font-weight:500">${p.nome}</span><span style="font-weight:600;color:${cor}">${fmtDur(p.minutos)}</span>
              </div>
              <div class="barra" style="height:7px;background:${trilho};border-radius:8px"><div style="width:${((p.minutos / topo) * 100).toFixed(0)}%;background:${barra};border-radius:8px"></div></div>
            </div>`;
          })
        : html`<div class="mutado" style="font-size:12.5px;padding:9px 0;border-top:1px solid var(--divisor)">Precisa de mais pets com atendimentos medidos.</div>`;

    return html`
      <div class="sub-pagina" style="margin-bottom:14px">Tempo de cada atendimento inteiro (da chegada até finalizar) · últimos ${JANELA_DIAS} dias</div>
      <div class="grade-4 fat-kpis">
        ${resumo.map(
          (r) => html`<div class="kpi compacto">
            <div class="kpi-rotulo"><span class="kpi-icone">${icon(r.icone, 13)}</span><span>${r.rotulo}</span></div>
            <div class="kpi-valor">${r.valor}</div>
          </div>`
        )}
      </div>

      ${vm.atendimentos
        ? html`<div class="tempos-grade">
            <div class="painel">
              <div style="display:flex;align-items:center;gap:7px;margin-bottom:12px;color:var(--rosa)">${icon('trending-up', 14)}<span class="titulo-card">Pets mais demorados</span></div>
              ${listaPets(vm.lentos, 'var(--rosa)', 'var(--rosa-trilho)', 'var(--rosa-barra)')}
            </div>
            <div class="painel">
              <div style="display:flex;align-items:center;gap:7px;margin-bottom:12px;color:var(--verde)">${icon('trending-down', 14)}<span class="titulo-card">Pets mais rápidos</span></div>
              ${listaPets(vm.rapidos, 'var(--verde-escuro)', 'var(--verde-fundo-2)', 'var(--verde-barra)')}
            </div>
          </div>`
        : html`<div class="card pad-18">${vazio({ icone: 'timer', titulo: 'Nenhum atendimento medido ainda', texto: 'O tempo aparece aqui quando você finaliza um atendimento: ele é medido da chegada do pet até finalizar.' })}</div>`}`;
  },

  acoes: {},
};
