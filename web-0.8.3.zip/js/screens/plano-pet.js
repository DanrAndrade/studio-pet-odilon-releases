import { html, icon, digitos } from '../core/dom.js';
import { avPet, descricaoPet, vazio, voltar } from '../core/ui.js';
import { pets, tutores, planos } from '../data/repo.js';
import { planoVigente, recorrenciaCurta, descricaoVigencia, fimDoPlano } from '../logic/planos.js';
import { combina, ordemAlfabetica } from '../core/busca.js';
import { nomesDoTutor, nomesParaBusca, telefonesDoTutor } from '../logic/contatos.js';

/* PLANO · ESCOLHER O PET — primeiro o Odilon acha o pet (pelo nome dele, do
   tutor ou pelo telefone); depois abre o plano daquele pet: cria um novo ou
   edita o que já existe. */

const ui = { busca: '' };

export default {
  titulo: 'Plano · escolha o pet',
  menu: 'planos',

  async carregar() {
    const mapaTutores = new Map((await tutores.listar()).map((t) => [t.id, t]));
    const vigentes = new Map();
    // qualquer plano que ainda não acabou (inclusive pausado): abre ele em vez de criar outro
    // dois planos ainda valendo para o mesmo pet: fica o que está valendo agora e, empatando, o mais novo
    const melhor = (a, b) => (planoVigente(a) !== planoVigente(b) ? (planoVigente(a) ? a : b) : (a.criadoEm || 0) >= (b.criadoEm || 0) ? a : b);
    for (const p of await planos.listar()) {
      if (!(planoVigente(p) || (!p.encerradoEm && (!fimDoPlano(p) || fimDoPlano(p) > Date.now())))) continue;
      const atual = vigentes.get(p.petId);
      vigentes.set(p.petId, atual ? melhor(atual, p) : p);
    }
    const linhas = (await pets.listar()).map((pet) => {
      const tutor = mapaTutores.get(pet.tutorId) || null;
      return {
        pet,
        tutor,
        plano: vigentes.get(pet.id) || null,
        textos: [pet.nome, pet.raca, ...nomesParaBusca(tutor)],
        telefones: telefonesDoTutor(tutor),
      };
    });
    // pelo nome do pet, como nas outras listas de pets; depois pelo tutor
    linhas.sort((a, b) => ordemAlfabetica(a.pet.nome, b.pet.nome) || ordemAlfabetica(a.tutor?.nome || '~', b.tutor?.nome || '~'));
    return { linhas };
  },

  render(vm) {
    const lista = vm.linhas.filter((l) => combina(ui.busca, l.textos, l.telefones));

    return html`
      ${voltar('Voltar para planos', 'voltar')}
      <div class="card r22 pad-18 pp-busca-card">
        <div class="titulo-card g">De quem é o plano?</div>
        <div class="mutado" style="font-size:12.5px;margin:3px 0 12px">Busque pelo nome do pet, do tutor ou pelo telefone. Se o pet já tem plano, ele abre para editar.</div>
        <div class="busca">
          ${icon('search', 16)}
          <input data-campo="busca" value="${ui.busca}" placeholder="Ex.: Thor, Marina, 99881…" autofocus>
          ${ui.busca ? html`<button data-acao="limpar" style="display:flex;color:var(--texto-3)" aria-label="Limpar">${icon('x', 15)}</button>` : ''}
        </div>
      </div>

      ${!vm.linhas.length
        ? html`<div class="card pad-18">${vazio({
            icone: 'paw-print',
            titulo: 'Nenhum pet cadastrado',
            texto: 'Cadastre o tutor e o pet primeiro.',
            acao: html`<button class="btn btn-roxo" data-acao="cadastrar">${icon('user-plus', 15)}<span>Novo cadastro</span></button>`,
          })}</div>`
        : !lista.length
          ? html`<div class="card pad-18">${vazio({
              icone: 'search',
              titulo: 'Nenhum pet encontrado',
              texto: 'Confira o nome ou cadastre o cliente.',
              acao: html`<button class="btn btn-branco" data-acao="cadastrar">${icon('user-plus', 15)}<span>Novo cadastro</span></button>`,
            })}</div>`
          : html`<div class="card r22 pp-lista">
              ${lista.map(
                (l) => html`<button class="pp-linha" data-acao="escolher" data-id="${l.pet.id}">
                  ${avPet(l.pet, 44, { borda: 0, sombra: false })}
                  <span class="pp-nomes">
                    <span class="pp-pet">${l.pet.nome}<span class="pp-tutor"> · ${nomesDoTutor(l.tutor) || 'sem tutor'}</span></span>
                    <span class="pp-sub">${l.plano ? `${recorrenciaCurta(l.plano)} · ${descricaoVigencia(l.plano)}` : descricaoPet(l.pet)}</span>
                  </span>
                  ${l.plano
                    ? html`<span class="pp-acao editar">${icon('pencil', 14)}<span>Editar plano</span></span>`
                    : html`<span class="pp-acao">${icon('plus', 14)}<span>Criar plano</span></span>`}
                </button>`
              )}
            </div>`}`;
  },

  aoDigitar(campo, valor, ctx) {
    if (campo !== 'busca') return;
    ui.busca = valor;
    ctx.redesenhar();
  },

  acoes: {
    limpar: (_, ctx) => {
      ui.busca = '';
      ctx.redesenhar();
    },
    voltar: (_, ctx) => ctx.navegar('planos', {}, { substituir: true }),
    cadastrar: (_, ctx) => ctx.navegar('cadastro'),
    escolher: ({ id }, ctx) => {
      const l = ctx.vm.linhas.find((x) => x.pet.id === id);
      ui.busca = '';
      if (l.plano) ctx.navegar('plano-rec', { id: l.plano.id });
      else ctx.navegar('plano-rec', { petId: id });
    },
  },
};
