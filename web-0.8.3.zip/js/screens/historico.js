import {
  html, icon, fmtBRL, fmtHora, fmtDataCurta, mesmoDia, addDias, digitos, DIAS_LONGOS,
  inicioDoDia, fimDoDia, inicioDaSemana, inicioDoMes, fimDoMes,
} from '../core/dom.js';
import { avPet, vazio, chip } from '../core/ui.js';
import { agendamentos, pets, tutores, planos, dataDoAtendimento, nomesParaRelatorio, mensalidadesDoPlano } from '../data/repo.js';
import { situacaoPagamento, ehBanhoDePlano, pagoEmOutroDia } from '../logic/pagamento.js';
import { combina } from '../core/busca.js';
import { escolherFormaRecebimento, descreverRecebimento } from '../modais/recebimento.js';
import { nomesParaBusca, telefonesDoTutor } from '../logic/contatos.js';
import { planoVigente } from '../logic/planos.js';

/* HISTÓRICO — todos os atendimentos finalizados, do mais recente para o mais
   antigo. Daqui dá para reabrir (voltar ao atendimento para corrigir) ou
   desfazer (voltar a ser só um agendamento) um atendimento finalizado por engano. */

const PERIODOS = ['Hoje', 'Semana', 'Este mês', 'Mês passado', 'Tudo'];
const FILTROS = ['Todos', 'Pagos', 'Não pagos', 'Plano'];
const POR_PAGINA = 60;
const ui = { periodo: 'Semana', filtro: 'Todos', busca: '', limite: POR_PAGINA };

/**
 * Filtros em que a linha aparece. Mensalidade recebida: Pagos e Plano. Banho do plano:
 * Plano (e Não pagos se a mensalidade cobrada nele está em aberto, ou o extra não foi pago).
 */
function situacao(l) {
  if (l.mensalidade) return ['Pagos', 'Plano'];
  if (l.recebimento) return ehBanhoDePlano(l.recebimento) ? ['Pagos', 'Plano'] : ['Pagos'];
  const s = [];
  const chave = situacaoPagamento(l.ag).chave;
  if (chave === 'pago') s.push('Pagos');
  if (chave === 'naoPago') s.push('Não pagos');
  if (ehBanhoDePlano(l.ag)) s.push('Plano');
  if (l.cobranca && !l.cobranca.pagamento && !s.includes('Não pagos')) s.push('Não pagos');
  return s;
}
const temCobranca = (ag) => (ag.valorCentavos || 0) > 0;

function intervalo(periodo, agora = Date.now()) {
  switch (periodo) {
    case 'Hoje':
      return { de: inicioDoDia(agora), ate: fimDoDia(agora) };
    case 'Semana':
      return { de: inicioDaSemana(agora), ate: fimDoDia(agora) };
    case 'Este mês':
      return { de: inicioDoMes(agora), ate: fimDoDia(agora) };
    case 'Mês passado': {
      const d = new Date(agora);
      const ref = new Date(d.getFullYear(), d.getMonth() - 1, 15).getTime();
      return { de: inicioDoMes(ref), ate: fimDoMes(ref) };
    }
    default:
      return { de: 0, ate: Infinity };
  }
}

function rotuloDia(ts) {
  const agora = Date.now();
  if (mesmoDia(ts, agora)) return 'Hoje';
  if (mesmoDia(ts, addDias(agora, -1))) return 'Ontem';
  return `${DIAS_LONGOS[new Date(ts).getDay()]}, ${fmtDataCurta(ts)}${new Date(ts).getFullYear() !== new Date(agora).getFullYear() ? '/' + new Date(ts).getFullYear() : ''}`;
}

const pagamento = situacaoPagamento;

export default {
  titulo: 'Histórico',
  menu: 'historico',

  async carregar() {
    const mapaPets = new Map((await pets.listar()).map((p) => [p.id, p]));
    const mapaTutores = new Map((await tutores.listar()).map((t) => [t.id, t]));
    // nomes também de pets e tutores excluídos: o histórico não perde quem foi
    const nomes = await nomesParaRelatorio();
    const { de, ate } = intervalo(ui.periodo);
    const concluidos = await agendamentos.concluidos();
    const lista = concluidos
      // mesmo critério do faturamento: o dia em que o pet foi atendido
      .map((ag) => ({ ag, quando: dataDoAtendimento(ag) }))
      .filter((x) => x.quando >= de && x.quando <= ate)
      .sort((a, b) => b.quando - a.quando);
    const itensPorAg = await agendamentos.itensDe(lista.map((x) => x.ag));
    // mensalidades: cada banho de cobrança mostra se a mensalidade foi paga, e a mensalidade
    // recebida aparece também no dia em que foi paga
    const cobrancaPorVisita = new Map();
    const mensalidadesPagas = [];
    const planoPorId = new Map();
    for (const plano of await planos.todos()) {
      planoPorId.set(plano.id, plano);
      // mesma regra do Faturamento: só cobra plano valendo, com valor, até o encerramento
      const mens = await mensalidadesDoPlano(plano);
      const visitas = await agendamentos.doPlano(plano.id);
      for (const m of mens) {
        const visita = visitas.find((v) => v.inicio === m.ts);
        if (visita) cobrancaPorVisita.set(visita.id, m);
        if (m.pagamento?.pagoEm >= de && m.pagamento.pagoEm <= ate) mensalidadesPagas.push(m);
      }
    }
    const linhas = [];
    for (const { ag, quando } of lista) {
      const pet = mapaPets.get(ag.petId) || (nomes.pets.get(ag.petId) ? { id: null, nome: nomes.pets.get(ag.petId) } : null);
      const tutorId = ag.tutorId || pet?.tutorId;
      const tutor = mapaTutores.get(tutorId) || (nomes.tutores.get(tutorId) ? { nome: nomes.tutores.get(tutorId) } : null);
      linhas.push({
        ag,
        quando,
        pet,
        tutor,
        servicos: (itensPorAg.get(ag.id) || []).map((i) => i.nome).join(' + '),
        cobranca: cobrancaPorVisita.get(ag.id) || null,
        plano: ag.planoId ? planoPorId.get(ag.planoId) || null : null,
        textos: [pet?.nome, ...nomesParaBusca(tutor)],
        telefones: telefonesDoTutor(tutor),
      });
    }
    // atendimento pago em outro dia: aparece também no dia em que foi pago (fora dos totais do período)
    for (const ag of concluidos) {
      if (!pagoEmOutroDia(ag) || !(ag.pagoEm >= de && ag.pagoEm <= ate)) continue;
      const pet = mapaPets.get(ag.petId) || (nomes.pets.get(ag.petId) ? { id: null, nome: nomes.pets.get(ag.petId) } : null);
      const tutorId = ag.tutorId || pet?.tutorId;
      const tutor = mapaTutores.get(tutorId) || (nomes.tutores.get(tutorId) ? { nome: nomes.tutores.get(tutorId) } : null);
      linhas.push({ recebimento: ag, quando: ag.pagoEm, pet, tutor, servicos: '', textos: [pet?.nome, ...nomesParaBusca(tutor)], telefones: telefonesDoTutor(tutor) });
    }
    for (const m of mensalidadesPagas) {
      const pet = mapaPets.get(m.plano.petId) || (nomes.pets.get(m.plano.petId) ? { id: null, nome: nomes.pets.get(m.plano.petId) } : null);
      const tutor = mapaTutores.get(m.plano.tutorId) || (nomes.tutores.get(m.plano.tutorId) ? { nome: nomes.tutores.get(m.plano.tutorId) } : null);
      linhas.push({ mensalidade: m, quando: m.pagamento.pagoEm, pet, tutor, servicos: '', textos: [pet?.nome, m.plano.nome, ...nomesParaBusca(tutor)], telefones: telefonesDoTutor(tutor) });
    }
    linhas.sort((a, b) => b.quando - a.quando);
    return { linhas };
  },

  render(vm) {
    const termo = ui.busca.trim();
    const filtradas = vm.linhas.filter((l) => (ui.filtro === 'Todos' || situacao(l).includes(ui.filtro)) && combina(termo, [...l.textos, l.servicos], l.telefones));
    const visiveis = filtradas.slice(0, ui.limite);
    const atendimentos = filtradas.filter((l) => l.ag);
    const total = atendimentos.reduce((s, l) => s + (l.ag.valorCentavos || 0), 0);
    const mensalidades = filtradas.filter((l) => l.mensalidade);
    const totalMensalidades = mensalidades.reduce((s, l) => s + l.mensalidade.valorCentavos, 0);
    const pagosDepois = filtradas.filter((l) => l.recebimento);
    const totalPagosDepois = pagosDepois.reduce((s, l) => s + (l.recebimento.valorCentavos || 0), 0);

    // agrupa por dia de finalização
    const grupos = [];
    for (const l of visiveis) {
      const chave = inicioDoDia(l.quando);
      if (!grupos.length || grupos[grupos.length - 1].chave !== chave) grupos.push({ chave, linhas: [] });
      grupos[grupos.length - 1].linhas.push(l);
    }

    return html`
      <div class="hist-topo">
        <div class="segmento">${PERIODOS.map((p) => html`<button class="${ui.periodo === p ? 'on' : ''}" data-acao="periodo" data-periodo="${p}">${p}</button>`)}</div>
        <div class="busca branca">
          ${icon('search', 16)}
          <input data-campo="busca" value="${ui.busca}" placeholder="Buscar por pet, tutor ou telefone…">
          ${ui.busca ? html`<button data-acao="limpar" style="display:flex;color:var(--texto-3)" aria-label="Limpar">${icon('x', 15)}</button>` : ''}
        </div>
      </div>

      <div class="chips" style="margin:-4px 0 12px;gap:8px">${FILTROS.map((f) => chip(f, ui.filtro === f, 'filtro', { filtro: f }, { suave: true }))}</div>

      <div class="hist-resumo-linha">
        <span><strong>${atendimentos.length}</strong> ${atendimentos.length === 1 ? 'atendimento finalizado' : 'atendimentos finalizados'}</span>
        <span>Total cobrado <strong>${fmtBRL(total)}</strong>${totalMensalidades ? html` · mensalidades recebidas <strong>${fmtBRL(totalMensalidades)}</strong>` : ''}${totalPagosDepois ? html` · pagamentos de atendimentos de outros dias <strong>${fmtBRL(totalPagosDepois)}</strong>` : ''}</span>
      </div>

      ${!filtradas.length
        ? html`<div class="card pad-18">${vazio({
            icone: 'history',
            titulo: termo || ui.filtro !== 'Todos' ? 'Nenhum atendimento encontrado' : 'Nenhum atendimento finalizado neste período',
            texto: termo || ui.filtro !== 'Todos' ? 'Tente outro filtro, nome ou período.' : 'Os atendimentos aparecem aqui assim que são finalizados.',
          })}</div>`
        : html`${grupos.map(
            (g) => html`<div class="card r22 hist-grupo">
              <div class="hist-dia">${rotuloDia(g.chave)}<span>${(() => { const n = g.linhas.filter((l) => l.ag).length; return `${n} ${n === 1 ? 'atendimento' : 'atendimentos'}`; })()}</span></div>
              ${g.linhas.map((l) => (l.mensalidade ? linhaMensalidade(l) : l.recebimento ? linhaRecebimento(l) : linha(l)))}
            </div>`
          )}
          ${filtradas.length > visiveis.length
            ? html`<button class="btn btn-branco bloco" data-acao="mais">Mostrar mais (${filtradas.length - visiveis.length} restantes)</button>`
            : ''}`}`;
  },

  aoDigitar(campo, valor, ctx) {
    if (campo !== 'busca') return;
    ui.busca = valor;
    ui.limite = POR_PAGINA;
    ctx.redesenhar();
  },

  acoes: {
    periodo: ({ periodo }, ctx) => {
      ui.periodo = periodo;
      ui.limite = POR_PAGINA;
      ctx.recarregar();
    },
    limpar: (_, ctx) => {
      ui.busca = '';
      ctx.redesenhar();
    },
    filtro: ({ filtro }, ctx) => {
      ui.filtro = filtro;
      ui.limite = POR_PAGINA;
      ctx.redesenhar();
    },
    // mensalidade do plano: receber / desfazer daqui também
    'pagar-mensalidade': async ({ plano, mes }, ctx) => {
      const p = (await planos.todos()).find((x) => x.id === plano);
      if (!p) return;
      // o valor a receber (no Mês 1 de um plano que começou por um banho avulso, já sem o que ele custou)
      const m = (await mensalidadesDoPlano(p)).find((x) => x.mes === mes);
      const r = await escolherFormaRecebimento(ctx, { valorCentavos: m?.valorCentavos ?? p.valorCentavos, detalhe: `${p.nome} · mensalidade` });
      if (!r) return;
      await planos.registrarPagamento(plano, mes, r.forma, r.quando, r.partes);
      ctx.toast(`Mensalidade recebida · ${descreverRecebimento(r)}`);
      ctx.recarregar();
    },
    'mensalidade-nao-paga': async ({ plano, mes }, ctx) => {
      const ok = await ctx.confirmar({
        titulo: 'Marcar a mensalidade como não paga?',
        texto: 'Ela volta a ficar como não paga (em "A receber" no Faturamento) e sai do faturamento até ser marcada como paga de novo.',
        botao: 'Marcar como não paga',
        perigo: false,
        icone: 'wallet',
      });
      if (!ok) return;
      await planos.desfazerPagamento(plano, mes);
      ctx.toast('Mensalidade marcada como não paga');
      ctx.recarregar();
    },
    // pago / não pago direto daqui, sem reabrir o atendimento
    pagar: async ({ id }, ctx) => {
      const l = ctx.vm.linhas.find((x) => x.ag?.id === id);
      const r = await escolherFormaRecebimento(ctx, { valorCentavos: l.ag.valorCentavos, detalhe: l.pet?.nome || '' });
      if (!r) return;
      await agendamentos.registrarRecebimento(id, r.forma, r.quando, r.partes);
      ctx.toast(`Marcado como pago · ${descreverRecebimento(r)}`);
      ctx.recarregar();
    },
    'nao-pago': async ({ id }, ctx) => {
      // a linha do atendimento ou a do pagamento recebido em outro dia
      const l = ctx.vm.linhas.find((x) => x.ag?.id === id) || ctx.vm.linhas.find((x) => x.recebimento?.id === id);
      const ag = l.ag || l.recebimento;
      const ok = await ctx.confirmar({
        titulo: `Marcar como não pago?`,
        texto: `${l.pet?.nome || 'O atendimento'} · ${fmtBRL(ag.valorCentavos)} volta a ficar como não pago (em "A receber" no Faturamento) e sai do faturamento até ser marcado como pago de novo.`,
        botao: 'Marcar como não pago',
        perigo: false,
        icone: 'wallet',
      });
      if (!ok) return;
      await agendamentos.marcarNaoPago(id);
      ctx.toast('Marcado como não pago');
      ctx.recarregar();
    },
    // cliente pediu para incluir no plano um banho avulso que já foi feito: abre o plano novo com ele como 1º banho
    'para-plano': async ({ id }, ctx) => {
      const l = ctx.vm.linhas.find((x) => x.ag?.id === id);
      if (!l?.pet?.id) return;
      if ((await planos.doPet(l.pet.id)).some((p) => planoVigente(p))) {
        return ctx.toast(`${l.pet.nome} já tem um plano valendo. Encerre ou edite o plano dele antes.`, { erro: true });
      }
      ctx.navegar('plano-rec', { petId: l.pet.id, banhoFeito: id });
    },
    'tirar-do-plano': async ({ id }, ctx) => {
      const l = ctx.vm.linhas.find((x) => x.ag?.id === id);
      const ok = await ctx.confirmar({
        titulo: `Tirar o banho de ${l?.pet?.nome || 'o pet'} do plano?`,
        texto: 'O banho volta a ser avulso, com o mesmo valor e pagamento de antes, e a mensalidade do Mês 1 volta ao valor cheio. Se ela já tinha sido paga com o abatimento, continua como foi paga (o dinheiro fecha: banho + mensalidade). O plano continua com os outros banhos.',
        botao: 'Tirar do plano',
        perigo: false,
        icone: 'undo-2',
      });
      if (!ok) return;
      await agendamentos.tirarDoPlano(id);
      ctx.toast('Banho voltou a ser avulso');
      ctx.recarregar();
    },
    mais: (_, ctx) => {
      ui.limite += POR_PAGINA;
      ctx.redesenhar();
    },
    ficha: ({ id }, ctx) => id && ctx.navegar('ficha-pet', { id }),
    reabrir: async ({ id }, ctx) => {
      const l = ctx.vm.linhas.find((x) => x.ag?.id === id);
      const nome = l.pet?.nome || 'o pet';
      const ok = await ctx.confirmar({
        titulo: `Reabrir o atendimento de ${nome}?`,
        texto: `O atendimento volta para o Atendimento do dia com os tempos já registrados e o relógio parado (não conta o tempo desde que foi finalizado). Você corrige o que precisar e finaliza de novo. Para só trocar pago/não pago, não precisa reabrir: use o botão ao lado.${l.ag.retornoId ? ' O retorno marcado na finalização é desmarcado.' : ''}`,
        botao: 'Reabrir',
        perigo: false,
        icone: 'rotate-ccw',
      });
      if (!ok) return;
      const r = await agendamentos.reabrir(id);
      if (!r) return ctx.toast('Este atendimento já não está finalizado', { erro: true });
      ctx.toast(`Atendimento de ${nome} reaberto${r.retornoRemovido ? ' · retorno desmarcado' : ''}`);
      ctx.navegar('atendimento', { id });
    },
    desfazer: async ({ id }, ctx) => {
      const l = ctx.vm.linhas.find((x) => x.ag?.id === id);
      const nome = l.pet?.nome || 'o pet';
      const ok = await ctx.confirmar({
        titulo: `Desfazer o atendimento de ${nome}?`,
        texto: `Volta a ser só um agendamento em ${fmtDataCurta(l.ag.inicio)} às ${fmtHora(l.ag.inicio)}, como se ${nome} não tivesse vindo. Os tempos cronometrados e o pagamento são apagados, e o valor sai do faturamento.${l.ag.retornoId ? ' O retorno marcado na finalização também é desmarcado.' : ''}${l.ag.entradaMensalidade ? ' Atenção: este banho foi a entrada da mensalidade do Mês 1 do plano. Sem ele a mensalidade do Mês 1 volta ao valor cheio, e se ela já foi paga com o abatimento, o plano fica abaixo do valor contratado.' : ''}`,
        botao: 'Desfazer atendimento',
        icone: 'undo-2',
      });
      if (!ok) return;
      const r = await agendamentos.desfazer(id);
      if (!r) return ctx.toast('Este atendimento já não está finalizado', { erro: true });
      ctx.toast(`Atendimento desfeito · ${nome} voltou para a agenda${r.retornoRemovido ? ' · retorno desmarcado' : ''}`);
      ctx.recarregar();
    },
  },
};

function linha(l) {
  const { ag, pet, tutor } = l;
  const pg = pagamento(ag);
  const { servicos } = l;
  return html`<div class="hist-item">
    <button class="hist-item-info" data-acao="ficha" data-id="${pet?.id || ''}">
      <span class="hist-hora">${fmtHora(l.quando)}</span>
      ${pet?.id ? avPet(pet, 40, { borda: 0, sombra: false }) : html`<span style="width:40px"></span>`}
      <span class="hist-nomes">
        <span class="hist-pet truncar">${pet?.nome || 'Pet excluído'}</span>
        <span class="hist-tutor truncar">${tutor?.nome || 'Sem tutor'}${servicos ? ' · ' + servicos : ''}</span>
        <span class="hist-datas">${datasDoAtendimento(ag)}</span>
      </span>
      <span class="hist-valor">
        ${valorDaLinha(l)}
        ${ag.planoId && ag.valorCentavos ? html`<span class="hist-pg lavanda">${ag.entradaMensalidade ? 'Plano · entrada da mensalidade' : 'Plano · extra cobrado'}</span>` : ''}
        <span class="hist-pg ${pg.cls}">${pg.texto}</span>
        ${l.cobranca ? html`<span class="hist-pg ${l.cobranca.pagamento ? 'verde' : 'ambar'}">Mensalidade ${l.cobranca.k}/${l.cobranca.total} · ${valorMensalidade(l.cobranca)} · ${l.cobranca.pagamento ? `paga${l.cobranca.pagamento.formaPagamento ? ' · ' + l.cobranca.pagamento.formaPagamento : ''}` : 'não paga'}</span>` : ''}
      </span>
    </button>
    <div class="hist-acoes">
      ${temCobranca(ag)
        ? ag.pagamentoPendente
          ? html`<button class="btn btn-roxo hist-btn" data-acao="pagar" data-id="${ag.id}">${icon('circle-dollar-sign', 14)}<span>Marcar pago</span></button>`
          : html`<button class="btn btn-branco hist-btn discreto" data-acao="nao-pago" data-id="${ag.id}">${icon('undo-2', 14)}<span>Marcar não pago</span></button>`
        : ''}
      ${l.cobranca && !l.cobranca.pagamento && !l.cobranca.plano.excluidoEm
        ? html`<button class="btn btn-roxo hist-btn" data-acao="pagar-mensalidade" data-plano="${l.cobranca.plano.id}" data-mes="${l.cobranca.mes}">${icon('circle-dollar-sign', 14)}<span>Receber mensalidade</span></button>`
        : ''}
      ${!ag.planoId && pet?.id ? html`<button class="btn btn-lavanda hist-btn" data-acao="para-plano" data-id="${ag.id}">${icon('repeat', 14)}<span>Colocar num plano</span></button>` : ''}
      ${ag.incluidoNoPlanoEm ? html`<button class="btn btn-branco hist-btn discreto" data-acao="tirar-do-plano" data-id="${ag.id}">${icon('undo-2', 14)}<span>Tirar do plano</span></button>` : ''}
      <button class="btn btn-lavanda hist-btn" data-acao="reabrir" data-id="${ag.id}">${icon('rotate-ccw', 14)}<span>Reabrir</span></button>
      <button class="btn btn-branco hist-btn desfazer" data-acao="desfazer" data-id="${ag.id}">${icon('undo-2', 14)}<span>Desfazer</span></button>
    </div>
  </div>`;
}

/** "Atendido qua 28/10 · Pago sex 30/10" — as duas datas sempre, mesmo quando são o mesmo dia. */
const diaCurto = (ts) => `${DIAS_LONGOS[new Date(ts).getDay()].slice(0, 3).toLowerCase()} ${fmtDataCurta(ts)}`;
function datasDoAtendimento(ag) {
  const sp = situacaoPagamento(ag);
  const atendido = `Atendido ${diaCurto(dataDoAtendimento(ag))}`;
  if (sp.chave === 'naoPago') return `${atendido} · Não pago`;
  if (sp.chave === 'plano') return `${atendido} · Incluso no plano`;
  if (sp.chave === 'semCobranca') return `${atendido} · Sem cobrança`;
  return `${atendido} · Pago ${diaCurto(ag.pagoEm || ag.finalizadoEm || dataDoAtendimento(ag))}`;
}

/** Atendimento pago num dia diferente do atendimento: aparece também no dia do pagamento. */
function linhaRecebimento(l) {
  const { recebimento: ag, pet, tutor } = l;
  return html`<div class="hist-item">
    <button class="hist-item-info" data-acao="ficha" data-id="${pet?.id || ''}">
      <span class="hist-hora">${fmtHora(l.quando)}</span>
      ${pet?.id ? avPet(pet, 40, { borda: 0, sombra: false }) : html`<span style="width:40px"></span>`}
      <span class="hist-nomes">
        <span class="hist-pet truncar">${pet?.nome || 'Pet excluído'} · pagamento recebido</span>
        <span class="hist-tutor truncar">${tutor?.nome || 'Sem tutor'}</span>
        <span class="hist-datas">${datasDoAtendimento(ag)}</span>
      </span>
      <span class="hist-valor">
        <span>${fmtBRL(ag.valorCentavos || 0)}</span>
        <span class="hist-pg verde">Pago${ag.formaPagamento ? ' · ' + ag.formaPagamento : ''}</span>
      </span>
    </button>
    <div class="hist-acoes">
      <button class="btn btn-branco hist-btn discreto" data-acao="nao-pago" data-id="${ag.id}">${icon('undo-2', 14)}<span>Marcar não pago</span></button>
    </div>
  </div>`;
}

/** Mensalidade de plano recebida: aparece no dia em que foi paga. */
function linhaMensalidade(l) {
  const { mensalidade: m, pet, tutor } = l;
  return html`<div class="hist-item">
    <button class="hist-item-info" data-acao="ficha" data-id="${pet?.id || ''}">
      <span class="hist-hora">${fmtHora(l.quando)}</span>
      ${pet?.id ? avPet(pet, 40, { borda: 0, sombra: false }) : html`<span style="width:40px"></span>`}
      <span class="hist-nomes">
        <span class="hist-pet truncar">${pet?.nome || 'Pet excluído'} · mensalidade${m.k ? ` ${m.k}/${m.total}` : ''}</span>
        <span class="hist-tutor truncar">${tutor?.nome || 'Sem tutor'} · ${m.plano.nome}</span>
      </span>
      <span class="hist-valor">
        <span>${fmtBRL(m.pagamento.valorCentavos ?? m.plano.valorCentavos ?? 0)}</span>
        <span class="hist-pg verde">Mensalidade paga${m.pagamento.formaPagamento ? ' · ' + m.pagamento.formaPagamento : ''}</span>
      </span>
    </button>
    <div class="hist-acoes">
      <button class="btn btn-branco hist-btn discreto" data-acao="mensalidade-nao-paga" data-plano="${m.plano.id}" data-mes="${m.mes}">${icon('undo-2', 14)}<span>Marcar não paga</span></button>
    </div>
  </div>`;
}

const valorMensalidade = (c) => fmtBRL(c.valorCentavos ?? c.plano.valorCentavos ?? 0);

/**
 * Valor mostrado na linha: o cobrado no atendimento; num banho do plano sem extra,
 * o valor do plano por mês (o banho está incluso nele).
 */
function valorDaLinha(l) {
  const { ag } = l;
  if (ag.planoId && !ag.valorCentavos) {
    return l.plano?.valorCentavos
      ? html`<span>${fmtBRL(l.plano.valorCentavos)}<small class="hist-mes">/mês</small></span>`
      : html`<span class="mutado">Incluso</span>`;
  }
  return html`<span>${fmtBRL(ag.valorCentavos || 0)}</span>`;
}
