import { html, fmtCron } from '../core/dom.js';

/* Marcação do cronômetro do atendimento (um só, desde a 0.7.0). O app atualiza estes
   elementos a cada segundo (ver tickCronometros em app.js) sem redesenhar a tela. */

/** Tempo do atendimento: desde a chegada, sem contar as pausas (nem o tempo entre finalizar e reabrir). */
export const segundosSessao = (ag, agora = Date.now()) => {
  const chegada = ag.chegadaEm || ag.inicio;
  return Math.max(0, ((ag.pausadoEm || agora) - chegada) / 1000 - (ag.pausaSeg || 0));
};

export const cronSessao = (ag) =>
  html`<span class="num" data-cron="sessao" data-desde="${ag.chegadaEm || ag.inicio}" data-pausa="${ag.pausaSeg || 0}" data-parado="${ag.pausadoEm || ''}">${fmtCron(segundosSessao(ag))}</span>`;
