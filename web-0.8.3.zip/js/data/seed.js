import { STORES, todos, putVarios, uuid } from './db.js';
import * as config from './config.js';
import { lerHorarios, textoDoExpediente } from '../logic/expediente.js';
import { estimarDuracao, JANELA_HISTORICO, MINIMO_AMOSTRAS } from '../logic/duracao.js';
import { duracaoDeReferencia } from '../logic/complementos.js';
import { montarBanhos, chaveBanho, tipoDoPlano, limitarMeses, limitarIntervalo, EDITAVEIS, TIPOS, datasDasMensalidades, chaveDaMensalidade, ehChaveAntiga, chaveDoMes } from '../logic/planos.js';

/* Primeiro uso: catálogo inicial com os serviços mais comuns, SEM preço: o
   Odilon cadastra os dele em Serviços. Os tempos reais vêm dos cronômetros. */

const CATALOGO = [
  { nome: 'Banho', categoria: 'Banho', precoCentavos: 0, duracaoPadraoMin: 30, cor: '#5b32e0', papel: 'banho' },
  { nome: 'Tosa completa', categoria: 'Tosa', precoCentavos: 0, duracaoPadraoMin: 60, cor: '#8b7bee', papel: 'complemento' },
  { nome: 'Tosa higiênica', categoria: 'Tosa', precoCentavos: 0, duracaoPadraoMin: 25, cor: '#f0339b', papel: 'complemento' },
  { nome: 'Hidratação', categoria: 'Estética', precoCentavos: 0, duracaoPadraoMin: 15, cor: '#bd991f', papel: 'complemento' },
  { nome: 'Corte de unhas', categoria: 'Adicional', precoCentavos: 0, duracaoPadraoMin: 10, cor: '#37b881', papel: 'complemento' },
];

// preços de exemplo que as versões até a 0.5.3 traziam de fábrica
const PRECOS_DE_EXEMPLO = new Map([
  ['Banho', 7000], ['Tosa completa', 15000], ['Tosa higiênica', 4500], ['Hidratação', 6000], ['Corte de unhas', 2500],
]);

/**
 * Correção única (0.5.4): zera os preços de exemplo que vieram de fábrica e o
 * Odilon não cadastrou. Conta como de exemplo o serviço nunca editado por ele
 * (registro sem atualizadoEm) ou que continua com o valor de exemplo exato e
 * sem preço por porte. O preço antigo fica guardado em precoExemploCentavos.
 * Só mexe no catálogo: atendimentos e agendamentos ficam como estão.
 */
async function zerarPrecosDeExemplo() {
  const migracoes = (await config.obter('migracoes')) || {};
  if (migracoes.precosDeExemplo) return;
  const zerados = [];
  for (const s of await todos(STORES.servicos)) {
    if (s.excluidoEm || !s.precoCentavos) continue;
    const exemplo = PRECOS_DE_EXEMPLO.get(s.nome);
    if (exemplo === undefined) continue;
    const temPorPorte = Object.values(s.precoPorPorte || {}).some(Boolean);
    const nuncaEditado = !s.atualizadoEm;
    const aindaDeExemplo = s.precoCentavos === exemplo && !temPorPorte;
    if (!nuncaEditado && !aindaDeExemplo) continue;
    await putVarios(STORES.servicos, [{ ...s, precoCentavos: 0, precoExemploCentavos: s.precoCentavos }]);
    zerados.push(s.nome);
  }
  await config.salvar('migracoes', { ...migracoes, precosDeExemplo: { em: Date.now(), servicos: zerados } });
}

/** Correção única (0.5.6): "Boleto" entra nas formas de pagamento de quem já usa o app. */
async function adicionarBoleto() {
  const migracoes = (await config.obter('migracoes')) || {};
  if (migracoes.boleto) return;
  const listas = (await config.obter('listas')) || {};
  const formas = listas['Formas de pagamento'];
  if (Array.isArray(formas) && !formas.some((f) => f.trim().toLowerCase() === 'boleto')) {
    const antes = formas.findIndex((f) => f === 'Fiado' || f === 'Incluso no plano');
    const nova = [...formas];
    nova.splice(antes < 0 ? nova.length : antes, 0, 'Boleto');
    await config.salvarLista('Formas de pagamento', nova);
  }
  await config.salvar('migracoes', { ...((await config.obter('migracoes')) || {}), boleto: Date.now() });
}

/**
 * Correção única (0.5.8): quinzenal passa a ser a cada 2 semanas (14 dias, mesmo
 * dia da semana), não 15. Move para o dia certo os banhos de plano quinzenal e
 * os agendamentos criados com "repetir a cada 15 dias" que:
 *   - ainda não aconteceram e são daqui a 7 dias ou mais (o que o cliente já
 *     combinou para esta semana não muda), tanto a data de antes quanto a nova;
 *   - estavam na data automática (o dia; a hora de cada um é mantida);
 *   - vão para um dia em que a loja abre e um horário livre.
 * O resto fica como está (aparece como "data própria" na folha do plano).
 * Grava primeiro os agendamentos, depois os planos e por último a marca da
 * correção: se o app fechar no meio, ela roda de novo sem estragar nada.
 * A lista do que mudou fica guardada para o aviso no sino.
 */
async function quinzenalACadaDuasSemanas() {
  const migracoes = (await config.obter('migracoes')) || {};
  if (migracoes.quinzenal14) return;
  const DIA = 864e5;
  const diaDe = (ts) => { const d = new Date(ts); d.setHours(0, 0, 0, 0); return d.getTime(); };
  const limite = diaDe(Date.now()) + 7 * DIA;
  const exp = await config.expediente();
  const todasVisitas = await todos(STORES.agendamentos);
  const vivas = todasVisitas.filter((v) => !v.excluidoEm && !['cancelado', 'nao_compareceu'].includes(v.status));
  const nomesPets = new Map((await todos(STORES.pets)).map((p) => [p.id, p.nome]));
  const mudados = new Map();
  const lista = [];
  const naoMovidos = [];

  /** Leva `v` para o dia `diaNovo` (mesma hora), se puder. */
  const mover = (v, diaNovo, motivo) => {
    const d = new Date(v.inicio);
    const alvo = new Date(diaNovo);
    alvo.setHours(d.getHours(), d.getMinutes(), 0, 0);
    const ts = alvo.getTime();
    if (ts === v.inicio) return;
    if (v.inicio < limite || ts < limite) return;
    const fim = ts + (v.duracaoPrevistaMin || 60) * 60000;
    const ocupado = vivas.some((o) => o.id !== v.id && !mudados.has(o.id) && o.inicio < fim && o.inicio + (o.duracaoPrevistaMin || 60) * 60000 > ts)
      || [...mudados.values()].some((o) => o.id !== v.id && o.inicio < fim && o.inicio + (o.duracaoPrevistaMin || 60) * 60000 > ts);
    const fechado = !exp.dias.includes(alvo.getDay());
    if (ocupado || fechado) {
      naoMovidos.push({ pet: nomesPets.get(v.petId) || 'Pet', de: v.inicio, motivo: fechado ? 'a loja não abre no dia certo' : 'horário ocupado no dia certo' });
      return;
    }
    mudados.set(v.id, { ...v, inicio: ts, lembreteEnviadoEm: null, atualizadoEm: Date.now(), quinzenalAntes: v.inicio, motivoAjuste: motivo });
    lista.push({ pet: nomesPets.get(v.petId) || 'Pet', de: v.inicio, para: ts });
  };

  // 1) planos quinzenais
  const planosParaAjustar = [];
  for (const plano of await todos(STORES.planos)) {
    if (tipoDoPlano(plano) !== 'Quinzenal' || Number(plano.intervalo) === 14) continue;
    planosParaAjustar.push(plano);
    if (plano.excluidoEm || plano.encerradoEm) continue;
    const intervaloAntigo = Number(plano.intervalo) || 15;
    const visitas = todasVisitas.filter((v) => v.planoId === plano.id && !v.excluidoEm).sort((a, b) => a.inicio - b.inicio);
    const chaveDe = (v, i) => chaveBanho(v.planoMes || Math.floor(i / 2) + 1, v.planoBanho || (i % 2) + 1);
    const cfg = { tipo: 'Quinzenal', meses: limitarMeses(plano.meses || 1), inicio: plano.inicio, hora: plano.hora };
    // padrão antigo sem pontos de partida: um "ponto de partida" que está no próprio dia do
    // padrão (só a hora foi trocada) não conta como mudança de dia
    const semAncora = new Map(montarBanhos({ ...cfg, intervalo: intervaloAntigo }).map((l) => [l.chave, diaDe(l.padrao)]));
    const ancoras = new Map();
    visitas.forEach((v, i) => {
      const chave = chaveDe(v, i);
      if (v.planoAncora && diaDe(v.inicio) !== semAncora.get(chave)) ancoras.set(chave, { ts: v.inicio, ancora: true });
    });
    const antes = new Map(montarBanhos({ ...cfg, intervalo: intervaloAntigo }, ancoras).map((l) => [l.chave, diaDe(l.padrao)]));
    const depois = new Map(montarBanhos({ ...cfg, intervalo: 14 }, ancoras).map((l) => [l.chave, diaDe(l.padrao)]));
    visitas.forEach((v, i) => {
      const chave = chaveDe(v, i);
      if (!EDITAVEIS.includes(v.status) || ancoras.has(chave)) return;
      // só o que está no dia automático antigo (a hora pode ter sido trocada)
      if (antes.get(chave) !== diaDe(v.inicio) || !Number.isFinite(depois.get(chave))) return;
      mover(v, depois.get(chave), 'quinzenal-plano');
    });
  }

  // 2) agendamentos avulsos criados com "repetir a cada 15 dias" (0.5.7, desde 20/10/2026):
  // mesmo pet, mesmo horário, criados juntos (segundos). Cada um vai para
  // primeiro + 14 × n, onde n é a posição dele na série (15·n a 15·n+6 dias do primeiro).
  const DESDE = new Date(2026, 9, 19).getTime();
  const avulsos = todasVisitas
    .filter((v) => !v.planoId && !v.excluidoEm && (v.criadoEm || 0) >= DESDE)
    .map((v) => ({ v, chave: `${v.petId}|${new Date(v.inicio).getHours()}:${new Date(v.inicio).getMinutes()}` }))
    .sort((a, b) => a.chave.localeCompare(b.chave) || a.v.criadoEm - b.v.criadoEm);
  const series = [];
  let chaveAnterior = null;
  for (const { v, chave } of avulsos) {
    const ultima = series[series.length - 1];
    const anterior = ultima?.[ultima.length - 1];
    if (anterior && chave === chaveAnterior && v.criadoEm - anterior.criadoEm <= 3000) ultima.push(v);
    else series.push([v]);
    chaveAnterior = chave;
  }
  /** Série do "a cada 15 dias": posições 0,1,2... (15·n a 15·n+6 dias do primeiro) e fora do ritmo de 14. */
  const ehSerie15 = (ordem) => {
    const base = diaDe(ordem[0].inicio);
    const offs = ordem.map((v) => Math.round((diaDe(v.inicio) - base) / DIA));
    return offs.every((d, i) => d >= 15 * i && d <= 15 * i + 6) && offs.some((d, i) => d !== 14 * i);
  };
  for (const serie of series.filter((x) => x.length >= 2)) {
    // um agendamento de fora criado junto (mesmo pet e hora) pode ter entrado no começo: tenta sem ele
    let ordem = null;
    for (let s0 = 0; s0 <= serie.length - 2 && !ordem; s0++) {
      const tentativa = serie.slice(s0).sort((a, b) => a.inicio - b.inicio);
      if (ehSerie15(tentativa)) ordem = tentativa;
    }
    if (!ordem) continue;
    ordem.forEach((v, n) => {
      if (!n || !EDITAVEIS.includes(v.status)) return;
      const alvo = new Date(ordem[0].inicio);
      alvo.setDate(alvo.getDate() + 14 * n);
      mover(v, diaDe(alvo.getTime()), 'quinzenal-repetir');
    });
  }

  // grava na ordem segura: agendamentos → planos → marca da correção
  if (mudados.size) await putVarios(STORES.agendamentos, [...mudados.values()]);
  if (planosParaAjustar.length) {
    await putVarios(STORES.planos, planosParaAjustar.map((p) => ({ ...p, intervalo: 14, intervaloAntes: Number(p.intervalo) || 15, atualizadoEm: Date.now() })));
  }
  await config.salvar('migracoes', {
    ...((await config.obter('migracoes')) || {}),
    quinzenal14: { em: Date.now(), planos: planosParaAjustar.length, banhos: lista.length, lista, naoMovidos },
  });
}

/**
 * Correção única (0.6.0): todos os banhos dos planos voltam ao ritmo do plano,
 * contando do 1º banho: a cada 7 dias (mensal) ou 14 dias (quinzenal), sempre no
 * mesmo dia da semana. Conserta as datas que as versões 0.5.7 e 0.5.8 deixaram
 * fora do ritmo (que a folha passou a mostrar como "só este mudou").
 *   - só mexe nos banhos que ainda não aconteceram (agendado/confirmado);
 *   - hoje e amanhã não mudam (o cliente já combinou): entram no aviso;
 *   - cada banho fica na hora dele, só o dia muda;
 *   - dia em que a loja não abre: não muda, entra no aviso;
 *   - horário que fica junto com outro agendamento: muda e entra no aviso.
 * Grava os agendamentos e depois a marca: se o app fechar no meio, roda de novo
 * e chega no mesmo resultado. A lista do que mudou fica para o aviso no sino.
 */
async function planosNoRitmo() {
  const migracoes = (await config.obter('migracoes')) || {};
  if (migracoes.ritmoDosPlanos) return;
  const DIA = 864e5;
  const diaDe = (ts) => { const d = new Date(ts); d.setHours(0, 0, 0, 0); return d.getTime(); };
  const hoje = diaDe(Date.now());
  const depoisDeAmanha = hoje + 2 * DIA;
  const exp = await config.expediente();
  const todasVisitas = await todos(STORES.agendamentos);
  const nomesPets = new Map((await todos(STORES.pets)).map((p) => [p.id, p.nome]));
  const mudados = new Map();
  const lista = [];
  const naoMovidos = [];
  const planosAcertados = [];

  for (const plano of await todos(STORES.planos)) {
    if (plano.excluidoEm || plano.encerradoEm || !plano.banhosPorMes) continue;
    const tipo = tipoDoPlano(plano);
    const porMes = TIPOS[tipo].banhosPorMes;
    const intervalo = limitarIntervalo(TIPOS[tipo].intervalo, tipo);
    // a folha conta pelo intervalo gravado no plano: tem que ser o do tipo
    if (Number(plano.intervalo) !== intervalo) planosAcertados.push({ ...plano, intervalo, atualizadoEm: Date.now() });
    const visitas = todasVisitas.filter((v) => v.planoId === plano.id && !v.excluidoEm).sort((a, b) => a.inicio - b.inicio);
    if (!visitas.length) continue;
    const posicao = (v, i) => (v.planoMes && v.planoBanho ? (v.planoMes - 1) * porMes + (v.planoBanho - 1) : i);
    // o 1º banho manda; sem ele (data que já tinha passado ao criar o plano), a data de início do plano
    const primeiro = visitas.find((v, i) => posicao(v, i) === 0);
    const base = diaDe(primeiro ? primeiro.inicio : plano.inicio);
    const pet = nomesPets.get(plano.petId) || 'Pet';
    visitas.forEach((v, i) => {
      const k = posicao(v, i);
      const flags = { planoManual: false, planoAncora: !!primeiro && v.id === primeiro.id && base !== diaDe(plano.inicio) };
      const alvoDia = new Date(base);
      alvoDia.setDate(alvoDia.getDate() + k * intervalo);
      const d = new Date(v.inicio);
      alvoDia.setHours(d.getHours(), d.getMinutes(), 0, 0);
      const ts = alvoDia.getTime();
      const editavel = EDITAVEIS.includes(v.status);
      const precisaMover = editavel && k > 0 && diaDe(ts) !== diaDe(v.inicio);
      if (precisaMover && (v.inicio < depoisDeAmanha || ts < depoisDeAmanha)) {
        naoMovidos.push({ pet, de: v.inicio, para: ts, motivo: 'é hoje ou amanhã' });
      } else if (precisaMover && !exp.dias.includes(alvoDia.getDay())) {
        naoMovidos.push({ pet, de: v.inicio, para: ts, motivo: 'a loja não abre no dia certo' });
      } else if (precisaMover) {
        mudados.set(v.id, { ...v, ...flags, inicio: ts, lembreteEnviadoEm: null, atualizadoEm: Date.now(), ritmoAntes: v.inicio });
        lista.push({ pet, de: v.inicio, para: ts, visitaId: v.id });
        return;
      }
      // fora isso, só acerta as marcas da folha (sem mudar a data)
      if (!!v.planoManual !== flags.planoManual || !!v.planoAncora !== flags.planoAncora) {
        mudados.set(v.id, { ...v, ...flags, atualizadoEm: Date.now() });
      }
    });
  }

  // horário junto com outro agendamento depois das mudanças: avisa (o Odilon decide)
  const final = todasVisitas.filter((v) => !v.excluidoEm && !['cancelado', 'nao_compareceu'].includes(v.status)).map((v) => mudados.get(v.id) || v);
  for (const item of lista) {
    const v = mudados.get(item.visitaId);
    const fim = v.inicio + (v.duracaoPrevistaMin || 60) * 60000;
    const outro = final.find((o) => o.id !== v.id && o.inicio < fim && o.inicio + (o.duracaoPrevistaMin || 60) * 60000 > v.inicio);
    if (outro) item.junto = nomesPets.get(outro.petId) || 'outro pet';
    delete item.visitaId;
  }

  if (mudados.size) await putVarios(STORES.agendamentos, [...mudados.values()]);
  if (planosAcertados.length) await putVarios(STORES.planos, planosAcertados);
  await config.salvar('migracoes', {
    ...((await config.obter('migracoes')) || {}),
    ritmoDosPlanos: { em: Date.now(), banhos: lista.length, lista, naoMovidos },
  });
}

/**
 * Correção única (0.6.4): a mensalidade passa a ser do mês do PACOTE (Mês 1, Mês 2...)
 * e não do mês do calendário. Cada pagamento já registrado ("2026-10") vai para o mês
 * do pacote do banho em que foi cobrado (o banho 1-1 → "pacote-1"). Se dois pagamentos
 * caírem no mesmo mês do pacote, o segundo vai para o próximo mês livre (pagamento
 * adiantado): nenhum valor some nem muda. Os pagamentos como estavam ficam guardados
 * no plano (pagamentosAntes). Grava os planos e depois a marca.
 */
async function mensalidadePorPacote() {
  const migracoes = (await config.obter('migracoes')) || {};
  if (migracoes.mensalidadePorPacote) return;
  const visitas = (await todos(STORES.agendamentos)).filter((v) => v.planoId && !v.excluidoEm);
  const lista = [];
  const mudados = [];
  for (const plano of await todos(STORES.planos)) {
    const antigos = Object.entries(plano.pagamentos || {}).filter(([k, v]) => v && ehChaveAntiga(k));
    if (!antigos.length) continue;
    const doPlano = visitas.filter((v) => v.planoId === plano.id).sort((a, b) => a.inicio - b.inicio);
    const porMes = TIPOS[tipoDoPlano(plano)].banhosPorMes;
    const meses = limitarMeses(plano.meses || 1);
    const datas = datasDasMensalidades({ ...plano, pagamentos: {} }, doPlano);
    const novos = Object.fromEntries(Object.entries(plano.pagamentos || {}).filter(([k, v]) => v && !ehChaveAntiga(k)));
    const ocupado = (n) => !!novos[chaveDaMensalidade(n)];
    antigos.sort(([a, x], [b, y]) => (x.cobradoEm ?? x.pagoEm ?? 0) - (y.cobradoEm ?? y.pagoEm ?? 0) || (a < b ? -1 : 1));
    for (const [antiga, pg] of antigos) {
      // mês do pacote do banho que cobrou; sem ele, o mês do pacote que cobra naquele mês do calendário
      const i = doPlano.findIndex((v) => v.inicio === pg.cobradoEm);
      let n = i >= 0 ? doPlano[i].planoMes || Math.floor(i / porMes) + 1 : datas.find((d) => chaveDoMes(d.ts) === antiga)?.k || null;
      if (!n || n > meses || ocupado(n)) {
        let livre = n && n <= meses ? n : 1;
        while (livre <= meses && ocupado(livre)) livre++;
        n = livre <= meses ? livre : null;
      }
      if (!n) { novos[antiga] = pg; continue; } // sem mês livre: fica como estava (continua contando)
      novos[chaveDaMensalidade(n)] = { ...pg, mesAntigo: antiga };
      lista.push({ planoId: plano.id, de: antiga, para: n });
    }
    mudados.push({ ...plano, pagamentos: novos, pagamentosAntes: plano.pagamentos, atualizadoEm: Date.now() });
  }
  if (mudados.length) await putVarios(STORES.planos, mudados);
  await config.salvar('migracoes', { ...((await config.obter('migracoes')) || {}), mensalidadePorPacote: { em: Date.now(), planos: mudados.length, lista } });
}

/**
 * Ajuste único (0.6.5): o horário que o Odilon informou (áudio de 03/11/2026) —
 * seg a sex 08:00 às 18:00 com almoço 12:00 às 14:00, sábado 08:00 às 12:30.
 * Só quando o quadro de horários ainda não foi salvo e o texto do expediente é o
 * que estava no app dele ("Seg a Sex 08:00 às 18:00 · Sab 08:00 às 12:00"). Se ele
 * já mexeu no horário, nada muda.
 */
async function horarioInformado() {
  const migracoes = (await config.obter('migracoes')) || {};
  if (migracoes.horarioInformado) return;
  const loja = await config.obter('loja');
  const lido = lerHorarios(loja.expediente);
  const igualAoDele = textoDoExpediente(lido) === 'Seg a sex · 08:00 às 18:00 · Sáb · 08:00 às 12:00';
  let aplicado = false;
  if (!loja.horarios && igualAoDele) {
    const horarios = lido.map((h, d) => (d >= 1 && d <= 5 ? { ...h, pausaDe: 720, pausaAte: 840 } : d === 6 ? { ...h, fecha: 750 } : h));
    await config.atualizar('loja', { horarios, expediente: textoDoExpediente(horarios), expedienteAntes: loja.expediente });
    aplicado = true;
  }
  await config.salvar('migracoes', { ...((await config.obter('migracoes')) || {}), horarioInformado: { em: Date.now(), aplicado } });
}

/**
 * Organização única (0.8.0): cada serviço do catálogo passa a ser BANHO ou COMPLEMENTO (campo `papel`).
 * O banho é o atendimento (tem o preço e o tempo); complemento entra com o valor, quase sempre R$ 0,
 * e não soma tempo. Não pelo nome: é banho o serviço de preço BASE de R$ 40 ou mais (o preço por porte
 * da linha Hydra passa disso nos cães grandes e não conta) ou que já foi usado sozinho em 3 atendimentos
 * ou mais (uma vez só pode ser um complemento agendado à parte); o resto é complemento. Na dúvida fica
 * complemento: o erro é inofensivo (só deixa de somar tempo) e se troca em Serviços. Quem já tem
 * `papel` não muda. A lista do que ficou em cada lado vai para o aviso no sino, para o Odilon conferir.
 */
async function organizarBanhoEComplementos() {
  const migracoes = (await config.obter('migracoes')) || {};
  if (migracoes.servicosPapel) return;
  const sem = (await todos(STORES.servicos)).filter((sv) => !sv.excluidoEm && !sv.papel);
  const vivos = new Set((await todos(STORES.agendamentos)).filter((a) => !a.excluidoEm).map((a) => a.id));
  const porAg = new Map();
  for (const i of await todos(STORES.itens)) {
    if (!vivos.has(i.agendamentoId)) continue;
    if (!porAg.has(i.agendamentoId)) porAg.set(i.agendamentoId, []);
    porAg.get(i.agendamentoId).push(i);
  }
  const sozinho = new Map();
  for (const lista of porAg.values()) if (lista.length === 1 && lista[0].servicoId) sozinho.set(lista[0].servicoId, (sozinho.get(lista[0].servicoId) || 0) + 1);
  const banhos = [];
  const complementos = [];
  const mudados = sem.map((sv) => {
    const banho = (sozinho.get(sv.id) || 0) >= 3 || (sv.precoCentavos || 0) >= 4000;
    (banho ? banhos : complementos).push(sv.nome);
    return { ...sv, papel: banho ? 'banho' : 'complemento' };
  });
  if (mudados.length) await putVarios(STORES.servicos, mudados);
  await config.salvar('migracoes', { ...((await config.obter('migracoes')) || {}), servicosPapel: { em: Date.now(), banhos, complementos } });
}

/**
 * Correção única (0.8.0): o tempo previsto das visitas que ainda não aconteceram (e o tempo de cada
 * plano) somava a duração de referência de TODOS os serviços; com 30 min em cada complemento chegava a
 * 4h20 por banho. Passa a valer a estimativa do atendimento: a média dos atendimentos do pet, a de
 * pets parecidos, ou o tempo de referência só do banho. Mexe só em duracaoPrevistaMin / duracaoMin
 * (visitas agendadas, confirmadas ou rascunho, de hoje em diante) e só REDUZ o que estava acima do
 * estimado: um tempo menor, que o Odilon possa ter digitado à mão, não é tocado. Grava visitas, planos e
 * por último a marca.
 */
async function tempoPrevistoSoDoBanho() {
  const migracoes = (await config.obter('migracoes')) || {};
  if (migracoes.tempoPrevisto) return;
  const catalogo = new Map((await todos(STORES.servicos)).map((sv) => [sv.id, sv]));
  const petsTodos = await todos(STORES.pets);
  const todasVisitas = await todos(STORES.agendamentos);
  const itensPorAg = new Map();
  for (const i of await todos(STORES.itens)) {
    if (!itensPorAg.has(i.agendamentoId)) itensPorAg.set(i.agendamentoId, []);
    itensPorAg.get(i.agendamentoId).push(i);
  }
  // histórico de tempo por pet: o atendimento inteiro (ou, em dados antigos, a soma dos serviços)
  const minutosDe = (a) => {
    if (Number.isFinite(a.duracaoRealMin)) return a.duracaoRealMin;
    const soma = (itensPorAg.get(a.id) || []).reduce((t, i) => t + (Number.isFinite(i.duracaoRealMin) ? i.duracaoRealMin : 0), 0);
    return soma > 0 ? soma : null;
  };
  const historico = new Map();
  for (const a of todasVisitas) {
    if (a.excluidoEm || a.status !== 'concluido' || a.usarNaMedia === false) continue;
    const m = minutosDe(a);
    if (!(m > 0)) continue;
    if (!historico.has(a.petId)) historico.set(a.petId, []);
    historico.get(a.petId).push({ ts: a.chegadaEm || a.inicio, duracaoRealMin: m });
  }
  for (const lista of historico.values()) lista.sort((x, y) => y.ts - x.ts);
  const estimar = (petId, fallbackMin) => {
    const pet = petsTodos.find((p) => p.id === petId);
    const doPet = historico.get(petId) || [];
    const semelhantes = [];
    if (pet && doPet.length < MINIMO_AMOSTRAS) {
      for (const outro of petsTodos) {
        if (outro.id === petId || outro.excluidoEm || outro.porte !== pet.porte || outro.especie !== pet.especie) continue;
        semelhantes.push(...(historico.get(outro.id) || []));
        if (semelhantes.length >= JANELA_HISTORICO * 2) break;
      }
    }
    return estimarDuracao(doPet, semelhantes, { duracaoPadraoMin: fallbackMin }).minutos;
  };
  const referenciaDe = (ids) => duracaoDeReferencia((ids || []).map((id) => catalogo.get(id)).filter(Boolean));

  const hoje = new Date();
  hoje.setHours(0, 0, 0, 0);
  const abertas = ['agendado', 'confirmado', 'rascunho_plano'];
  const visitasMudadas = [];
  const antes = [];
  const depois = [];
  for (const a of todasVisitas) {
    if (a.excluidoEm || !abertas.includes(a.status) || a.inicio < hoje.getTime()) continue;
    const ref = referenciaDe((itensPorAg.get(a.id) || []).map((i) => i.servicoId).filter(Boolean));
    const novo = estimar(a.petId, ref);
    antes.push(a.duracaoPrevistaMin || 0);
    // só reduz o que estava acima do estimado (o inflado pela soma dos serviços); tempo menor fica como está
    const alvo = a.duracaoPrevistaMin > novo ? novo : a.duracaoPrevistaMin;
    depois.push(alvo);
    if (alvo !== a.duracaoPrevistaMin) visitasMudadas.push({ ...a, duracaoPrevistaMin: alvo });
  }
  const planosMudados = [];
  for (const plano of await todos(STORES.planos)) {
    if (plano.excluidoEm || plano.encerradoEm) continue;
    const novo = estimar(plano.petId, referenciaDe(plano.servicos));
    if (plano.duracaoMin > novo) planosMudados.push({ ...plano, duracaoMin: novo });
  }
  const mediana = (xs) => (xs.length ? [...xs].sort((x, y) => x - y)[Math.floor(xs.length / 2)] : null);
  if (visitasMudadas.length) await putVarios(STORES.agendamentos, visitasMudadas);
  if (planosMudados.length) await putVarios(STORES.planos, planosMudados);
  await config.salvar('migracoes', {
    ...((await config.obter('migracoes')) || {}),
    tempoPrevisto: { em: Date.now(), visitas: visitasMudadas.length, planos: planosMudados.length, medianaAntes: mediana(antes), medianaDepois: mediana(depois) },
  });
}

export async function prepararPrimeiroUso() {
  const existentes = await todos(STORES.servicos);
  if (!existentes.length) {
    const agora = Date.now();
    await putVarios(
      STORES.servicos,
      CATALOGO.map((s, ordem) => ({ ...s, id: uuid(), ativo: true, ordem, precoPorPorte: {}, criadoEm: agora }))
    );
  }
  await zerarPrecosDeExemplo();
  await adicionarBoleto();
  await quinzenalACadaDuasSemanas();
  await planosNoRitmo();
  await mensalidadePorPacote();
  await horarioInformado();
  await organizarBanhoEComplementos();
  await tempoPrevistoSoDoBanho();
  const perfil = await config.obter('perfil');
  if (!perfil.desde) await config.salvar('perfil', { ...perfil, desde: Date.now() });
}
