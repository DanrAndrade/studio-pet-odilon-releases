import { STORES, todos, putVarios, uuid } from './db.js';
import * as config from './config.js';
import { montarBanhos, chaveBanho, tipoDoPlano, limitarMeses, EDITAVEIS } from '../logic/planos.js';

/* Primeiro uso: catálogo inicial com os serviços mais comuns, SEM preço: o
   Odilon cadastra os dele em Serviços. Os tempos reais vêm dos cronômetros. */

const CATALOGO = [
  { nome: 'Banho', categoria: 'Banho', precoCentavos: 0, duracaoPadraoMin: 30, cor: '#5b32e0' },
  { nome: 'Tosa completa', categoria: 'Tosa', precoCentavos: 0, duracaoPadraoMin: 60, cor: '#8b7bee' },
  { nome: 'Tosa higiênica', categoria: 'Tosa', precoCentavos: 0, duracaoPadraoMin: 25, cor: '#f0339b' },
  { nome: 'Hidratação', categoria: 'Estética', precoCentavos: 0, duracaoPadraoMin: 15, cor: '#bd991f' },
  { nome: 'Corte de unhas', categoria: 'Adicional', precoCentavos: 0, duracaoPadraoMin: 10, cor: '#37b881' },
];

// preços de exemplo que as versões até a 0.5.3 traziam de fábrica
const PRECOS_DE_EXEMPLO = new Map([
  ['Banho', 7000], ['Tosa completa', 15000], ['Tosa higiênica', 4500], ['Hidratação', 6000], ['Corte de unhas', 2500],
]);

/**
 * Correção única (0.5.4): zera os preços de exemplo que vieram de fábrica e o
 * Odilon não cadastrou. Conta como de exemplo o serviço nunca editado por ele
 * (registro sem atualizadoEm) ou que continua com o valor de exemplo exato e
 * sem preço por porte. O preço antigo fica guardado em precoExemploCentavos.
 * Só mexe no catálogo: atendimentos e agendamentos ficam como estão.
 */
async function zerarPrecosDeExemplo() {
  const migracoes = (await config.obter('migracoes')) || {};
  if (migracoes.precosDeExemplo) return;
  const zerados = [];
  for (const s of await todos(STORES.servicos)) {
    if (s.excluidoEm || !s.precoCentavos) continue;
    const exemplo = PRECOS_DE_EXEMPLO.get(s.nome);
    if (exemplo === undefined) continue;
    const temPorPorte = Object.values(s.precoPorPorte || {}).some(Boolean);
    const nuncaEditado = !s.atualizadoEm;
    const aindaDeExemplo = s.precoCentavos === exemplo && !temPorPorte;
    if (!nuncaEditado && !aindaDeExemplo) continue;
    await putVarios(STORES.servicos, [{ ...s, precoCentavos: 0, precoExemploCentavos: s.precoCentavos }]);
    zerados.push(s.nome);
  }
  await config.salvar('migracoes', { ...migracoes, precosDeExemplo: { em: Date.now(), servicos: zerados } });
}

/** Correção única (0.5.6): "Boleto" entra nas formas de pagamento de quem já usa o app. */
async function adicionarBoleto() {
  const migracoes = (await config.obter('migracoes')) || {};
  if (migracoes.boleto) return;
  const listas = (await config.obter('listas')) || {};
  const formas = listas['Formas de pagamento'];
  if (Array.isArray(formas) && !formas.some((f) => f.trim().toLowerCase() === 'boleto')) {
    const antes = formas.findIndex((f) => f === 'Fiado' || f === 'Incluso no plano');
    const nova = [...formas];
    nova.splice(antes < 0 ? nova.length : antes, 0, 'Boleto');
    await config.salvarLista('Formas de pagamento', nova);
  }
  await config.salvar('migracoes', { ...((await config.obter('migracoes')) || {}), boleto: Date.now() });
}

/**
 * Correção única (0.5.8): quinzenal passa a ser a cada 2 semanas (14 dias, mesmo
 * dia da semana), não 15. Move para o dia certo os banhos de plano quinzenal e
 * os agendamentos criados com "repetir a cada 15 dias" que:
 *   - ainda não aconteceram e são daqui a 7 dias ou mais (o que o cliente já
 *     combinou para esta semana não muda), tanto a data de antes quanto a nova;
 *   - estavam na data automática (o dia; a hora de cada um é mantida);
 *   - vão para um dia em que a loja abre e um horário livre.
 * O resto fica como está (aparece como "data própria" na folha do plano).
 * Grava primeiro os agendamentos, depois os planos e por último a marca da
 * correção: se o app fechar no meio, ela roda de novo sem estragar nada.
 * A lista do que mudou fica guardada para o aviso no sino.
 */
async function quinzenalACadaDuasSemanas() {
  const migracoes = (await config.obter('migracoes')) || {};
  if (migracoes.quinzenal14) return;
  const DIA = 864e5;
  const diaDe = (ts) => { const d = new Date(ts); d.setHours(0, 0, 0, 0); return d.getTime(); };
  const limite = diaDe(Date.now()) + 7 * DIA;
  const exp = await config.expediente();
  const todasVisitas = await todos(STORES.agendamentos);
  const vivas = todasVisitas.filter((v) => !v.excluidoEm && !['cancelado', 'nao_compareceu'].includes(v.status));
  const nomesPets = new Map((await todos(STORES.pets)).map((p) => [p.id, p.nome]));
  const mudados = new Map();
  const lista = [];
  const naoMovidos = [];

  /** Leva `v` para o dia `diaNovo` (mesma hora), se puder. */
  const mover = (v, diaNovo, motivo) => {
    const d = new Date(v.inicio);
    const alvo = new Date(diaNovo);
    alvo.setHours(d.getHours(), d.getMinutes(), 0, 0);
    const ts = alvo.getTime();
    if (ts === v.inicio) return;
    if (v.inicio < limite || ts < limite) return;
    const fim = ts + (v.duracaoPrevistaMin || 60) * 60000;
    const ocupado = vivas.some((o) => o.id !== v.id && !mudados.has(o.id) && o.inicio < fim && o.inicio + (o.duracaoPrevistaMin || 60) * 60000 > ts)
      || [...mudados.values()].some((o) => o.id !== v.id && o.inicio < fim && o.inicio + (o.duracaoPrevistaMin || 60) * 60000 > ts);
    const fechado = !exp.dias.includes(alvo.getDay());
    if (ocupado || fechado) {
      naoMovidos.push({ pet: nomesPets.get(v.petId) || 'Pet', de: v.inicio, motivo: fechado ? 'a loja não abre no dia certo' : 'horário ocupado no dia certo' });
      return;
    }
    mudados.set(v.id, { ...v, inicio: ts, lembreteEnviadoEm: null, atualizadoEm: Date.now(), quinzenalAntes: v.inicio, motivoAjuste: motivo });
    lista.push({ pet: nomesPets.get(v.petId) || 'Pet', de: v.inicio, para: ts });
  };

  // 1) planos quinzenais
  const planosParaAjustar = [];
  for (const plano of await todos(STORES.planos)) {
    if (tipoDoPlano(plano) !== 'Quinzenal' || Number(plano.intervalo) === 14) continue;
    planosParaAjustar.push(plano);
    if (plano.excluidoEm || plano.encerradoEm) continue;
    const intervaloAntigo = Number(plano.intervalo) || 15;
    const visitas = todasVisitas.filter((v) => v.planoId === plano.id && !v.excluidoEm).sort((a, b) => a.inicio - b.inicio);
    const chaveDe = (v, i) => chaveBanho(v.planoMes || Math.floor(i / 2) + 1, v.planoBanho || (i % 2) + 1);
    const cfg = { tipo: 'Quinzenal', meses: limitarMeses(plano.meses || 1), inicio: plano.inicio, hora: plano.hora };
    // padrão antigo sem pontos de partida: um "ponto de partida" que está no próprio dia do
    // padrão (só a hora foi trocada) não conta como mudança de dia
    const semAncora = new Map(montarBanhos({ ...cfg, intervalo: intervaloAntigo }).map((l) => [l.chave, diaDe(l.padrao)]));
    const ancoras = new Map();
    visitas.forEach((v, i) => {
      const chave = chaveDe(v, i);
      if (v.planoAncora && diaDe(v.inicio) !== semAncora.get(chave)) ancoras.set(chave, { ts: v.inicio, ancora: true });
    });
    const antes = new Map(montarBanhos({ ...cfg, intervalo: intervaloAntigo }, ancoras).map((l) => [l.chave, diaDe(l.padrao)]));
    const depois = new Map(montarBanhos({ ...cfg, intervalo: 14 }, ancoras).map((l) => [l.chave, diaDe(l.padrao)]));
    visitas.forEach((v, i) => {
      const chave = chaveDe(v, i);
      if (!EDITAVEIS.includes(v.status) || ancoras.has(chave)) return;
      // só o que está no dia automático antigo (a hora pode ter sido trocada)
      if (antes.get(chave) !== diaDe(v.inicio) || !Number.isFinite(depois.get(chave))) return;
      mover(v, depois.get(chave), 'quinzenal-plano');
    });
  }

  // 2) agendamentos avulsos criados com "repetir a cada 15 dias" (0.5.7, desde 20/10/2026):
  // mesmo pet, mesmo horário, criados juntos (segundos). Cada um vai para
  // primeiro + 14 × n, onde n é a posição dele na série (15·n a 15·n+6 dias do primeiro).
  const DESDE = new Date(2026, 9, 19).getTime();
  const avulsos = todasVisitas
    .filter((v) => !v.planoId && !v.excluidoEm && (v.criadoEm || 0) >= DESDE)
    .map((v) => ({ v, chave: `${v.petId}|${new Date(v.inicio).getHours()}:${new Date(v.inicio).getMinutes()}` }))
    .sort((a, b) => a.chave.localeCompare(b.chave) || a.v.criadoEm - b.v.criadoEm);
  const series = [];
  let chaveAnterior = null;
  for (const { v, chave } of avulsos) {
    const ultima = series[series.length - 1];
    const anterior = ultima?.[ultima.length - 1];
    if (anterior && chave === chaveAnterior && v.criadoEm - anterior.criadoEm <= 3000) ultima.push(v);
    else series.push([v]);
    chaveAnterior = chave;
  }
  /** Série do "a cada 15 dias": posições 0,1,2... (15·n a 15·n+6 dias do primeiro) e fora do ritmo de 14. */
  const ehSerie15 = (ordem) => {
    const base = diaDe(ordem[0].inicio);
    const offs = ordem.map((v) => Math.round((diaDe(v.inicio) - base) / DIA));
    return offs.every((d, i) => d >= 15 * i && d <= 15 * i + 6) && offs.some((d, i) => d !== 14 * i);
  };
  for (const serie of series.filter((x) => x.length >= 2)) {
    // um agendamento de fora criado junto (mesmo pet e hora) pode ter entrado no começo: tenta sem ele
    let ordem = null;
    for (let s0 = 0; s0 <= serie.length - 2 && !ordem; s0++) {
      const tentativa = serie.slice(s0).sort((a, b) => a.inicio - b.inicio);
      if (ehSerie15(tentativa)) ordem = tentativa;
    }
    if (!ordem) continue;
    ordem.forEach((v, n) => {
      if (!n || !EDITAVEIS.includes(v.status)) return;
      const alvo = new Date(ordem[0].inicio);
      alvo.setDate(alvo.getDate() + 14 * n);
      mover(v, diaDe(alvo.getTime()), 'quinzenal-repetir');
    });
  }

  // grava na ordem segura: agendamentos → planos → marca da correção
  if (mudados.size) await putVarios(STORES.agendamentos, [...mudados.values()]);
  if (planosParaAjustar.length) {
    await putVarios(STORES.planos, planosParaAjustar.map((p) => ({ ...p, intervalo: 14, intervaloAntes: Number(p.intervalo) || 15, atualizadoEm: Date.now() })));
  }
  await config.salvar('migracoes', {
    ...((await config.obter('migracoes')) || {}),
    quinzenal14: { em: Date.now(), planos: planosParaAjustar.length, banhos: lista.length, lista, naoMovidos },
  });
}

export async function prepararPrimeiroUso() {
  const existentes = await todos(STORES.servicos);
  if (!existentes.length) {
    const agora = Date.now();
    await putVarios(
      STORES.servicos,
      CATALOGO.map((s, ordem) => ({ ...s, id: uuid(), ativo: true, ordem, precoPorPorte: {}, criadoEm: agora }))
    );
  }
  await zerarPrecosDeExemplo();
  await adicionarBoleto();
  await quinzenalACadaDuasSemanas();
  const perfil = await config.obter('perfil');
  if (!perfil.desde) await config.salvar('perfil', { ...perfil, desde: Date.now() });
}
