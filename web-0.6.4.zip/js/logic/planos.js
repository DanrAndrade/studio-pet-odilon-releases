import { inicioDoDia, comHora, addDias, fmtData, fmtHora } from '../core/dom.js';

/* Planos (pacotes), no formato do contrato em papel do Odilon:
     Mês 1 — 1º banho, 2º banho, 3º banho, 4º banho
     Mês 2 — ...
   Mensal = 4 banhos por mês (a cada 7 dias); Quinzenal = 2 banhos por mês (a
   cada 2 semanas = 14 dias, sempre no mesmo dia da semana: quarta sim, quarta não). O Odilon escolhe a primeira data e o app preenche as outras
   com o intervalo; qualquer data pode ser trocada à mão sem mexer nas demais.
   "Seguir daqui" faz as datas seguintes continuarem a partir de uma data trocada.
   O valor é fechado por mês (mensalidade): os banhos do pacote não têm preço. */

export const TIPOS = {
  Mensal: { banhosPorMes: 4, intervalo: 7, descricao: '4 banhos por mês' },
  Quinzenal: { banhosPorMes: 2, intervalo: 14, descricao: '2 banhos por mês' },
};
// o Odilon trabalha com planos de até 6 meses (o limite maior só protege planos antigos)
export const VIGENCIAS = [1, 2, 3, 4, 5, 6];
export const MESES_MAX = 24;
export const INTERVALO_MAX = 60;

/** Situações da visita que o plano não pode mais mexer. */
export const EDITAVEIS = ['agendado', 'confirmado', 'rascunho_plano'];

export function limitarMeses(n) {
  return Math.min(Math.max(parseInt(n, 10) || 1, 1), MESES_MAX);
}

export function limitarIntervalo(n, tipo) {
  const v = parseInt(n, 10);
  return Number.isFinite(v) && v >= 1 ? Math.min(v, INTERVALO_MAX) : TIPOS[tipo]?.intervalo || 7;
}

/** Planos antigos (Semanal, Mensal por dia...) viram um dos dois pacotes. */
export function tipoDoPlano(plano) {
  if (TIPOS[plano?.tipo]) return plano.tipo;
  return plano?.tipo === 'Quinzenal' ? 'Quinzenal' : 'Mensal';
}

/** Plano valendo agora: não pausado, não encerrado e dentro da vigência. */
export function planoVigente(plano, agora = Date.now()) {
  if (!plano || plano.ativo === false || plano.encerradoEm) return false;
  const fim = fimDoPlano(plano);
  return !fim || fim > agora;
}

export const banhosPorMes = (plano) => TIPOS[tipoDoPlano(plano)].banhosPorMes;

/** Soma meses mantendo o dia (31/01 + 1 mês = 28/02 ou 29/02). */
export function addMeses(ts, meses) {
  const d = new Date(ts);
  const dia = d.getDate();
  d.setDate(1);
  d.setMonth(d.getMonth() + meses);
  d.setDate(Math.min(dia, new Date(d.getFullYear(), d.getMonth() + 1, 0).getDate()));
  return d.getTime();
}

/** Fim da vigência (exclusivo): encerramento antecipado ou início + meses. */
export function fimDoPlano(plano) {
  if (plano.fim) return plano.fim;
  if (!plano.meses) return null;
  return addMeses(inicioDoDia(plano.inicio || Date.now()), limitarMeses(plano.meses));
}

export const chaveBanho = (mes, banho) => `${mes}-${banho}`;
export const rotuloBanho = (banho) => `${banho}º banho`;

/**
 * Monta a folha do pacote: uma linha por banho, com a data de cada um.
 * @param {object} cfg   { tipo, meses, inicio (ts do 1º banho), intervalo (dias), hora 'HH:MM' }
 * @param {Map}    fixas chave "mes-banho" → { ts, manual, ancora, travado, agId, status }
 *   - travado: visita que já aconteceu/cancelou: a data fica como está
 *   - manual: data trocada à mão: fica como está, as outras seguem o padrão
 *   - ancora: data trocada com "este e os seguintes": as seguintes contam a partir
 *     dela, na mesma hora dela
 * @returns {{mes, banho, chave, indice, ts, padrao, manual, ancora, travado, agId, status}[]}
 */
export function montarBanhos(cfg, fixas = new Map()) {
  const porMes = TIPOS[cfg.tipo]?.banhosPorMes || 4;
  const intervalo = limitarIntervalo(cfg.intervalo, cfg.tipo);
  const total = limitarMeses(cfg.meses) * porMes;
  let ancora = { indice: 0, dia: inicioDoDia(cfg.inicio || Date.now()), hora: cfg.hora };
  const linhas = [];
  for (let indice = 0; indice < total; indice++) {
    const mes = Math.floor(indice / porMes) + 1;
    const banho = (indice % porMes) + 1;
    const chave = chaveBanho(mes, banho);
    const fixa = fixas.get(chave) || {};
    if (fixa.ancora && Number.isFinite(fixa.ts)) ancora = { indice, dia: inicioDoDia(fixa.ts), hora: fmtHora(fixa.ts) };
    const padrao = comHora(addDias(ancora.dia, (indice - ancora.indice) * intervalo), ancora.hora);
    const manterData = Number.isFinite(fixa.ts) && (fixa.travado || fixa.manual || fixa.ancora);
    linhas.push({
      mes,
      banho,
      chave,
      indice,
      ts: manterData ? fixa.ts : padrao,
      padrao,
      manual: !fixa.travado && !!(fixa.manual || fixa.ancora) && fixa.ts !== padrao,
      ancora: !!fixa.ancora,
      travado: !!fixa.travado,
      agId: fixa.agId || null,
      status: fixa.status || null,
    });
  }
  return linhas;
}

/** "Mensal · 4 banhos por mês" — a linha da lista de planos. */
export function recorrenciaCurta(plano) {
  const tipo = tipoDoPlano(plano);
  const hora = plano.hora ? ` · ${plano.hora}` : '';
  return `${tipo} · ${TIPOS[tipo].descricao}${hora}`;
}

/** "6 meses · até 17/03/2027" */
export function descricaoVigencia(plano) {
  const fim = fimDoPlano(plano);
  if (!fim) return plano.repeticoes ? `${plano.repeticoes} visitas` : '';
  const meses = plano.meses ? `${plano.meses} ${Number(plano.meses) === 1 ? 'mês' : 'meses'} · ` : '';
  return `${meses}${plano.encerradoEm ? 'encerrado em' : 'até'} ${fmtData(fim - 1)}`;
}

/** "A cada 7 dias, às 10:00" — resumo do pacote. */
export function resumoRecorrencia(plano) {
  const tipo = tipoDoPlano(plano);
  const dias = limitarIntervalo(plano.intervalo, tipo);
  return `A cada ${dias} ${dias === 1 ? 'dia' : 'dias'}${plano.hora ? ', às ' + plano.hora : ''}`;
}

/** Hora "HH:MM" de um timestamp (para os campos de hora da folha). */
export const horaDe = (ts) => fmtHora(ts);

/* ------------------------------ Mensalidades ------------------------------ */
/* A mensalidade é cobrada no 1º banho de cada MÊS DO PACOTE (Mês 1, Mês 2... da
   folha): os 4 banhos (mensal) ou 2 (quinzenal) de um mês do pacote são um pacote
   só, mesmo que passem de um mês do calendário para o outro. Se o 1º banho do mês
   do pacote foi cancelado ou o pet faltou, cobra no seguinte do mesmo mês do pacote.
   Chave do pagamento: "pacote-N" (N = número do mês do pacote). */

export const chaveDoMes = (ts) => {
  const d = new Date(ts);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
};

/** Chave da mensalidade do mês N do pacote. */
export const chaveDaMensalidade = (n) => `pacote-${n}`;
/** Número do mês do pacote de uma chave ("pacote-2" → 2); chave antiga (mês do calendário) → null. */
export const numeroDaMensalidade = (chave) => {
  const m = /^pacote-(\d+)$/.exec(String(chave || ''));
  return m ? Number(m[1]) : null;
};
/** Chave antiga, por mês do calendário ("2026-10"), das versões até a 0.6.3. */
export const ehChaveAntiga = (chave) => /^\d{4}-\d{2}$/.test(String(chave || ''));

const NAO_VEIO = ['cancelado', 'nao_compareceu'];

/**
 * Datas de cobrança do plano: [{ k, mes: "pacote-k", ts }], uma por mês do pacote.
 * Usa os banhos agendados; mês do pacote sem banho na agenda (datas que já tinham
 * passado quando o plano foi criado) usa a data da folha. Banhos excluídos da agenda
 * depois de criado o plano não geram cobrança numa data sem banho.
 */
export function datasDasMensalidades(plano, visitas = []) {
  const tipo = tipoDoPlano(plano);
  const porMes = TIPOS[tipo].banhosPorMes;
  const meses = limitarMeses(plano.meses || 1);
  const vivas = visitas.filter((v) => !v.excluidoEm).sort((a, b) => a.inicio - b.inicio);
  const porPacote = new Map();
  vivas.forEach((v, i) => {
    const mes = v.planoMes || Math.floor(i / porMes) + 1;
    const banho = v.planoBanho || (i % porMes) + 1;
    if (!porPacote.has(mes)) porPacote.set(mes, []);
    porPacote.get(mes).push({ banho, ts: v.inicio, veio: !NAO_VEIO.includes(v.status) });
  });
  const folha = montarBanhos({
    tipo, meses, inicio: plano.inicio || plano.criadoEm || Date.now(), intervalo: plano.intervalo ?? TIPOS[tipo].intervalo, hora: plano.hora,
  });
  // banho da folha que não entrou na agenda porque a data já tinha passado quando o plano
  // foi criado: conta com a data da folha (é um banho do pacote). Banho excluído da agenda
  // depois não conta.
  const criadoEm = plano.criadoEm || Infinity;
  for (const l of folha) {
    if (l.padrao >= criadoEm) continue;
    const doMes = porPacote.get(l.mes) || [];
    if (doMes.some((b) => b.banho === l.banho)) continue;
    doMes.push({ banho: l.banho, ts: l.padrao, veio: true });
    porPacote.set(l.mes, doMes);
  }
  const saida = [];
  for (let k = 1; k <= meses; k++) {
    const banhos = (porPacote.get(k) || []).sort((a, b) => a.banho - b.banho || a.ts - b.ts);
    if (!banhos.length) continue;
    const ts = (banhos.find((b) => b.veio) || banhos[0]).ts;
    if (Number.isFinite(ts)) saida.push({ k, mes: chaveDaMensalidade(k), ts });
  }
  return saida;
}
