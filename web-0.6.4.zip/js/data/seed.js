import { STORES, todos, putVarios, uuid } from './db.js';
import * as config from './config.js';
import { montarBanhos, chaveBanho, tipoDoPlano, limitarMeses, limitarIntervalo, EDITAVEIS, TIPOS, datasDasMensalidades, chaveDaMensalidade, ehChaveAntiga, chaveDoMes } from '../logic/planos.js';

/* Primeiro uso: catálogo inicial com os serviços mais comuns, SEM preço: o
   Odilon cadastra os dele em Serviços. Os tempos reais vêm dos cronômetros. */

const CATALOGO = [
  { nome: 'Banho', categoria: 'Banho', precoCentavos: 0, duracaoPadraoMin: 30, cor: '#5b32e0' },
  { nome: 'Tosa completa', categoria: 'Tosa', precoCentavos: 0, duracaoPadraoMin: 60, cor: '#8b7bee' },
  { nome: 'Tosa higiênica', categoria: 'Tosa', precoCentavos: 0, duracaoPadraoMin: 25, cor: '#f0339b' },
  { nome: 'Hidratação', categoria: 'Estética', precoCentavos: 0, duracaoPadraoMin: 15, cor: '#bd991f' },
  { nome: 'Corte de unhas', categoria: 'Adicional', precoCentavos: 0, duracaoPadraoMin: 10, cor: '#37b881' },
];

// preços de exemplo que as versões até a 0.5.3 traziam de fábrica
const PRECOS_DE_EXEMPLO = new Map([
  ['Banho', 7000], ['Tosa completa', 15000], ['Tosa higiênica', 4500], ['Hidratação', 6000], ['Corte de unhas', 2500],
]);

/**
 * Correção única (0.5.4): zera os preços de exemplo que vieram de fábrica e o
 * Odilon não cadastrou. Conta como de exemplo o serviço nunca editado por ele
 * (registro sem atualizadoEm) ou que continua com o valor de exemplo exato e
 * sem preço por porte. O preço antigo fica guardado em precoExemploCentavos.
 * Só mexe no catálogo: atendimentos e agendamentos ficam como estão.
 */
async function zerarPrecosDeExemplo() {
  const migracoes = (await config.obter('migracoes')) || {};
  if (migracoes.precosDeExemplo) return;
  const zerados = [];
  for (const s of await todos(STORES.servicos)) {
    if (s.excluidoEm || !s.precoCentavos) continue;
    const exemplo = PRECOS_DE_EXEMPLO.get(s.nome);
    if (exemplo === undefined) continue;
    const temPorPorte = Object.values(s.precoPorPorte || {}).some(Boolean);
    const nuncaEditado = !s.atualizadoEm;
    const aindaDeExemplo = s.precoCentavos === exemplo && !temPorPorte;
    if (!nuncaEditado && !aindaDeExemplo) continue;
    await putVarios(STORES.servicos, [{ ...s, precoCentavos: 0, precoExemploCentavos: s.precoCentavos }]);
    zerados.push(s.nome);
  }
  await config.salvar('migracoes', { ...migracoes, precosDeExemplo: { em: Date.now(), servicos: zerados } });
}

/** Correção única (0.5.6): "Boleto" entra nas formas de pagamento de quem já usa o app. */
async function adicionarBoleto() {
  const migracoes = (await config.obter('migracoes')) || {};
  if (migracoes.boleto) return;
  const listas = (await config.obter('listas')) || {};
  const formas = listas['Formas de pagamento'];
  if (Array.isArray(formas) && !formas.some((f) => f.trim().toLowerCase() === 'boleto')) {
    const antes = formas.findIndex((f) => f === 'Fiado' || f === 'Incluso no plano');
    const nova = [...formas];
    nova.splice(antes < 0 ? nova.length : antes, 0, 'Boleto');
    await config.salvarLista('Formas de pagamento', nova);
  }
  await config.salvar('migracoes', { ...((await config.obter('migracoes')) || {}), boleto: Date.now() });
}

/**
 * Correção única (0.5.8): quinzenal passa a ser a cada 2 semanas (14 dias, mesmo
 * dia da semana), não 15. Move para o dia certo os banhos de plano quinzenal e
 * os agendamentos criados com "repetir a cada 15 dias" que:
 *   - ainda não aconteceram e são daqui a 7 dias ou mais (o que o cliente já
 *     combinou para esta semana não muda), tanto a data de antes quanto a nova;
 *   - estavam na data automática (o dia; a hora de cada um é mantida);
 *   - vão para um dia em que a loja abre e um horário livre.
 * O resto fica como está (aparece como "data própria" na folha do plano).
 * Grava primeiro os agendamentos, depois os planos e por último a marca da
 * correção: se o app fechar no meio, ela roda de novo sem estragar nada.
 * A lista do que mudou fica guardada para o aviso no sino.
 */
async function quinzenalACadaDuasSemanas() {
  const migracoes = (await config.obter('migracoes')) || {};
  if (migracoes.quinzenal14) return;
  const DIA = 864e5;
  const diaDe = (ts) => { const d = new Date(ts); d.setHours(0, 0, 0, 0); return d.getTime(); };
  const limite = diaDe(Date.now()) + 7 * DIA;
  const exp = await config.expediente();
  const todasVisitas = await todos(STORES.agendamentos);
  const vivas = todasVisitas.filter((v) => !v.excluidoEm && !['cancelado', 'nao_compareceu'].includes(v.status));
  const nomesPets = new Map((await todos(STORES.pets)).map((p) => [p.id, p.nome]));
  const mudados = new Map();
  const lista = [];
  const naoMovidos = [];

  /** Leva `v` para o dia `diaNovo` (mesma hora), se puder. */
  const mover = (v, diaNovo, motivo) => {
    const d = new Date(v.inicio);
    const alvo = new Date(diaNovo);
    alvo.setHours(d.getHours(), d.getMinutes(), 0, 0);
    const ts = alvo.getTime();
    if (ts === v.inicio) return;
    if (v.inicio < limite || ts < limite) return;
    const fim = ts + (v.duracaoPrevistaMin || 60) * 60000;
    const ocupado = vivas.some((o) => o.id !== v.id && !mudados.has(o.id) && o.inicio < fim && o.inicio + (o.duracaoPrevistaMin || 60) * 60000 > ts)
      || [...mudados.values()].some((o) => o.id !== v.id && o.inicio < fim && o.inicio + (o.duracaoPrevistaMin || 60) * 60000 > ts);
    const fechado = !exp.dias.includes(alvo.getDay());
    if (ocupado || fechado) {
      naoMovidos.push({ pet: nomesPets.get(v.petId) || 'Pet', de: v.inicio, motivo: fechado ? 'a loja não abre no dia certo' : 'horário ocupado no dia certo' });
      return;
    }
    mudados.set(v.id, { ...v, inicio: ts, lembreteEnviadoEm: null, atualizadoEm: Date.now(), quinzenalAntes: v.inicio, motivoAjuste: motivo });
    lista.push({ pet: nomesPets.get(v.petId) || 'Pet', de: v.inicio, para: ts });
  };

  // 1) planos quinzenais
  const planosParaAjustar = [];
  for (const plano of await todos(STORES.planos)) {
    if (tipoDoPlano(plano) !== 'Quinzenal' || Number(plano.intervalo) === 14) continue;
    planosParaAjustar.push(plano);
    if (plano.excluidoEm || plano.encerradoEm) continue;
    const intervaloAntigo = Number(plano.intervalo) || 15;
    const visitas = todasVisitas.filter((v) => v.planoId === plano.id && !v.excluidoEm).sort((a, b) => a.inicio - b.inicio);
    const chaveDe = (v, i) => chaveBanho(v.planoMes || Math.floor(i / 2) + 1, v.planoBanho || (i % 2) + 1);
    const cfg = { tipo: 'Quinzenal', meses: limitarMeses(plano.meses || 1), inicio: plano.inicio, hora: plano.hora };
    // padrão antigo sem pontos de partida: um "ponto de partida" que está no próprio dia do
    // padrão (só a hora foi trocada) não conta como mudança de dia
    const semAncora = new Map(montarBanhos({ ...cfg, intervalo: intervaloAntigo }).map((l) => [l.chave, diaDe(l.padrao)]));
    const ancoras = new Map();
    visitas.forEach((v, i) => {
      const chave = chaveDe(v, i);
      if (v.planoAncora && diaDe(v.inicio) !== semAncora.get(chave)) ancoras.set(chave, { ts: v.inicio, ancora: true });
    });
    const antes = new Map(montarBanhos({ ...cfg, intervalo: intervaloAntigo }, ancoras).map((l) => [l.chave, diaDe(l.padrao)]));
    const depois = new Map(montarBanhos({ ...cfg, intervalo: 14 }, ancoras).map((l) => [l.chave, diaDe(l.padrao)]));
    visitas.forEach((v, i) => {
      const chave = chaveDe(v, i);
      if (!EDITAVEIS.includes(v.status) || ancoras.has(chave)) return;
      // só o que está no dia automático antigo (a hora pode ter sido trocada)
      if (antes.get(chave) !== diaDe(v.inicio) || !Number.isFinite(depois.get(chave))) return;
      mover(v, depois.get(chave), 'quinzenal-plano');
    });
  }

  // 2) agendamentos avulsos criados com "repetir a cada 15 dias" (0.5.7, desde 20/10/2026):
  // mesmo pet, mesmo horário, criados juntos (segundos). Cada um vai para
  // primeiro + 14 × n, onde n é a posição dele na série (15·n a 15·n+6 dias do primeiro).
  const DESDE = new Date(2026, 9, 19).getTime();
  const avulsos = todasVisitas
    .filter((v) => !v.planoId && !v.excluidoEm && (v.criadoEm || 0) >= DESDE)
    .map((v) => ({ v, chave: `${v.petId}|${new Date(v.inicio).getHours()}:${new Date(v.inicio).getMinutes()}` }))
    .sort((a, b) => a.chave.localeCompare(b.chave) || a.v.criadoEm - b.v.criadoEm);
  const series = [];
  let chaveAnterior = null;
  for (const { v, chave } of avulsos) {
    const ultima = series[series.length - 1];
    const anterior = ultima?.[ultima.length - 1];
    if (anterior && chave === chaveAnterior && v.criadoEm - anterior.criadoEm <= 3000) ultima.push(v);
    else series.push([v]);
    chaveAnterior = chave;
  }
  /** Série do "a cada 15 dias": posições 0,1,2... (15·n a 15·n+6 dias do primeiro) e fora do ritmo de 14. */
  const ehSerie15 = (ordem) => {
    const base = diaDe(ordem[0].inicio);
    const offs = ordem.map((v) => Math.round((diaDe(v.inicio) - base) / DIA));
    return offs.every((d, i) => d >= 15 * i && d <= 15 * i + 6) && offs.some((d, i) => d !== 14 * i);
  };
  for (const serie of series.filter((x) => x.length >= 2)) {
    // um agendamento de fora criado junto (mesmo pet e hora) pode ter entrado no começo: tenta sem ele
    let ordem = null;
    for (let s0 = 0; s0 <= serie.length - 2 && !ordem; s0++) {
      const tentativa = serie.slice(s0).sort((a, b) => a.inicio - b.inicio);
      if (ehSerie15(tentativa)) ordem = tentativa;
    }
    if (!ordem) continue;
    ordem.forEach((v, n) => {
      if (!n || !EDITAVEIS.includes(v.status)) return;
      const alvo = new Date(ordem[0].inicio);
      alvo.setDate(alvo.getDate() + 14 * n);
      mover(v, diaDe(alvo.getTime()), 'quinzenal-repetir');
    });
  }

  // grava na ordem segura: agendamentos → planos → marca da correção
  if (mudados.size) await putVarios(STORES.agendamentos, [...mudados.values()]);
  if (planosParaAjustar.length) {
    await putVarios(STORES.planos, planosParaAjustar.map((p) => ({ ...p, intervalo: 14, intervaloAntes: Number(p.intervalo) || 15, atualizadoEm: Date.now() })));
  }
  await config.salvar('migracoes', {
    ...((await config.obter('migracoes')) || {}),
    quinzenal14: { em: Date.now(), planos: planosParaAjustar.length, banhos: lista.length, lista, naoMovidos },
  });
}

/**
 * Correção única (0.6.0): todos os banhos dos planos voltam ao ritmo do plano,
 * contando do 1º banho: a cada 7 dias (mensal) ou 14 dias (quinzenal), sempre no
 * mesmo dia da semana. Conserta as datas que as versões 0.5.7 e 0.5.8 deixaram
 * fora do ritmo (que a folha passou a mostrar como "só este mudou").
 *   - só mexe nos banhos que ainda não aconteceram (agendado/confirmado);
 *   - hoje e amanhã não mudam (o cliente já combinou): entram no aviso;
 *   - cada banho fica na hora dele, só o dia muda;
 *   - dia em que a loja não abre: não muda, entra no aviso;
 *   - horário que fica junto com outro agendamento: muda e entra no aviso.
 * Grava os agendamentos e depois a marca: se o app fechar no meio, roda de novo
 * e chega no mesmo resultado. A lista do que mudou fica para o aviso no sino.
 */
async function planosNoRitmo() {
  const migracoes = (await config.obter('migracoes')) || {};
  if (migracoes.ritmoDosPlanos) return;
  const DIA = 864e5;
  const diaDe = (ts) => { const d = new Date(ts); d.setHours(0, 0, 0, 0); return d.getTime(); };
  const hoje = diaDe(Date.now());
  const depoisDeAmanha = hoje + 2 * DIA;
  const exp = await config.expediente();
  const todasVisitas = await todos(STORES.agendamentos);
  const nomesPets = new Map((await todos(STORES.pets)).map((p) => [p.id, p.nome]));
  const mudados = new Map();
  const lista = [];
  const naoMovidos = [];
  const planosAcertados = [];

  for (const plano of await todos(STORES.planos)) {
    if (plano.excluidoEm || plano.encerradoEm || !plano.banhosPorMes) continue;
    const tipo = tipoDoPlano(plano);
    const porMes = TIPOS[tipo].banhosPorMes;
    const intervalo = limitarIntervalo(TIPOS[tipo].intervalo, tipo);
    // a folha conta pelo intervalo gravado no plano: tem que ser o do tipo
    if (Number(plano.intervalo) !== intervalo) planosAcertados.push({ ...plano, intervalo, atualizadoEm: Date.now() });
    const visitas = todasVisitas.filter((v) => v.planoId === plano.id && !v.excluidoEm).sort((a, b) => a.inicio - b.inicio);
    if (!visitas.length) continue;
    const posicao = (v, i) => (v.planoMes && v.planoBanho ? (v.planoMes - 1) * porMes + (v.planoBanho - 1) : i);
    // o 1º banho manda; sem ele (data que já tinha passado ao criar o plano), a data de início do plano
    const primeiro = visitas.find((v, i) => posicao(v, i) === 0);
    const base = diaDe(primeiro ? primeiro.inicio : plano.inicio);
    const pet = nomesPets.get(plano.petId) || 'Pet';
    visitas.forEach((v, i) => {
      const k = posicao(v, i);
      const flags = { planoManual: false, planoAncora: !!primeiro && v.id === primeiro.id && base !== diaDe(plano.inicio) };
      const alvoDia = new Date(base);
      alvoDia.setDate(alvoDia.getDate() + k * intervalo);
      const d = new Date(v.inicio);
      alvoDia.setHours(d.getHours(), d.getMinutes(), 0, 0);
      const ts = alvoDia.getTime();
      const editavel = EDITAVEIS.includes(v.status);
      const precisaMover = editavel && k > 0 && diaDe(ts) !== diaDe(v.inicio);
      if (precisaMover && (v.inicio < depoisDeAmanha || ts < depoisDeAmanha)) {
        naoMovidos.push({ pet, de: v.inicio, para: ts, motivo: 'é hoje ou amanhã' });
      } else if (precisaMover && !exp.dias.includes(alvoDia.getDay())) {
        naoMovidos.push({ pet, de: v.inicio, para: ts, motivo: 'a loja não abre no dia certo' });
      } else if (precisaMover) {
        mudados.set(v.id, { ...v, ...flags, inicio: ts, lembreteEnviadoEm: null, atualizadoEm: Date.now(), ritmoAntes: v.inicio });
        lista.push({ pet, de: v.inicio, para: ts, visitaId: v.id });
        return;
      }
      // fora isso, só acerta as marcas da folha (sem mudar a data)
      if (!!v.planoManual !== flags.planoManual || !!v.planoAncora !== flags.planoAncora) {
        mudados.set(v.id, { ...v, ...flags, atualizadoEm: Date.now() });
      }
    });
  }

  // horário junto com outro agendamento depois das mudanças: avisa (o Odilon decide)
  const final = todasVisitas.filter((v) => !v.excluidoEm && !['cancelado', 'nao_compareceu'].includes(v.status)).map((v) => mudados.get(v.id) || v);
  for (const item of lista) {
    const v = mudados.get(item.visitaId);
    const fim = v.inicio + (v.duracaoPrevistaMin || 60) * 60000;
    const outro = final.find((o) => o.id !== v.id && o.inicio < fim && o.inicio + (o.duracaoPrevistaMin || 60) * 60000 > v.inicio);
    if (outro) item.junto = nomesPets.get(outro.petId) || 'outro pet';
    delete item.visitaId;
  }

  if (mudados.size) await putVarios(STORES.agendamentos, [...mudados.values()]);
  if (planosAcertados.length) await putVarios(STORES.planos, planosAcertados);
  await config.salvar('migracoes', {
    ...((await config.obter('migracoes')) || {}),
    ritmoDosPlanos: { em: Date.now(), banhos: lista.length, lista, naoMovidos },
  });
}

/**
 * Correção única (0.6.4): a mensalidade passa a ser do mês do PACOTE (Mês 1, Mês 2...)
 * e não do mês do calendário. Cada pagamento já registrado ("2026-10") vai para o mês
 * do pacote do banho em que foi cobrado (o banho 1-1 → "pacote-1"). Se dois pagamentos
 * caírem no mesmo mês do pacote, o segundo vai para o próximo mês livre (pagamento
 * adiantado): nenhum valor some nem muda. Os pagamentos como estavam ficam guardados
 * no plano (pagamentosAntes). Grava os planos e depois a marca.
 */
async function mensalidadePorPacote() {
  const migracoes = (await config.obter('migracoes')) || {};
  if (migracoes.mensalidadePorPacote) return;
  const visitas = (await todos(STORES.agendamentos)).filter((v) => v.planoId && !v.excluidoEm);
  const lista = [];
  const mudados = [];
  for (const plano of await todos(STORES.planos)) {
    const antigos = Object.entries(plano.pagamentos || {}).filter(([k, v]) => v && ehChaveAntiga(k));
    if (!antigos.length) continue;
    const doPlano = visitas.filter((v) => v.planoId === plano.id).sort((a, b) => a.inicio - b.inicio);
    const porMes = TIPOS[tipoDoPlano(plano)].banhosPorMes;
    const meses = limitarMeses(plano.meses || 1);
    const datas = datasDasMensalidades({ ...plano, pagamentos: {} }, doPlano);
    const novos = Object.fromEntries(Object.entries(plano.pagamentos || {}).filter(([k, v]) => v && !ehChaveAntiga(k)));
    const ocupado = (n) => !!novos[chaveDaMensalidade(n)];
    antigos.sort(([a, x], [b, y]) => (x.cobradoEm ?? x.pagoEm ?? 0) - (y.cobradoEm ?? y.pagoEm ?? 0) || (a < b ? -1 : 1));
    for (const [antiga, pg] of antigos) {
      // mês do pacote do banho que cobrou; sem ele, o mês do pacote que cobra naquele mês do calendário
      const i = doPlano.findIndex((v) => v.inicio === pg.cobradoEm);
      let n = i >= 0 ? doPlano[i].planoMes || Math.floor(i / porMes) + 1 : datas.find((d) => chaveDoMes(d.ts) === antiga)?.k || null;
      if (!n || n > meses || ocupado(n)) {
        let livre = n && n <= meses ? n : 1;
        while (livre <= meses && ocupado(livre)) livre++;
        n = livre <= meses ? livre : null;
      }
      if (!n) { novos[antiga] = pg; continue; } // sem mês livre: fica como estava (continua contando)
      novos[chaveDaMensalidade(n)] = { ...pg, mesAntigo: antiga };
      lista.push({ planoId: plano.id, de: antiga, para: n });
    }
    mudados.push({ ...plano, pagamentos: novos, pagamentosAntes: plano.pagamentos, atualizadoEm: Date.now() });
  }
  if (mudados.length) await putVarios(STORES.planos, mudados);
  await config.salvar('migracoes', { ...((await config.obter('migracoes')) || {}), mensalidadePorPacote: { em: Date.now(), planos: mudados.length, lista } });
}

export async function prepararPrimeiroUso() {
  const existentes = await todos(STORES.servicos);
  if (!existentes.length) {
    const agora = Date.now();
    await putVarios(
      STORES.servicos,
      CATALOGO.map((s, ordem) => ({ ...s, id: uuid(), ativo: true, ordem, precoPorPorte: {}, criadoEm: agora }))
    );
  }
  await zerarPrecosDeExemplo();
  await adicionarBoleto();
  await quinzenalACadaDuasSemanas();
  await planosNoRitmo();
  await mensalidadePorPacote();
  const perfil = await config.obter('perfil');
  if (!perfil.desde) await config.salvar('perfil', { ...perfil, desde: Date.now() });
}
