import { STORES, todos, putVarios, uuid } from './db.js';
import * as config from './config.js';

/* Primeiro uso: catálogo inicial com os serviços mais comuns, SEM preço: o
   Odilon cadastra os dele em Serviços. Os tempos reais vêm dos cronômetros. */

const CATALOGO = [
  { nome: 'Banho', categoria: 'Banho', precoCentavos: 0, duracaoPadraoMin: 30, cor: '#5b32e0' },
  { nome: 'Tosa completa', categoria: 'Tosa', precoCentavos: 0, duracaoPadraoMin: 60, cor: '#8b7bee' },
  { nome: 'Tosa higiênica', categoria: 'Tosa', precoCentavos: 0, duracaoPadraoMin: 25, cor: '#f0339b' },
  { nome: 'Hidratação', categoria: 'Estética', precoCentavos: 0, duracaoPadraoMin: 15, cor: '#bd991f' },
  { nome: 'Corte de unhas', categoria: 'Adicional', precoCentavos: 0, duracaoPadraoMin: 10, cor: '#37b881' },
];

// preços de exemplo que as versões até a 0.5.3 traziam de fábrica
const PRECOS_DE_EXEMPLO = new Map([
  ['Banho', 7000], ['Tosa completa', 15000], ['Tosa higiênica', 4500], ['Hidratação', 6000], ['Corte de unhas', 2500],
]);

/**
 * Correção única (0.5.4): zera os preços de exemplo que vieram de fábrica e o
 * Odilon não cadastrou. Conta como de exemplo o serviço nunca editado por ele
 * (registro sem atualizadoEm) ou que continua com o valor de exemplo exato e
 * sem preço por porte. O preço antigo fica guardado em precoExemploCentavos.
 * Só mexe no catálogo: atendimentos e agendamentos ficam como estão.
 */
async function zerarPrecosDeExemplo() {
  const migracoes = (await config.obter('migracoes')) || {};
  if (migracoes.precosDeExemplo) return;
  const zerados = [];
  for (const s of await todos(STORES.servicos)) {
    if (s.excluidoEm || !s.precoCentavos) continue;
    const exemplo = PRECOS_DE_EXEMPLO.get(s.nome);
    if (exemplo === undefined) continue;
    const temPorPorte = Object.values(s.precoPorPorte || {}).some(Boolean);
    const nuncaEditado = !s.atualizadoEm;
    const aindaDeExemplo = s.precoCentavos === exemplo && !temPorPorte;
    if (!nuncaEditado && !aindaDeExemplo) continue;
    await putVarios(STORES.servicos, [{ ...s, precoCentavos: 0, precoExemploCentavos: s.precoCentavos }]);
    zerados.push(s.nome);
  }
  await config.salvar('migracoes', { ...migracoes, precosDeExemplo: { em: Date.now(), servicos: zerados } });
}

export async function prepararPrimeiroUso() {
  const existentes = await todos(STORES.servicos);
  if (!existentes.length) {
    const agora = Date.now();
    await putVarios(
      STORES.servicos,
      CATALOGO.map((s, ordem) => ({ ...s, id: uuid(), ativo: true, ordem, precoPorPorte: {}, criadoEm: agora }))
    );
  }
  await zerarPrecosDeExemplo();
  const perfil = await config.obter('perfil');
  if (!perfil.desde) await config.salvar('perfil', { ...perfil, desde: Date.now() });
}
