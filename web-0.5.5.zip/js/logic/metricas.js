import { DIA_MS, diasEntre } from '../core/dom.js';
import { enderecoTexto } from './endereco.js';

/* Indicadores calculados a partir do histórico. Funções puras: recebem
   os registros já carregados e não tocam no banco. */

const soma = (xs) => xs.reduce((a, b) => a + b, 0);
const media = (xs) => (xs.length ? soma(xs) / xs.length : 0);

/** Minutos reais de uma visita = soma dos cronômetros dos serviços. */
export const minutosDaVisita = (itens) => soma(itens.map((i) => i.duracaoRealMin || 0));

/**
 * @param {object[]} agendamentos do pet, qualquer ordem
 * @param {Map<string, object[]>} itensPorAg
 */
export function estatisticasPet(agendamentos, itensPorAg) {
  const concluidos = agendamentos
    .filter((a) => a.status === 'concluido' && !a.excluidoEm)
    .sort((a, b) => b.inicio - a.inicio);

  const pagos = concluidos.filter((a) => (a.valorCentavos || 0) > 0);
  const totalGasto = soma(concluidos.map((a) => a.valorCentavos || 0));
  const duracoes = concluidos.map((a) => minutosDaVisita(itensPorAg.get(a.id) || [])).filter((m) => m > 0);

  const ultima = concluidos[0]?.inicio || null;
  const intervalos = [];
  for (let i = 0; i < Math.min(concluidos.length - 1, 6); i++) {
    intervalos.push(diasEntre(concluidos[i + 1].inicio, concluidos[i].inicio));
  }
  const frequenciaDias = intervalos.length ? Math.round(media(intervalos.filter((d) => d > 0)) || 0) || null : null;
  const diasDesdeUltima = ultima ? diasEntre(ultima, Date.now()) : null;

  // combinação de serviços mais frequente nas últimas visitas
  const combos = new Map();
  for (const ag of concluidos.slice(0, 6)) {
    const nome = (itensPorAg.get(ag.id) || []).map((i) => i.nome).join(' + ');
    if (nome) combos.set(nome, (combos.get(nome) || 0) + 1);
  }
  const comboTipico = [...combos.entries()].sort((a, b) => b[1] - a[1])[0]?.[0] || '';

  // tendência: média das 3 últimas visitas vs. as 3 anteriores
  const recentes = duracoes.slice(0, 3);
  const anteriores = duracoes.slice(3, 6);
  const tendenciaMin = recentes.length && anteriores.length ? Math.round(media(recentes) - media(anteriores)) : null;

  return {
    concluidos,
    atendimentos: concluidos.length,
    totalGastoCentavos: totalGasto,
    ticketMedioCentavos: pagos.length ? Math.round(soma(pagos.map((a) => a.valorCentavos)) / pagos.length) : 0,
    visitaTipicaMin: duracoes.length ? Math.round(media(duracoes.slice(0, 5))) : null,
    tempoTotalMin: soma(duracoes),
    ultimaVisita: ultima,
    diasDesdeUltima,
    frequenciaDias,
    retornoAtrasado: !!(frequenciaDias && diasDesdeUltima !== null && diasDesdeUltima > frequenciaDias + 2),
    comboTipico,
    tendenciaMin,
    pendenteCentavos: soma(concluidos.filter((a) => a.pagamentoPendente).map((a) => a.valorCentavos || 0)),
  };
}

/** Sugestão de data de retorno: frequência habitual do pet ou 7 dias. */
export function sugestaoRetorno(stats, base = Date.now()) {
  const dias = stats?.frequenciaDias && stats.frequenciaDias >= 3 ? stats.frequenciaDias : 7;
  return { dias, ts: base + dias * DIA_MS };
}

/** Percentual de cadastro preenchido (tutor). */
export function completudeTutor(tutor) {
  const campos = ['nome', 'telefone', 'email', 'cpf', 'origem'];
  const preenchidos = campos.filter((c) => String(tutor?.[c] || '').trim()).length + (enderecoTexto(tutor) ? 1 : 0);
  return Math.round((preenchidos / (campos.length + 1)) * 100);
}

/* "Cadastro incompleto" = falta o que o dia a dia precisa: contato do tutor e
   raça/porte do pet (o porte define preço e tempo). Vacina, veterinário, CPF e
   e-mail são opcionais e não entram. */
const vazioOuPendente = (v) => {
  const s = String(v || '').trim();
  return !s || s === 'Não informado';
};

export function cadastroPetIncompleto(pet) {
  return ['raca', 'porte'].some((c) => vazioOuPendente(pet?.[c]));
}

export function cadastroTutorIncompleto(tutor) {
  return ['nome', 'telefone'].some((c) => vazioOuPendente(tutor?.[c]));
}
