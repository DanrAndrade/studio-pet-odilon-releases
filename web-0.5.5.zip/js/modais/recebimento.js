import { html, icon, fmtBRL } from '../core/dom.js';
import { chip } from '../core/ui.js';
import * as config from '../data/config.js';

/* Registrar um recebimento: pergunta a forma realmente usada, para o faturamento
   separar certo PIX, dinheiro e cartão — inclusive de fiado quitado depois. */

const FORMAS_RESERVA = ['Dinheiro', 'PIX', 'Débito', 'Crédito'];

const modal = {
  render: (e) => html`<div class="modal-fundo">
    <div class="modal m-430">
      <div class="modal-cab">
        <div>
          <div class="modal-titulo m">${e.titulo}</div>
          <div class="modal-sub">${e.sub}</div>
        </div>
        <button class="modal-fechar" data-acao="fechar-modal" aria-label="Fechar">${icon('x', 16)}</button>
      </div>
      <div>
        <div class="rotulo-campo" style="margin-bottom:8px">Como foi pago?</div>
        <div class="chips">${e.formas.map((f) => chip(f, e.forma === f, 'forma', { forma: f }, { suave: true, cls: 'forte' }))}</div>
      </div>
      <div class="modal-rodape" style="margin-top:6px">
        <button class="btn btn-branco" data-acao="fechar-modal">Cancelar</button>
        <button class="btn btn-roxo" data-acao="ok" ${e.forma ? '' : 'disabled'}>Registrar recebimento</button>
      </div>
    </div>
  </div>`,

  acoes: {
    forma: ({ forma }, { atualizar }) => atualizar({ forma }),
    ok: (_, { estado, fechar }) => {
      if (estado.forma) fechar(estado.forma);
    },
  },
};

/** Abre o modal e devolve a forma escolhida (ou null se cancelar). */
export async function escolherFormaRecebimento(ctx, { titulo = 'Registrar recebimento', valorCentavos = 0, detalhe = '' } = {}) {
  const configuradas = (await config.lista('Formas de pagamento')).filter((f) => f !== 'Incluso no plano' && f !== 'Fiado');
  return ctx.abrirModal(modal, {
    titulo,
    sub: [fmtBRL(valorCentavos), detalhe].filter(Boolean).join(' · '),
    formas: configuradas.length ? configuradas : FORMAS_RESERVA,
    forma: null,
  });
}
