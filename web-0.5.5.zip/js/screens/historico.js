import {
  html, icon, fmtBRL, fmtHora, fmtDataCurta, mesmoDia, addDias, digitos, DIAS_LONGOS,
  inicioDoDia, fimDoDia, inicioDaSemana, inicioDoMes, fimDoMes,
} from '../core/dom.js';
import { avPet, vazio } from '../core/ui.js';
import { agendamentos, pets, tutores, dataDoAtendimento, nomesParaRelatorio } from '../data/repo.js';
import { combina } from '../core/busca.js';
import { nomesParaBusca, telefonesDoTutor } from '../logic/contatos.js';

/* HISTÓRICO — todos os atendimentos finalizados, do mais recente para o mais
   antigo. Daqui dá para reabrir (voltar ao atendimento para corrigir) ou
   desfazer (voltar a ser só um agendamento) um atendimento finalizado por engano. */

const PERIODOS = ['Hoje', 'Semana', 'Este mês', 'Mês passado', 'Tudo'];
const POR_PAGINA = 60;
const ui = { periodo: 'Semana', busca: '', limite: POR_PAGINA };

function intervalo(periodo, agora = Date.now()) {
  switch (periodo) {
    case 'Hoje':
      return { de: inicioDoDia(agora), ate: fimDoDia(agora) };
    case 'Semana':
      return { de: inicioDaSemana(agora), ate: fimDoDia(agora) };
    case 'Este mês':
      return { de: inicioDoMes(agora), ate: fimDoDia(agora) };
    case 'Mês passado': {
      const d = new Date(agora);
      const ref = new Date(d.getFullYear(), d.getMonth() - 1, 15).getTime();
      return { de: inicioDoMes(ref), ate: fimDoMes(ref) };
    }
    default:
      return { de: 0, ate: Infinity };
  }
}

function rotuloDia(ts) {
  const agora = Date.now();
  if (mesmoDia(ts, agora)) return 'Hoje';
  if (mesmoDia(ts, addDias(agora, -1))) return 'Ontem';
  return `${DIAS_LONGOS[new Date(ts).getDay()]}, ${fmtDataCurta(ts)}${new Date(ts).getFullYear() !== new Date(agora).getFullYear() ? '/' + new Date(ts).getFullYear() : ''}`;
}

function pagamento(ag) {
  if (ag.planoId && !ag.valorCentavos) return { texto: 'Plano', cls: 'lavanda' };
  if (ag.pagamentoPendente) return { texto: ag.formaPagamento === 'Fiado' ? 'Fiado' : 'A receber', cls: 'ambar' };
  return { texto: ag.formaPagamento || 'Pago', cls: 'verde' };
}

export default {
  titulo: 'Histórico',
  menu: 'historico',

  async carregar() {
    const mapaPets = new Map((await pets.listar()).map((p) => [p.id, p]));
    const mapaTutores = new Map((await tutores.listar()).map((t) => [t.id, t]));
    // nomes também de pets e tutores excluídos: o histórico não perde quem foi
    const nomes = await nomesParaRelatorio();
    const { de, ate } = intervalo(ui.periodo);
    const lista = (await agendamentos.concluidos())
      // mesmo critério do faturamento: o dia em que o pet foi atendido
      .map((ag) => ({ ag, quando: dataDoAtendimento(ag) }))
      .filter((x) => x.quando >= de && x.quando <= ate)
      .sort((a, b) => b.quando - a.quando);
    const itensPorAg = await agendamentos.itensDe(lista.map((x) => x.ag));
    const linhas = [];
    for (const { ag, quando } of lista) {
      const pet = mapaPets.get(ag.petId) || (nomes.pets.get(ag.petId) ? { id: null, nome: nomes.pets.get(ag.petId) } : null);
      const tutorId = ag.tutorId || pet?.tutorId;
      const tutor = mapaTutores.get(tutorId) || (nomes.tutores.get(tutorId) ? { nome: nomes.tutores.get(tutorId) } : null);
      linhas.push({
        ag,
        quando,
        pet,
        tutor,
        servicos: (itensPorAg.get(ag.id) || []).map((i) => i.nome).join(' + '),
        textos: [pet?.nome, ...nomesParaBusca(tutor)],
        telefones: telefonesDoTutor(tutor),
      });
    }
    return { linhas };
  },

  render(vm) {
    const termo = ui.busca.trim();
    const filtradas = vm.linhas.filter((l) => combina(termo, [...l.textos, l.servicos], l.telefones));
    const visiveis = filtradas.slice(0, ui.limite);
    const total = filtradas.reduce((s, l) => s + (l.ag.valorCentavos || 0), 0);

    // agrupa por dia de finalização
    const grupos = [];
    for (const l of visiveis) {
      const chave = inicioDoDia(l.quando);
      if (!grupos.length || grupos[grupos.length - 1].chave !== chave) grupos.push({ chave, linhas: [] });
      grupos[grupos.length - 1].linhas.push(l);
    }

    return html`
      <div class="hist-topo">
        <div class="segmento">${PERIODOS.map((p) => html`<button class="${ui.periodo === p ? 'on' : ''}" data-acao="periodo" data-periodo="${p}">${p}</button>`)}</div>
        <div class="busca branca">
          ${icon('search', 16)}
          <input data-campo="busca" value="${ui.busca}" placeholder="Buscar por pet, tutor ou telefone…">
          ${ui.busca ? html`<button data-acao="limpar" style="display:flex;color:var(--texto-3)" aria-label="Limpar">${icon('x', 15)}</button>` : ''}
        </div>
      </div>

      <div class="hist-resumo-linha">
        <span><strong>${filtradas.length}</strong> ${filtradas.length === 1 ? 'atendimento finalizado' : 'atendimentos finalizados'}</span>
        <span>Total cobrado <strong>${fmtBRL(total)}</strong></span>
      </div>

      ${!filtradas.length
        ? html`<div class="card pad-18">${vazio({
            icone: 'history',
            titulo: termo ? 'Nenhum atendimento encontrado' : 'Nenhum atendimento finalizado neste período',
            texto: termo ? 'Tente outro nome ou outro período.' : 'Os atendimentos aparecem aqui assim que são finalizados.',
          })}</div>`
        : html`${grupos.map(
            (g) => html`<div class="card r22 hist-grupo">
              <div class="hist-dia">${rotuloDia(g.chave)}<span>${g.linhas.length} ${g.linhas.length === 1 ? 'atendimento' : 'atendimentos'}</span></div>
              ${g.linhas.map(linha)}
            </div>`
          )}
          ${filtradas.length > visiveis.length
            ? html`<button class="btn btn-branco bloco" data-acao="mais">Mostrar mais (${filtradas.length - visiveis.length} restantes)</button>`
            : ''}`}`;
  },

  aoDigitar(campo, valor, ctx) {
    if (campo !== 'busca') return;
    ui.busca = valor;
    ui.limite = POR_PAGINA;
    ctx.redesenhar();
  },

  acoes: {
    periodo: ({ periodo }, ctx) => {
      ui.periodo = periodo;
      ui.limite = POR_PAGINA;
      ctx.recarregar();
    },
    limpar: (_, ctx) => {
      ui.busca = '';
      ctx.redesenhar();
    },
    mais: (_, ctx) => {
      ui.limite += POR_PAGINA;
      ctx.redesenhar();
    },
    ficha: ({ id }, ctx) => id && ctx.navegar('ficha-pet', { id }),
    reabrir: async ({ id }, ctx) => {
      const l = ctx.vm.linhas.find((x) => x.ag.id === id);
      const nome = l.pet?.nome || 'o pet';
      const ok = await ctx.confirmar({
        titulo: `Reabrir o atendimento de ${nome}?`,
        texto: `O atendimento volta para o Atendimento do dia com os tempos já registrados. Você corrige o que precisar (serviços, desconto, forma de pagamento) e finaliza de novo. Até lá, o valor sai do faturamento.${l.ag.retornoId ? ' O retorno marcado na finalização é desmarcado.' : ''}`,
        botao: 'Reabrir',
        perigo: false,
        icone: 'rotate-ccw',
      });
      if (!ok) return;
      const r = await agendamentos.reabrir(id);
      if (!r) return ctx.toast('Este atendimento já não está finalizado', { erro: true });
      ctx.toast(`Atendimento de ${nome} reaberto${r.retornoRemovido ? ' · retorno desmarcado' : ''}`);
      ctx.navegar('atendimento', { id });
    },
    desfazer: async ({ id }, ctx) => {
      const l = ctx.vm.linhas.find((x) => x.ag.id === id);
      const nome = l.pet?.nome || 'o pet';
      const ok = await ctx.confirmar({
        titulo: `Desfazer o atendimento de ${nome}?`,
        texto: `Volta a ser só um agendamento em ${fmtDataCurta(l.ag.inicio)} às ${fmtHora(l.ag.inicio)}, como se ${nome} não tivesse vindo. Os tempos cronometrados e o pagamento são apagados, e o valor sai do faturamento.${l.ag.retornoId ? ' O retorno marcado na finalização também é desmarcado.' : ''}`,
        botao: 'Desfazer atendimento',
        icone: 'undo-2',
      });
      if (!ok) return;
      const r = await agendamentos.desfazer(id);
      if (!r) return ctx.toast('Este atendimento já não está finalizado', { erro: true });
      ctx.toast(`Atendimento desfeito · ${nome} voltou para a agenda${r.retornoRemovido ? ' · retorno desmarcado' : ''}`);
      ctx.recarregar();
    },
  },
};

function linha(l) {
  const { ag, pet, tutor } = l;
  const pg = pagamento(ag);
  const { servicos } = l;
  return html`<div class="hist-item">
    <button class="hist-item-info" data-acao="ficha" data-id="${pet?.id || ''}">
      <span class="hist-hora">${fmtHora(l.quando)}</span>
      ${pet?.id ? avPet(pet, 40, { borda: 0, sombra: false }) : html`<span style="width:40px"></span>`}
      <span class="hist-nomes">
        <span class="hist-pet truncar">${pet?.nome || 'Pet excluído'}</span>
        <span class="hist-tutor truncar">${tutor?.nome || 'Sem tutor'}${servicos ? ' · ' + servicos : ''}</span>
      </span>
      <span class="hist-valor">
        <span>${ag.planoId && !ag.valorCentavos ? '—' : fmtBRL(ag.valorCentavos || 0)}</span>
        <span class="hist-pg ${pg.cls}">${pg.texto}</span>
      </span>
    </button>
    <div class="hist-acoes">
      <button class="btn btn-lavanda hist-btn" data-acao="reabrir" data-id="${ag.id}">${icon('rotate-ccw', 14)}<span>Reabrir</span></button>
      <button class="btn btn-branco hist-btn desfazer" data-acao="desfazer" data-id="${ag.id}">${icon('undo-2', 14)}<span>Desfazer</span></button>
    </div>
  </div>`;
}
