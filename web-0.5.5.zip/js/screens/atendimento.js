import { html, icon, fmtHora, fmtDur, fmtBRL } from '../core/dom.js';
import { avPet, tagsPet, selo, vazio, voltar } from '../core/ui.js';
import { agendamentos, pets, tutores, montarItens, servicosInclusosNoPlano } from '../data/repo.js';
import { cronDesde, cronItem, cronSoma, barraItem, estadoItem } from './_cronometro.js';
import { abrirWhatsapp } from '../modais/whatsapp.js';
import { escolherServico } from '../modais/adicionar-servico.js';
import { registrarOcorrencia } from '../modais/ocorrencia.js';
import { editarObservacoes } from '../modais/observacoes.js';

/* ATENDIMENTO EM ANDAMENTO — detalhe de um pet na loja. */

function linhaServico(item) {
  const e = estadoItem(item);
  return html`<div class="at-serv">
    <div style="min-width:0">
      <div class="at-serv-nome">${item.nome}</div>
      <div class="at-serv-media">Média deste pet: ${item.mediaSeg ? fmtDur(item.mediaSeg / 60) : 'sem histórico'}</div>
      ${barraItem(item)}
    </div>
    <div class="at-serv-tempo" style="color:${e.cor}">${cronItem(item)}</div>
    <div>${selo(e.tag, e.tom)}</div>
    <div class="at-serv-botoes">
      <button class="btn-cron-g" data-acao="alternar" data-item="${item.id}">${icon(e.icone, 13)}<span>${e.botao}</span></button>
      ${item.done ? '' : html`<button class="btn-concluir-g" data-acao="concluir-item" data-item="${item.id}">${icon('check', 13)}<span>Concluir</span></button>`}
    </div>
  </div>`;
}

export default {
  titulo: 'Atendimento em andamento',
  menu: 'atendimento-dia',

  async carregar({ id }) {
    const ag = await agendamentos.obter(id);
    if (!ag) return { ag: null };
    const pet = await pets.obter(ag.petId);
    const tutor = pet?.tutorId ? await tutores.obter(pet.tutorId) : null;
    return { ag, pet, tutor, itens: await agendamentos.itens(id) };
  },

  render(vm) {
    if (!vm.ag || !vm.pet) {
      return html`${voltar('Voltar')}<div class="card pad-18">${vazio({ icone: 'search', titulo: 'Atendimento não encontrado' })}</div>`;
    }
    const { ag, pet, tutor, itens } = vm;

    if (ag.status !== 'em_atendimento') {
      const concluido = ag.status === 'concluido';
      return html`${voltar('Voltar')}<div class="card pad-18">${vazio({
        icone: concluido ? 'circle-check-big' : 'clock',
        titulo: concluido ? `O atendimento ${pet.sexo === 'Fêmea' ? 'da' : 'do'} ${pet.nome} já foi concluído` : `${pet.nome} ainda não chegou`,
        texto: concluido ? 'O tempo e o pagamento já estão registrados na ficha.' : 'Registre a chegada para ligar os cronômetros.',
        acao: concluido
          ? html`<button class="btn btn-branco" data-acao="ficha">Ver ficha do pet</button>`
          : html`<button class="btn btn-roxo" data-acao="chegada">Registrar chegada</button>`,
      })}</div>`;
    }

    const chegada = ag.chegadaEm || ag.inicio;
    const sub = [pet.raca, pet.porte, tutor?.nome, tutor?.telefone].filter(Boolean).join(' · ');
    const obs = ag.observacoes || [];

    return html`${voltar('Voltar')}
      <div class="at-grade">
        <div class="at-col">
          <div class="card at-pet">
            ${avPet(pet, 72, { borda: 3 })}
            <div style="flex:1;min-width:0">
              <div class="at-pet-nome">${pet.nome}</div>
              <div class="at-pet-sub">${sub}</div>
              ${tagsPet(pet).length ? html`<div class="at-tags">${tagsPet(pet).map((t) => selo(t.label, t.tom))}</div>` : ''}
            </div>
            <div class="at-relogio">
              <div class="at-relogio-rotulo">Tempo desde a chegada</div>
              <div class="at-relogio-valor">${cronDesde(chegada)}</div>
              <div class="at-relogio-sub">chegou às ${fmtHora(chegada)} · em serviço ${cronSoma(itens)}</div>
            </div>
          </div>

          <div class="card at-servicos">
            <div class="at-servicos-cab">
              <div class="titulo-card">Serviços do atendimento</div>
              <button class="link-acao" data-acao="adicionar-servico">+ Adicionar serviço</button>
            </div>
            ${itens.length ? itens.map(linhaServico) : html`<div class="at-serv-media" style="padding:12px 0;border-top:1px solid var(--divisor)">Nenhum serviço ainda.</div>`}
          </div>

          <div class="at-acoes">
            <button class="at-acao" data-acao="adicionar-servico">${icon('plus-circle', 18)}<span>Adicionar serviço</span></button>
            <button class="at-acao" data-acao="pet-pronto">${icon('message-circle', 18)}<span>Avisar tutor: pet pronto</span></button>
            <button class="at-acao" data-acao="ocorrencia">${icon('clipboard-list', 18)}<span>Registrar ocorrência</span></button>
            <button class="at-acao" data-acao="observacoes">${icon('sticky-note', 18)}<span>Observação rápida</span></button>
          </div>
        </div>

        <div class="at-col">
          <div class="card pad-16">
            <div class="titulo-card" style="margin-bottom:8px">Observações</div>
            ${obs.length ? html`<div style="display:flex;flex-direction:column;gap:8px;margin-bottom:10px">${obs.map((o) => html`<div class="obs-item">${o}</div>`)}</div>` : ''}
            <button class="btn-obs" data-acao="observacoes">${icon('pencil-line', 15)}<span>${obs.length ? 'Editar observações' : 'Adicionar observação'}</span></button>
          </div>
          <div class="botoes">
            <button class="btn btn-roxo bloco" data-acao="finalizar">Finalizar atendimento</button>
            <div class="botoes-linha">
              <button class="btn btn-branco" data-acao="pausar">Pausar</button>
              <button class="btn btn-rosa-contorno" data-acao="cancelar">Cancelar</button>
            </div>
          </div>
        </div>
      </div>`;
  },

  acoes: {
    alternar: async ({ item }, ctx) => {
      await agendamentos.alternarItem(item);
      ctx.recarregar();
    },
    'concluir-item': async ({ item }, ctx) => {
      await agendamentos.concluirItem(item);
      ctx.recarregar();
    },
    'adicionar-servico': async (_, ctx) => {
      const servico = await escolherServico(ctx, ctx.vm.pet?.porte);
      if (!servico) return;
      // num atendimento de plano, só o que o plano cobre sai sem custo; o extra é cobrado
      const cobertos = ctx.vm.ag.origem === 'plano' ? await servicosInclusosNoPlano(ctx.vm.pet.id) : new Set();
      const incluso = cobertos.has(servico.id);
      const [item] = await montarItens(ctx.vm.pet, [servico], { incluso });
      await agendamentos.adicionarItem(ctx.vm.ag.id, item);
      ctx.toast(`${servico.nome} adicionado · ${incluso ? 'incluso no plano' : fmtBRL(item.precoCentavos)}`);
      ctx.recarregar();
    },
    'pet-pronto': (_, ctx) => abrirWhatsapp(ctx, { tutor: ctx.vm.tutor, pet: ctx.vm.pet, modelo: 'Pet pronto' }),
    ocorrencia: async (_, ctx) => {
      if (await registrarOcorrencia(ctx, { petId: ctx.vm.pet.id, agendamentoId: ctx.vm.ag.id })) ctx.recarregar();
    },
    observacoes: async (_, ctx) => {
      await editarObservacoes(ctx, { agendamentoId: ctx.vm.ag.id });
      ctx.recarregar();
    },
    finalizar: (_, ctx) => ctx.navegar('finalizar', { id: ctx.vm.ag.id }),
    pausar: async (_, ctx) => {
      await agendamentos.pausarTodos(ctx.vm.ag.id);
      ctx.toast('Cronômetros pausados');
      ctx.recarregar();
    },
    cancelar: async (_, ctx) => {
      const ok = await ctx.confirmar({
        titulo: `Cancelar o atendimento ${ctx.vm.pet.sexo === 'Fêmea' ? 'da' : 'do'} ${ctx.vm.pet.nome}?`,
        texto: 'Os cronômetros são descartados e o agendamento fica marcado como cancelado.',
        botao: 'Cancelar atendimento',
        cancelar: 'Voltar',
      });
      if (!ok) return;
      await agendamentos.pausarTodos(ctx.vm.ag.id);
      await agendamentos.mudarStatus(ctx.vm.ag.id, 'cancelado');
      ctx.toast('Atendimento cancelado');
      ctx.navegar('agenda', {}, { substituir: true });
    },
    chegada: async (_, ctx) => {
      await agendamentos.registrarChegada(ctx.vm.ag.id);
      ctx.recarregar();
    },
    ficha: (_, ctx) => ctx.navegar('ficha-pet', { id: ctx.vm.pet.id }),
  },
};
