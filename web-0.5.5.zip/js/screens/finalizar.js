import { html, icon, fmtBRL, fmtDur, fmtHora, fmtDataCurta, paraCentavos, centavosParaCampo, comHora, addDias, $ } from '../core/dom.js';
import { chip, linhaToggle, vazio, voltar } from '../core/ui.js';
import { agendamentos, pets, tutores, servicos, tempos, montarItens } from '../data/repo.js';
import * as config from '../data/config.js';
import { estatisticasPet, sugestaoRetorno } from '../logic/metricas.js';
import { cronDesde, cronSoma, segundosItem } from './_cronometro.js';

/* FINALIZAR ATENDIMENTO — congela os tempos, cobra e (opcional) agenda o retorno. */

const ui = {};

function reiniciar(ag, subtotal) {
  let forma = ag.formaPagamento && ag.formaPagamento !== 'A definir' ? ag.formaPagamento : null;
  // "Incluso no plano" só vale se não há nada a cobrar (serviço extra fora do plano pede forma real)
  if (subtotal > 0 && forma === 'Incluso no plano') forma = null;
  if (!subtotal && ag.origem === 'plano') forma = 'Incluso no plano';
  Object.assign(ui, {
    id: ag.id,
    desconto: centavosParaCampo(ag.descontoCentavos),
    forma,
    // fiado previsto no agendamento continua sendo pagamento pendente
    pendente: forma === 'Fiado',
    semMedia: false,
    retorno: false,
    recomendacao: ag.recomendacao || '',
    // preço final de cada serviço digitado na hora de cobrar ({ itemId: texto do campo })
    precos: {},
  });
}

/** Preço final do serviço: o digitado agora ou o que veio do agendamento. */
const precoDe = (item) => (ui.precos[item.id] !== undefined ? paraCentavos(ui.precos[item.id]) : item.precoCentavos || 0);
const subtotalDe = (vm) => vm.itens.reduce((s, i) => s + precoDe(i), 0);
const totalCom = (vm) => Math.max(0, subtotalDe(vm) - paraCentavos(ui.desconto) + (vm.ag.acrescimoCentavos || 0));
// "Incluso no plano" só aparece quando não há nada a cobrar
const formasPara = (vm) => vm.todasFormas.filter((f) => f !== 'Incluso no plano' || (vm.ag.origem === 'plano' && !subtotalDe(vm)));

export default {
  titulo: 'Finalizar atendimento',
  menu: 'atendimento-dia',

  async carregar({ id }) {
    const ag = await agendamentos.obter(id);
    if (!ag) return { ag: null };

    const pet = await pets.obter(ag.petId);
    const tutor = pet?.tutorId ? await tutores.obter(pet.tutorId) : null;
    const itens = await agendamentos.itens(id);

    const historico = await agendamentos.doPet(ag.petId);
    const stats = estatisticasPet(historico, await agendamentos.itensDe(historico));

    const medias = new Map();
    for (const item of itens) {
      const servico = item.servicoId ? await servicos.obter(item.servicoId) : null;
      medias.set(item.id, servico && pet ? (await tempos.estimar(pet, servico)).minutos : Math.round((item.mediaSeg || 0) / 60));
    }

    const subtotal = itens.reduce((s, i) => s + (i.precoCentavos || 0), 0);
    if (ui.id !== id) reiniciar(ag, subtotal);
    const todasFormas = await config.lista('Formas de pagamento');
    return { ag, pet, tutor, itens, stats, medias, todasFormas };
  },

  render(vm) {
    if (!vm.ag || !vm.pet) return html`${voltar('Voltar')}<div class="card pad-18">${vazio({ icone: 'search', titulo: 'Atendimento não encontrado' })}</div>`;
    if (vm.ag.status === 'concluido') {
      return html`${voltar('Voltar')}<div class="card pad-18">${vazio({
        icone: 'circle-check-big',
        titulo: 'Este atendimento já foi concluído',
        texto: `Valor registrado: ${fmtBRL(vm.ag.valorCentavos)}${vm.ag.formaPagamento ? ' · ' + vm.ag.formaPagamento : ''}.`,
        acao: html`<button class="btn btn-branco" data-acao="ficha">Ver ficha do pet</button>`,
      })}</div>`;
    }

    const { ag, pet, itens, medias, stats } = vm;
    const subtotal = subtotalDe(vm);
    const formas = formasPara(vm);
    const chegada = ag.chegadaEm || ag.inicio;
    const sug = sugestaoRetorno(stats, ag.inicio);
    const desconto = paraCentavos(ui.desconto);

    return html`
      ${voltar('Voltar ao atendimento', 'voltar-atendimento')}
      <div class="titulo-pagina">Finalizar atendimento · ${pet.nome}</div>
      <div class="sub-pagina">Tempo na loja: ${cronDesde(chegada)} · em serviço ${cronSoma(itens)}</div>

      <div class="at-grade">
        <div class="at-col">
          <div class="card fin-tabela">
            <div class="cab-tabela fin-colunas"><div>Serviço realizado</div><div>Duração real</div><div>Média anterior</div><div style="text-align:right">Preço final</div></div>
            ${itens.map((item) => {
              const realMin = Math.round(segundosItem(item) / 60);
              const mediaMin = medias.get(item.id) || 0;
              const delta = mediaMin ? realMin - mediaMin : 0;
              const cor = delta > 0 ? 'var(--rosa)' : delta < 0 ? 'var(--verde-escuro)' : 'var(--texto-2)';
              return html`<div class="linha-tabela fin-colunas">
                <div class="fin-nome"><span class="fin-check">${icon('check', 12)}</span><span>${item.nome}</span></div>
                <div class="fin-real" style="color:${cor}">${fmtDur(realMin)} ${delta ? html`<small>(${delta > 0 ? '+' : ''}${delta}min)</small>` : ''}</div>
                <div class="mutado">${mediaMin ? fmtDur(mediaMin) : '—'}</div>
                <div class="fin-preco">
                  <input class="campo-inline" data-campo="preco-${item.id}" value="${centavosParaCampo(precoDe(item))}" placeholder="R$ 0" inputmode="decimal" data-formato="moeda" aria-label="Preço final de ${item.nome}">
                  ${precoDe(item) !== (item.precoTabelaCentavos ?? item.precoCentavos ?? 0)
                    ? html`<small>tabela ${fmtBRL(item.precoTabelaCentavos ?? item.precoCentavos ?? 0)}</small>`
                    : ''}
                </div>
              </div>`;
            })}
          </div>

          <div class="card pad-18">
            <div class="titulo-card" style="margin-bottom:10px">Observações e recomendação</div>
            <div style="display:flex;flex-direction:column;gap:8px">
              ${(ag.observacoes || []).length
                ? ag.observacoes.map((o) => html`<div class="obs-item">${o}</div>`)
                : html`<div class="obs-item">Sem observações registradas neste atendimento.</div>`}
            </div>
            <textarea class="caixa-texto" style="margin-top:10px" data-campo="recomendacao" rows="2" placeholder="Recomendação para a próxima visita…">${ui.recomendacao}</textarea>
          </div>
        </div>

        <div class="at-col">
          <div class="card pad-18">
            <div class="titulo-card" style="margin-bottom:10px">Pagamento</div>
            <div class="linha"><span class="l-rotulo">Subtotal</span><span class="l-valor" id="fin-subtotal" style="color:var(--texto-2)">${fmtBRL(subtotal)}</span></div>
            <div class="mutado" style="font-size:11.5px;margin:-2px 0 4px">Toque no preço de um serviço para mudar só neste atendimento.</div>
            <div class="linha">
              <span class="l-rotulo">Desconto</span>
              <input class="campo-inline" data-campo="desconto" value="${ui.desconto}" placeholder="—" inputmode="decimal" data-formato="moeda" style="color:${desconto ? 'var(--rosa)' : 'var(--texto-3)'}">
            </div>
            ${ag.acrescimoCentavos ? html`<div class="linha"><span class="l-rotulo">Acréscimo</span><span class="l-valor" style="color:var(--texto-2)">+ ${fmtBRL(ag.acrescimoCentavos)}</span></div>` : ''}
            <div class="linha"><span class="l-rotulo">Total recebido</span><span class="l-valor" id="fin-total" style="font-weight:700">${fmtBRL(totalCom(vm))}</span></div>
            <div class="chips" style="margin-top:12px">${formas.map((f) => chip(f, ui.forma === f, 'forma', { forma: f }, { suave: true, cls: 'mini' }))}</div>
          </div>

          <div class="card pad-18" style="padding-top:7px">
            ${linhaToggle({ rotulo: 'Ainda não recebi o pagamento', dica: 'Entra em "A receber" no faturamento', ligado: ui.pendente, acao: 'sw', attrs: { chave: 'pendente' }, compacta: true })}
            ${linhaToggle({ rotulo: 'Não usar este tempo na média', dica: 'Quando algo fora do normal atrasou o serviço', ligado: ui.semMedia, acao: 'sw', attrs: { chave: 'semMedia' }, compacta: true })}
            ${linhaToggle({ rotulo: 'Já agendar retorno', dica: `Sugestão: ${sug.dias} dias · ${fmtDataCurta(sug.ts)}`, ligado: ui.retorno, acao: 'sw', attrs: { chave: 'retorno' }, compacta: true })}
          </div>

          <div class="botoes">
            <button class="btn btn-roxo bloco" data-acao="concluir">Concluir atendimento</button>
            <button class="btn btn-branco bloco" data-acao="concluir-retorno">Concluir e agendar retorno</button>
          </div>
        </div>
      </div>`;
  },

  aoDigitar(campo, valor, ctx, el) {
    if (campo.startsWith('preco-')) {
      ui.precos[campo.slice(6)] = valor;
      const sub = $('#fin-subtotal');
      if (sub) sub.textContent = fmtBRL(subtotalDe(ctx.vm));
      const total = $('#fin-total');
      if (total) total.textContent = fmtBRL(totalCom(ctx.vm));
      return;
    }
    ui[campo] = valor;
    if (campo === 'desconto') {
      const total = $('#fin-total');
      if (total) total.textContent = fmtBRL(totalCom(ctx.vm));
      el.style.color = paraCentavos(valor) ? 'var(--rosa)' : 'var(--texto-3)';
    }
  },

  // ao sair do campo de preço: "Incluso no plano" só vale se continua sem nada a cobrar
  aoAlterar(campo, _, ctx) {
    if (!campo.startsWith('preco-')) return;
    const sub = subtotalDe(ctx.vm);
    if (sub > 0 && ui.forma === 'Incluso no plano') ui.forma = null;
    if (!sub && ctx.vm.ag.origem === 'plano' && !ui.forma) ui.forma = 'Incluso no plano';
    ctx.redesenhar();
  },

  acoes: {
    forma: ({ forma }, ctx) => {
      ui.forma = ui.forma === forma ? null : forma;
      // fiado é, por definição, pagamento pendente
      if (ui.forma === 'Fiado') ui.pendente = true;
      else if (forma === 'Fiado') ui.pendente = false;
      ctx.redesenhar();
    },
    sw: ({ chave }, ctx) => {
      ui[chave] = !ui[chave];
      if (chave === 'pendente' && !ui.pendente && ui.forma === 'Fiado') ui.forma = null;
      ctx.redesenhar();
    },
    'voltar-atendimento': (_, ctx) => ctx.navegar('atendimento', { id: ctx.vm.ag.id }, { substituir: true }),
    ficha: (_, ctx) => ctx.navegar('ficha-pet', { id: ctx.vm.pet.id }),
    concluir: (_, ctx) => concluir(ctx, false),
    'concluir-retorno': (_, ctx) => concluir(ctx, true),
  },
};

async function concluir(ctx, abrirRetorno) {
  const { ag, pet, itens, stats } = ctx.vm;
  const total = totalCom(ctx.vm);
  if (total > 0 && !ui.pendente && (!ui.forma || ui.forma === 'Incluso no plano')) {
    return ctx.toast('Escolha como foi pago ou marque "Ainda não recebi o pagamento"', { erro: true });
  }
  await agendamentos.finalizar(ag.id, {
    descontoCentavos: paraCentavos(ui.desconto),
    formaPagamento: ui.forma,
    pagamentoPendente: total > 0 && ui.pendente,
    usarNaMedia: !ui.semMedia,
    recomendacao: ui.recomendacao.trim(),
    // só os preços que ele mexeu; os outros ficam como vieram do agendamento
    precos: Object.fromEntries(itens.filter((i) => ui.precos[i.id] !== undefined).map((i) => [i.id, precoDe(i)])),
  });
  ui.id = null;

  const sug = sugestaoRetorno(stats, ag.inicio);
  const exp = await config.expediente();
  let inicioRetorno = comHora(sug.ts, fmtHora(ag.inicio));
  // o retorno cai num dia em que a loja abre
  for (let i = 0; i < 7 && !exp.dias.includes(new Date(inicioRetorno).getDay()); i++) inicioRetorno = addDias(inicioRetorno, 1);
  const idsServicos = itens.map((i) => i.servicoId).filter(Boolean);

  if (abrirRetorno) {
    ctx.toast('Atendimento concluído');
    return ctx.navegar('novo-agendamento', { petId: pet.id, inicio: inicioRetorno, servicos: idsServicos.join(',') }, { substituir: true });
  }

  if (ui.retorno) {
    const lista = (await Promise.all(idsServicos.map((id) => servicos.obter(id)))).filter((s) => s && !s.excluidoEm);
    const retorno = await agendamentos.gravarComItens(
      { petId: pet.id, tutorId: pet.tutorId, inicio: inicioRetorno, status: 'agendado', origem: 'avulso' },
      await montarItens(pet, lista)
    );
    // guardado no atendimento: se ele for reaberto ou desfeito, o retorno sai junto
    const finalizado = await agendamentos.obter(ag.id);
    await agendamentos.salvar({ ...finalizado, retornoId: retorno.id });
    ctx.toast(`Atendimento concluído · retorno em ${fmtDataCurta(inicioRetorno)} às ${fmtHora(inicioRetorno)}`);
  } else {
    ctx.toast('Atendimento concluído');
  }

  const aindaNaLoja = await agendamentos.emAtendimento();
  ctx.navegar(aindaNaLoja.length ? 'atendimento-dia' : 'agenda', {}, { substituir: true });
}
