import {
  html, icon, fmtBRL, fmtBRLCurto, fmtData, fmtDataCurta, fmtHora, mesmoDia, DIA_MS,
  inicioDoDia, fimDoDia, inicioDaSemana, inicioDoMes, fimDoMes, valorData,
} from '../core/dom.js';
import { vazio, barra, CORES_TRACO } from '../core/ui.js';
import { agendamentos, faturamento, planos, tutores, servicos, dataDoAtendimento, nomesParaRelatorio } from '../data/repo.js';
import { compartilharArquivo } from '../core/nativo.js';
import { minutosDaVisita } from '../logic/metricas.js';
import { escolherFormaRecebimento } from '../modais/recebimento.js';

/* FATURAMENTO — atendimentos concluídos + mensalidades de planos.
   "Faturamento" é o que foi vendido no período (atendimento pelo dia em que o
   pet veio, mensalidade no 1º banho do plano em cada mês), inclusive o que ainda não foi pago.
   "Recebido no caixa" é o que entrou no período, pela data do pagamento; o
   quadro "por forma de pagamento" detalha esse mesmo valor. */

const PERIODOS = ['Hoje', 'Semana', 'Este mês', 'Mês passado'];
const ICONES_PAGAMENTO = { PIX: 'qr-code', Dinheiro: 'banknote', Débito: 'credit-card', Crédito: 'credit-card', Fiado: 'wallet' };
const MAX_FATIAS = 5;
const MAX_LINHAS_RECEBER = 10;
const COR_PLANOS = 'var(--roxo-claro)';

// recebimentos feitos nesta visita à tela (chave → forma anterior): permitem desfazer sem a linha sumir
const ui = { periodo: 'Este mês', recebidos: new Map() };

function intervalo(periodo, agora = Date.now()) {
  switch (periodo) {
    case 'Hoje':
      return { de: inicioDoDia(agora), ate: fimDoDia(agora) };
    case 'Semana':
      return { de: inicioDaSemana(agora), ate: fimDoDia(agora) };
    case 'Mês passado': {
      const d = new Date(agora);
      const ref = new Date(d.getFullYear(), d.getMonth() - 1, 15).getTime();
      return { de: inicioDoMes(ref), ate: fimDoMes(ref) };
    }
    default:
      return { de: inicioDoMes(agora), ate: fimDoDia(agora) };
  }
}

/** Reparte o valor cobrado entre os serviços, proporcional ao preço de cada um (desconto incluso). */
function porServico(concluidos, itensPorAg, cores) {
  const mapa = new Map();
  for (const ag of concluidos) {
    const itens = itensPorAg.get(ag.id) || [];
    const bruto = itens.reduce((s, i) => s + (i.precoCentavos || 0), 0);
    if (!ag.valorCentavos) continue;
    if (!bruto) {
      const outros = mapa.get('Outros') || { nome: 'Outros', valor: 0, cor: 'var(--texto-6)' };
      outros.valor += ag.valorCentavos;
      mapa.set('Outros', outros);
      continue;
    }
    // o arredondamento de cada parte vai para o último serviço: a soma bate com o valor cobrado
    let distribuido = 0;
    itens.forEach((i, n) => {
      const parte = n === itens.length - 1 ? ag.valorCentavos - distribuido : Math.round(((i.precoCentavos || 0) / bruto) * ag.valorCentavos);
      distribuido += parte;
      const atual = mapa.get(i.nome) || { nome: i.nome, valor: 0, cor: cores.get(i.servicoId) };
      atual.valor += parte;
      mapa.set(i.nome, atual);
    });
  }
  const outrosAvulsos = mapa.get('Outros')?.valor || 0;
  mapa.delete('Outros');
  const lista = [...mapa.values()].sort((a, b) => b.valor - a.valor);
  const principais = lista.slice(0, MAX_FATIAS);
  const resto = lista.slice(MAX_FATIAS).reduce((s, x) => s + x.valor, 0) + outrosAvulsos;
  if (resto) principais.push({ nome: 'Outros', valor: resto, cor: 'var(--texto-6)' });
  principais.forEach((x, i) => (x.cor = x.cor || CORES_TRACO[i % CORES_TRACO.length]));
  return principais;
}

/** Percentuais inteiros que sempre somam 100 (o arredondamento sobra para as maiores partes). */
function percentuais(valores) {
  const total = valores.reduce((s, v) => s + v, 0);
  if (!total) return valores.map(() => 0);
  const brutos = valores.map((v) => (v / total) * 100);
  const saida = brutos.map(Math.floor);
  let falta = 100 - saida.reduce((s, v) => s + v, 0);
  const ordem = brutos.map((b, i) => [b - Math.floor(b), i]).sort((x, y) => y[0] - x[0]);
  for (const [, i] of ordem) if (falta-- > 0) saida[i]++;
  return saida;
}

export default {
  titulo: 'Faturamento',
  menu: 'faturamento',

  async carregar() {
    const { de, ate } = intervalo(ui.periodo);
    const { concluidos, itensPorAg, mensalidades, recebimentos } = await faturamento.periodo(de, ate);
    // nomes inclusive de pets e tutores excluídos: o histórico não perde quem foi
    const { pets: nomesPets, tutores: nomesTutores } = await nomesParaRelatorio();
    const listaTutores = await tutores.listar();
    // "Como conheceu a loja": de onde vêm os clientes (tutores ativos)
    const ativos = listaTutores.filter((x) => x.ativo !== false);
    const origens = new Map();
    for (const t of ativos) {
      const o = (t.origem || '').trim() || 'Não informado';
      origens.set(o, (origens.get(o) || 0) + 1);
    }
    const cores = new Map((await servicos.listar()).map((s) => [s.id, s.cor]));

    const atendimentosCentavos = concluidos.reduce((s, a) => s + (a.valorCentavos || 0), 0);
    const planosCentavos = mensalidades.reduce((s, m) => s + m.valorCentavos, 0);
    const pagos = concluidos.filter((a) => (a.valorCentavos || 0) > 0);
    const minutos = [...itensPorAg.values()].reduce((s, itens) => s + minutosDaVisita(itens), 0);

    // caixa: o que entrou no período, pela forma realmente usada
    const formas = new Map();
    for (const r of recebimentos) formas.set(r.forma, (formas.get(r.forma) || 0) + r.valorCentavos);
    const recebidoCentavos = recebimentos.reduce((s, r) => s + r.valorCentavos, 0);

    const fatias = porServico(concluidos, itensPorAg, cores);
    if (planosCentavos) fatias.push({ nome: 'Mensalidades de planos', valor: planosCentavos, cor: COR_PLANOS });

    // "A receber" é o saldo em aberto de sempre, independente do período escolhido
    const receber = [
      ...(await faturamento.pendentes()).map((a) => ({
        chave: `ag:${a.id}`,
        tipo: 'ag',
        id: a.id,
        ts: dataDoAtendimento(a),
        valor: a.valorCentavos || 0,
        titulo: nomesPets.get(a.petId) || 'Pet',
        sub: nomesTutores.get(a.tutorId) || 'Sem tutor',
        forma: a.formaPagamento || null,
      })),
      ...(await faturamento.mensalidadesAbertas()).map((m) => ({
        chave: `plano:${m.plano.id}:${m.mes}`,
        tipo: 'plano',
        planoId: m.plano.id,
        mes: m.mes,
        ts: m.ts,
        valor: m.valorCentavos,
        titulo: `${nomesPets.get(m.plano.petId) || 'Pet'} · mensalidade${m.k ? ` ${m.k}/${m.total}` : ''}`,
        sub: m.plano.nome,
      })),
    ].sort((a, b) => a.ts - b.ts);

    const totalCentavos = atendimentosCentavos + planosCentavos;
    return {
      de,
      ate,
      concluidos,
      itensPorAg,
      mensalidades,
      recebimentos,
      nomesPets,
      nomesTutores,
      totalCentavos,
      recebidoCentavos,
      qtd: concluidos.length,
      qtdMensalidades: mensalidades.length,
      ticketCentavos: pagos.length ? Math.round(pagos.reduce((s, a) => s + a.valorCentavos, 0) / pagos.length) : 0,
      // as mensalidades pagam os banhos dos planos, que também gastam horas de cronômetro
      porHoraCentavos: minutos ? Math.round(totalCentavos / (minutos / 60) / 100) * 100 : 0,
      fatias,
      formas: [...formas.entries()].sort((a, b) => b[1] - a[1]),
      receber,
      origens: [...origens.entries()].sort((a, b) => b[1] - a[1]),
      totalTutores: ativos.length,
    };
  },

  render(vm) {
    const somaFatias = vm.fatias.reduce((s, f) => s + f.valor, 0);
    const pcts = percentuais(vm.fatias.map((f) => f.valor));
    let acumulado = 0;
    const gradiente = somaFatias
      ? `conic-gradient(${vm.fatias
          .map((f) => {
            const ini = (acumulado / somaFatias) * 100;
            acumulado += f.valor;
            return `${f.cor} ${ini.toFixed(2)}% ${((acumulado / somaFatias) * 100).toFixed(2)}%`;
          })
          .join(', ')})`
      : 'var(--borda)';

    const abertos = vm.receber.filter((r) => !ui.recebidos.has(r.chave));
    const totalAberto = abertos.reduce((s, r) => s + r.valor, 0);
    const atrasados = abertos.filter((r) => Date.now() - r.ts > 15 * DIA_MS).length;
    const quando = (ts) => (mesmoDia(ts, Date.now()) ? `hoje · ${fmtHora(ts)}` : fmtDataCurta(ts));
    const lancamentos = (n) => `${n} ${n === 1 ? 'lançamento' : 'lançamentos'}`;

    return html`
      <div class="fat-topo">
        <div class="segmento">${PERIODOS.map((p) => html`<button class="${ui.periodo === p ? 'on' : ''}" data-acao="periodo" data-periodo="${p}">${p}</button>`)}</div>
        <button class="btn btn-branco" style="font-weight:500;padding:10px 15px" data-acao="exportar">${icon('download', 15)}<span>Exportar</span></button>
      </div>

      <div class="grade-4 fat-kpis">
        <div class="kpi"><div class="kpi-rotulo">Faturamento</div><div class="kpi-valor">${fmtBRLCurto(vm.totalCentavos)}</div><div class="kpi-sub">${vm.qtd} ${vm.qtd === 1 ? 'atendimento' : 'atendimentos'}${vm.qtdMensalidades ? ` + ${vm.qtdMensalidades} ${vm.qtdMensalidades === 1 ? 'mensalidade' : 'mensalidades'}` : ''}</div></div>
        <div class="kpi"><div class="kpi-rotulo">Recebido no caixa</div><div class="kpi-valor" style="color:var(--verde-escuro)">${fmtBRLCurto(vm.recebidoCentavos)}</div><div class="kpi-sub">pela data do pagamento</div></div>
        <div class="kpi"><div class="kpi-rotulo">Ticket médio</div><div class="kpi-valor">${fmtBRLCurto(vm.ticketCentavos)}</div></div>
        <div class="kpi"><div class="kpi-rotulo">Faturamento/hora</div><div class="kpi-valor">${vm.porHoraCentavos ? fmtBRLCurto(vm.porHoraCentavos) : '—'}</div></div>
      </div>

      <div class="grade-2 fat-grade">
        <div class="card pad-18 fat-donut-card">
          <div class="fat-donut" style="background:${gradiente}">
            <div class="fat-donut-miolo">
              <div style="font-size:11px;color:var(--texto-3);font-weight:500">Total</div>
              <div style="font-size:17px;font-weight:600;color:var(--tinta-2)">${fmtBRLCurto(somaFatias)}</div>
            </div>
          </div>
          <div style="display:flex;flex-direction:column;gap:9px;flex:1;min-width:0">
            <div class="titulo-card" style="margin-bottom:2px">Faturamento por serviço</div>
            ${vm.fatias.length
              ? vm.fatias.map(
                  (f, i) => html`<div class="fat-legenda">
                    <span class="fat-ponto" style="background:${f.cor}"></span>
                    <span class="truncar" style="color:var(--texto-2);font-weight:500;flex:1;min-width:0">${f.nome}</span>
                    <span style="color:var(--tinta-2);font-weight:600;white-space:nowrap">${fmtBRLCurto(f.valor)}</span>
                    <span style="color:var(--texto-5);white-space:nowrap;width:34px;text-align:right">${pcts[i]}%</span>
                  </div>`
                )
              : html`<div class="mutado" style="font-size:12.5px">Nada faturado no período.</div>`}
          </div>
        </div>

        <div class="painel">
          <div class="titulo-card" style="margin-bottom:2px">Recebido por forma de pagamento</div>
          <div class="mutado" style="font-size:12px;margin-bottom:10px">O que entrou no caixa no período · total ${fmtBRL(vm.recebidoCentavos)}</div>
          ${vm.formas.length
            ? vm.formas.map(
                ([nome, valor]) => html`<div class="linha">
                  <span style="display:flex;align-items:center;gap:8px;color:var(--texto-2)"><span style="color:var(--texto-3);display:flex">${icon(ICONES_PAGAMENTO[nome] || 'wallet', 14)}</span>${nome}</span>
                  <span style="font-weight:600;color:var(--tinta-2)">${fmtBRLCurto(valor)}</span>
                </div>`
              )
            : html`<div class="mutado" style="font-size:12.5px;padding:9px 0;border-top:1px solid var(--divisor)">Nada entrou no caixa neste período.</div>`}
        </div>
      </div>

      <div class="grade-2 fat-grade">
        <div class="painel">
          <div style="display:flex;justify-content:space-between;align-items:baseline;margin-bottom:2px;gap:10px">
            <div class="titulo-card">A receber</div>
            <div style="font-size:17px;font-weight:600;color:var(--rosa)">${fmtBRL(totalAberto)}</div>
          </div>
          <div class="mutado" style="font-size:12px;margin-bottom:4px">${lancamentos(abertos.length)} aguardando pagamento</div>
          ${vm.receber.length
            ? html`${vm.receber.slice(0, MAX_LINHAS_RECEBER).map((r) => {
                const recebido = ui.recebidos.has(r.chave);
                return html`<div class="fat-receber">
                  <div style="min-width:0">
                    <div class="truncar" style="font-size:13px;font-weight:600;color:var(--tinta-2)">${r.titulo} · ${fmtBRL(r.valor)}</div>
                    <div class="truncar mutado" style="font-size:11.5px;margin-top:2px">${r.sub} · ${r.tipo === 'plano' ? `1º banho do mês em ${fmtDataCurta(r.ts)}` : quando(r.ts)}</div>
                  </div>
                  <button class="aviso-botao${recebido ? ' recebido' : ' pagar'}" data-acao="receber" data-chave="${r.chave}">${recebido ? 'Recebido · desfazer' : 'Marcar recebido'}</button>
                </div>`;
              })}
              ${vm.receber.length > MAX_LINHAS_RECEBER
                ? html`<div class="mutado" style="font-size:12px;padding-top:10px;border-top:1px solid var(--divisor)">e mais ${lancamentos(vm.receber.length - MAX_LINHAS_RECEBER)} (os mais antigos aparecem primeiro)</div>`
                : ''}`
            : vazio({ icone: 'circle-check-big', titulo: 'Nada a receber', texto: 'Atendimentos e mensalidades estão pagos.', compacto: true })}
        </div>
        <div class="fat-pendentes">
          <div style="display:flex;align-items:center;gap:8px;color:var(--ambar)"><span style="font-size:13px;font-weight:600">Pendentes de recebimento</span></div>
          <div style="font-size:26px;font-weight:600;color:var(--ambar-escuro);margin-top:8px">${fmtBRL(totalAberto)}</div>
          <div style="font-size:12px;color:var(--ambar-texto);margin-top:2px">${lancamentos(abertos.length)}${atrasados ? ` · ${atrasados} há mais de 15 dias` : ''}</div>
        </div>
      </div>

      <div class="painel">
        <div class="cab-card" style="margin-bottom:10px">
          <div class="titulo-card">Como os clientes chegaram</div>
          <span class="mutado" style="font-size:12px">${vm.totalTutores} ${vm.totalTutores === 1 ? 'tutor' : 'tutores'}</span>
        </div>
        ${vm.origens.length
          ? vm.origens.map(([nome, qtd]) => {
              const pct = Math.round((qtd / vm.totalTutores) * 100);
              return html`<div style="padding:8px 0;border-top:1px solid var(--divisor)">
                <div style="display:flex;justify-content:space-between;font-size:12.5px;margin-bottom:6px"><span style="color:var(--texto-2);font-weight:500">${nome}</span><span style="font-weight:600;color:var(--tinta-2)">${qtd} · ${pct}%</span></div>
                ${barra(pct, nome === 'Não informado' ? 'var(--texto-6)' : 'var(--roxo)', 7)}
              </div>`;
            })
          : html`<div class="mutado" style="font-size:12.5px;padding:9px 0;border-top:1px solid var(--divisor)">Cadastre tutores marcando “Como conheceu a loja”.</div>`}
      </div>`;
  },

  acoes: {
    periodo: ({ periodo }, ctx) => {
      ui.periodo = periodo;
      ui.recebidos.clear();
      ctx.recarregar();
    },
    receber: async ({ chave }, ctx) => {
      const r = ctx.vm.receber.find((x) => x.chave === chave);
      if (!r) return;
      if (ui.recebidos.has(chave)) {
        if (r.tipo === 'ag') await agendamentos.desfazerRecebimento(r.id, ui.recebidos.get(chave));
        else await planos.desfazerPagamento(r.planoId, r.mes);
        ui.recebidos.delete(chave);
        ctx.toast('Recebimento desfeito');
        return ctx.redesenhar();
      }
      const forma = await escolherFormaRecebimento(ctx, { valorCentavos: r.valor, detalhe: r.titulo });
      if (!forma) return;
      if (r.tipo === 'ag') await agendamentos.registrarRecebimento(r.id, forma);
      else await planos.registrarPagamento(r.planoId, r.mes, forma);
      ui.recebidos.set(chave, r.forma ?? null);
      ctx.toast(`Recebimento registrado · ${forma}`);
      ctx.redesenhar();
    },
    exportar: (_, ctx) => exportarCsv(ctx),
  },

  aoSair() {
    ui.recebidos.clear();
  },
};

function exportarCsv(ctx) {
  const vm = ctx.vm;
  const celula = (v) => `"${String(v ?? '').replace(/"/g, '""')}"`;
  const reais = (c) => ((c || 0) / 100).toFixed(2).replace('.', ',');
  const quando = (ts) => (ts ? `${fmtData(ts)} ${fmtHora(ts)}` : '');
  const linhas = [['Data', 'Tipo', 'Pet', 'Tutor', 'Serviços', 'Subtotal (R$)', 'Desconto (R$)', 'Acréscimo (R$)', 'Valor (R$)', 'Forma de pagamento', 'Situação', 'Recebido em']];

  for (const ag of [...vm.concluidos].sort((a, b) => dataDoAtendimento(a) - dataDoAtendimento(b))) {
    linhas.push([
      quando(dataDoAtendimento(ag)),
      'Atendimento',
      vm.nomesPets.get(ag.petId) || '',
      vm.nomesTutores.get(ag.tutorId) || '',
      (vm.itensPorAg.get(ag.id) || []).map((i) => i.nome).join(' + '),
      reais(ag.subtotalCentavos),
      reais(ag.descontoCentavos),
      reais(ag.acrescimoCentavos),
      reais(ag.valorCentavos),
      ag.formaPagamento || '',
      !ag.valorCentavos ? 'Sem cobrança' : ag.pagamentoPendente ? 'A receber' : 'Pago',
      ag.pagamentoPendente || !ag.valorCentavos ? '' : quando(ag.pagoEm || ag.finalizadoEm),
    ]);
  }
  for (const m of vm.mensalidades) {
    linhas.push([
      fmtData(m.ts),
      'Mensalidade de plano',
      vm.nomesPets.get(m.plano.petId) || '',
      vm.nomesTutores.get(m.plano.tutorId) || '',
      m.plano.nome,
      reais(m.valorCentavos),
      reais(0),
      reais(0),
      reais(m.valorCentavos),
      m.pagamento?.formaPagamento || '',
      m.pagamento ? 'Pago' : 'Em aberto',
      m.pagamento ? quando(m.pagamento.pagoEm) : '',
    ]);
  }
  if (linhas.length === 1) return ctx.toast('Nada para exportar neste período', { erro: true });
  linhas.push([]);
  linhas.push(['Faturamento do período', '', '', '', '', '', '', '', reais(vm.totalCentavos)]);
  linhas.push(['Recebido no caixa no período', '', '', '', '', '', '', '', reais(vm.recebidoCentavos)]);

  // ; e BOM: abre certo no Excel em português
  const csv = '\ufeff' + linhas.map((l) => l.map(celula).join(';')).join('\r\n');
  compartilharArquivo(`faturamento-${valorData(vm.de)}-a-${valorData(vm.ate)}.csv`, csv, 'text/csv');
  ctx.toast(`Planilha gerada · ${vm.concluidos.length + vm.mensalidades.length} lançamentos`);
}
