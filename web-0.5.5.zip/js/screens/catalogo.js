import { html, icon, fmtBRLCurto, fmtDur, inicioDoMes, fimDoMes } from '../core/dom.js';
import { patinhasHero, vazio } from '../core/ui.js';
import { agendamentos, servicos, tempos } from '../data/repo.js';
import { editarServico } from '../modais/servico.js';
import { combina, ordenarPor } from '../core/busca.js';

/* CATÁLOGO DE SERVIÇOS — preço de referência, tempo de referência x real.
   Exibido em ordem alfabética; a ordem gravada (usada no agendamento) não muda. */

const ui = { busca: '' };

export default {
  titulo: 'Catálogo de serviços',
  menu: 'servicos',

  async carregar() {
    const lista = await servicos.listar();
    const doMes = (await agendamentos.concluidos()).filter((a) => a.inicio >= inicioDoMes(Date.now()) && a.inicio <= fimDoMes(Date.now()));
    const execucoes = new Map();
    for (const itens of (await agendamentos.itensDe(doMes)).values()) {
      for (const i of itens) if (i.servicoId) execucoes.set(i.servicoId, (execucoes.get(i.servicoId) || 0) + 1);
    }
    const linhas = [];
    for (const s of ordenarPor(lista, (x) => x.nome)) linhas.push({ servico: s, real: await tempos.mediaDaLoja(s.id) });
    return {
      linhas,
      stats: [
        { rotulo: 'Serviços ativos', valor: lista.filter((s) => s.ativo !== false).length },
        { rotulo: 'Categorias', valor: new Set(lista.map((s) => s.categoria).filter(Boolean)).size },
        { rotulo: 'Execuções no mês', valor: [...execucoes.values()].reduce((a, b) => a + b, 0) },
      ],
    };
  },

  render(vm) {
    const visiveis = vm.linhas.filter((l) => combina(ui.busca, [l.servico.nome, l.servico.categoria]));
    return html`<div class="card r24 cortar">
      <div class="hero">
        ${patinhasHero('padrao')}
        <div class="hero-conteudo" style="display:flex;justify-content:flex-end;align-items:center;gap:10px;flex-wrap:wrap">
          <button class="btn btn-branco" style="font-size:13.5px;padding:10px 16px" data-acao="categorias">${icon('tags', 15)}<span>Categorias</span></button>
          <button class="btn btn-roxo" style="font-size:13.5px;padding:10px 16px" data-acao="novo">${icon('plus', 15)}<span>Novo serviço</span></button>
        </div>
      </div>

      <div class="cat-stats">
        ${vm.stats.map((s) => html`<div class="kpi suave"><div class="kpi-rotulo">${s.rotulo}</div><div class="kpi-valor">${s.valor}</div></div>`)}
      </div>

      <div class="cat-lista">
        ${vm.linhas.length > 1 ? html`<div class="busca branca lista-busca">
          ${icon('search', 16)}
          <input data-campo="busca" value="${ui.busca}" placeholder="Buscar serviço ou categoria…">
          ${ui.busca ? html`<button data-acao="limpar-busca" style="display:flex;color:var(--texto-3)" aria-label="Limpar">${icon('x', 15)}</button>` : ''}
        </div>` : ''}
        ${vm.linhas.length && !visiveis.length ? vazio({ icone: 'search', titulo: 'Nenhum serviço encontrado', texto: 'Tente outro nome.', compacto: true }) : ''}
        ${vm.linhas.length
          ? visiveis.map(({ servico: s, real }) => {
              const ativo = s.ativo !== false;
              const portes = s.precoPorPorte && Object.values(s.precoPorPorte).some(Boolean);
              return html`<div class="cat-linha${ativo ? '' : ' inativo'}">
                <div style="min-width:0">
                  <div class="cat-nome truncar">${s.nome}</div>
                  <div style="margin-top:6px"><span class="selo selo-lavanda redondo">${s.categoria || 'Sem categoria'}</span></div>
                </div>
                <div>
                  <div class="rotulo-caps">Preço</div>
                  <div class="cat-valor">${s.precoCentavos ? fmtBRLCurto(s.precoCentavos) : portes ? '' : html`<span class="cat-sem-preco">Sem preço</span>`}${portes ? html`<span class="cat-porte">por porte</span>` : ''}</div>
                </div>
                <div>
                  <div class="rotulo-caps">Ref. / real</div>
                  <div style="font-size:14px;margin-top:3px;white-space:nowrap">
                    <span style="color:var(--texto-3);font-weight:500">${fmtDur(s.duracaoPadraoMin)}</span>
                    <span style="color:#bdb2ee">/</span>
                    <span style="color:var(--roxo);font-weight:600">${real ? fmtDur(real.mediaMin) : '—'}</span>
                  </div>
                </div>
                <div><button class="selo ${ativo ? 'selo-verde' : 'selo-neutro'} redondo" style="padding:5px 11px" data-acao="alternar" data-id="${s.id}">${ativo ? 'Ativo' : 'Inativo'}</button></div>
                <div class="cat-acoes">
                  <button class="cat-btn" data-acao="editar" data-id="${s.id}" aria-label="Editar">${icon('pencil', 14)}</button>
                  <button class="cat-btn rosa" data-acao="excluir" data-id="${s.id}" aria-label="Excluir">${icon('trash-2', 14)}</button>
                </div>
              </div>`;
            })
          : vazio({ icone: 'scissors', titulo: 'Nenhum serviço no catálogo', texto: 'Cadastre banho, tosa e adicionais com preço e duração de referência.', compacto: true })}
        <button class="cat-novo" data-acao="novo">${icon('plus', 15)}<span>Cadastrar novo serviço</span></button>
      </div>
    </div>`;
  },

  aoDigitar(campo, valor, ctx) {
    if (campo !== 'busca') return;
    ui.busca = valor;
    ctx.redesenhar();
  },

  acoes: {
    'limpar-busca': (_, ctx) => {
      ui.busca = '';
      ctx.redesenhar();
    },
    categorias: (_, ctx) => ctx.navegar('lista', { nome: 'Categorias de serviço' }),
    novo: async (_, ctx) => {
      if (await editarServico(ctx, null)) ctx.recarregar();
    },
    editar: async ({ id }, ctx) => {
      const linha = ctx.vm.linhas.find((l) => l.servico.id === id);
      if (await editarServico(ctx, linha.servico)) ctx.recarregar();
    },
    alternar: async ({ id }, ctx) => {
      const s = ctx.vm.linhas.find((l) => l.servico.id === id).servico;
      await servicos.salvar({ ...s, ativo: s.ativo === false });
      ctx.toast(s.ativo === false ? `${s.nome} ativado` : `${s.nome} desativado · não aparece mais no agendamento`);
      ctx.recarregar();
    },
    excluir: async ({ id }, ctx) => {
      const s = ctx.vm.linhas.find((l) => l.servico.id === id).servico;
      const ok = await ctx.confirmar({
        titulo: `Excluir “${s.nome}”?`,
        texto: 'O serviço sai do catálogo e vai para a lixeira por 30 dias. Atendimentos antigos continuam com o histórico.',
        botao: 'Mover para lixeira',
      });
      if (!ok) return;
      await servicos.excluir(id);
      ctx.toast('Serviço movido para a lixeira');
      ctx.recarregar();
    },
  },
};
