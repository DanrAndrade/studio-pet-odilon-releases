import * as db from './db.js';
import * as config from './config.js';
import { estimarDuracao, descartarOutliers, JANELA_HISTORICO, MINIMO_AMOSTRAS } from '../logic/duracao.js';
import { conflitos } from '../logic/agenda.js';
import { planoVigente, datasDasMensalidades, EDITAVEIS } from '../logic/planos.js';
import { ordemAlfabetica } from '../core/busca.js';
import { DIA_MS, digitos, inicioDoDia, fimDoDia } from '../core/dom.js';

/* Repositório de domínio. As telas conversam só com este módulo — nenhuma
   delas conhece IndexedDB. Dinheiro em centavos, duração em minutos. */

const { STORES } = db;
const agora = () => Date.now();
// ordem alfabética do português: acento e maiúscula não mudam a ordem
const porNome = (a, b) => ordemAlfabetica(a.nome || '', b.nome || '');
const RETENCAO_DIAS = 30;

function novoRegistro(dados) {
  const reg = { ...dados, id: dados.id || db.uuid(), atualizadoEm: agora() };
  if (!reg.criadoEm) reg.criadoEm = agora();
  return reg;
}

async function marcarExcluido(store, id, quando = agora()) {
  const r = await db.obter(store, id);
  if (r && !r.excluidoEm) await db.put(store, { ...r, excluidoEm: quando });
  return quando;
}

/* ============================== Tutores ============================== */

export const tutores = {
  async listar({ incluirInativos = true } = {}) {
    const lista = db.vivos(await db.todos(STORES.tutores)).sort(porNome);
    return incluirInativos ? lista : lista.filter((t) => t.ativo !== false);
  },
  obter: (id) => db.obter(STORES.tutores, id),
  async salvar(dados) {
    const reg = novoRegistro(dados);
    if (reg.ativo === undefined) reg.ativo = true;
    return db.put(STORES.tutores, reg);
  },
  async porTelefone(telefone) {
    const d = digitos(telefone);
    if (d.length < 8) return null;
    // vale o telefone principal ou o do segundo responsável
    const bate = (f) => digitos(f).length >= 8 && digitos(f).endsWith(d.slice(-8));
    return (await this.listar()).find((t) => bate(t.telefone) || bate(t.telefone2)) || null;
  },
  /** Exclui o tutor junto com os pets dele (mesmo carimbo, para restaurar tudo junto). */
  async excluir(id) {
    const quando = await marcarExcluido(STORES.tutores, id);
    for (const pet of await pets.doTutor(id)) await pets.excluir(pet.id, quando);
  },
};

/* ================================ Pets =============================== */

export const pets = {
  async listar() {
    return db.vivos(await db.todos(STORES.pets)).sort(porNome);
  },
  obter: (id) => db.obter(STORES.pets, id),
  async doTutor(tutorId) {
    return db.vivos(await db.porIndice(STORES.pets, 'tutorId', tutorId)).sort(porNome);
  },
  async salvar(dados) {
    return db.put(STORES.pets, novoRegistro(dados));
  },
  /** Exclui o pet e os agendamentos futuros ainda não realizados. */
  async excluir(id, quando = agora()) {
    await marcarExcluido(STORES.pets, id, quando);
    const futuros = (await db.porIndice(STORES.agendamentos, 'petId', id)).filter(
      (a) => !a.excluidoEm && a.inicio >= inicioDoDia(agora()) && a.status !== 'concluido'
    );
    for (const ag of futuros) await marcarExcluido(STORES.agendamentos, ag.id, quando);
    // o plano de um pet excluído para de gerar visitas e mensalidades (volta junto se o pet for restaurado)
    for (const plano of db.vivos(await db.porIndice(STORES.planos, 'petId', id))) {
      await marcarExcluido(STORES.planos, plano.id, quando);
    }
  },
  async registrarOcorrencia(petId, { tipo, texto, agendamentoId = null }) {
    const pet = await this.obter(petId);
    if (!pet) return null;
    const ocorrencia = { id: db.uuid(), tipo, texto, agendamentoId, em: agora() };
    await this.salvar({ ...pet, ocorrencias: [ocorrencia, ...(pet.ocorrencias || [])] });
    return ocorrencia;
  },
};

/* ============================== Serviços ============================= */

export const servicos = {
  async listar() {
    // ordem alfabética em todas as listas (agendamento, plano, catálogo)
    return db.vivos(await db.todos(STORES.servicos)).sort(porNome);
  },
  async ativos() {
    return (await this.listar()).filter((s) => s.ativo !== false);
  },
  obter: (id) => db.obter(STORES.servicos, id),
  async salvar(dados) {
    const reg = novoRegistro(dados);
    if (reg.ativo === undefined) reg.ativo = true;
    if (reg.ordem === undefined) reg.ordem = (await this.listar()).length + 1;
    return db.put(STORES.servicos, reg);
  },
  excluir: (id) => marcarExcluido(STORES.servicos, id),
};

/** Os portes com que o Odilon trabalha, do menor para o maior. */
export const PORTES = ['Pequeno', 'Pequeno/Médio', 'Médio', 'Médio/Grande', 'Grande', 'Gigante'];

/**
 * Preço do serviço para o porte do pet: o preço daquele porte; sem ele, o
 * padrão do serviço. (Gigante sem preço próprio usa o de Grande, como antes.)
 */
export function precoParaPorte(servico, porte) {
  const tabela = servico?.precoPorPorte || {};
  if (tabela[porte]) return tabela[porte];
  if (porte === 'Gigante' && tabela.Grande) return tabela.Grande;
  return servico?.precoCentavos || 0;
}

/* =========================== Agendamentos ============================ */

const ordenarItens = (xs) => xs.sort((a, b) => (a.ordem ?? 0) - (b.ordem ?? 0));

/**
 * Desconto e acréscimo válidos: nunca negativos, e o desconto nunca passa do
 * que há para cobrar (o total nunca fica abaixo de zero).
 */
/**
 * Aplica um preço final ao serviço do atendimento. Guarda o preço de tabela na
 * primeira mudança; voltando ao preço de tabela, a marca de ajuste sai.
 */
export function comPreco(item, novo) {
  if (novo === undefined || novo === null || !Number.isFinite(Number(novo))) return item;
  const preco = Math.max(0, Math.round(Number(novo)));
  const tabela = item.precoTabelaCentavos ?? item.precoCentavos ?? 0;
  const { precoTabelaCentavos, ...resto } = item;
  return preco === tabela ? { ...resto, precoCentavos: preco } : { ...resto, precoCentavos: preco, precoTabelaCentavos: tabela };
}

export function ajustes(subtotal, descontoCentavos, acrescimoCentavos) {
  const acrescimo = Math.max(0, Math.round(acrescimoCentavos || 0));
  const desconto = Math.min(Math.max(0, Math.round(descontoCentavos || 0)), Math.max(0, subtotal) + acrescimo);
  return { desconto, acrescimo };
}

export const agendamentos = {
  async porPeriodo(de, ate) {
    return db.vivos(await db.porIntervalo(STORES.agendamentos, 'inicio', de, ate)).sort((a, b) => a.inicio - b.inicio);
  },
  obter: (id) => db.obter(STORES.agendamentos, id),
  async doPet(petId) {
    return db.vivos(await db.porIndice(STORES.agendamentos, 'petId', petId)).sort((a, b) => b.inicio - a.inicio);
  },
  async doPlano(planoId) {
    return db.vivos(await db.porIndice(STORES.agendamentos, 'planoId', planoId)).sort((a, b) => a.inicio - b.inicio);
  },
  /** Banhos do plano depois de `antesTs` que ainda não aconteceram (os que uma remarcação pode levar junto). */
  async seguintesDoPlano(planoId, antesTs, exceto) {
    return (await this.doPlano(planoId)).filter((v) => v.id !== exceto && v.inicio > antesTs && EDITAVEIS.includes(v.status));
  },
  /** Leva os banhos seguintes do plano `dias` dias para frente (ou para trás), cada um no seu horário. */
  async moverSeguintesDoPlano(planoId, antesTs, exceto, dias) {
    const seguintes = await this.seguintesDoPlano(planoId, antesTs, exceto);
    for (const v of seguintes) {
      const d = new Date(v.inicio);
      d.setDate(d.getDate() + dias);
      await this.salvar({ ...v, inicio: d.getTime(), planoManual: false, planoAncora: false, lembreteEnviadoEm: null });
    }
    return seguintes.length;
  },
  async emAtendimento() {
    return db
      .vivos(await db.porIndice(STORES.agendamentos, 'status', 'em_atendimento'))
      .sort((a, b) => (a.chegadaEm || a.inicio) - (b.chegadaEm || b.inicio));
  },
  async concluidos() {
    return db.vivos(await db.porIndice(STORES.agendamentos, 'status', 'concluido'));
  },
  async itens(agendamentoId) {
    return ordenarItens(await db.porIndice(STORES.itens, 'agendamentoId', agendamentoId));
  },
  async itensDe(lista) {
    const mapa = new Map();
    for (const ag of lista) mapa.set(ag.id, await this.itens(ag.id));
    return mapa;
  },
  async salvar(dados) {
    return db.put(STORES.agendamentos, novoRegistro(dados));
  },

  /**
   * Cria ou atualiza um agendamento com seus serviços.
   * @param {object} ag    campos do agendamento (id opcional para edição)
   * @param {object[]} itens { servicoId, nome, categoria, precoCentavos, duracaoPrevistaMin, mediaSeg }
   */
  async gravarComItens(ag, itens) {
    const subtotal = itens.reduce((s, i) => s + (i.precoCentavos || 0), 0);
    const duracao = itens.reduce((s, i) => s + (i.duracaoPrevistaMin || 0), 0) || ag.duracaoPrevistaMin || 60;
    const { desconto, acrescimo } = ajustes(subtotal, ag.descontoCentavos, ag.acrescimoCentavos);
    const registro = await this.salvar({
      status: 'agendado',
      origem: 'avulso',
      observacoes: [],
      ...ag,
      subtotalCentavos: subtotal,
      descontoCentavos: desconto,
      acrescimoCentavos: acrescimo,
      duracaoPrevistaMin: duracao,
      valorCentavos: subtotal - desconto + acrescimo,
    });

    const anteriores = await this.itens(registro.id);
    await db.removerVarios(STORES.itens, anteriores.map((i) => i.id));
    await db.putVarios(
      STORES.itens,
      itens.map((i, ordem) => ({
        accSeg: 0,
        t0: null,
        done: false,
        usarNaMedia: true,
        ...i,
        id: db.uuid(),
        agendamentoId: registro.id,
        ordem,
      }))
    );
    return registro;
  },

  /** Pet chegou: começa o atendimento e liga o cronômetro do primeiro serviço. */
  async registrarChegada(id) {
    const ag = await this.obter(id);
    if (!ag) return null;
    const itens = await this.itens(id);
    if (!itens.some((i) => i.t0) && itens.length) {
      const primeiro = itens.find((i) => !i.done);
      if (primeiro) await db.put(STORES.itens, { ...primeiro, t0: agora() });
    }
    return this.salvar({ ...ag, status: 'em_atendimento', chegadaEm: ag.chegadaEm || agora() });
  },

  /** Iniciar / pausar / reabrir o cronômetro de um serviço (como no protótipo). */
  async alternarItem(itemId) {
    const item = await db.obter(STORES.itens, itemId);
    if (!item) return;
    const t = agora();
    if (item.done) Object.assign(item, { done: false, t0: t });
    else if (item.t0) Object.assign(item, { accSeg: (item.accSeg || 0) + (t - item.t0) / 1000, t0: null });
    else item.t0 = t;
    await db.put(STORES.itens, item);
  },

  async concluirItem(itemId) {
    const item = await db.obter(STORES.itens, itemId);
    if (!item) return;
    if (item.t0) item.accSeg = (item.accSeg || 0) + (agora() - item.t0) / 1000;
    await db.put(STORES.itens, { ...item, t0: null, done: true });
  },

  /** Para os cronômetros dos serviços; devolve os ids dos que estavam correndo. */
  async pausarTodos(agendamentoId) {
    const t = agora();
    const correndo = [];
    for (const item of await this.itens(agendamentoId)) {
      if (!item.t0) continue;
      correndo.push(item.id);
      await db.put(STORES.itens, { ...item, accSeg: (item.accSeg || 0) + (t - item.t0) / 1000, t0: null });
    }
    return correndo;
  },

  /**
   * Pausa o atendimento: o relógio do atendimento para e os serviços que
   * estavam correndo param junto (e voltam ao retomar).
   */
  async pausar(id) {
    const ag = await this.obter(id);
    if (!ag || ag.status !== 'em_atendimento' || ag.pausadoEm) return ag;
    const correndo = await this.pausarTodos(id);
    return this.salvar({ ...ag, pausadoEm: agora(), pausadosItens: correndo });
  },

  /** Retoma o atendimento pausado; `servicos` = religar os serviços que foram pausados juntos. */
  async retomar(id, { servicos = true } = {}) {
    const ag = await this.obter(id);
    if (!ag || !ag.pausadoEm) return ag;
    const t = agora();
    if (servicos) {
      for (const itemId of ag.pausadosItens || []) {
        const item = await db.obter(STORES.itens, itemId);
        if (item && !item.done && !item.t0) await db.put(STORES.itens, { ...item, t0: t });
      }
    }
    return this.salvar({ ...ag, pausaSeg: (ag.pausaSeg || 0) + Math.max(0, (t - ag.pausadoEm) / 1000), pausadoEm: null, pausadosItens: [] });
  },

  async adicionarItem(agendamentoId, item) {
    const atuais = await this.itens(agendamentoId);
    await db.put(STORES.itens, {
      accSeg: 0,
      t0: null,
      done: false,
      usarNaMedia: true,
      ...item,
      id: db.uuid(),
      agendamentoId,
      ordem: atuais.length,
    });
    await this.recalcularValores(agendamentoId);
  },

  async recalcularValores(agendamentoId) {
    const ag = await this.obter(agendamentoId);
    const itens = await this.itens(agendamentoId);
    const subtotal = itens.reduce((s, i) => s + (i.precoCentavos || 0), 0);
    const { desconto, acrescimo } = ajustes(subtotal, ag.descontoCentavos, ag.acrescimoCentavos);
    return this.salvar({
      ...ag,
      subtotalCentavos: subtotal,
      descontoCentavos: desconto,
      acrescimoCentavos: acrescimo,
      duracaoPrevistaMin: itens.reduce((s, i) => s + (i.duracaoPrevistaMin || 0), 0) || ag.duracaoPrevistaMin,
      valorCentavos: subtotal - desconto + acrescimo,
    });
  },

  async observar(agendamentoId, texto) {
    const ag = await this.obter(agendamentoId);
    return this.salvar({ ...ag, observacoes: [...(ag.observacoes || []), texto] });
  },

  async removerObservacao(agendamentoId, indice) {
    const ag = await this.obter(agendamentoId);
    return this.salvar({ ...ag, observacoes: (ag.observacoes || []).filter((_, i) => i !== indice) });
  },

  /**
   * Fecha o atendimento: congela os cronômetros, grava a duração real de cada
   * serviço (é isso que alimenta as médias) e registra o pagamento.
   */
  /**
   * @param {object} opcoes.precos  preço final por serviço, ajustado na hora de cobrar
   *   ({ [itemId]: centavos }). O preço de tabela fica guardado em precoTabelaCentavos.
   */
  async finalizar(id, { descontoCentavos = 0, formaPagamento, pagamentoPendente = false, pagoEm = null, usarNaMedia = true, recomendacao = '', precos = {} }) {
    const ag = await this.obter(id);
    const t = agora();
    // relógio do atendimento parado (pausa ou reabertura): o tempo parado não conta
    const pausaSeg = (ag.pausaSeg || 0) + (ag.pausadoEm ? Math.max(0, (t - ag.pausadoEm) / 1000) : 0);
    const itens = await this.itens(id);
    const finais = itens.map((i) => {
      const acc = (i.accSeg || 0) + (i.t0 ? (t - i.t0) / 1000 : 0);
      return comPreco(
        { ...i, accSeg: acc, t0: null, done: true, duracaoRealMin: acc >= 30 ? Math.max(1, Math.round(acc / 60)) : null, usarNaMedia },
        precos[i.id]
      );
    });
    await db.putVarios(STORES.itens, finais);

    const subtotal = finais.reduce((s, i) => s + (i.precoCentavos || 0), 0);
    const { desconto, acrescimo } = ajustes(subtotal, descontoCentavos, ag.acrescimoCentavos);
    const valor = subtotal - desconto + acrescimo;
    return this.salvar({
      ...ag,
      status: 'concluido',
      finalizadoEm: t,
      subtotalCentavos: subtotal,
      descontoCentavos: desconto,
      acrescimoCentavos: acrescimo,
      valorCentavos: valor,
      // null explícito = sem forma (ex.: pendente); só herda a forma prevista se nada foi informado
      formaPagamento: formaPagamento === undefined ? ag.formaPagamento || null : formaPagamento,
      pagamentoPendente: pagamentoPendente && valor > 0,
      // data do pagamento é independente da do atendimento (reaberto: mantém a de antes)
      pagoEm: pagamentoPendente && valor > 0 ? null : pagoEm ?? ag.pagamentoAnterior?.pagoEm ?? t,
      pagamentoAnterior: null,
      pausadoEm: null,
      pausaSeg,
      pausadosItens: [],
      recomendacao,
    });
  },

  /** Pagamento pendente recebido, com a forma realmente usada e a data do pagamento (padrão: agora). */
  async registrarRecebimento(id, formaPagamento, quando = agora()) {
    const ag = await this.obter(id);
    if (!ag || ag.status !== 'concluido' || !ag.pagamentoPendente) return ag;
    return this.salvar({ ...ag, pagamentoPendente: false, pagoEm: quando, formaPagamento: formaPagamento || ag.formaPagamento || null });
  },

  /** Atendimento marcado como pago por engano: volta a ficar "a receber". */
  async marcarNaoPago(id) {
    const ag = await this.obter(id);
    if (!ag || ag.status !== 'concluido' || ag.pagamentoPendente || !(ag.valorCentavos > 0)) return ag;
    return this.salvar({ ...ag, pagamentoPendente: true, pagoEm: null, formaPagamento: null });
  },

  /** Desfaz um recebimento registrado por engano, voltando à forma anterior. */
  async desfazerRecebimento(id, formaAnterior = null) {
    const ag = await this.obter(id);
    return this.salvar({ ...ag, pagamentoPendente: true, pagoEm: null, formaPagamento: formaAnterior });
  },

  /** Retorno criado automaticamente na finalização, se ainda não aconteceu, sai junto. */
  async _descartarRetorno(ag) {
    if (!ag.retornoId) return false;
    const ret = await this.obter(ag.retornoId);
    if (!ret || ret.excluidoEm || !['agendado', 'confirmado'].includes(ret.status)) return false;
    await marcarExcluido(STORES.agendamentos, ret.id);
    return true;
  },

  /**
   * Reabre um atendimento finalizado (ex.: finalizou por engano): volta para
   * "em atendimento" com os tempos registrados, e sai do faturamento até ser
   * finalizado de novo.
   */
  async reabrir(id) {
    const ag = await this.obter(id);
    if (!ag || ag.status !== 'concluido') return null;
    const retornoRemovido = await this._descartarRetorno(ag);
    const pago = !ag.pagamentoPendente && ag.valorCentavos > 0 && ag.pagoEm;
    await this.salvar({
      ...ag,
      status: 'em_atendimento',
      chegadaEm: ag.chegadaEm || ag.inicio,
      finalizadoEm: null,
      pagoEm: null,
      pagamentoPendente: false,
      // a finalização de novo já vem com o pagamento como estava (e a mesma data)
      pagamentoAnterior: pago ? { pagoEm: ag.pagoEm, formaPagamento: ag.formaPagamento } : null,
      retornoId: null,
      reabertoEm: agora(),
      // o relógio volta parado no tempo em que foi finalizado; "Retomar" continua de onde parou
      pausadoEm: ag.finalizadoEm || agora(),
      pausadosItens: [],
    });
    return { retornoRemovido };
  },

  /**
   * Desfaz um atendimento finalizado: volta a ser só um agendamento, no mesmo
   * dia e horário, como se o pet não tivesse vindo. Tempos e pagamento são descartados.
   */
  async desfazer(id) {
    const ag = await this.obter(id);
    if (!ag || !['concluido', 'em_atendimento'].includes(ag.status)) return null;
    const retornoRemovido = await this._descartarRetorno(ag);
    const itens = await this.itens(id);
    await db.putVarios(
      STORES.itens,
      // como se o pet não tivesse vindo: preço ajustado na cobrança volta ao de tabela
      itens.map((i) => comPreco({ ...i, accSeg: 0, t0: null, done: false, duracaoRealMin: null }, i.precoTabelaCentavos))
    );
    await this.salvar({
      ...ag,
      status: 'agendado',
      chegadaEm: null,
      finalizadoEm: null,
      pagoEm: null,
      pagamentoPendente: false,
      pagamentoAnterior: null,
      pausadoEm: null,
      pausaSeg: 0,
      pausadosItens: [],
      formaPagamento: ag.planoId ? 'Incluso no plano' : null,
      descontoCentavos: 0,
      recomendacao: '',
      retornoId: null,
    });
    await this.recalcularValores(id);
    return { retornoRemovido };
  },

  async mudarStatus(id, status) {
    const ag = await this.obter(id);
    return this.salvar({ ...ag, status });
  },

  excluir: (id) => marcarExcluido(STORES.agendamentos, id),
};

/* =============================== Planos ============================== */

export const planos = {
  async listar() {
    return db.vivos(await db.todos(STORES.planos)).sort(porNome);
  },
  obter: (id) => db.obter(STORES.planos, id),
  async doPet(petId) {
    return db.vivos(await db.porIndice(STORES.planos, 'petId', petId)).sort(porNome);
  },
  async doTutor(tutorId) {
    return db.vivos(await db.porIndice(STORES.planos, 'tutorId', tutorId)).sort(porNome);
  },
  async salvar(dados) {
    const reg = novoRegistro(dados);
    if (reg.ativo === undefined) reg.ativo = true;
    return db.put(STORES.planos, reg);
  },

  /**
   * Salva o pacote e deixa a agenda igual à folha de banhos: cada linha vira
   * (ou atualiza) um agendamento do plano, numerado pelo mês e pelo banho.
   * Banhos que já aconteceram, foram cancelados ou faltaram não são tocados.
   * Datas que já passaram e ainda não existiam não entram na agenda.
   * Banhos que saíram da folha (ex.: menos meses) e não aconteceram são apagados.
   */
  async salvarPacote(dados, linhas) {
    const plano = await this.salvar(dados);
    const hoje = inicioDoDia(agora());
    const existentes = await agendamentos.doPlano(plano.id);
    const porId = new Map(existentes.map((a) => [a.id, a]));
    const editavel = (ag) => ['agendado', 'confirmado', 'rascunho_plano'].includes(ag.status);

    const pet = await pets.obter(plano.petId);
    const catalogo = (await Promise.all((plano.servicos || []).map((id) => servicos.obter(id)))).filter(Boolean);
    const duracao = plano.duracaoMin || catalogo.reduce((s, c) => s + (c.duracaoPadraoMin || 0), 0) || 60;
    // a estimativa de tempo é a mesma para todos os banhos: calcula uma vez
    const itens = [];
    for (const s of catalogo) {
      const est = pet ? await tempos.estimar(pet, s) : { minutos: s.duracaoPadraoMin || 30 };
      itens.push({ servicoId: s.id, nome: s.nome, categoria: s.categoria, precoCentavos: 0, duracaoPrevistaMin: est.minutos, mediaSeg: est.minutos * 60 });
    }
    const idsServicos = catalogo.map((c) => c.id).join();

    let criados = 0;
    let removidos = 0;
    const usados = new Set();
    for (const l of linhas) {
      const numeracao = { planoMes: l.mes, planoBanho: l.banho, planoManual: !!l.manual, planoAncora: !!l.ancora };
      const ag = l.agId ? porId.get(l.agId) : null;
      if (ag) {
        usados.add(ag.id);
        if (!editavel(ag)) {
          if (ag.planoMes !== l.mes || ag.planoBanho !== l.banho) await agendamentos.salvar({ ...ag, planoMes: l.mes, planoBanho: l.banho });
          continue;
        }
        const campos = { ...ag, ...numeracao, inicio: l.ts, status: ag.status === 'rascunho_plano' ? 'agendado' : ag.status, tutorId: plano.tutorId };
        const servicosDoAg = (await agendamentos.itens(ag.id)).map((i) => i.servicoId).join();
        if (servicosDoAg !== idsServicos) await agendamentos.gravarComItens({ ...campos, duracaoPrevistaMin: duracao }, itens);
        else await agendamentos.salvar(campos);
      } else {
        if (l.ts < hoje) continue;
        await agendamentos.gravarComItens(
          {
            petId: plano.petId,
            tutorId: plano.tutorId,
            planoId: plano.id,
            ...numeracao,
            inicio: l.ts,
            status: 'agendado',
            origem: 'plano',
            formaPagamento: 'Incluso no plano',
            duracaoPrevistaMin: duracao,
          },
          itens
        );
        criados++;
      }
    }
    for (const ag of existentes) {
      if (usados.has(ag.id) || !editavel(ag)) continue;
      const itensAg = await agendamentos.itens(ag.id);
      await db.removerVarios(STORES.itens, itensAg.map((i) => i.id));
      await db.remover(STORES.agendamentos, ag.id);
      removidos++;
    }
    return { plano, criados, removidos };
  },

  /**
   * Encerra o plano antes do fim (cliente desistiu): para de cobrar mensalidade
   * a partir de hoje e tira da agenda os banhos que ainda não aconteceram.
   */
  async encerrar(id) {
    const plano = await this.obter(id);
    const t = agora();
    await this.salvar({ ...plano, fim: t, encerradoEm: t });
    let removidos = 0;
    for (const ag of await agendamentos.doPlano(id)) {
      if (!['agendado', 'confirmado', 'rascunho_plano'].includes(ag.status) || ag.inicio < t) continue;
      const itensAg = await agendamentos.itens(ag.id);
      await db.removerVarios(STORES.itens, itensAg.map((i) => i.id));
      await db.remover(STORES.agendamentos, ag.id);
      removidos++;
    }
    return removidos;
  },

  /** Mensalidade do mês `mes` ("2026-10") recebida, com a forma usada. */
  async registrarPagamento(planoId, mes, formaPagamento, quando = agora()) {
    const plano = await this.obter(planoId);
    if (!plano || plano.pagamentos?.[mes]) return plano; // já recebida: segundo toque não troca nada
    // o valor fica gravado: mudar o preço do plano depois não altera o que já foi recebido
    const valorCentavos = (plano.pagamentos?.[mes]?.valorCentavos) ?? plano.valorCentavos ?? 0;
    // a data da cobrança também fica: remarcar o banho depois não muda o mês em que ela entrou
    const cobradoEm = (await mensalidadesDoPlano(plano)).find((m) => m.mes === mes)?.ts;
    const pagamento = { pagoEm: quando, formaPagamento, valorCentavos, ...(Number.isFinite(cobradoEm) ? { cobradoEm } : {}) };
    return this.salvar({ ...plano, pagamentos: { ...(plano.pagamentos || {}), [mes]: pagamento } });
  },

  async desfazerPagamento(planoId, mes) {
    const plano = await this.obter(planoId);
    const pagamentos = { ...(plano.pagamentos || {}) };
    delete pagamentos[mes];
    return this.salvar({ ...plano, pagamentos });
  },

  /** Exclui o plano e as visitas futuras dele que ainda não aconteceram. */
  async excluir(id) {
    const quando = await marcarExcluido(STORES.planos, id);
    const futuros = (await agendamentos.doPlano(id)).filter(
      (a) => ['rascunho_plano', 'agendado', 'confirmado'].includes(a.status) && a.inicio >= inicioDoDia(agora())
    );
    for (const ag of futuros) await marcarExcluido(STORES.agendamentos, ag.id, quando);
  },
};

/* ======================= Inteligência de tempo ======================= */

async function execucoesDoPet(petId, servicoId) {
  const doPet = (await db.porIndice(STORES.agendamentos, 'petId', petId)).filter((a) => !a.excluidoEm && a.status === 'concluido');
  const quando = new Map(doPet.map((a) => [a.id, a.inicio]));
  return (await db.porIndice(STORES.itens, 'servicoId', servicoId))
    .filter((i) => quando.has(i.agendamentoId) && i.usarNaMedia !== false && Number.isFinite(i.duracaoRealMin))
    .sort((a, b) => quando.get(b.agendamentoId) - quando.get(a.agendamentoId));
}

async function execucoesDaLoja(servicoId, { de = 0, ate = Infinity } = {}) {
  const concluidos = new Map(
    (await agendamentos.concluidos()).filter((a) => a.inicio >= de && a.inicio <= ate).map((a) => [a.id, a])
  );
  return (await db.porIndice(STORES.itens, 'servicoId', servicoId)).filter(
    (i) => concluidos.has(i.agendamentoId) && i.usarNaMedia !== false && Number.isFinite(i.duracaoRealMin)
  );
}

const mediaInt = (xs) => (xs.length ? Math.round(xs.reduce((a, b) => a + b, 0) / xs.length) : 0);

export const tempos = {
  /** Duração estimada de um serviço para este pet + de onde veio a estimativa. */
  async estimar(pet, servico) {
    const doPet = await execucoesDoPet(pet.id, servico.id);
    let semelhantes = [];
    if (doPet.length < MINIMO_AMOSTRAS) {
      const parecidos = new Set(
        (await pets.listar()).filter((p) => p.id !== pet.id && p.porte === pet.porte && p.especie === pet.especie).map((p) => p.id)
      );
      const agDeParecidos = new Set(
        (await agendamentos.concluidos()).filter((a) => parecidos.has(a.petId)).map((a) => a.id)
      );
      semelhantes = (await execucoesDaLoja(servico.id)).filter((i) => agDeParecidos.has(i.agendamentoId)).slice(0, JANELA_HISTORICO * 2);
    }
    return estimarDuracao(doPet, semelhantes, { duracaoPadraoMin: servico.duracaoPadraoMin || 30 });
  },

  /** Tempo real médio da loja para um serviço (ou null sem histórico). */
  async mediaDaLoja(servicoId, periodo) {
    const xs = (await execucoesDaLoja(servicoId, periodo)).map((i) => i.duracaoRealMin);
    return xs.length ? { mediaMin: mediaInt(xs), menorMin: Math.min(...xs), maiorMin: Math.max(...xs), qtd: xs.length } : null;
  },

  /** Tabela por procedimento de um pet (aba Tempos da ficha). */
  async doPet(pet) {
    const linhas = [];
    for (const servico of await servicos.listar()) {
      const execs = await execucoesDoPet(pet.id, servico.id);
      if (!execs.length) continue;
      const janela = execs.slice(0, JANELA_HISTORICO).map((e) => e.duracaoRealMin);
      const usados = descartarOutliers(janela).length ? descartarOutliers(janela) : janela;
      const loja = await this.mediaDaLoja(servico.id);
      const recentes = janela.slice(0, 2);
      const anteriores = janela.slice(2);
      const tendencia = recentes.length && anteriores.length ? mediaInt(recentes) - mediaInt(anteriores) : 0;
      linhas.push({
        servico,
        mediaMin: mediaInt(usados),
        amostras: usados.length,
        menorMin: Math.min(...usados),
        maiorMin: Math.max(...usados),
        lojaMin: loja?.mediaMin || servico.duracaoPadraoMin || 30,
        estimado: usados.length < MINIMO_AMOSTRAS,
        tendencia,
      });
    }
    return linhas;
  },
};

/* ============================ Faturamento ============================ */
/* Duas visões do dinheiro, sempre em centavos inteiros:
   - FATURAMENTO (competência): o que foi vendido no período. Atendimento conta
     no dia em que o pet foi atendido (chegada); mensalidade, no vencimento.
     Conta mesmo se ainda não foi pago.
   - CAIXA (recebido): o que entrou de fato no período, pela data do
     recebimento, com a forma usada. Fiado e pendente só entram quando pagos.
   Dinheiro recebido nunca some dos relatórios: pagamento de plano excluído ou
   encerrado continua contando. */

/** Mês de uma mensalidade: "2026-09". */
export const chaveMes = (ts) => {
  const d = new Date(ts);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
};

/** Dia em que o atendimento aconteceu (chegada do pet; sem chegada, o agendado). */
export const dataDoAtendimento = (ag) => ag.chegadaEm || ag.inicio;

/** Vencimento de uma mensalidade no mês "AAAA-MM" (meses curtos usam o último dia). */
function vencimentoNoMes(mes, dia) {
  const [ano, m] = mes.split('-').map(Number);
  return new Date(ano, m - 1, Math.min(dia || 1, new Date(ano, m, 0).getDate())).getTime();
}

/**
 * Mensalidades de um plano com cobrança entre `de` e `ate`:
 * - as do contrato (plano vivo e ativo): uma por mês do calendário, no 1º banho
 *   do plano naquele mês; depois de encerrado o plano, não cobra mais;
 * - e todas as já pagas, mesmo de plano excluído ou encerrado, na data em que
 *   foram cobradas.
 * O valor de uma mensalidade paga é o que foi recebido, não o preço atual do plano.
 */
function vencimentos(plano, de, ate, visitas = []) {
  const saida = new Map();
  const pagamentos = plano.pagamentos || {};
  const datas = datasDasMensalidades(plano, visitas);
  const total = datas.length;
  const vigente = !plano.excluidoEm && plano.ativo !== false && plano.valorCentavos > 0;
  if (vigente) {
    for (const { k, mes, ts } of datas) {
      if (pagamentos[mes] || ts < de || ts > ate) continue;
      if (plano.encerradoEm && ts >= plano.encerradoEm) continue;
      saida.set(mes, { plano, ts, mes, k, total, pagamento: null, valorCentavos: plano.valorCentavos });
    }
  }
  for (const [mes, pagamento] of Object.entries(pagamentos)) {
    if (!pagamento) continue;
    const d = datas.find((x) => x.mes === mes);
    // pagas antes da 0.5.5 (vencimento em dia fixo) não guardaram a data da cobrança
    const ts = pagamento.cobradoEm ?? d?.ts ?? vencimentoNoMes(mes, plano.vencimentoDia) ?? pagamento.pagoEm;
    if (!Number.isFinite(ts) || ts < de || ts > ate) continue;
    saida.set(mes, { plano, ts, mes, k: d?.k ?? null, total, pagamento, valorCentavos: pagamento.valorCentavos ?? plano.valorCentavos ?? 0 });
  }
  return [...saida.values()].sort((a, b) => a.ts - b.ts);
}

/** Visitas de cada plano (inclusive canceladas), para achar o 1º banho de cada mês. */
async function visitasPorPlano() {
  const mapa = new Map();
  for (const ag of await db.todos(STORES.agendamentos)) {
    if (!ag.planoId || ag.excluidoEm) continue;
    if (!mapa.has(ag.planoId)) mapa.set(ag.planoId, []);
    mapa.get(ag.planoId).push(ag);
  }
  return mapa;
}

/** Mensalidades de um plano entre `de` e `ate` (para telas que mostram um plano só). */
export async function mensalidadesDoPlano(plano, de = 0, ate = Infinity) {
  return vencimentos(plano, de, ate, await agendamentos.doPlano(plano.id));
}

/** Todos os planos, inclusive os excluídos (os pagamentos deles continuam valendo). */
const todosOsPlanos = () => db.todos(STORES.planos);

export const faturamento = {
  /**
   * @returns {{ concluidos, itensPorAg, mensalidades, recebimentos }}
   *   recebimentos: o que entrou no caixa no período, { tipo, valorCentavos, forma, ts, ag?, mensalidade? }
   */
  async periodo(de, ate) {
    const todosConcluidos = await agendamentos.concluidos();
    const concluidos = todosConcluidos.filter((a) => {
      const quando = dataDoAtendimento(a);
      return quando >= de && quando <= ate;
    });
    const itensPorAg = await agendamentos.itensDe(concluidos);
    const planosTodos = await todosOsPlanos();
    const visitas = await visitasPorPlano();
    const mensalidades = planosTodos.flatMap((plano) => vencimentos(plano, de, ate, visitas.get(plano.id) || []));

    const recebimentos = [];
    for (const ag of todosConcluidos) {
      if (ag.pagamentoPendente || !(ag.valorCentavos > 0)) continue;
      const quando = ag.pagoEm || ag.finalizadoEm || dataDoAtendimento(ag);
      if (quando >= de && quando <= ate) recebimentos.push({ tipo: 'atendimento', valorCentavos: ag.valorCentavos, forma: ag.formaPagamento || 'Não informado', ts: quando, ag });
    }
    for (const plano of planosTodos) {
      for (const [mes, pg] of Object.entries(plano.pagamentos || {})) {
        if (!pg || !(pg.pagoEm >= de && pg.pagoEm <= ate)) continue;
        const valor = pg.valorCentavos ?? plano.valorCentavos ?? 0;
        if (valor > 0) recebimentos.push({ tipo: 'mensalidade', valorCentavos: valor, forma: pg.formaPagamento || 'Não informado', ts: pg.pagoEm, mensalidade: { plano, mes } });
      }
    }
    return { concluidos, itensPorAg, mensalidades, recebimentos };
  },

  async pendentes() {
    return (await agendamentos.concluidos()).filter((a) => a.pagamentoPendente && a.valorCentavos > 0).sort((a, b) => b.inicio - a.inicio);
  },

  /** Mensalidades já vencidas (até hoje) que ainda não foram recebidas (só de planos vivos). */
  async mensalidadesAbertas() {
    const visitas = await visitasPorPlano();
    return (await planos.listar())
      .flatMap((plano) => vencimentos(plano, 0, fimDoDia(agora()), visitas.get(plano.id) || []))
      .filter((m) => !m.pagamento)
      .sort((a, b) => a.ts - b.ts);
  },
};

/** Nomes para relatórios: inclui pets e tutores excluídos, para o histórico não perder quem foi. */
export async function nomesParaRelatorio() {
  const nomes = async (store) => new Map((await db.todos(store)).map((r) => [r.id, r.nome || '']));
  return { pets: await nomes(STORES.pets), tutores: await nomes(STORES.tutores) };
}

/* ============================== Lixeira ============================== */

const TIPOS_LIXEIRA = [
  { tipo: 'Tutor', store: STORES.tutores },
  { tipo: 'Pet', store: STORES.pets },
  { tipo: 'Serviço', store: STORES.servicos },
  { tipo: 'Plano', store: STORES.planos },
  { tipo: 'Agendamento', store: STORES.agendamentos },
];

async function temHistoricoFinanceiro(store, id) {
  if (store === STORES.planos) return Object.values((await db.obter(store, id))?.pagamentos || {}).some(Boolean);
  if (store === STORES.agendamentos) return (await db.obter(store, id))?.status === 'concluido';
  const concluidos = (await db.porIndice(STORES.agendamentos, 'status', 'concluido')).filter((a) => !a.excluidoEm);
  if (store === STORES.pets) return concluidos.some((a) => a.petId === id);
  if (store === STORES.tutores) {
    const doTutor = new Set((await db.porIndice(STORES.pets, 'tutorId', id)).map((p) => p.id));
    return concluidos.some((a) => a.tutorId === id || doTutor.has(a.petId));
  }
  return false;
}

export const lixeira = {
  async listar() {
    const petsTodos = new Map((await db.todos(STORES.pets)).map((p) => [p.id, p]));
    const saida = [];
    for (const { tipo, store } of TIPOS_LIXEIRA) {
      for (const r of await db.todos(store)) {
        if (!r.excluidoEm || r.arquivadoEm) continue;
        let nome = r.nome || 'Sem nome';
        if (tipo === 'Agendamento') {
          const d = new Date(r.inicio);
          nome = `${petsTodos.get(r.petId)?.nome || 'Pet'} · ${String(d.getDate()).padStart(2, '0')}/${String(d.getMonth() + 1).padStart(2, '0')} ${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`;
        } else if (tipo === 'Pet' && r.raca) {
          nome = `${r.nome} · ${r.raca}`;
        }
        const restantes = RETENCAO_DIAS - Math.floor((agora() - r.excluidoEm) / DIA_MS);
        saida.push({ id: r.id, tipo, store, nome, excluidoEm: r.excluidoEm, diasRestantes: Math.max(0, restantes) });
      }
    }
    return saida.sort((a, b) => b.excluidoEm - a.excluidoEm);
  },

  /**
   * Restaura o registro e o que foi excluído junto com ele. A cascata usa o
   * carimbo de exclusão: só volta o que saiu no mesmo instante — um pet que
   * já estava na lixeira antes do tutor continua lá.
   */
  async restaurar({ store, id }) {
    const r = await db.obter(store, id);
    if (!r || !r.excluidoEm) return;
    const carimbo = r.excluidoEm;
    delete r.excluidoEm;
    await db.put(store, r);

    if (store === STORES.tutores) {
      for (const pet of await db.porIndice(STORES.pets, 'tutorId', id)) {
        if (pet.excluidoEm === carimbo) await this.restaurar({ store: STORES.pets, id: pet.id });
      }
    }
    if (store === STORES.pets) {
      for (const plano of await db.porIndice(STORES.planos, 'petId', id)) {
        if (plano.excluidoEm !== carimbo) continue;
        delete plano.excluidoEm;
        await db.put(STORES.planos, plano);
      }
    }
    if (store === STORES.pets || store === STORES.planos) {
      const indice = store === STORES.pets ? 'petId' : 'planoId';
      for (const ag of await db.porIndice(STORES.agendamentos, indice, id)) {
        if (ag.excluidoEm !== carimbo) continue;
        delete ag.excluidoEm;
        await db.put(STORES.agendamentos, ag);
      }
    }
  },

  /**
   * Apaga de vez. O que tem histórico de dinheiro (atendimento finalizado,
   * mensalidade paga, pet ou tutor com atendimentos) não é apagado: sai da
   * lixeira, mas continua guardado para o faturamento dos meses passados.
   */
  async excluirDefinitivo({ store, id }) {
    if (await temHistoricoFinanceiro(store, id)) {
      const r = await db.obter(store, id);
      if (r) await db.put(store, { ...r, arquivadoEm: agora() });
      return;
    }
    if (store === STORES.agendamentos) {
      const itens = await db.porIndice(STORES.itens, 'agendamentoId', id);
      await db.removerVarios(STORES.itens, itens.map((i) => i.id));
    }
    await db.remover(store, id);
  },

  async esvaziar() {
    for (const item of await this.listar()) await this.excluirDefinitivo(item);
  },

  /** Remove de vez o que passou do prazo de retenção. Chamado ao abrir o app. */
  async purgarVencidos() {
    for (const item of await this.listar()) {
      if (item.diasRestantes <= 0) await this.excluirDefinitivo(item);
    }
  },
};

/* ======================== Montagem de serviços ======================= */

/**
 * Itens de agendamento para um pet: preço do porte dele e duração estimada
 * pelo histórico dele. `incluso` zera o preço (visita coberta por plano).
 */
export async function montarItens(pet, lista, { incluso = false } = {}) {
  const itens = [];
  for (const s of lista) {
    const est = await tempos.estimar(pet, s);
    itens.push({
      servicoId: s.id,
      nome: s.nome,
      categoria: s.categoria,
      precoCentavos: incluso ? 0 : precoParaPorte(s, pet.porte),
      duracaoPrevistaMin: est.minutos,
      mediaSeg: est.minutos * 60,
    });
  }
  return itens;
}

/** Serviços cobertos pelos planos ativos do pet (Set vazio = pet sem plano ativo). */
export async function servicosInclusosNoPlano(petId) {
  const ids = new Set();
  for (const plano of await planos.doPet(petId)) {
    if (planoVigente(plano)) (plano.servicos || []).forEach((id) => ids.add(id));
  }
  return ids;
}

/* ============================== Checagens ============================ */

export async function conflitosDoHorario(inicio, duracaoMin, ignorarId = null) {
  const doDia = await agendamentos.porPeriodo(inicioDoDia(inicio), fimDoDia(inicio));
  return conflitos(inicio, duracaoMin, doDia, ignorarId);
}
