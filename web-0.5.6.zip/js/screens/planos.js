import { html, icon, fmtBRLCurto, fmtDataCurta, inicioDoMes, fimDoMes, inicioDoDia, diasEntre } from '../core/dom.js';
import { patinhasHero, vazio, chip } from '../core/ui.js';
import { agendamentos, pets, tutores, planos, servicos, mensalidadesDoPlano } from '../data/repo.js';
import { recorrenciaCurta, descricaoVigencia, fimDoPlano, planoVigente, tipoDoPlano } from '../logic/planos.js';
import { combina, ordemAlfabetica } from '../core/busca.js';
import { nomesDoTutor, nomesParaBusca, telefonesDoTutor } from '../logic/contatos.js';

/* PLANOS — os pacotes (mensal 4 banhos, quinzenal 2 banhos), banhos feitos e vencimento. */

const AVISO_VENCIMENTO_DIAS = 5;
const FILTROS = ['Todos', 'Valendo', 'Mensalidade em aberto', 'Mensal', 'Quinzenal', 'Encerrados'];
const ui = { busca: '', filtro: 'Todos' };

function passa(l) {
  switch (ui.filtro) {
    case 'Valendo':
      return l.vigente;
    case 'Mensalidade em aberto':
      return status(l.plano, l.proxima).rotulo === 'Mensalidade em aberto';
    case 'Mensal':
    case 'Quinzenal':
      return tipoDoPlano(l.plano) === ui.filtro;
    case 'Encerrados':
      return !l.vigente;
    default:
      return true;
  }
}

/** Status do plano; `proxima` é a 1ª mensalidade ainda não paga (cobrada no 1º banho do mês). */
function status(plano, proxima) {
  const fim = fimDoPlano(plano);
  if (plano.encerradoEm) return { rotulo: 'Encerrado', cls: 'selo-neutro' };
  if (fim && fim <= Date.now()) return { rotulo: 'Concluído', cls: 'selo-neutro' };
  if (!plano.ativo) return { rotulo: 'Pausado', cls: 'selo-neutro' };
  if (proxima) {
    const dias = diasEntre(inicioDoDia(Date.now()), inicioDoDia(proxima.ts));
    if (dias < 0) return { rotulo: 'Mensalidade em aberto', cls: 'selo-rosa' };
    if (dias <= AVISO_VENCIMENTO_DIAS) return { rotulo: 'A vencer', cls: 'selo-ambar' };
  }
  return { rotulo: 'Ativo', cls: 'selo-verde' };
}

export default {
  titulo: 'Planos',
  menu: 'planos',

  async carregar() {
    const lista = await planos.listar();
    const nomesPets = new Map((await pets.listar()).map((p) => [p.id, p.nome]));
    const mapaTutores = new Map((await tutores.listar()).map((t) => [t.id, t]));
    const nomesServicos = new Map((await servicos.listar()).map((s) => [s.id, s.nome]));
    const linhas = [];
    for (const plano of lista) {
      // visitas da vigência inteira; nos planos antigos (sem vigência), só as do mês
      const semVigencia = !fimDoPlano(plano);
      const visitas = (await agendamentos.doPlano(plano.id)).filter(
        (a) =>
          !['cancelado', 'nao_compareceu'].includes(a.status) &&
          (!semVigencia || (a.inicio >= inicioDoMes(Date.now()) && a.inicio <= fimDoMes(Date.now())))
      );
      const usados = visitas.filter((a) => a.status === 'concluido').length;
      const proxima = (await mensalidadesDoPlano(plano)).find((m) => !m.pagamento) || null;
      linhas.push({
        proxima,
        plano,
        pet: nomesPets.get(plano.petId) || 'Pet removido',
        tutor: nomesDoTutor(mapaTutores.get(plano.tutorId)) || 'Sem tutor',
        textos: [nomesPets.get(plano.petId), plano.nome, ...nomesParaBusca(mapaTutores.get(plano.tutorId))],
        telefones: telefonesDoTutor(mapaTutores.get(plano.tutorId)),
        vigente: planoVigente(plano),
        servicos: (plano.servicos || []).map((id) => nomesServicos.get(id)).filter(Boolean).join(' + ') || 'Sem serviços',
        usados,
        total: visitas.length,
        semVigencia,
      });
    }
    // os que estão valendo primeiro; dentro de cada grupo, ordem alfabética do pet e do tutor
    linhas.sort((a, b) => Number(b.vigente) - Number(a.vigente) || ordemAlfabetica(a.pet, b.pet) || ordemAlfabetica(a.tutor, b.tutor));
    return { linhas };
  },

  render(vm) {
    const lista = vm.linhas.filter((l) => passa(l) && combina(ui.busca, l.textos, l.telefones));
    return html`<div class="card r24 cortar">
      <div class="hero">
        ${patinhasHero('padrao')}
        <div class="hero-conteudo" style="display:flex;justify-content:flex-end;align-items:center;gap:10px;flex-wrap:wrap">
          ${vm.linhas.length ? html`<div class="busca branca lista-busca" style="flex:1;min-width:220px">
          ${icon('search', 16)}
          <input data-campo="busca" value="${ui.busca}" placeholder="Buscar por pet, tutor ou telefone…">
          ${ui.busca ? html`<button data-acao="limpar-busca" style="display:flex;color:var(--texto-3)" aria-label="Limpar">${icon('x', 15)}</button>` : ''}
        </div>` : ''}
          <button class="btn btn-roxo" style="font-size:13.5px;padding:10px 16px" data-acao="novo">${icon('plus', 15)}<span>Novo plano</span></button>
        </div>
      </div>
      <div class="planos-lista">
        ${vm.linhas.length ? html`<div class="chips" style="gap:8px;padding:2px 0 10px">${FILTROS.map((f) => chip(f, ui.filtro === f, 'filtro', { filtro: f }, { suave: true }))}</div>` : ''}
        ${vm.linhas.length && !lista.length
          ? vazio({ icone: 'search', titulo: 'Nenhum plano encontrado', texto: 'Tente outro filtro, nome ou telefone.', compacto: true })
          : ''}
        ${vm.linhas.length
          ? lista.map((l) => {
              const st = status(l.plano, l.proxima);
              const pct = l.total ? (l.usados / l.total) * 100 : 0;
              const uso = l.total
                ? `${l.usados} de ${l.total} ${l.total === 1 ? 'banho feito' : 'banhos feitos'}`
                : l.semVigencia ? 'Nenhuma data neste mês' : 'Nenhum banho agendado';
              const vigencia = descricaoVigencia(l.plano);
              return html`<button class="plano-linha" data-acao="abrir" data-id="${l.plano.id}">
                <div style="min-width:0">
                  <div class="pl-nome truncar">${l.plano.nome || 'Plano sem nome'}</div>
                  <div class="pl-sub truncar">${l.tutor} · ${l.pet}</div>
                </div>
                <div style="min-width:0">
                  <div class="pl-serv">${l.servicos}</div>
                  <div class="pl-sub">${recorrenciaCurta(l.plano)}${vigencia ? ` · ${vigencia}` : ''}</div>
                </div>
                <div class="pl-uso">
                  <div class="pl-sub" style="font-weight:500;margin:0">${l.semVigencia ? 'Uso no mês' : 'Banhos do pacote'}</div>
                  <div class="barra" style="height:6px;background:var(--borda);margin-top:6px"><div style="width:${pct.toFixed(0)}%;background:var(--roxo)"></div></div>
                  <div class="pl-sub" style="margin-top:5px">${uso}</div>
                </div>
                <div>
                  <div class="pl-valor">${l.plano.valorCentavos ? fmtBRLCurto(l.plano.valorCentavos) : '—'}</div>
                  <div class="pl-sub" style="margin:0">${l.proxima ? `cobrar em ${fmtDataCurta(l.proxima.ts)} (${l.proxima.k}/${l.proxima.total})` : l.plano.valorCentavos ? 'mensalidades em dia' : 'sem valor'}</div>
                </div>
                <div class="pl-status">
                  <span class="selo ${st.cls}">${st.rotulo}</span>
                  <span style="color:var(--texto-5);display:flex">${icon('chevron-right', 16)}</span>
                </div>
              </button>`;
            })
          : vazio({
              icone: 'repeat',
              titulo: 'Nenhum plano cadastrado',
              texto: 'Monte o pacote do pet (mensal com 4 banhos ou quinzenal com 2 banhos) e as datas entram na agenda.',
              acao: html`<button class="btn btn-roxo" data-acao="novo">${icon('plus', 15)}<span>Novo plano</span></button>`,
            })}
      </div>
    </div>`;
  },

  aoDigitar(campo, valor, ctx) {
    if (campo !== 'busca') return;
    ui.busca = valor;
    ctx.redesenhar();
  },

  acoes: {
    'limpar-busca': (_, ctx) => {
      ui.busca = '';
      ctx.redesenhar();
    },
    filtro: ({ filtro }, ctx) => {
      ui.filtro = filtro;
      ctx.redesenhar();
    },
    novo: (_, ctx) => ctx.navegar('plano-pet'),
    abrir: ({ id }, ctx) => ctx.navegar('plano-rec', { id }),
  },
};
