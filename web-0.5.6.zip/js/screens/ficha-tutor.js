import { html, icon, fmtBRL, fmtBRLCurto, fmtData, fmtDataCurta } from '../core/dom.js';
import { avPet, avTutor, selo, vazio, voltar, barra } from '../core/ui.js';
import { agendamentos, pets, tutores, planos, nomesParaRelatorio } from '../data/repo.js';
import { ligar } from '../core/nativo.js';
import { completudeTutor } from '../logic/metricas.js';
import { abrirWhatsapp } from '../modais/whatsapp.js';
import { editarTutor } from '../modais/editar-tutor.js';
import { escolherFormaRecebimento, descreverRecebimento } from '../modais/recebimento.js';
import { enderecoTexto } from '../logic/endereco.js';
import { contatosDoTutor, nomesDoTutor } from '../logic/contatos.js';
import { fimDoPlano } from '../logic/planos.js';
import { escolherContato } from '../modais/contato.js';

/* FICHA DO TUTOR — contato, pets, histórico consolidado e pendências. */

export default {
  titulo: 'Ficha do tutor',
  menu: 'clientes',

  async carregar({ id, petId }) {
    const tutor = await tutores.obter(id);
    if (!tutor || tutor.excluidoEm) return { tutor: null };
    const listaPets = await pets.doTutor(id);
    const todosNomes = await nomesParaRelatorio();
    const nomes = new Map(listaPets.map((p) => [p.id, p.nome]));

    // atendimentos do tutor, inclusive de pets que já foram excluídos (a dívida não some)
    const doTutor = new Set(listaPets.map((p) => p.id));
    const historico = (await agendamentos.concluidos()).filter((a) => a.tutorId === id || doTutor.has(a.petId));
    const ultimaPorPet = new Map();
    for (const ag of historico) {
      if (!nomes.has(ag.petId)) nomes.set(ag.petId, todosNomes.pets.get(ag.petId) || 'Pet excluído');
      if (!ultimaPorPet.has(ag.petId) || ag.inicio > ultimaPorPet.get(ag.petId)) ultimaPorPet.set(ag.petId, ag.inicio);
    }
    historico.sort((a, b) => b.inicio - a.inicio);

    const pagos = historico.filter((a) => (a.valorCentavos || 0) > 0);
    const total = historico.reduce((s, a) => s + (a.valorCentavos || 0), 0);
    const pendentes = historico.filter((a) => a.pagamentoPendente && a.valorCentavos > 0);

    return {
      tutor,
      origemPet: petId ? await pets.obter(petId) : null,
      pets: listaPets,
      nomes,
      ultimaPorPet,
      historico,
      itens: await agendamentos.itensDe(historico.slice(0, 12)),
      totalCentavos: total,
      ticketCentavos: pagos.length ? Math.round(pagos.reduce((s, a) => s + a.valorCentavos, 0) / pagos.length) : 0,
      pendentes,
      pendenteCentavos: pendentes.reduce((s, a) => s + (a.valorCentavos || 0), 0),
      planos: await planos.doTutor(id),
    };
  },

  render(vm) {
    if (!vm.tutor) return html`${voltar('Voltar para clientes')}<div class="card pad-18">${vazio({ icone: 'search', titulo: 'Tutor não encontrado' })}</div>`;
    const { tutor } = vm;
    const pct = completudeTutor(tutor);
    const ativo = tutor.ativo !== false;
    const contatos = contatosDoTutor(tutor);
    const fones = contatos.length > 1 ? contatos.map((c) => `${c.rotulo}: ${c.telefone}`) : contatos.map((c) => `${c.telefone} · WhatsApp`);
    const linha1 = [...(fones.length ? fones : ['Sem telefone']), tutor.email].filter(Boolean).join(' · ');
    const linha2 = [enderecoTexto(tutor), tutor.origem ? `conheceu por ${tutor.origem.toLowerCase()}` : ''].filter(Boolean).join(' · ');

    return html`
      ${voltar(vm.origemPet ? `Voltar para a ficha ${vm.origemPet.sexo === 'Fêmea' ? 'da' : 'do'} ${vm.origemPet.nome}` : 'Voltar para clientes')}
      <div class="titulo-pagina" style="margin-bottom:14px">Ficha do tutor</div>

      <div class="card tutor-cab">
        ${avTutor(62)}
        <div class="tutor-info">
          <div class="tutor-nome">${nomesDoTutor(tutor) || 'Tutor sem nome'}${ativo ? '' : html` <span class="selo selo-neutro p" style="vertical-align:middle">Inativo</span>`}</div>
          <div class="tutor-linha">${linha1}</div>
          ${linha2 ? html`<div class="tutor-linha" style="margin-top:2px">${linha2}</div>` : ''}
        </div>
        <div class="tutor-completude">
          <div class="mutado" style="font-size:12px;font-weight:500;margin-bottom:6px">Cadastro ${pct}% completo</div>
          ${barra(pct)}
        </div>
        <div class="tutor-botoes">
          <button class="btn-icone verde" data-acao="whats" aria-label="WhatsApp">${icon('message-circle', 15)}</button>
          <button class="btn-icone" data-acao="ligar" aria-label="Ligar">${icon('phone', 15)}</button>
          <button class="btn-icone" data-acao="editar" aria-label="Editar">${icon('pencil', 15)}</button>
          <button class="btn-ativo${ativo ? '' : ' reativar'}" data-acao="ativo">${icon(ativo ? 'user-x' : 'user-check', 14)}<span>${ativo ? 'Desativar cliente' : 'Reativar cliente'}</span></button>
        </div>
      </div>

      <div class="grade-lateral">
        <div class="at-col" style="gap:16px">
          <div class="card pad-18">
            <div class="cab-card">
              <div class="titulo-card">Pets</div>
              <button class="link-acao" data-acao="add-pet">+ Adicionar pet</button>
            </div>
            ${vm.pets.length
              ? html`<div class="pets-tutor">
                  ${vm.pets.map(
                    (p) => html`<div class="pet-mini">
                      <button class="pet-mini-abrir" data-acao="pet" data-id="${p.id}">
                        ${avPet(p, 48, { borda: 0, sombra: false })}
                        <span style="min-width:0"><span class="pm-nome">${p.nome}</span><span class="pm-sub">Último: ${vm.ultimaPorPet.has(p.id) ? fmtDataCurta(vm.ultimaPorPet.get(p.id)) : '—'}</span></span>
                      </button>
                      <button class="btn-icone rosa" data-acao="excluir-pet" data-id="${p.id}" aria-label="Excluir ${p.nome}" title="Excluir pet">${icon('trash-2', 15)}</button>
                    </div>`
                  )}
                </div>`
              : vazio({ icone: 'paw-print', titulo: 'Nenhum pet vinculado', compacto: true })}
          </div>

          <div class="card pad-18">
            <div class="titulo-card" style="margin-bottom:6px">Histórico consolidado</div>
            ${vm.historico.length
              ? vm.historico.slice(0, 12).map((ag) => {
                  const pgto = ag.pagamentoPendente
                    ? ['Pendente', 'rosa']
                    : ag.formaPagamento === 'Incluso no plano' || ag.origem === 'plano'
                      ? ['Plano', 'roxo']
                      : [ag.formaPagamento || 'Pago', 'verde'];
                  return html`<div class="hist-linha hist-tutor">
                    <div class="hl-data" style="font-weight:500">${fmtData(ag.inicio)}</div>
                    <div class="hl-pet">${vm.nomes.get(ag.petId) || '—'}</div>
                    <div class="hl-serv">${(vm.itens.get(ag.id) || []).map((i) => i.nome).join(' + ') || '—'}</div>
                    <div class="hl-forte">${ag.origem === 'plano' && !ag.valorCentavos ? 'Plano' : fmtBRLCurto(ag.valorCentavos)}</div>
                    <div style="text-align:right">${selo(pgto[0], pgto[1])}</div>
                  </div>`;
                })
              : vazio({ icone: 'scissors', titulo: 'Nenhum atendimento concluído', compacto: true })}
          </div>
        </div>

        <div class="at-col">
          <div class="card pad-18">
            <div class="titulo-card" style="margin-bottom:10px">Resumo financeiro</div>
            <div class="linha"><span class="l-rotulo">Total gasto</span><span class="l-valor">${fmtBRLCurto(vm.totalCentavos)}</span></div>
            <div class="linha"><span class="l-rotulo">Ticket médio</span><span class="l-valor">${fmtBRLCurto(vm.ticketCentavos)}</span></div>
            <div class="linha"><span class="l-rotulo">Pendente</span><span class="l-valor" style="color:${vm.pendenteCentavos ? 'var(--rosa)' : 'var(--tinta-2)'}">${fmtBRL(vm.pendenteCentavos)}</span></div>
            ${vm.pendenteCentavos ? html`<button class="btn btn-lavanda bloco" style="margin-top:12px;padding:10px;border-radius:12px" data-acao="quitar">Quitar pendência de ${fmtBRLCurto(vm.pendenteCentavos)}</button>` : ''}
          </div>
          <div class="card pad-18">
            <div class="titulo-card" style="margin-bottom:10px">Planos contratados</div>
            ${vm.planos.length
              ? vm.planos.map(
                  (p) => html`<button class="linha" style="width:100%" data-acao="plano" data-id="${p.id}">
                    <span style="color:var(--texto-2);text-align:left">${p.nome} · ${vm.nomes.get(p.petId) || '—'}</span>
                    ${p.encerradoEm ? selo('Encerrado', 'neutro') : fimDoPlano(p) && fimDoPlano(p) <= Date.now() ? selo('Concluído', 'neutro') : p.ativo ? selo('Ativo', 'verde') : selo('Pausado', 'neutro')}
                  </button>`
                )
              : html`<div class="linha"><span class="mutado">Nenhum plano</span><button class="link-acao" data-acao="novo-plano">Criar plano</button></div>`}
          </div>
          <div class="card pad-18">
            <div class="titulo-card" style="margin-bottom:8px">Observações</div>
            <div class="texto-longo">${tutor.observacoes || 'Sem observações.'}</div>
          </div>
        </div>
      </div>`;
  },

  acoes: {
    whats: (_, ctx) => abrirWhatsapp(ctx, { tutor: ctx.vm.tutor, pet: ctx.vm.pets[0], modelo: 'Mensagem livre' }),
    ligar: async (_, ctx) => {
      const contato = await escolherContato(ctx, ctx.vm.tutor);
      if (contato) ligar(contato.telefone);
      else if (!contatosDoTutor(ctx.vm.tutor).length) ctx.toast('Este tutor não tem telefone cadastrado', { erro: true });
    },
    editar: async (_, ctx) => {
      const resultado = await editarTutor(ctx, ctx.vm.tutor);
      if (resultado === 'excluido') ctx.navegar('clientes', {}, { substituir: true });
      else if (resultado) ctx.recarregar();
    },
    ativo: async (_, ctx) => {
      const ativo = ctx.vm.tutor.ativo !== false;
      await tutores.salvar({ ...ctx.vm.tutor, ativo: !ativo });
      ctx.toast(ativo ? 'Cliente desativado' : 'Cliente reativado');
      ctx.recarregar();
    },
    'add-pet': (_, ctx) => ctx.navegar('cadastro', { tutorId: ctx.vm.tutor.id }),
    pet: ({ id }, ctx) => ctx.navegar('ficha-pet', { id }),
    'excluir-pet': async ({ id }, ctx) => {
      const pet = ctx.vm.pets.find((p) => p.id === id);
      const ok = await ctx.confirmar({
        titulo: `Excluir ${pet.nome}?`,
        texto: `${pet.nome} sai da lista de ${ctx.vm.tutor.nome}, com os agendamentos futuros e o plano. Tudo fica na lixeira por 30 dias. Os atendimentos já feitos continuam no faturamento.`,
        botao: 'Mover para lixeira',
      });
      if (!ok) return;
      await pets.excluir(id);
      ctx.toast(`${pet.nome} foi para a lixeira`);
      ctx.recarregar();
    },
    plano: ({ id }, ctx) => ctx.navegar('plano-rec', { id }),
    'novo-plano': (_, ctx) => ctx.navegar('plano-rec', { petId: ctx.vm.pets[0]?.id }),
    quitar: async (_, ctx) => {
      const n = ctx.vm.pendentes.length;
      const forma = await escolherFormaRecebimento(ctx, {
        titulo: 'Quitar pendência',
        valorCentavos: ctx.vm.pendenteCentavos,
        detalhe: `${n} ${n === 1 ? 'atendimento' : 'atendimentos'}`,
      });
      if (!forma) return;
      for (const ag of ctx.vm.pendentes) await agendamentos.registrarRecebimento(ag.id, forma.forma, forma.quando);
      ctx.toast(`Pendência quitada · ${descreverRecebimento(forma)}`);
      ctx.recarregar();
    },
  },
};
